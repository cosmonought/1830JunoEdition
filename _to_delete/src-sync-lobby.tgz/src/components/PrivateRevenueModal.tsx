// frontend/src/components/PrivateRevenueModal.tsx
//
// The private companies pay, and the table watches it happen.
//
// ==================================================================
//  DESIGN NOTE 1049: THE PHASE GETS A SURFACE THAT STOPS THE ROUND
// ==================================================================
//
// ASKED: "in the physical game, the PC payouts is a separate phase prior to any corporation acting. All
// players receive their PC income at that time, and I think the current version has minimized or obscured
// that process."
//
// AND THAT IS A FIDELITY ARGUMENT, NOT A VISIBILITY ONE, which is why #1047's answer -- a toast that waits to
// be dismissed -- was only ever going to be a near miss. A toast in the corner is ambient by construction:
// #1016 put it there for the stated reason that it "arrives when a round opens, unbidden", which is the exact
// register a phase must NOT be in. The information was legible and the ceremony was missing.
//
// #1047 ARGUED AGAINST THIS MODAL AND THE ARGUMENT IS NOW WITHDRAWN, in place rather than deleted, because
// half of it was right and stays true. It said: "a recurring modal for the least surprising event in the game
// would spend the interruption budget where it buys least, and would train players to dismiss the fleet-loss
// modal, where dismissing without reading costs a turn."
//   THE PREMISE WENT FIRST. That note leaned on #1032 -- "modals kept firing at the start of basically every
//   operating round" -- and the report behind it was then clarified: "the reason the modals happening every
//   Operating Round was annoying is that the information they were displaying was irrelevant/old." The
//   complaint was staleness, and #1032 fixed staleness. A modal whose content is always current and always
//   about money that just moved is not the thing that was annoying.
//   THE STACKING COST WAS PRICED RATHER THAN DISMISSED: "there aren't any Rust/Train Limit events in the first
//   two phases, so PC payouts won't be competing with anything. Once players hit phase 4, they might then get
//   hit with two modals in a row on one OR ... but two modals carrying meaningful information does not seem so
//   overwhelming, and one is for players, the other is for the corporation."
//   WHAT SURVIVES IS THE DESENSITISATION RISK, and it is answered by SEQUENCE rather than by absence -- see
//   `App.tsx` #1049a. This modal is shown FIRST and the fleet-loss modal is withheld until it is gone, so the
//   two never appear as an undifferentiated stack of things to click through. That ordering is also the
//   physical one: everybody collects, and then the first corporation acts.
//
// THERE IS NO SILENCE TOGGLE, and its absence is deliberate enough to be worth a line. `FleetLossModal` #896
// offers one because that notice is a WARNING, and a player who already knows the rule gains nothing from
// being told again. This is not a warning; it is a payment being made to the reader. A phase you can switch
// off is not a phase, and switching it off would put the money back in the feed this note exists to get it
// out of.
//
// ==================================================================
//  DESIGN NOTE 1050: THE SEAT COLOUR GOES WHERE IT CAN CARRY TEXT
// ==================================================================
//
// REPORTED of #1048's 5px accent rule: "I'm not sure about it. You've implemented something like this before
// and we've had to change it because it's far too subtle for human players to notice."
//
// AND THAT IS THE SECOND TIME, WHICH MAKES IT A PATTERN RATHER THAN A MISS. #1048 chose an edge over a ground
// on a measured argument -- seat colours are picked to be distinguishable from each other, not to carry ink --
// and the argument was sound about CONTRAST while being wrong about SALIENCE. A 5px rule on a panel the reader
// is not looking at is a detail you find once you already know to look for it, which is no signal at all.
//
// THE TWO OPTIONS OFFERED WERE the player card's layout ("the player name and color stripe up top, and the
// info below it") and the whole surface in the seat colour with ink adjusted per seat. THE SIZE OBJECTION TO
// THE FIRST -- "the problem with this would be that it makes the toast notification twice as large" -- WAS A
// TOAST OBJECTION AND DIED WITH THE TOAST. A modal already has the room.
//
// SUPERSEDED IN PART BY DESIGN NOTE 1097 -- READ THIS BEFORE RELYING ON THE PARAGRAPH BELOW. That note
// re-cut the three failing seat colours, and against white ink ALL SIX NOW CLEAR 4.5:1 (the weakest is Ochre
// `#847400` at 4.69:1). The measurement this decision rested on no longer says what it said.
//
// THE DECISION IS LEFT STANDING ANYWAY, and deliberately: the stripe was also chosen because a full-surface
// seat colour makes the modal's ground change identity from player to player, which was never a contrast
// argument. But that is now the WHOLE case rather than half of it, so anyone reopening this should reopen it
// on those grounds and not by re-running the numbers below -- which no longer fail.
//
// AND THE MEASUREMENT DECIDES THE REST. Against white ink, three of the six seat colours fall under the 4.5:1
// body-text threshold: Ochre `#a88a3f` at 3.3:1, Teal `#3f8a94` at 4.0:1, Moss `#4f8a5c` at 4.1:1. Colouring
// the whole surface therefore means either darkening every seat's ground or forcing every figure to
// large-bold, both of which change the seat colours into something that is no longer the seat colour. The
// stripe puts the colour on a band that carries ONE short bold name at heading size, where 3:1 is the
// applicable threshold and all six pass -- and `bestContrastTextColor` picks that name's ink per seat rather
// than asserting one colour for six grounds, exactly as `PlayerCards` #606 already does.
//
// SO THIS IS NOT A NEW TREATMENT, WHICH IS THE POINT. It is the player card's own header, on the card surface
// the auction's private companies already use. A reader who has looked at their player card once knows what
// the band means before reading a word of it -- which is #569's whole case for seat colour: "colour in exactly
// one place is decoration; colour meaning the same thing in several places is a language."
//
// See docs/ai_architecture/ui_shell_layout.md, PrivateRevenueModal.tsx #1049.

// Design note #1052: `useEffect` left with the Escape listener -- one exit, and no hook to hold it open.
import React from "react";

import { FONT_SIZE, RADIUS } from "../styles/typography";
import {
  CARD_BORDER,
  CARD_DIVIDER,
  CARD_INK,
  CARD_INK_FAINT,
  CARD_INK_MUTED,
  CARD_INK_POSITIVE,
  CARD_SURFACE,
  CARD_SURFACE_MUTED,
  washedPlayerSurface,
} from "../styles/palette";
// Design note #1050: the same per-seat ink choice the player card's own stripe makes.
import { bestContrastTextColor } from "../styles/corporationLivery";
/* Design note #1290: the chrome scale, so a viewport unit inside it can be divided back out. */
import { useUiScale } from "../utils/useUiScale";
import { privateOrdinal } from "../gameEngine/privateOrdinal";

/** One of the viewer's privates, already formatted. The display shape #984 established, plus #1052's number. */
export interface PrivateRevenueLine {
  /** Design note #1052: the catalog's own number, so this panel numbers a private the way every other one does. */
  privateId: number;
  label: string;
  value: string;
}

/** Another player's round, as one line.
 *
 *  Design note #1049: RESOLVED BY THE SHELL, not by this component. The seat colour needs the roster index and
 *  the name needs the nickname registry, both of which are `App.tsx`'s to know -- handing this component two
 *  resolver callbacks would make it ask questions it has no business asking, and would make it untestable
 *  without a room. It paints what it is given. */
export interface PrivateRevenueOther {
  name: string;
  /** `null` for an address the roster cannot place, which is #232's answer rather than a guessed colour. */
  seatColor: string | null;
  total: number;
  /** ==================================================================
   *   DESIGN NOTE 1052: WHERE THIS SEAT NOW STANDS
   *  ==================================================================
   *
   * ASKED: "it might also be useful for the other players' information to show their $before + $payout > $new
   * cash holdings."
   *
   * THE PAYOUT AND THE STANDING, NOT THE FULL MOVEMENT. Three figures on every row, for up to five rows of
   * information the reader is not acting on, is a table rather than a glance -- and the `before` is the one
   * of the three that is a subtraction away. What a player actually tracks across a game is what a rival
   * HOLDS, so the row says what arrived and what it arrived at.
   * `null` WHEN THE STATE DID NOT REPORT IT, and the row then shows the payout alone rather than inventing a
   * balance (#232, and #562's rule that a missing figure and a zero are different facts). */
  cashAfter: number | null;
  /** Design note #1270: the other end of the movement, READ from the pre-payout state for #1052's reason --
   *  the collapsed row prints `$before -> $after` and a subtraction would be right until it was not. */
  cashBefore: number | null;
  /** Design note #1270: this collector's privates and what each paid, for the expanded row. */
  lines: readonly PrivateRevenueLine[];
}

export interface PrivateRevenueModalProps {
  /** `null` renders nothing. Raised only when the VIEWER collected -- see the note below. */
  round: {
    viewerName: string;
    viewerSeatColor: string | null;
    lines: readonly PrivateRevenueLine[];
    total: number;
    /** ==================================================================
     *   DESIGN NOTE 1052: THE MOVEMENT, WHICH IS HOW THIS APP REPORTS MONEY
     *  ==================================================================
     *
     * ASKED: "on payouts, we usually include $before > $after somewhere."
     *
     * AND IT IS THE HOUSE FORM, not a nicety -- #670 settled it for the dividend report and #682 rebuilt the
     * Stock Round's projection around it: money moving is TWO facts, what arrived and where it left you, and
     * they read as a before and an after rather than as one figure. This panel reported only the first.
     *
     * BOTH `null` WHEN THE STATE DID NOT SAY, and the line is then omitted entirely rather than printed with
     * an em dash on one side. A movement is a claim about two numbers; with one of them missing there is no
     * movement to state, and #562's dash is for a missing figure in a column of figures, not for half a
     * sentence. */
    cashBefore: number | null;
    cashAfter: number | null;
    others: readonly PrivateRevenueOther[];
  } | null;
  /** Which Operating Round this is, so the modal names the moment rather than floating free of it. */
  roundLabel: string | null;
  onAcknowledge: () => void;
}

export function PrivateRevenueModal({ round, roundLabel, onAcknowledge }: PrivateRevenueModalProps) {
  const uiScale = useUiScale();
  /* ==================================================================
      DESIGN NOTE 1052: ONE EXIT, AND #1049 ARGUED THE OPPOSITE
     ==================================================================
     #1049 GAVE THIS MODAL ESCAPE AND A BACKDROP CLICK, on the argument that #896's reason for removing both
     from `FleetLossModal` does not apply: "nothing is lost by dismissing this one. The money is already paid
     ... what the modal supplies is the CEREMONY, and ceremony a player wants to skip should be skippable."
     REPORTED FROM PLAYTEST: "clicking anywhere on the screen dismisses the modal: I think it's better to make
     players click the Begin Operations button since an accidental click elsewhere immediately dismisses it."
     AND THE ARGUMENT WAS ABOUT THE WRONG COST. It priced what a player LOSES by dismissing -- correctly,
     nothing -- and never priced how easily they dismiss it BY ACCIDENT. A modal that opens under the cursor
     at the start of every Operating Round will eat a click the player had aimed at the board underneath, and
     the ceremony this panel exists to restore is gone before it has been read. The cost of a mis-click is not
     lost information, it is the whole feature not happening.
     SO IT IS ONE EXIT, the same shape #896 chose for the same practical reason and not for its stated one.
     Escape goes with the backdrop click: it is the less likely accident of the two, but two exits is exactly
     what the report asks to remove, and the footer button carries `autoFocus` so a keyboard player presses
     Enter rather than hunting for it.
     THE EFFECT IS GONE, NOT NEUTERED. A listener that captured Escape and did nothing would leave a reader
     wondering which of the two was intended. */

  if (!round) return null;

  const stripe = round.viewerSeatColor;
  const stripeInk = stripe ? bestContrastTextColor(stripe) : CARD_INK;

  return (
    /* Design note #1052: NO `onClick` ON THE BACKDROP, and the absence is deliberate enough to be worth the
       same comment `FleetLossModal` carries -- every other modal in this app closes on a backdrop click, so a
       later tidy-up would otherwise "restore" it for consistency and reintroduce the mis-click. */
    <div style={styles.backdrop} role="dialog" aria-modal="true" aria-label="Private company payouts">
      <div style={{ ...styles.card, maxHeight: `${84 / uiScale}vh` }}>
        {/* ---- The phase, named ---- */}
        <div style={styles.phaseRow}>
          <span style={styles.phaseName}>Private Company Payouts</span>
          {roundLabel && <span style={styles.phaseRound}>{roundLabel}</span>}
        </div>
        {/* ==================================================================
             DESIGN NOTE 1270: THE RULE LINE IS GONE
            ==================================================================
            #1049 put "Paid from the bank at the start of every Operating Round, before any corporation acts"
            here so the phase would not be "minimized or obscured". RULED (7 September, 4.3b): drop it -- the
            modal appears at the moment the rule fires, which says when it happens better than a sentence
            does. The phase name and the round stamp above still name it. */}

        {/* ---- The viewer's own stripe, borrowed from their player card ---- */}
        {/* Design note #1347: and its paper, washed in the seat colour like every player surface. */}
        <div style={{ ...styles.mine, backgroundColor: washedPlayerSurface(CARD_SURFACE, stripe) }}>
          <header
            style={{
              ...styles.stripe,
              ...(stripe ? { backgroundColor: stripe, color: stripeInk } : styles.stripeUnknown),
            }}
          >
            {/* ==================================================================
                 DESIGN NOTE 1052: THE STRIPE IS IDENTITY AND NOTHING ELSE
                ==================================================================
                IT CARRIED THE TOTAL, and #1049 defended that: "the stripe answers 'how much did I get' at a
                glance and the column closes underneath." REPORTED: "the sum does not need to be listed in the
                player color stripe since it's printed a few lines below that." Which is right, and the
                defence was thin -- four lines apart is not two registers, it is the same number twice.
                AND IT PUTS THE BAND BACK TO WHAT #1050 ARGUED IT WAS FOR. That note's case for the stripe was
                that a reader who has looked at their player card already knows what a coloured band with a
                name means; the player card's header carries no figure either. The figure was my addition to a
                borrowed component, and it is the part that did not belong. */}
            <span style={styles.stripeName}>{round.viewerName}</span>
            {/* ==================================================================
                 DESIGN NOTE 1290: THE MOVEMENT RIDES THE STRIPE, LIKE THE OTHER PLAYERS'
                ==================================================================
                ASKED (8c): "I like how in 'Also collected' the cash consequence is printed on the right on
                the player color stripe... that could be done on the active player's card so there is a fast
                way to scan the effect. Then remove the Cash line altogether, which looks strange anyway
                having two sums below the line." So the stripe carries `$before -> $after` in its own ink,
                and the Cash row under the column is gone -- one movement per player, all in one place.
                (#1052's "the stripe is identity and nothing else" gave way to a better rule: every stripe
                on this panel says the same two things, who and what it came to.) */}
            {round.cashBefore !== null && round.cashAfter !== null && (
              <span style={styles.stripeMovement}>
                ${round.cashBefore} → ${round.cashAfter}
              </span>
            )}
          </header>

          {/* Design note #984's two-column grid, unchanged in substance: names flush left, figures right in
              tabular numerals, because "easily comparable" is a claim about a column of digits. */}
          <div style={styles.lines}>
            {round.lines.map((line) => (
              /* The label is the key: a player cannot hold the same private twice, so it is unique by the
                 rules rather than by construction. */
              <React.Fragment key={line.label}>
                {/* Design note #1052: `${private_id}. ${name}`, the form the Ledger, the player cards, the
                    trade panel, the auction dashboard and the action bar all already use. */}
                <span style={styles.lineLabel}>
                  <span style={styles.lineNumber}>{privateOrdinal(line.privateId)}.</span> {line.label}
                </span>
                <span style={styles.lineValue}>{line.value}</span>
              </React.Fragment>
            ))}
            {round.lines.length > 1 && (
              /* Design note #1047: ONLY WHEN THERE IS SOMETHING TO ADD UP. One private is its own total, and a
                 "Total" row under a single line restates it -- #697's argument against the padded receipt.
                 Design note #1052: THE PARAGRAPH THAT STOOD HERE DEFENDED THE STRIPE'S COPY OF THIS FIGURE and
                 is gone with it -- the total appears once now, at the foot of the column it totals. */
              <>
                <span style={styles.totalLabel}>Total</span>
                <span style={styles.totalValue}>${round.total}</span>
              </>
            )}
            {/* Design note #1290: the Cash row is gone -- the movement is on the stripe above. */}
          </div>
        </div>

        {/* ---- Everybody else, one line each ---- */}
        {round.others.length > 0 && (
          <div style={styles.others}>
            {/* Design note #1049: LABELLED AS THE TABLE'S, so the reader never has to work out whose figures
                these are. #967's objection was to an undifferentiated total; a named block of named rows is
                the answer to it rather than an instance of it. */}
            <span style={styles.othersLabel}>Also collected</span>
            {/* ==================================================================
                 DESIGN NOTE 1270: THE OTHER ROWS ARE STRIPES, AND THEY OPEN
                ==================================================================
                RULED (7 September, 4.3a and 4.3d). THE SWATCH IS GONE: each row is drawn in its player's own
                stripe -- the same band the viewer's card wears above -- with the name in the stripe's ink,
                which is the "names in their player colours" the report asks for without the legibility
                problem #1050 found in tinting a label on a dark ground. Collapsed, a row is the name and the
                cash consequence, nothing else. Expanded, it lists that player's privates and what each paid,
                in the same two-column grid the viewer's own card uses.
                THIS SUPERSEDES THE "FULL CARD PER COLLECTOR" IDEA. The attraction was real -- private
                ownership is otherwise buried at the bottom of the screen -- but full cards would flood the
                modal. An expandable row gets the same information without the clutter, and the collapsed
                state stays scannable. Rows open independently; a `<button>` with `aria-expanded`, so a
                keyboard reader can open one too. */}
            <div style={styles.othersRows}>
              {round.others.map((other) => (
                <OtherCollectorRow key={other.name} other={other} />
              ))}
            </div>
          </div>
        )}

        <div style={styles.footer}>
          <button type="button" style={styles.primaryButton} onClick={onAcknowledge} autoFocus>
            Begin operations
          </button>
        </div>
      </div>
    </div>
  );
}

export default PrivateRevenueModal;

/* Design note #1270: one other collector, folded. Its own component so each row owns its open state. */
function OtherCollectorRow({ other }: { other: PrivateRevenueOther }) {
  const [open, setOpen] = React.useState(false);
  const stripe = other.seatColor;
  const stripeInk = stripe ? bestContrastTextColor(stripe) : CARD_INK;
  /* Design note #1052's `+` survives in the fallback: a payout alone must not read as a balance. */
  const movement =
    other.cashBefore !== null && other.cashAfter !== null
      ? `$${other.cashBefore} → $${other.cashAfter}`
      : other.cashAfter !== null
        ? `→ $${other.cashAfter}`
        : `+$${other.total}`;
  return (
    <div style={{ ...styles.otherCard, backgroundColor: washedPlayerSurface(CARD_SURFACE, stripe) }}>
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((current) => !current)}
        title={open ? "Hide their privates" : "Show their privates and what each paid"}
        style={{
          ...styles.otherRow,
          ...(stripe ? { backgroundColor: stripe, color: stripeInk } : styles.stripeUnknown),
        }}
      >
        <span style={styles.otherChevron} aria-hidden="true">
          {open ? "▾" : "▸"}
        </span>
        <span style={styles.otherName}>{other.name}</span>
        <span style={styles.otherMovement}>{movement}</span>
      </button>
      {open && (
        <div style={styles.lines}>
          {other.lines.map((line) => (
            <React.Fragment key={line.label}>
              <span style={styles.lineLabel}>
                <span style={styles.lineNumber}>{line.privateId}.</span> {line.label}
              </span>
              <span style={styles.lineValue}>{line.value}</span>
            </React.Fragment>
          ))}
          {other.lines.length > 1 && (
            <>
              <span style={styles.totalLabel}>Total</span>
              <span style={styles.totalValue}>+${other.total}</span>
            </>
          )}
        </div>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  backdrop: {
    position: "fixed",
    inset: 0,
    /* ==================================================================
        DESIGN NOTE 1049a: ABOVE THE FLEET-LOSS MODAL, AND THE SEQUENCE IS THE REAL GUARD
       ==================================================================
       `FleetLossModal` sits at 3800 and #896 says it is "above everything -- the turn does not start until it
       is answered." That is still true of the TURN. This is not part of a turn: it is the phase before any
       turn begins, so when both have something to say this one is read first.
       THE Z-INDEX IS NOT WHAT ENFORCES THAT. `App.tsx` withholds the fleet notice entirely while this is
       open, so the two are never mounted together and nothing is stacked behind anything. This value is here
       so that if that suppression is ever lost, the failure is a modal in the wrong order rather than a modal
       invisible underneath another one -- the recoverable direction. */
    zIndex: 3900,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "24px",
    backgroundColor: "rgba(6, 9, 15, 0.82)",
  },
  /* Design note #1048's surviving half: the auction's private-company cards' own surface, shared as a constant
     rather than matched by eye, so this panel reads as the same family of object as the cards these companies
     were bought from. */
  card: {
    width: "min(440px, 100%)",
    /* ==================================================================
        DESIGN NOTE 1290: 84vh INSIDE THE CHROME ZOOM IS NOT 84% OF THE WINDOW
       ==================================================================
       REPORTED (8): "when expanding an 'Also collected' entity, the player's information gets partially
       covered up instead of the entire modal expanding." The card is inside `zoom: UI_SCALE`, and #1144
       measured what that does to a viewport unit: `84vh` resolves to 84% of a viewport that is itself
       scaled, so the card capped at roughly half the window and started SCROLLING the moment a row opened
       -- the viewer's card slid up under the header, which is what "covered" looked like. Divided back out,
       as `CHROME_ZOOM.minHeight` is (#1144), so the cap is the 84% of the window it was written to be. */
    /* Design note #1294: `maxHeight` is written per render from `useUiScale()`. */
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    padding: "16px 18px",
    borderRadius: RADIUS.layer,
    border: `1px solid ${CARD_BORDER}`,
    /* ==================================================================
        DESIGN NOTE 1162: THE GROUND RECEDES; THE CARDS DO NOT RISE
       ==================================================================
       REPORTED: "the modal background uses the exact same color as the player cards inside it, creating a
       flat, unreadable hierarchy."
       LITERALLY THE SAME COLOUR, and not by resemblance: this panel was `CARD_SURFACE` and the player card
       inside it declared no background at all, so it INHERITED the identical `#f2f0eb`. The only thing
       between them was a `CARD_DIVIDER` hairline at 1.13:1 -- a line you can find if you already know it is
       there.
       THE SUGGESTED FIX ASSUMED THE INK LADDER -- "map the cards to a slightly lighter rung on the ink/purple
       ladder" -- and this is a PAPER surface. There is no lighter rung: `CARD_SURFACE` is the top of it, and
       lightening the cards would mean inventing a colour above the lightest one the system has.
       SO THE CONTAINER STEPS DOWN INSTEAD, which is the same relationship reached from the other end and the
       conventional direction for paper: the desk is darker than what lies on it. `CARD_SURFACE_MUTED` is
       already in the ladder for exactly this, so nothing new is introduced.
       MEASURED: the two surfaces separate at 1.20:1, which is a visible step for adjacent large areas without
       becoming two competing brightnesses; `CARD_INK` reads 12.69:1 on the new ground, so the panel's own
       captions and headings keep AA with room to spare (they were 15.28:1). */
    backgroundColor: CARD_SURFACE_MUTED,
    boxShadow: "0 12px 40px rgba(0,0,0,0.6)",
    color: CARD_INK,
    fontFamily: "system-ui, -apple-system, Segoe UI, sans-serif",
  },
  phaseRow: { display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "10px" },
  phaseName: { fontSize: FONT_SIZE.strong, fontWeight: 800, color: CARD_INK },
  phaseRound: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    letterSpacing: "0.06em",
    color: CARD_INK_FAINT,
    flex: "none",
  },
  /* Design note #1270: `phaseCaption` is gone with the rule line it set. */
  /* Design note #1162: the card names its own surface now. Inheriting was the whole fault -- an object that
     does not declare a ground cannot be distinguished from the one it sits on, and it silently followed the
     panel every time that changed. The border steps up from `CARD_DIVIDER` to `CARD_BORDER` to match the
     panel's own edge, and a short shadow does the lifting the colour step starts. */
  mine: {
    display: "flex",
    flexDirection: "column",
    borderRadius: 0, // #1291a: a player surface is square
    border: `1px solid ${CARD_BORDER}`,
    backgroundColor: CARD_SURFACE,
    boxShadow: "0 1px 3px rgba(8, 8, 8, 0.18)",
    overflow: "hidden",
    marginTop: "2px",
  },
  /* Design note #1050: the player card's own header, same padding and same weight, so the two are recognisably
     one object seen twice rather than two designs that resemble each other. */
  stripe: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    padding: "6px 10px",
    minWidth: 0,
  },
  /* No seat colour resolved: the muted paper, never a guessed hue. #232's rule -- absence is not an answer,
     and inventing a seat colour would attach an identity the roster did not give. */
  stripeUnknown: { backgroundColor: CARD_DIVIDER, color: CARD_INK },
  stripeName: {
    fontSize: FONT_SIZE.strong,
    fontWeight: 800,
    letterSpacing: "0.2px",
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    minWidth: 0,
  },
  // Design note #1052: `stripeTotal` is deleted, not emptied -- the stripe carries identity only now, and an
  // unused style is an invitation to put a figure back in the band #1050 cleared for a name.
  lineNumber: { color: CARD_INK_FAINT, fontVariantNumeric: "tabular-nums" },
  lines: {
    display: "grid",
    gridTemplateColumns: "1fr auto",
    columnGap: "14px",
    rowGap: "3px",
    padding: "9px 10px",
    fontSize: FONT_SIZE.small,
  },
  lineLabel: { color: CARD_INK_MUTED, textAlign: "left" },
  lineValue: {
    color: CARD_INK_POSITIVE,
    textAlign: "right",
    /* Design note #1270 stepped this to 600; #1290 keeps every figure on the panel at one size and one
       weight -- "the bolded numbers are harder to read", "keep it all the same size". */
    fontWeight: 600,
    fontVariantNumeric: "tabular-nums",
  },
  totalLabel: {
    color: CARD_INK_MUTED,
    textAlign: "left",
    borderTop: `1px solid ${CARD_DIVIDER}`,
    paddingTop: "4px",
    marginTop: "3px",
  },
  /* ==================================================================
      DESIGN NOTE 1052: THE SUM IS MONEY ARRIVING, SO IT IS GREEN
     ==================================================================
     REPORTED: "the revenue numbers are in green, but the sum is in black."
     AND THE INCONSISTENCY WAS INHERITED RATHER THAN CHOSEN. The dark total came from the toast, where #1030
     had darkened every figure against a cream ground and the rows had no green to be consistent WITH. Carried
     onto a panel whose rows are `CARD_INK_POSITIVE`, it made the one figure that sums the others the only one
     that did not look like income.
     #670's RULE IS THE WHOLE ARGUMENT: green means money, or a thing arriving. A column of green figures with
     a black sum says the sum is a different kind of quantity, which is exactly what it is not. */
  totalValue: {
    color: CARD_INK_POSITIVE,
    textAlign: "right",
    fontWeight: 600, // #1290: one weight for every figure
    fontVariantNumeric: "tabular-nums",
    borderTop: `1px solid ${CARD_DIVIDER}`,
    paddingTop: "4px",
    marginTop: "3px",
  },
  /* Design note #1052: the movement, quieter than the sum above it. The sum is what the phase paid and is the
     figure being checked against the column; this is where it landed, which is context rather than the claim.
     MONOSPACED FOR THE ARROW, matching #738's treatment of the same before/after on the dividend receipt --
     "a pair of figures rather than a sentence" -- so two panels reporting one kind of fact look alike. */
  /* Design note #1290: `cashLabel`/`cashValue` are gone with the Cash row; the movement is `stripeMovement`. */
  stripeMovement: {
    flex: "none",
    fontWeight: 600,
    fontVariantNumeric: "tabular-nums",
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  },
  others: { display: "flex", flexDirection: "column", gap: "5px", marginTop: "2px" },
  othersLabel: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    letterSpacing: "0.06em",
    color: CARD_INK_FAINT,
  },
  othersRows: { display: "flex", flexDirection: "column", gap: "4px" },
  /* Design note #1270: one collector -- a stripe that opens onto their rows. Same paper as `mine`. */
  otherCard: {
    display: "flex",
    flexDirection: "column",
    borderRadius: 0, // #1291a: a player surface is square
    border: `1px solid ${CARD_BORDER}`,
    backgroundColor: CARD_SURFACE,
    overflow: "hidden",
  },
  /* Design note #1270: the row IS the stripe, and it is a button. `font: inherit` and no border so it draws
     as the band and not as a control; the chevron and `aria-expanded` carry the affordance. */
  otherRow: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    padding: "5px 10px",
    font: "inherit",
    fontSize: FONT_SIZE.small,
    border: "none",
    textAlign: "left",
    cursor: "pointer",
    minWidth: 0,
    width: "100%",
  },
  otherChevron: { flex: "none", fontSize: FONT_SIZE.micro, opacity: 0.8 },
  otherName: {
    fontWeight: 800,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    flex: "1 1 auto",
    minWidth: 0,
  },
  /* Design note #1270: the cash consequence, in the stripe's own ink -- the collapsed row's only figure. */
  otherMovement: {
    /* Design note #1290: 600, the same as every other figure. */
    fontWeight: 600,
    fontVariantNumeric: "tabular-nums",
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
    flex: "none",
  },
  footer: { display: "flex", justifyContent: "flex-end", marginTop: "4px" },
  primaryButton: {
    padding: "7px 14px",
    borderRadius: RADIUS.card,
    border: "1px solid #3f7a55",
    backgroundColor: "#1d4030",
    color: "#e6f5ec",
    fontSize: FONT_SIZE.small,
    fontWeight: 700,
    cursor: "pointer",
  },
};
