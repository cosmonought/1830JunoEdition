// frontend/src/utils/gameState.ts
//
// A hand-kept TypeScript mirror of `msg.rs`'s `QueryMsg::GetGameState` response shape, plus the polling
// hooks every dashboard panel shares instead of re-implementing its own query.
//
// Design note #1: hand-kept, not codegen -- there is no schema-derived TS type, so these fields must be
// kept in exact sync with `src/msg.rs` by hand. Same DESIGN GAP as every other contract mirror here.
//
// Design note #2: what this deliberately does NOT expose, because the backend does not either. `state.rs`
// genuinely models hardware/train inventory and route-tracing, but NO `QueryMsg` returns any of it. Every
// panel that would want it renders an honest "not yet exposed by the contract" state.
//
// Design note #4: polling, not a subscription -- CosmWasm has no browser-reachable push mechanism, so each
// hook re-fires on a fixed interval with a monotonic sequence guard that discards a stale response.
//
// Design notes #3/#6/#7 and #352/#379/#526/#544/#553/#656/#662: see `docs/ai_architecture/utils_layer.md`.

// Design note #526: the one printed-limits table.
import { certLimitForPlayers } from "./gameSetup";
import { certificateCardsHeld } from "./doubleCertificate";
import type { OperatingSubPhase } from "./operatingSubPhase";
import type { GameVariants } from "./gameVariants";

/* ------------------------------------------------------------------ */
/* Contract data mirror -- see design note #1                         */
/* ------------------------------------------------------------------ */

/** Hover text for the inline Priority Deal marker. Defined once and shared by every surface that renders
 *  it, so two panels cannot drift into explaining the same indicator two different ways -- which is exactly
 *  what happens when a tooltip string is retyped per call site. */
export const PRIORITY_DEAL_TOOLTIP = "Priority Deal: Starts the next Stock Round.";

export type TileColor = "Yellow" | "Green" | "Brown" | "Gray"; // #1312: Gray only under the Project 18XX+ tile set
/** Pre-Game Waterfall Auction (`waterfall.rs`): every room genesis-starts here, before `"StockRound"` is
 *  ever reachable. Mirrors `state.rs`'s `RoundType` exactly. */
/** Design note #898: `GameEnd` is a ROUND, and putting it here is what makes the ending survive a replay.
 *  The game's end was previously a derivation in the shell -- "is the bank at zero right now" -- which had no
 *  way to express "and the current set finishes first", and no way to be undone. A terminal round type is a
 *  fact the log produces, so every client reaches it at the same action. */
export type RoundType = "WaterfallAuction" | "StockRound" | "OperatingRound" | "GameEnd";

export interface PlayerCashEntry {
  player: string;
  cash_vgp: string;
}

/** Omitted entirely from `PublicCompanyState.player_holdings` for any
 *  player holding exactly 0% -- mirrors `src/msg.rs`'s own doc comment on
 *  `PlayerShareEntry`. */
export interface PlayerShareEntry {
  player: string;
  percentage: number;
}

export interface PublicCompanyState {
  company_id: number;
  ticker: string;
  is_floated: boolean;
  treasury: string;
  total_shares_issued: number;
  par_value: string | null;
  /** Total revenue this corporation's trains earned on their most recent run. Written on EVERY run, paid out
   *  or withheld alike, and reset to zero by a run that found no legal route -- so it always reads as "what it
   *  earned last time", never a stale high-water mark.
   *  Optional because a contract predating the field returns no key, and `undefined` must stay distinguishable
   *  from a real `"0"`: the first means "this build cannot tell you", the second "it earned nothing". */
  last_route_revenue?: string;
  /* ==================================================================
      DESIGN NOTE 941: THE PRINTED SUM, KEPT BECAUSE THE ROLL IS ON THE TOTAL
     ==================================================================
     RULED: one die per corporation's turn, "applied to the total aggregated printed revenue of all trains
     combined".
     WHICH THE ARM CANNOT DO FROM `last_route_revenue` ALONE. That field holds the MODIFIED figure, and the
     modification is lossy -- #938 rounds to the nearest ten, so $77 and $80 and $84 all become $80 and no
     amount of arithmetic recovers the printed total from it. A turn's second train therefore has nothing to
     add to.
     SO THE RAW SUM IS KEPT BESIDE IT. Each `RunManualRoute` adds this train's printed value here, then
     recomputes `last_route_revenue` as the turn's one roll applied to the WHOLE of it. That makes every
     dispatch produce the correct aggregate for the trains run so far, with no train needing to know whether
     it is the last -- which is the only way this works over a loop the reducer cannot see the end of.
     OPTIONAL, AND #232'S RULE APPLIES: `undefined` means "this build does not report it", never "zero".
     Turn-scoped, and cleared beside `last_route_revenue` by #777's turn-change rule. */
  printed_route_revenue?: string;
  /** ==================================================================
   *   DESIGN NOTE 1028: THE FIGURE THAT OUTLIVES THE TURN
   *  ==================================================================
   *
   * REPORTED: "corporations are displaying 'Last Run --' instead of their previous route value", and then,
   * decisively: "all corporation cards on the Stock tab have 'Last Run --' during an Operating Round ... it
   * was only printing the Last Run value of the last corporation to run."
   *
   * THAT SECOND SENTENCE IS THE WHOLE DIAGNOSIS. `last_route_revenue` is TURN-SCOPED and #777 clears it on
   * every turn change -- correctly, because leaving it would make the next turn's die apply to last turn's
   * routes. So the only corporation whose figure survives is the one currently operating, and every card that
   * has already run this round reads zero. The Stock tab was rendering the field faithfully; the field simply
   * does not mean what "Last Run" means.
   *
   * SO THIS ONE IS NOT CLEARED, EVER. It is written at the same moment #777 zeroes its turn-scoped sibling --
   * the figure being wiped is precisely the completed run worth remembering -- and it is per corporation, so
   * eight cards carry eight answers rather than sharing one.
   *
   * THE VARIANT-ADJUSTED FIGURE, not the printed one. `last_route_revenue` holds what the corporation was
   * actually paid (#903 applies the die there), and "Last Run" is a claim about money. Copying the printed
   * total instead would put a number on the card that nobody ever received.
   *
   * OPTIONAL, AND #232'S RULE APPLIES: `undefined` means "this build does not report it", never "$0". A
   * corporation that has genuinely never run is `undefined` here and reads as "--", which is the honest
   * rendering and the one the panel already had. */
  last_completed_run_revenue?: string;
  /** ==================================================================
   *   DESIGN NOTE 1031: WHAT EACH TRAIN EARNED, FOR THE PEOPLE NOT DRIVING
   *  ==================================================================
   *
   * REQUESTED (Batch 33 item 7): rival train chips should show revenue. Watchers could see WHICH trains the
   * acting corporation was running -- the roster is derived from this state, so every client agrees on it --
   * but not what any of them earned.
   *
   * PRESENCE ALONE COULD NOT ANSWER IT. `routeValues` is the president's live scratch: published while they
   * draft, gone when the turn moves on, and absent entirely for a watcher who joins late or reloads. It is
   * the right channel for a figure that is still changing and the wrong one for a figure that is settled.
   *
   * SO THE SETTLED FIGURE LIVES HERE, in the log-replayed state every client rebuilds identically. The two
   * are not redundant: presence answers "what is the president looking at right now", this answers "what did
   * that train earn", and the chip prefers the first while it exists.
   *
   * PRINTED VALUES, NOT ADJUSTED ONES, and that is a rules constraint rather than a convenience. #941 rules
   * the Unpredictable Revenue die is rolled ONCE per corporation turn and applied to the aggregate, so no
   * train has an adjusted figure of its own. Splitting the adjusted total back across trains would require an
   * apportionment 1830 does not define, and #938's rounding is lossy besides -- the per-train shares would
   * not re-sum to the figure the treasury actually received. The corporation-level fields remain the
   * authority on money; this is the authority on which train ran where.
   *
   * `train_index` IS THE FLEET SLOT (#1031 on the payload), because a model cannot identify a train when a
   * corporation owns two of the same one.
   *
   * OPTIONAL, AND #232'S RULE APPLIES: `undefined` means "this log does not say", never "the trains earned
   * nothing" -- which is exactly the case the chip's `priceRoute` fallback still exists to cover. */
  last_run_breakdown?: ReadonlyArray<{
    train_index: number;
    model: string;
    /** `Uint128` on the wire, so a string here too -- the printed revenue of this train's route. */
    printed_revenue: string;
  }>;
  president: string | null;
  ipo_pool_percentage: number;
  bank_pool_percentage: number;
  player_holdings: PlayerShareEntry[];
  /** Station Tokens (`hexmap.rs` module doc comment #23): this company's
   *  preprinted home hex label (e.g. `"H12"`), or `null` for the one core
   *  company with none assigned on this custom board (NNH). Mirrors
   *  `msg.rs::PublicCompanyState.home_hex_label` exactly. */
  home_hex_label: string | null;
  /** `(q, r)` pairs, home hex first (if granted, via `grant_home_station_token`
   *  at float) -- mirrors `msg.rs::PublicCompanyState.station_token_hexes`
   *  exactly. Empty before this company floats. */
  station_token_hexes: Array<[number, number]>;
  /* Design note #560: A HEX IS NOT A CITY. `station_token_hexes` is `(q, r)` and cannot express which of a
     two-city hex holds a token -- ERIE's home, New York and every OO tile carry two -- so the renderer falls
     back to a heuristic, and the heuristic picks the first slot every time for every corporation.
     So the answer the player gave is recorded. `hexContractTypes.ts` has declared this field since #134 and
     the renderer already PREFERS it; nothing on this side ever wrote it, so the preference never had anything
     to prefer.
     OPTIONAL, with three distinguishable states: absent means "this chain predates G-12, use the heuristic";
     an entry means "this slot, definitively"; a hex in `station_token_hexes` with no entry means the same as
     absent for that token. What it must never mean is "no token" -- which is why the two arrays are written
     together and never one without the other. */
  station_tokens?: Array<[number, number, number]> | null;
  /** This company's total Station Token limit, home token included -- see
   *  `hexmap::station_token_limit`. Mirrors `msg.rs::PublicCompanyState.
   *  station_token_limit` exactly. */
  station_token_limit: number;
  /** Design note #1323: Kanawha Licences held (Level Playing Field). Non-transferable, so nothing moves them;
   *  absent means none. A licence is what lets this corporation's routes and network cross Coal River (L8). */
  kanawha_licenses?: number;
  /** Design note #1324: WHERE THE 20% STANDARD CERTIFICATE IS, for the two corporations that have one (ERIE
   *  and N&W under the Level Playing Field). `"Ipo"`, `"Bank"` or a player address. Absent means the
   *  corporation has no such certificate, which is every corporation in every other game. Holdings stay
   *  percentages; this is the one extra fact the percentage cannot carry -- which 20% of a holder's stake is
   *  one card rather than two. */
  double_certificate?: { at: string } | null;
  /** Audit G-15c: the MODEL of every train this corporation owns, e.g. `["2", "2", "4"]` -- duplicates are
   *  meaningful. OPTIONAL, and the optionality carries meaning the UI must respect: `undefined` means a
   *  contract predating the field, i.e. UNKNOWN, not "owns nothing". Conflating the two would grey out every
   *  train on every corporation against an older chain and make trading look broken rather than unsupported. */
  owned_trains?: string[] | null;
  /** Design note #903: how many trains this corporation has already run THIS turn. It exists to give each
   *  train its own die under Unpredictable Revenue -- two 4-trains are two runs and may roll differently, and
   *  keying the roll by train MODEL would hand both the same face.
   *  Turn-scoped, and cleared beside `last_route_revenue` by the same turn-change rule (#777). */
  routes_run_this_turn?: number;
  /** Design note #906: trains under Gentle Rust that are living on borrowed time.
   *
   *  NOT IN `owned_trains`, and that is the whole mechanism: every surface that counts a corporation's trains
   *  counts that array, so moving a doomed train here is what implements the ruling that a pending-rust train
   *  occupies no train-limit slot -- without a single one of those surfaces learning a new rule.
   *  They still RUN. `settleRoundTransitions` clears them at the end of that corporation's next Operating
   *  Round turn (#906a), which is after its revenue has been recorded. */
  pending_rust_trains?: readonly string[];
  /** ==================================================================
   *   DESIGN NOTE 1046: THE CORPORATION THE SIGN MARKED
   *  ==================================================================
   *
   * RULED: "Flag the specific corporation with a tracker (e.g. `hasYellowSign`)."
   *
   * A REAL STATE FIELD THIS TIME, and #1044 said the opposite for a reason that has now expired. While the
   * Easter egg was cosmetic, deriving the mark from the Activity Log was right: nothing was stored, and every
   * client agreed because every client replays the same log. The mark now DELETES A TRAIN AND MOVES MONEY, so
   * it is board state -- and board state in this app is written by the reducer from a replayed action, or it
   * is one browser's private opinion.
   * SET BY THE REDUCER, CLEARED BY THE REDUCER, and never written from the shell. */
  has_yellow_sign?: boolean;
  /** ==================================================================
   *   DESIGN NOTE 1046: TRAINS THE BANK NEVER SOLD
   *  ==================================================================
   *
   * RULED of the Stage 2 gift: "it does not deplete the bank's supply ... and it bypasses train limit checks
   * until the end of the Operating Round."
   *
   * A MULTISET BESIDE `owned_trains`, exactly like `pending_rust_trains`, and for the same reason: the train
   * IS in the fleet -- it draws a chip, it can be sold, it runs from next turn -- and one fact about it is
   * different. A separate array would be a second roster to fall out of step with the first (#979's lesson,
   * which cost two batches).
   * EMPTIED AT THE OPERATING ROUND BOUNDARY, which is what "until the end of the Operating Round" means: the
   * exemption expires, the train becomes ordinary, and a corporation left over the limit discards down.
   *
   * OPTIONAL, AND #232'S RULE APPLIES: `undefined` is "this build does not report it", never "there are
   * none" -- and a standard game never has one. */
  ghost_trains?: readonly string[];
  /** ==================================================================
   *   DESIGN NOTE 1089: THE IDENTITY OUTLIVES THE EXEMPTION
   *  ==================================================================
   *
   * A THIRD LIST BESIDE `pending_rust_trains` AND `ghost_trains`, and the reason is the one #1046 already gave
   * for splitting the first two: THEY EXPIRE ON DIFFERENT CLOCKS.
   *
   *   `ghost_trains`     "occupies no train-limit slot", emptied at the END OF THE OPERATING ROUND.
   *   `carcosan_trains`  "this is the gold-trimmed train", emptied when the DOOM CLOCK fires -- a full OR set
   *                      later, and often several rounds after the exemption has gone.
   *
   * REUSING `ghost_trains` FOR BOTH WAS THE FIRST DRAFT AND IT IS WRONG BY A ROUND. The chip icon (#1088) is
   * drawn from this mark, so a train that had merely stopped being limit-exempt would have lost its Yellow
   * Sign while still being the cursed train -- and the doom clock would have had nothing left to point at.
   * The bug is invisible in the OR the gift arrives and appears in the next one, which is the worst shape.
   *
   * A MULTISET, like both of its neighbours: a corporation that already owned a 5 and is gifted one holds two
   * identical models and exactly one of them is gold-trimmed. */
  carcosan_trains?: readonly string[];
  /** ==================================================================
   *   DESIGN NOTE 1089: THE CURSE IS ON THE COMPANY, NOT ONLY ON THE TRAIN
   *  ==================================================================
   *
   * RULED: "Apply an `isCarcosan` boolean flag to the Corporation state, rather than just the Train state ...
   * The only way a corporation loses the flag is by successfully transferring the Carcosa train to another
   * company ... If the Carcosa train rusts while owned, the corporation remains permanently cursed."
   *
   * AND THE REASON IS AN EDGE CASE THAT WOULD HAVE KILLED THE END-GAME EGG: the train rusts, `carcosan_trains`
   * empties, and a scoreboard keyed on holding the train would find nobody to name. The curse has to be a
   * fact about the corporation that survives the object that caused it.
   *
   * SET WITH THE GIFT AND CLEARED ONLY BY A TRANSFER, which makes it a one-way door for everybody except the
   * corporation willing to pay the Blood Price -- the whole of what makes that trade a decision. */
  is_carcosan?: boolean;
  /** The OR set at whose conclusion this corporation's Carcosan train disappears.
   *
   *  Design note #1089: A STORED NUMBER RATHER THAN A LOG SCAN, unlike the Yellow Sign's own state (#1044).
   *  That one is read from the log because it is a fact about what the GAME has seen and every client must
   *  agree; this is a fact about one corporation that the reducer writes deterministically while replaying,
   *  so every client computes it identically without parsing sentences for a date.
   *  `undefined` MEANS THE CLOCK HAS NOT STARTED -- a gifted 5 or 6 waits for the first D-train. */
  carcosan_doom_after_macro_round?: number;
}

export interface PrivateCompanyState {
  private_id: number;
  name: string;
  cost: string;
  revenue_per_or: string;
  owner: string | null;
  /** Phase-Gated Corporate Purchase Protocol (`trading.rs` module doc
   *  comment #17): the `company_id` this private is owned by, if a
   *  corporation bought it -- mutually exclusive with `owner`. Mirrors
   *  `msg.rs::PrivateCompanyState.owner_protocol_id` exactly. */
  owner_protocol_id: number | null;
  /** Design note #1340: what the auction SETTLED this private at -- the face value on a buy-lowest, the
   *  winning bid on a contest, `0` when it was marked down to nothing. Written by the reducer on the win and
   *  absent until then; `cost` stays the printed figure (#303). Sandbox-only, like `market_positions`. */
  settled_price?: number;
  /** Whether this private has been permanently closed (B&O Special Closure
   *  or Phase 5 Private Closure -- `hardware.rs` module doc comments
   *  #11/#12). A closed private can never be bought or sold again. Mirrors
   *  `msg.rs::PrivateCompanyState.closed` exactly. */
  closed: boolean;
}

/** A corporation's standing offer for a private company -- design note #662. Snake_case to match everything
 *  else on `GameStateResponse` even though no contract sends it: a reader scanning this object should not
 *  have to work out which fields came off the wire from their casing. */
export interface PrivatePurchaseOffer {
  private_id: number;
  /** Carried, not re-derived, so every client's prompt names what the buyer
   *  was looking at. */
  private_name: string;
  /** The wallet whose consent is required. */
  owner: string;
  buyer_protocol_id: number;
  buyer_ticker: string;
  price: number;
  /** Design note #1247: the owner said yes and the purchase is OWED. Set by the reducer's `AnswerPrivatePurchase`
   *  arm on an accept; cleared -- with the whole offer -- by the `BuyPrivateCompany` that settles it, which
   *  `nextDerivedAction` generates from this flag. Absent means "awaiting an answer", as it always did. */
  /** Design note #1597 (Batch 7.4, R74-B): WHICH offer this is -- its instance id, `offer_serial`'s value at the
   *  moment the proposal arm wrote it. Two later offers between the same parties for the same asset at the same
   *  price are two instances; the derived settlement is keyed on this and nothing else. Absent on an offer a
   *  fixture wrote by hand (`nextDerivedAction` keys such an offer on its transaction instead). */
  instance?: number;
  accepted?: true;
  /** Design note #1541: a SELLER-initiated offer made to fund a forced train purchase (rulebook 6.6.3). The
   *  direction is reversed -- the owner offered, and the BUYING corporation's president answers with
   *  `AnswerFundingPrivateOffer`; acceptance settles the transfer in the same arm. Absent on every ordinary
   *  (corporation-initiated) offer. */
  funding?: true;
}

/** Design note #701: the train-trade offer awaiting the seller president's answer. The train equivalent of
 *  `PrivatePurchaseOffer`, and here for the same reason: a proposal is something the OTHER player has to see,
 *  and the sandbox's shared state is the only thing both clients hold.
 *  Sandbox-only. Online the contract keeps a real offer register and `GetTrainOffers` reaches the counterparty
 *  already -- which is why this went unnoticed for so long. Both paths render the same prompt, and only one of
 *  them had a register behind it. */
export interface TrainPurchaseOffer {
  seller_protocol_id: number;
  seller_ticker: string;
  seller_president: string | null;
  buyer_protocol_id: number;
  buyer_ticker: string;
  model_type: string;
  /** String, matching the contract's `Uint128` -- see `ProposeTrainPurchaseMsg`. */
  price: string;
  /** Design note #1597 (Batch 7.4, R74-B): WHICH offer this is -- its instance id, `offer_serial`'s value at the
   *  moment the proposal arm wrote it. Two later offers between the same parties for the same asset at the same
   *  price are two instances; the derived settlement is keyed on this and nothing else. Absent on an offer a
   *  fixture wrote by hand (`nextDerivedAction` keys such an offer on its transaction instead). */
  instance?: number;
  /** Design note #1247: the seller's president said yes and the trade is OWED -- see `PrivatePurchaseOffer`. */
  accepted?: true;
}

/** Design note #1593 (Batch 7.4): the player <-> player private-company sale awaiting the counterparty's answer
 *  (rulebook 3.1; ruled Q12 / D-24). A THIRD FIELD beside the two corporation-buyer offers rather than a
 *  discriminator on `PrivatePurchaseOffer`, whose shape is a corporation buyer. Either party may propose on
 *  their own Stock Round turn; `proposer` records which, so the OTHER party is the one who answers and only
 *  the proposer may withdraw. Settlement is the answer arm's (`accept: true`), so there is no `accepted` flag
 *  here: an accepted trade is a settled one. Sandbox-only, like its two siblings. */
export interface PrivateTradeOffer {
  private_id: number;
  /** Carried for every client's prompt, exactly as `PrivatePurchaseOffer.private_name` is. */
  private_name: string;
  seller: string;
  buyer: string;
  /** Whole VGP, $0 allowed ("any mutually agreed price"). */
  price: number;
  /** Design note #1597 (Batch 7.4, R74-B): WHICH offer this is -- its instance id, `offer_serial`'s value at the
   *  moment the proposal arm wrote it. Two later offers between the same parties for the same asset at the same
   *  price are two instances; the derived settlement is keyed on this and nothing else. Absent on an offer a
   *  fixture wrote by hand (`nextDerivedAction` keys such an offer on its transaction instead). */
  instance?: number;
  /** The party who made the offer -- the seller or the buyer. */
  proposer: string;
}

export interface GameStateResponse {
  game_id: number;
  creator: string;
  is_active: boolean;
  total_juno_pool: string;
  virtual_bank_vgp: string;
  virtual_bank_start: string;
  max_players: number;
  player_addresses: string[];
  /** Index into `player_addresses` -- whose turn it currently is. Advanced
   *  by `ExecuteMsg::PassTurn`. */
  active_player_index: number;
  /** Real field, but per `state.rs`'s own doc comment currently static `0` for every room -- nothing yet
   *  reassigns it during play on chain. The SANDBOX reassigns it at the end of a Stock Round
   *  (`sandboxSession.ts #353`), which is the rule the contract will apply when it implements its own half. */
  priority_deal_index: number;
  /* SANDBOX-ONLY FIELDS. Neither comes off the wire: `GetGameState` does not report them and a live room
     leaves them `undefined`, which every reader treats as "not applicable" rather than as a value. They live
     on the state object rather than in module scope because the undo snapshot copies the state and cannot
     copy a closure (#352). Marked optional rather than added to the mirror, so nothing here can be mistaken
     for a field the chain will one day send.
     Design note #352: the seat that last bought or sold this Stock Round, for the Priority Deal handover. */
  last_trader_index?: number | null;
  /** Design note #353: set for one dispatch when a full round of passes
   *  closed the Stock Round, so the shell can log the handover and move to
   *  the Operating Round. Consumed and cleared by the caller. */
  stock_round_just_ended?: boolean;
  /** Design note #411: the mirror of `stock_round_just_ended` for the other
   *  direction -- set for one dispatch when the last corporation in the
   *  operating queue finished its turn and the macro round closed. Consumed
   *  and cleared by the caller, which owns the log and the tab. */
  operating_round_just_ended?: boolean;
  /** Design note #899: the room is closed and the payout has been dispatched.
   *
   *  IN STATE RATHER THAN IN THE SHELL because it is what makes `CloseRoom` idempotent: every client runs its
   *  own auto-close timer and every one of them dispatches, so the reducer has to be able to tell the first
   *  from the fourth. A flag the shell held would make each client's answer its own.
   *  NOT `?? false` ANYWHERE IT IS WRITTEN BACK -- #232's rule and #897's correction. Absent means an older
   *  log that predates room closure, which is a different thing from a room that is open. */
  room_closed?: boolean;
  /** Design note #902: the house rules this game is being played under, recorded at setup so a replay uses
   *  the same ones. Absent on every game logged before variants existed, which `resolveVariants` reads as the
   *  standard game. */
  variants?: Partial<GameVariants>;
  /** Design note #904a: whether the private company auction has concluded.
   *
   *  Written by the one transition that closes it (`OpenStockRound`), so it is true from the first Stock
   *  Round of a standard game and stays false through SR1 and SR2 of a delayed-auction game. It is what the
   *  B&O lock asks -- see `boIsLocked` for why the auction and not the round number.
   *  ABSENT MEANS COMPLETE, for logs written before the field existed: those are standard games whose auction
   *  did happen, and reading absence as "incomplete" would lock the B&O across every historical replay. */
  private_auction_complete?: boolean;
  /** Design note #656: WHICH STEP of its turn the acting corporation is on. This was React state in `App.tsx`
   *  re-seeded by an effect keyed on the era and phase tier -- so buying a train that advanced the phase sent
   *  the buying corporation back to the top of its own turn. A cursor held outside the reducer is also not in
   *  the action log, so a client that joined or undid mid-turn rebuilt every treasury exactly and then showed
   *  whichever step its own effect seeded. Same split #642 found one layer down.
   *  Sandbox-only: a live room leaves it `undefined` because the CONTRACT owns the cursor there (`or_phase`,
   *  and `WrongOperatingSubPhase` when a client disagrees). Readers treat `undefined` as "ask the opening
   *  rule", never as a step. */
  operating_sub_phase?: OperatingSubPhase;
  /** Design note #662: the private-company purchase awaiting its owner's answer. On the STATE rather than in
   *  a React ref because a proposal is something the other player has to see, and the sandbox's shared state
   *  is the only thing both clients hold -- it was a ref in `App.tsx`, so the seller was never asked and the
   *  buyer answered their own offer.
   *  Sandbox-only: the contract's `BuyPrivateCompany` is single-party (it reads `private.owner` and never
   *  consults them), so there is no chain-side offer for this to mirror. */
  private_purchase_offer?: PrivatePurchaseOffer | null;
  /** Design note #701: the train-trade offer awaiting its seller's answer. Sandbox-only, for the reason on
   *  `TrainPurchaseOffer` -- online this lives in the contract's offer register. */
  train_purchase_offer?: TrainPurchaseOffer | null;
  /** Design note #1593 (Batch 7.4): the player <-> player private-company trade awaiting its answer. The third
   *  ordinary offer field; at most one of the three (and never beside a funding offer) stands at a time --
   *  `pendingOfferHold.ts` is the one reader of "is an offer standing". Absent on every log written before
   *  Batch 7.4 (#232). */
  private_trade_offer?: PrivateTradeOffer | null;
  /** ==================================================================
   *   DESIGN NOTE 1597: THE OFFER SERIAL -- ONE IDENTITY PER ORDINARY OFFER LIFECYCLE (Batch 7.4, R74-B)
   *  ==================================================================
   *  The instance id of the most recent ordinary offer this board has carried (private purchase, train
   *  purchase or player trade); absent means none has been proposed (#232). Written by the three proposal
   *  arms and by nothing else: each successful proposal takes `(offer_serial ?? 0) + 1`, records it as the
   *  offer's `instance` and stores it here. NEVER decremented, never cleared -- not by an answer, a rescission,
   *  a settlement, a turn end or a round end -- so the sequence is strictly monotonic over the log and a
   *  completed offer's number is never reused.
   *  WHY A COUNTER AND NOT A TUPLE. The derived settlement (`nextDerivedAction`, #1247) is de-duplicated by a
   *  key; the key used to name a tuple of board facts (seller, model, buyer, the buyer's fleet size), and
   *  Opus's R74-B matrix proved five legal sequences in which rust, an intercorporate sale or a depot purchase
   *  bring the tuple back to a value already settled -- the second, distinct, legal offer then derived nothing
   *  and the hold froze the table. A tuple of game properties can recur; a lifecycle serial cannot. Adding the
   *  price would not have helped (R74-B.2 is a same-price collision).
   *  LOG-DERIVED, LIKE EVERY OTHER FIELD: a replay assigns the same numbers in the same order, `RevertTo`
   *  rebuilds the board without the reverted offers and their numbers, and a restart recomputes the guard
   *  from the surviving log (#1208). No UUID, no clock, no server-side sequence. The Batch-5 FUNDING offer
   *  (#1541) is not an ordinary offer, is never derived, and takes no number. */
  offer_serial?: number;
  /** Design note #723: every hex whose TERRAIN FEE has already been charged, as `"q,r"` keys.
   *
   *  In state rather than derived from the tile grid, because the grid is a separate atom that this reducer
   *  does not own and cannot replay. During an Undo rebuild the log is replayed while `mapGrid` is a React
   *  value captured at render, so asking it "does this hex have a tile" answers about a board from some other
   *  moment -- charging every hex again, or nothing at all, depending on where the render landed. A fact the
   *  reducer must decide has to travel in the state the reducer replays.
   *
   *  A hex appears here IF AND ONLY IF its fee has been paid, so a lay on clear ground adds nothing: the
   *  question is "has this ground been paid for", not "has anything been built here". */
  terrain_fees_paid?: readonly string[];
  /** Design note #744: per player, the corporations they have SOLD in the current Stock Round -- and may
   *  therefore not buy back until the next one.
   *
   *  IN STATE FOR #723'S REASON: the Undo path replays the whole log, so a rule about "what has happened this
   *  round" has to be a function of the log rather than of anything a client remembers. Cleared when a Stock
   *  Round opens, which is the only event that ends the lockout. */
  sold_this_round?: Readonly<Record<string, readonly number[]>>;
  /** Design note #745: has the seat now acting already DONE something this turn? True after a sale, false
   *  again the moment the seat moves.
   *
   *  IT IS A SEPARATE FIELD FROM `sold_this_round` BECAUSE THE TWO HAVE DIFFERENT LIVES. #744's record lasts
   *  the whole round on purpose -- that is what makes the buy-back lockout a lockout. This one must expire at
   *  the end of the turn that set it, or a player who sold on their first turn would never be able to pass at
   *  all: every later Pass would be read as "they acted", and the Stock Round would not end.
   *
   *  IN STATE FOR #723'S REASON, like #744's: Undo replays the log, so anything the reducer must decide
   *  travels in the state the reducer replays. */
  turn_action_taken?: boolean;
  /** ==================================================================
   *   DESIGN NOTE 1183: THE TURN KEY A RUN ALREADY CARRIES
   *  ==================================================================
   *
   * FROM THE EXPORTED LOG, indices 318 and 319: the same corporation ran the same two routes twice, six
   * seconds apart, both stamped `revenue_turn: "7.1.7"` and each with its own `revenue_seed`. The revenue
   * landed twice and index 320 declared dividends on $540 -- exactly twice the $270 those routes earn.
   *
   * THE MESSAGE ALREADY IDENTIFIES ITS OWN TURN. `revenue_turn` is round.cycle.corporation, minted by
   * `turnSeedKey` so an undone run can find its earlier roll (#1051) -- so two runs bearing one key are, by
   * construction, one turn's run sent twice. `seedAlreadyRolled` was supposed to notice, and could not: it
   * searches the RAW log, which in a room does not contain the first run until the snapshot returns. The
   * second click beat it, took a fresh seed, and doubled the money.
   *
   * SO THE BOARD REMEMBERS THE LAST KEY IT APPLIED. Both sides come out of the log -- the key travels in the
   * message and this field is rebuilt by the replay -- so every client refuses the duplicate identically, and
   * an undo that drops the first run also drops this, which is what lets the legitimate re-dispatch through.
   *
   * SELF-SCOPING, so nothing clears it: a different turn mints a different key. That is why this is a key
   * rather than the counter #1172 needed. */
  last_run_turn_key?: string | null;
  /** Design note #1551 (Batch 6): THE RULES ENGINE THIS BOARD IS A PROGRAM FOR, copied onto the state by the
   *  `SetupGame` arm from the message the server stamped (#1520). Absent on a board dealt from a legacy
   *  (unpinned) log -- #232's "the log does not say" -- which is the one population the legacy
   *  `RunManualRoute` arm still serves; a pinned board refuses that message (`applySandboxActionCore`). */
  rules_engine_version?: number | null;
  /** Design note #1314: TRAINS TRADED IN FOR A DIESEL AND BACK IN THE BANK'S DEPOT (Project 18XX+). RULED:
   *  "the traded-in train is not removed from the game. It must be returned to the Bank's Supply Depot, where
   *  it becomes available for any corporation to purchase at face value (provided it hasn't rusted)." One
   *  entry per train, by model. A returned model rusts in the depot when its tier rusts, exactly as it would
   *  have on a corporation. Absent on every log written before the rule (#232), and the standard game never
   *  writes it. */
  returned_trains?: readonly string[];
  /** ==================================================================
   *   DESIGN NOTE 1172: THE COUNT RULE 4 WAS ALWAYS WAITING FOR
   *  ==================================================================
   *
   * `sharePurchaseBlock` has enforced "one certificate purchase per turn, waived for Brown-zone Bank Pool
   * shares" since #712 -- reading a `boughtThisTurn` parameter that NO CALLER HAS EVER PASSED. It defaults to
   * `0`, so the branch could not fire, and the rule was #712's own reported fault repeated inside #712's own
   * fix: "encoded as PREDICATES and none of them as GATES."
   *
   * A COUNT OF CERTIFICATES, NOT A BOOLEAN, because the Brown allowance is expressed in certificates and
   * arrives as one message with a `quantity`. A flag would answer "have you bought" where the rule asks "how
   * many have you taken".
   *
   * SEPARATE FROM `turn_action_taken` ABOVE, which a SALE also sets: 1830 lets a player sell and then buy in
   * one turn, so a shared flag would refuse the legal half of that.
   *
   * IN STATE FOR #723'S REASON, like the two records above it: Undo replays the log, so anything the reducer
   * must decide travels in the state the reducer replays. */
  bought_this_turn?: number;
  /** ==================================================================
   *   DESIGN NOTE 1570: WHICH CORPORATION THE TURN'S PURCHASE OPENED WITH (Batch 7.2, S7-18)
   *  ==================================================================
   *
   * Rulebook §4.4's Brown-zone allowance is "any number of certificates from the bank pool of ONE
   * corporation". The engine represents that allowance as SEVERAL `BuyStock` messages in one turn (#712/#1172
   * kept `bought_this_turn` as a running certificate count for exactly this), and the multi-message
   * representation is preserved so every stored log keeps replaying -- so the "one corporation" half of the
   * printed rule has nowhere to live but the state.
   *
   * WRITTEN BY THE FIRST PURCHASE OF THE TURN and cleared by all three sites that clear `bought_this_turn`
   * (`advanceSeat`, `recordPass`, `openingStockRoundReset`), because it has exactly that life: it is a fact
   * about the turn now in progress and it dies with the turn.
   *
   * ABSENT IS "NOT SAID" (#232), never "any corporation may continue". A board rebuilt mid-turn from a log
   * written before this field existed carries no continuation rule, which is what keeps a legacy replay
   * replaying rather than refusing a purchase the old engine allowed. */
  bought_this_turn_company?: number;
  /** #1443: the Stock Round turn's stage under Sell-Buy-Sell. Absent is "sell" (the opening stage); `"buy"`
   *  once the player has declined to sell further; the third stage ("sell again") is implied by
   *  `bought_this_turn > 0`. Cleared wherever the seat moves. */
  stock_turn_stage?: "sell" | "buy";
  consecutive_passes: number;
  current_global_era: TileColor;
  /** Operating Round Corporation Turn Queue -- `company_id`s in turn order. */
  active_operating_order: number[];
  active_corporation_index: number;
  current_round_type: RoundType;
  /** Design note #1540: the president whose forced train purchase could not be funded, written by the
   *  reducer in the same transition that moves the round to `GameEnd` (rulebook 6.7: "he goes bankrupt and
   *  the game ends"). The one fact the ended board must carry -- the obligation that proved it is gone with
   *  the round. Absent on every board that ended any other way, and on every board still being played. */
  bankrupt_president?: string;
  /** ==================================================================
   *   DESIGN NOTE 1561: THE BANK BROKE, AND IT STAYS BROKEN (S7-20)
   *  ==================================================================
   *
   * Written by `cashLedger.debitBank` the first time a payout leaves the Bank's balance at or below zero, and
   * cleared by nothing: no receipt, no arm, no settlement. `bankIsBroken` reads it first and falls back to the
   * live balance test only for boards that carry no field -- #232's "the log does not say", which is every
   * fixture and every legacy log written before this batch.
   *
   * Absent means "never broken". `false` is never written: a board either says it broke or says nothing, so
   * the field joins the digest only where the fact exists.
   *
   * IT IS NOT A DATE. #898 established that "the game ends when the first OR SET COMPLETES at or after the
   * break", which needs no `bank_broke_at` and no macro-round comparison -- `settleRoundTransitions` asks at
   * the boundary and this says whether the break has ever happened. `RevertTo` past the breaking payout
   * rebuilds a board without the field, because state is a function of the log (#1026). */
  bank_broken?: true;
  macro_round_number: number;
  sub_round_index: number;
  operating_round_sequence_length: number;
  player_cash: PlayerCashEntry[];
  public_companies: PublicCompanyState[];
  private_companies: PrivateCompanyState[];
  /** ==================================================================
   *   DESIGN NOTE 1196: THE CHART'S POSITIONS COME ONTO THE STATE
   *  ==================================================================
   *
   * PHASE 1 OF THE SERVER MIGRATION, and the fix for the handoff's oldest open root cause (§5a).
   *
   * THE CHART IS TWO THINGS WEARING ONE NAME. Its GEOMETRY -- the price ladder, `cellAt`, the four
   * projections -- is a static board definition, identical in every browser and no more dangerous to inject
   * than `hexTileCatalog`, which `sandboxSession.ts` has imported from `components/` for as long as it has
   * existed. Its POSITIONS are mutable state, and until now every client maintained its own copy in a React
   * ref that no rule could see.
   *
   * THAT IS WHAT MADE TWO BROWSERS DISAGREE. `buildOperatingOrder` filters on floated-with-a-president and
   * sorts on price, column and arrival -- all three read through injected resolvers backed by that per-client
   * ref. Two charts that differ produce two turn orders, which is exactly indices 310/311 of `JUNO-3XD`, and
   * exactly what #1174 and #1182 both tried and failed to paper over from the wrong end.
   *
   * SO THE POSITIONS MOVE HERE, where the reducer writes them and the log determines them. Once the queue
   * sorts on a field of this response, it is a function of the log by construction -- and §5b's "stamp a seat
   * on the log entry" question stops needing an answer, because the cursor stops being a place two clients
   * can differ.
   *
   * OPTIONAL, AND #232'S RULE APPLIES. `undefined` means "this build does not carry positions" -- which is
   * every log written before this note, and the shell until increment 2 -- and the resolvers stay as the
   * fallback for exactly those. It is NOT "the chart is empty"; an empty chart is `{}`.
   *
   * ALREADY REPLAY-SAFE. `enteredAt` is an arrival ORDINAL derived from the marks already present (#646),
   * never a clock, so a replay reproduces the same numbers rather than continuing from wherever a browser's
   * session had reached. The tie-break the operating order depends on needed no redesign to come here. */
  market_positions?: Readonly<Record<number, MarketPositionMark | null>>;
  /** ==================================================================
   *   DESIGN NOTE 1340: THE AUCTION ATOM COMES ONTO THE STATE, AS THE CHART DID
   *  ==================================================================
   *
   * `WaterfallStateResponse` was the last atom the shell and the replay engine still composed by hand: the
   * waterfall reducer RETURNED its charges, its wins and an `allPassed` flag (#261, #334, #337), and two
   * composition layers -- `App.tsx` and `RoomEngine` -- each applied them to the board in the same order,
   * and each was found short at least once (#1192, #1227, #1281). #1196/#1197 ended that arrangement for
   * the chart; this ends it for the auction. The atom rides here, the reducer advances it and settles every
   * consequence inside one call, and a caller holds no rule about auctions at all.
   *
   * OPTIONAL, ON #1196's RULE. `undefined` means "this build does not carry the auction" -- a chain game, or a
   * fixture that never seeded one -- and the reducer then touches no auction. `null` is a seeded game whose
   * auction atom is absent (the scenario has none). */
  waterfall?: WaterfallStateResponse | null;
  /** ==================================================================
   *   DESIGN NOTE 1204: THE PRIVATE POWERS COME OFF THE SHELL TOO
   *  ==================================================================
   *
   * `usedPrivateAbilities` was a `useState<ReadonlySet<string>>` in `App.tsx` -- three keys, `dh-tile`,
   * `dh-token` and `csl-tile` -- and it is the same fault as the market chart one private power over.
   *
   * #1044 STATES THE RULE THIS BREAKS, in its own words: "this app has no server and no mutable game state:
   * every client rebuilds the board by replaying one append-only log, and anything not derivable from that
   * log is a fact one browser knows and the others do not." A player who reloads loses whether the D&H's
   * lay has been spent; a player who joins late never had it. And it is not cosmetic -- `dhPowerState`
   * computes `forfeited = hexBuilt && !layUsed`, so two clients disagreeing about `layUsed` disagree about
   * whether a power still exists.
   *
   * IT ALSO REACHES THE REDUCER. `stationPlacementBlockReason` asks whether the free station is still
   * available, and that answer decides whether the Tokens step is auto-skipped -- so a shell-held flag was
   * feeding a decision that takes a player's turn away.
   *
   * HALF OF IT IS DERIVABLE FROM THE LOG AS IT STANDS. `dh-token` is spent by a `PlaceHomeStation` carrying
   * `kind: "dh"`, which the log already records -- index 115 of `JUNO-3XD` is one. The reducer records that
   * for itself.
   *
   * THE OTHER HALF NEEDS THE MESSAGE TO SAY SO, and this is the interesting part. `dh-tile` and `csl-tile`
   * are spent by laying a tile ON A PARTICULAR HEX -- but a corporation may also lay there NORMALLY, which
   * forfeits the power rather than using it. #817 is the report: "I placed a tile that was not the F16 one,
   * and it seems the DH power was consumed." The hex alone cannot tell the two apart; only the player's
   * intent can, and intent is a CHOICE, which #550 says belongs in the log. So `LayTile` carries an optional
   * `ability_key`, exactly as `PlaceHomeStation` already carries `kind: "dh"`.
   *
   * OPTIONAL, AND #232'S RULE APPLIES: absent means "this build did not say", which is every log written
   * before this note. Such a log cannot answer whether the D&H's lay was its own, and no amount of
   * inspection will make it -- which is the honest reading rather than a heuristic that guesses wrong on
   * #817's exact case. */
  used_private_abilities?: readonly string[];
  /* ==================================================================
      DESIGN NOTE 1323: THE LEVEL PLAYING FIELD'S GAME-WIDE COUNTERS
     ==================================================================
     Three facts that belong to the game rather than to any corporation, all optional per #232 -- absent is
     "this log predates the variant", never zero -- and all written only by reducer arms so a replay rebuilds
     them. `kanawhaLicense.ts` and `levelPlayingField.ts` are their only readers. */
  /** How many of the four purchasable Kanawha Licences the Bank has sold. The JK's free grant is not one. */
  kanawha_licenses_sold?: number;
  /** Whether the JK's one-time free licence has been handed to the first corporation to buy it. */
  jk_license_granted?: boolean;
}

/** One corporation's token on the stock market chart.
 *
 *  DECLARED HERE RATHER THAN IMPORTED, because `sandboxState.ts` imports this module and the edge must stay
 *  one-way. `SandboxMarketMark` is an alias of this, so there is one definition and not two that can drift --
 *  which is #1184's failure mode and has now cost this project time three separate ways. */
export interface MarketPositionMark {
  price: number;
  x: number;
  y: number;
  /** Design note #646: an arrival ORDINAL, not a clock. */
  enteredAt?: number;
}

/** The seat that should be holding the controls right now, given the phase. Two pointers answer "who acts
 *  next" in 1830 and which is correct depends entirely on the round: the Waterfall Auction and Stock Round
 *  are SEAT-driven, so `active_player_index` is the answer directly; Operating Rounds are
 *  CORPORATION-driven, and the seat pointer is not meaningful there and can easily point at a player with
 *  nothing to do.
 *  Returns `null` when the acting seat cannot be resolved. Callers should leave the seat where it is rather
 *  than guess. */
export function actingSeatIndex(state: GameStateResponse): number | null {
  if (state.player_addresses.length === 0) return null;

  if (state.current_round_type === "OperatingRound") {
    const companyId = state.active_operating_order[state.active_corporation_index];
    if (companyId === undefined) return null;
    const company = state.public_companies.find((c) => c.company_id === companyId);
    const president = company?.president;
    if (!president) return null;
    const seat = state.player_addresses.indexOf(president);
    return seat === -1 ? null : seat;
  }

  return state.active_player_index;
}


/* Design note #544: A MINI-AUCTION SUSPENDS THE TURN ORDER. `actingSeatIndex` returns
   `active_player_index` during the auction, and that field is right about the WATERFALL and knows nothing
   about a contest running on top of it -- the contest's cursor lives on a different document, on a
   different atom, fetched by a different query. So the two halves of the screen each read a pointer that
   was correct about a different question, and neither was wrong on its own terms.
   THE SUSPENSION IS THE WHOLE RULE: while a contest is live the main rotation does not advance and nobody
   may take a waterfall action -- the reducer has preserved `waterfall.current_turn` across a contest since
   #338 precisely so it can be resumed untouched, which makes it a STALE pointer for the duration.
   WHY AN ADDRESS AND NOT A SEAT INDEX: a bidder is identified by address, and mapping back only to have
   callers map forward again would add a lookup that can fail to a path that currently cannot.
   `actingSeatIndex` IS LEFT ALONE -- it answers a narrower question, and widening it would thread the
   waterfall document through callers that have no business knowing an auction exists. */
export function actingAddress(
  state: GameStateResponse,
  waterfall: WaterfallStateResponse | null,
): string | null {
  const contest =
    state.current_round_type === "WaterfallAuction" ? waterfall?.mini_auction : null;
  if (contest) return contest.current_turn || null;

  /* ==================================================================
      DESIGN NOTE 1232: DURING THE AUCTION, THE AUCTION SAYS WHOSE TURN IT IS
     ==================================================================
     THE SEAT WAS A MIRROR OF THE AUCTION'S CURSOR, AND THE MIRROR DRIFTED. #544 reads the seat here because
     "that field is right about the WATERFALL" -- which held only while every arm that moved one moved the
     other. A mini-auction pass advanced the seat and not the cursor (`sandboxSession.ts` #1232), and this
     function then named a player the auction was not waiting for. The game locked with a turn indicator
     pointing at somebody whose every click was refused.

     `applySandboxWaterfallAction` ALREADY DECIDES THE ACTOR FROM `waterfall.current_turn`, not from the seat
     and not from the message. So a gate or an authority that reads the seat is judging by a different cursor
     than the one the reducer will apply the action under -- #1174's two-judge problem, inside one process.
     Reading the auction's own cursor here makes the question and the answer come from the same place.

     THE SEAT REMAINS THE FALLBACK, for #232's reason: before the deal `current_turn` is `""` ("matches nobody",
     #542), and a waterfall that is absent or unseated has said nothing about the turn. Both read as "no
     opinion", and the seat -- which the reducer still keeps in step for the ordinary waterfall actions --
     answers as it always did. */
  if (
    state.current_round_type === "WaterfallAuction" &&
    waterfall?.current_turn &&
    /* ONLY A CURSOR THAT NAMES A SEATED PLAYER IS BELIEVED. A room before its deal (#538) has an empty roster
       and must answer `null` -- a bare `""` would equal a spectator's missing address and hand them the turn.
       And an atom whose cursor names somebody the board does not seat is stale or foreign, not authoritative;
       the seat answers as before. */
    state.player_addresses.includes(waterfall.current_turn)
  ) {
    return waterfall.current_turn;
  }

  const seat = actingSeatIndex(state);
  if (seat === null) return null;
  return state.player_addresses[seat] ?? null;
}

/** Whether `address` is shut out of the contest currently running -- a seat at the table who is not one of
 *  its bidders. `false` whenever no mini-auction is live, because there is then nothing to be excluded from.
 *  `ContextualActionBar #545`: states a real fact about the game rather than a visual one -- these players
 *  cannot act, and cannot be acted for, until the contest resolves. */
export function isSidelinedByMiniAuction(
  state: GameStateResponse,
  waterfall: WaterfallStateResponse | null,
  address: string,
): boolean {
  const contest =
    state.current_round_type === "WaterfallAuction" ? waterfall?.mini_auction : null;
  if (!contest) return false;
  return !contest.bidders.includes(address);
}


/** `QueryMsg::PlayerNetWorth`'s response -- mirrors
 *  `msg.rs::PlayerNetWorthResponse` exactly. See design note #6. */
export interface PlayerNetWorthResponse {
  game_id: number;
  player: string;
  cash_vgp: string;
  stock_portfolio_value: string;
  net_worth: string;
}

/* ------------------------------------------------------------------ */
/* Derived helpers -- see design note #3                              */
/* ------------------------------------------------------------------ */

/** EXACT certificate count for `playerAddress`. Renamed from `estimateCertificateCount`, and the "~N"
 *  presentation went with it: the name was inherited from a pass where the president's-certificate rule was
 *  unconfirmed and the count really was a guess. That rule is now confirmed against three independent
 *  sources (design note #3) and every input is queryable exact state. Nothing here approximates anything.
 *  Equivalent to `(total public % / 10) - presidencies held + privates held`: a president's 20% share is a
 *  single physical certificate, so it counts once rather than twice.
 *  The one thing it cannot do is see a certificate the QUERIES do not expose -- but no such certificate
 *  exists in the current schema, so that is a statement about future changes, not present accuracy. */
/** Design note #734: THE ZONE-BLIND COUNT, and it is no longer what any surface displays.
 *
 *  Kept because `presidencyTransfer` reasons about it -- a presidency changing hands moves no percentages, so
 *  a physical-card count is the right instrument for asserting that -- and because `certificateBreakdown`'s
 *  `total` is defined as what this returns.
 *
 *  NOT FOR A LIMIT. A certificate limit is measured against `certificateBreakdown(...).counted`, which knows
 *  about the yellow/orange/brown exemptions (#712). This function does not and never did; the Player Card read
 *  it for a limit and told players they were full when they were not. If you are about to compare this to
 *  `certLimitForPlayers`, you want the breakdown instead. */
export function certificateCount(playerAddress: string, state: GameStateResponse): number {
  let count = 0;
  for (const priv of state.private_companies) {
    // Design note #736: a CLOSED private is off the board and off the limit. It was still being counted.
    if (priv.closed) continue;
    if (priv.owner === playerAddress) count += 1;
  }
  for (const pub of state.public_companies) {
    // The president's 20% certificate is a single physical card and counts as exactly 1 certificate -- see
    // design note #3. Anything held beyond that 20% is ordinary 10% certificates, each still counting as 1.
    // Design note #1324: and the 20% standard certificate (ERIE, N&W under the Level Playing Field) is one
    // card too. `certificateCardsHeld` is the one place that arithmetic lives; `certificateBreakdown` below
    // asks it as well, so the two counts cannot drift.
    count += certificateCardsHeld(pub, playerAddress);
  }
  return count;
}

/* Design note #526: the local copy is GONE. It carried a doc comment saying "mirrors `RulesReference`'s
   table" -- a correctness requirement enforced by a sentence, the arrangement TD-1 catalogued and #507 hit
   again. `gameEngine/gameSetup.ts` is the one table now; a third copy is what this delegation exists to avoid. */

/** How many certificates a player may hold, given the room's size.
 *  `null` for a player count the printed table does not cover, so a caller
 *  renders "--" rather than inventing a ceiling. */
export function certificateLimit(state: GameStateResponse): number | null {
  return certLimitForPlayers(state.player_addresses.length);
}

export interface CertificateBreakdown {
  /** Certificates that count against the limit. */
  counted: number;
  /** Certificates held in a Yellow, Orange or Brown zone corporation, which
   *  are exempt from the limit. */
  exempt: number;
  /** `counted + exempt` -- what `certificateCount` returns. */
  total: number;
  /** The room's ceiling, or `null` if the player count is off the table. */
  limit: number | null;
}

/* Design note #7: THE CERTIFICATE LIMIT EXEMPTION. Shares priced in the Yellow, Orange or Brown zone do not
   count toward the limit -- a MARKET-POSITION rule, not an ownership one: the same certificate counts today
   and stops counting tomorrow if the price moves, with nothing about the certificate changing.
   WHY THE ZONE ARRIVES AS A CALLBACK: the table lives in `StockMarketRenderer.tsx` and `utils/` may not
   import from `components/`. Taking it as a parameter keeps that boundary intact AND keeps this pure and
   testable, rather than copying the price-to-zone table where it could drift from the board.
   OMITTING THE CALLBACK IS A VALID CALL, not a degraded one -- the caller has no market data, everything is
   counted, and that is the correct conservative answer. PRIVATE COMPANIES ARE NEVER EXEMPT: no price, no
   zone. */
export function certificateBreakdown(
  playerAddress: string,
  state: GameStateResponse,
  /** Live market price per `company_id`. Omit when unknown. */
  marketPrices?: Readonly<Record<number, number | null>> | null,
  /** Price -> zone. Pass `marketZoneForPrice`; see design note #7 for why
   *  this is injected rather than imported. */
  zoneForPrice?: (price: number | null | undefined) => string | null,
): CertificateBreakdown {
  let counted = 0;
  let exempt = 0;

  for (const priv of state.private_companies) {
    /* Design note #736: likewise here, and this is the half the report saw -- "the private companies are
       still displayed (and counting toward certificates)". `playerPrivateCompanies` already filtered closed
       ones out of the DISPLAY list, so the two disagreed the moment anything set the flag. */
    if (priv.closed) continue;
    if (priv.owner === playerAddress) counted += 1;
  }

  for (const pub of state.public_companies) {
    const holding = pub.player_holdings.find((h) => h.player === playerAddress);
    if (!holding || holding.percentage <= 0) continue;

    // Same physical-card arithmetic as `certificateCount` -- the president's 20% is ONE card, the 20%
    // standard certificate (#1324) is one card, the rest are 10% cards.
    const cards = certificateCardsHeld(pub, playerAddress);

    const zone =
      marketPrices && zoneForPrice ? zoneForPrice(marketPrices[pub.company_id]) : null;
    if (zone === "Yellow" || zone === "Orange" || zone === "Brown") exempt += cards;
    else counted += cards;
  }

  return { counted, exempt, total: counted + exempt, limit: certificateLimit(state) };
}

/** `"4 (+2 exempt) / 13"`, or `"4 / 13"` when nothing is exempt, or
 *  `"4"` when the room size has no printed limit. One formatter so the
 *  Player Index and the Game Ledger cannot render the same fact two ways. */
export function formatCertificateCount(breakdown: CertificateBreakdown): string {
  const head =
    breakdown.exempt > 0
      ? `${breakdown.counted} (+${breakdown.exempt} exempt)`
      : `${breakdown.counted}`;
  return breakdown.limit === null ? head : `${head} / ${breakdown.limit}`;
}

/** Every public company `playerAddress` currently holds any nonzero share
 *  of, paired with that holding -- the building block for a Financial
 *  Ledger "certificate tree" (see `FinancialLedger.tsx`). */
export function playerCompanyHoldings(
  playerAddress: string,
  state: GameStateResponse,
): Array<{ company: PublicCompanyState; percentage: number }> {
  const holdings: Array<{ company: PublicCompanyState; percentage: number }> = [];
  for (const company of state.public_companies) {
    const holding = company.player_holdings.find((h) => h.player === playerAddress);
    if (holding && holding.percentage > 0) {
      holdings.push({ company, percentage: holding.percentage });
    }
  }
  return holdings;
}

/* Design note #497: THE LEDGER SAID "NOT CONNECTED" TO ITS OWN DATA. The gate is
   `queryClient && contractAddress && gameId`, and a sandbox has none of the three -- so both money columns
   fell to the placeholder for the whole of offline mode, on the screen whose job is to total up what
   everybody owns.
   `FinancialLedger #4` was why, and it was right WHEN WRITTEN: reproducing the figure would have meant a
   second query plus duplicating the backend's valuation math, or substituting par for market price. THE
   PREMISE EXPIRED -- `marketGrid` is a prop of that panel now and is already unpacked into a price map, so
   the live prices are sitting in the same function that printed "not connected".
   Design note #497a: AN ESTIMATE THAT KNOWS IT IS ONE. This does not replace `PlayerNetWorth`; the chain's
   figure stays authoritative and the caller prefers it. What this replaces is the BLANK -- and the two can
   legitimately differ, so a client-side total presented as authoritative would be the "silently
   substituting" failure wearing a different hat.
   `null` PROPAGATES rather than being coerced to zero: an unknown portfolio value is not a zero one, and
   reporting "$0 net worth" for someone holding five certificates is worse than reporting nothing. */

/** One 1830 certificate is 10% of a corporation, and a market price is
 *  quoted per certificate -- so a 30% holding is three certificates at that
 *  price. Named rather than inlined as `/ 10`, because the divisor is a rule
 *  rather than an arithmetic convenience. */
const PERCENT_PER_CERTIFICATE = 10;

/** What `playerAddress`'s shares are worth at live market prices, or `null` when any corporation they hold
 *  has no price to value them at. Keyed by `company_id`, exactly as `FinancialLedger`'s own map is. */
/** What one 10% certificate of this corporation is worth, and therefore what it would sell for.
 *
 *  Design note #711: AN UNPARRED SHARE IS WORTH $0, NOT "UNKNOWN".
 *
 *  REPORTED: "if a share has no market price it is unsellable, so it should either be excluded or count as
 *  $0 -- and the only case in which this can ever happen is the 10% PRR share granted by the private company
 *  before PRR pars/sells its President's Share. Regarding Net Worth: unsellable shares ... are effectively
 *  worth $0."
 *
 *  THAT IS THE FACT THE OLD CODE WAS MISSING: a corporation acquires a price the moment its President's Share
 *  is sold at a par. So "no price" is not a gap in what this client knows, it is a statement about the board
 *  -- nobody has parred the corporation, its shares cannot be sold to anyone at any figure, and $0 is the
 *  answer rather than a refusal to answer. In practice it happens once per game, to the certificate a private
 *  company grants.
 *
 *  PARRED, NOT FLOATED, and the distinction is the one #562a already had to make from the other side: "a
 *  started-but-unfloated corporation sits at its par position and its shares sell perfectly well". Floating is
 *  about how many shares have sold; pricing happens at the par, before any of that.
 *
 *  SO THE THREE READINGS COLLAPSE INTO ONE LADDER. `estimateStockPortfolioValue` returned `null` on an unknown
 *  price; #566 added a par fallback for the card only, on the grounds that "a corporation whose president has
 *  set a par but whose token is not yet on the chart is not unpriced"; and the Ledger kept the stricter
 *  reading. All three were circling the same ladder -- market, then par, then nothing to sell -- and the
 *  disagreement was only about where it stopped.
 *
 *  WHICH RETIRES #566's SPLIT. There is no longer a looser reading and a stricter one for the two surfaces to
 *  choose between, because par is not a fallback: it is the price, whenever the chart has not moved off it. */
export function sharePriceFor(
  company: PublicCompanyState,
  marketPrices: Readonly<Record<number, number | null>>,
): number {
  const market = marketPrices[company.company_id];
  if (market != null && Number.isFinite(market)) return market;
  const par = Number(company.par_value ?? NaN);
  if (Number.isFinite(par) && par > 0) return par;
  // Unparred: no IPO price, no chart position, no buyer. Design note #711.
  return 0;
}

export function estimateStockPortfolioValue(
  playerAddress: string,
  state: GameStateResponse,
  marketPrices: Readonly<Record<number, number | null>>,
): number {
  let total = 0;
  for (const holding of playerCompanyHoldings(playerAddress, state)) {
    /* Design note #711: no `null` branch any more. It read "unknown price, unknown total ... an under-report
       is indistinguishable from a correct smaller number", which is sound reasoning about a MISSING FIGURE and
       was being applied to a share that has no value. Counting it as zero is not under-reporting; it is the
       report. */
    total += (holding.percentage / PERCENT_PER_CERTIFICATE) * sharePriceFor(holding.company, marketPrices);
  }
  return total;
}

/** Liquid cash plus portfolio value, or `null` when the player's CASH is unknown -- which is now the only
 *  thing that can make this unanswerable (design note #711). */
export function estimatePlayerNetWorth(
  playerAddress: string,
  state: GameStateResponse,
  marketPrices: Readonly<Record<number, number | null>>,
): { stockValue: number; netWorth: number } | null {
  const stockValue = estimateStockPortfolioValue(playerAddress, state, marketPrices);
  const entry = state.player_cash.find((row) => row.player === playerAddress);
  const cash = Number(entry?.cash_vgp ?? NaN);
  // No cash record is not zero cash -- a player the state has not reported is not a player with nothing.
  if (!Number.isFinite(cash)) return null;
  return { stockValue, netWorth: cash + stockValue };
}

/* Design note #379: A PRIVATE CAN BELONG TO A COMPANY, NOT A PLAYER. `PrivateCompanyState` has carried
   both owners since the schema was written -- `owner` for a player, `owner_protocol_id` for a corporation,
   mutually exclusive per its own doc comment -- and every reader in the app looked only at `owner`. So the
   moment a private crossed from a player to a company it left the seller's ledger row and arrived nowhere:
   it paid revenue to a treasury (#329) that no surface attributed to it.
   ONE HELPER, so the ledger column and the Operating Round strip cannot disagree about what a corporation
   owns. CLOSED PRIVATES ARE EXCLUDED -- a closed company is off the board, pays nothing, and listing it
   would show an asset the corporation no longer has. */
export function corporationPrivateCompanies(
  companyId: number,
  state: GameStateResponse,
): PrivateCompanyState[] {
  return state.private_companies.filter(
    (priv) => !priv.closed && priv.owner_protocol_id === companyId,
  );
}

/** Every private `playerAddress` currently owns -- the other half of a certificate tree. Includes closed
 *  privates still on this player's own ledger; use the sellable list below when the goal is specifically
 *  what a corporation could still buy from them. */
export function playerPrivateCompanies(
  playerAddress: string,
  state: GameStateResponse,
): PrivateCompanyState[] {
  /* Design note #736: CLOSED ONES ARE OFF THE BOARD, and this list is what the Player Card and the Ledger
     render. Its corporate twin `corporationPrivateCompanies` has excluded them since it was written -- "a
     closed company is off the board, pays nothing, and listing it would show an asset the corporation no
     longer has" -- and every word of that applies to a player. The two disagreed only because nothing ever
     set `closed`, so the asymmetry was invisible until #736 made the flag real. */
  return state.private_companies.filter((p) => !p.closed && p.owner === playerAddress);
}

/** Every private `playerAddress` owns AND could still sell via `BuyPrivateCompany` -- the list above minus
 *  any already `closed`. A closed private permanently rejects `execute_buy_private_company` (`trading.rs`
 *  module doc #17), so offering one would just produce a guaranteed-failing tx. The Buy Private Company
 *  tray uses this, not the plain list. */
export function playerSellablePrivateCompanies(
  playerAddress: string,
  state: GameStateResponse,
): PrivateCompanyState[] {
  return state.private_companies.filter((p) => p.owner === playerAddress && !p.closed);
}

// Pre-Game Waterfall Auction (`waterfall.rs`) -- design note #7. Mirrors `WaterfallStateResponse` and its
// nested types exactly, plus a THIRD independent polling hook on the same fixed-interval-plus-monotonic-
// guard pattern. Separate rather than folded into `GameStateResponse` because `GetWaterfallState` is its
// own query and, unlike `PlayerNetWorth`, is only meaningful while the auction is current -- so every other
// panel keeps polling `GetGameState` alone without paying for a response it never renders.

/** One standing bid on a private company -- mirrors `msg.rs`'s
 *  `WaterfallBidEntry` exactly. */
export interface WaterfallBidEntry {
  bidder: string;
  bid_amount: string;
}

/** One still-unowned core private company's live Waterfall Auction status --
 *  mirrors `msg.rs`'s `WaterfallPrivateStatus` exactly. */
export interface WaterfallPrivateStatus {
  private_id: number;
  name: string;
  face_value: string;
  /** `true` only for whichever private is currently the cheapest
   *  still-unowned one -- the only one `WaterfallBuyLowest` can target, and
   *  the only one that can never itself be bid on. */
  is_lowest_offered: boolean;
  bids: WaterfallBidEntry[];
}

/** The currently-in-progress mini-auction's live status (2+ competing bidders on
 *  a single private) -- mirrors `msg.rs`'s `WaterfallMiniAuctionStatus`
 *  exactly. `null` on `WaterfallStateResponse.mini_auction` whenever no
 *  mini-auction is active. */
export interface WaterfallMiniAuctionStatus {
  private_id: number;
  /** The competing bidders, in the order they will be asked to act: ascending by the bid each held when the
   *  contest opened, so the lowest bidder is always first to answer. See `sandboxSession.ts #544` for why the
   *  queue is fixed at that moment rather than re-sorted after every raise. */
  bidders: string[];
  /** Whose turn it currently is within `bidders` -- always someone other
   *  than `high_bidder`, whose own turns are auto-skipped. */
  current_turn: string;
  high_bid: string;
  high_bidder: string;
  /** ==================================================================
   *   DESIGN NOTE 1581: HOW MANY BIDDERS HAVE PASSED SINCE THE LAST RAISE (Batch 7.3, S7-3)
   *  ==================================================================
   *
   * Rulebook §1.2.2 ends a contest when "all of the bidders pass consecutively" -- which is a COUNT, and the
   * engine had nowhere to keep one. It resolved the contest by ELIMINATION instead: a pass removed the bidder
   * from `bidders` and deleted his bid, so the last player standing won. That is a different game. §1.2.2 is
   * explicit that a bidder "may pass and still bid later if the auction does not end", and under elimination
   * a player who passed once could never come back -- audit M1.
   *
   * SO THE PASS BECOMES A COUNTER AND THE BIDDER STAYS. Incremented by `WaterfallMiniAuctionPass`, reset to
   * zero by any legal `WaterfallMiniAuctionRaise`, and the contest resolves the moment it reaches
   * `bidders.length - 1` -- every bidder but the high bidder, who is never asked to outbid himself
   * (`nextMiniTurn`, #544).
   *
   * ABSENT MEANS ZERO (#232), which is what keeps every stored log replaying: a contest rebuilt from a log
   * written before this field existed has had no passes since its last raise, because it has had no passes
   * at all. Every mini-auction in the corpus is a two-bidder contest, where `bidders.length - 1` is 1 and
   * one pass resolves it under both rules -- so the repaired machine reproduces them exactly. */
  passes_since_raise?: number;
}

/** `QueryMsg::GetWaterfallState`'s response -- mirrors `msg.rs`'s
 *  `WaterfallStateResponse` exactly. */
export interface WaterfallStateResponse {
  game_id: number;
  waterfall_auction_active: boolean;
  /** Every still-unowned core private company, in ascending face-value
   *  order -- empty once all six have been won. */
  privates: WaterfallPrivateStatus[];
  /** Whose turn it is in the main Waterfall Auction turn order. Stays fixed
   *  (not meaningfully actionable) while a mini-auction is in progress --
   *  use `mini_auction.current_turn` instead in that case. */
  current_turn: string;
  /** Non-`null` only while a 2+-bidder mini-auction is currently
   *  resolving. */
  mini_auction: WaterfallMiniAuctionStatus | null;
  /** How many consecutive `WaterfallPass` calls have occurred so far --
   *  reaching `player_addresses.length` ends the auction early. */
  consecutive_waterfall_passes: number;
}

/** Mirrors `msg::TrainOfferEntry`. */
export interface TrainOfferEntry {
  offer_id: number;
  buyer_protocol_id: number;
  seller_protocol_id: number;
  model_type: string;
  /** `Uint128` -- a JSON string. Never parsed to a number. */
  price: string;
  seller_president: string | null;
  buyer_president: string | null;
}

export interface TrainOffersResponse {
  game_id: number;
  offers: TrainOfferEntry[];
}


/* Design note #553: A CORPORATION'S PAR IS THE CORPORATION'S, NOT YOURS. The resolver read the local par
   LADDER, falling back to a hardcoded "100" when this browser had never touched it. The ladder is a UI
   selection -- per-browser by design, and empty on every client but the one that made the choice -- so
   everybody else fell through to the default, which happens to be the top rung, which is why the wrong
   number looked like a plausible one.
   SO THE LADDER IS AN INPUT, AND THE PAR IS A FACT: once the founding purchase lands
   `PublicCompanyState.par_value` holds the answer and every client has it. The ladder is consulted only
   while that field is empty -- exactly what #351 already said the rule was; the reducer honoured it and the
   price the UI quoted and dispatched did not.
   THE SAME BUG AS #549, one layer up: there the reducer resolved WHO from local state, here the UI resolved
   HOW MUCH. Both produce the same failure -- no error, two clients that disagree, and a symptom that
   surfaces somewhere else entirely. */
export function parPriceFor(
  state: GameStateResponse | null,
  companyId: number,
  ladderSelection?: string,
  fallback = "100",
): string {
  const set = state?.public_companies.find((c) => c.company_id === companyId)?.par_value;
  /* A par of 0 is not a price -- treat it as unset. The contract sends the
     field as a string or null, and "0" is what an uninitialised numeric
     column looks like on the way through. */
  if (set !== null && set !== undefined && Number(set) > 0) return String(set);
  return ladderSelection ?? fallback;
}
