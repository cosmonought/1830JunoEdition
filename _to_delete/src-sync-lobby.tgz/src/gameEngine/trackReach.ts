// frontend/src/utils/trackReach.ts
//
// Which hexes a corporation may lay track on -- the board-dimming set.
//
// Design note #0: A HINT ABOUT REACH, NOT A RULING ABOUT LEGALITY. 18xx.games dims the board during a tile lay
// and lights only the buildable hexes, which is a genuine usability feature: 1830's board is 100-odd hexes and
// a corporation can usually build on three or four, so without it the player's first move is to work out where
// their own network ends -- every turn, by eye.
// WHAT THIS DOES NOT ANSWER, and must never grow to: whether a given TILE fits (that is
// `hexmap::execute_lay_tile`'s, mirrored for the picker by `sandboxTileLegality`); the one-tile-per-turn rule;
// token blocking (a full city stops a ROUTE, not a lay); or whether it is this corporation's turn.
// The consequence of this file being wrong is a hex dimmed when it should not be -- an inconvenience -- rather
// than an illegal action being accepted, which is why the fallback opens the board up rather than closing it.
//
// Design note #1: connectivity is checked from BOTH SIDES -- a dead-end stub otherwise reads as connected to
// whatever sits beyond it. `liveEdgesForHex` resolves the four sources of track, so this file asks it rather
// than knowing about any of them.
//
// Design notes #2/#3/#4/#483: see `docs/ai_architecture/routing_pathfinding.md`.

/* Design note #686: `liveEdgesForHex` is no longer imported here. The one line that called it -- the start of
   the walk, taking every rail on a station's hex -- now asks `cityExitEdges`, which answers the same question
   for a hex with one city and a narrower one for a hex with two.
   Dropped rather than left imported: this file's whole history is the hex-as-a-node model being removed one
   caller at a time (#4, #483, and now this), and an unused import of the function that embodies it is an
   invitation to reach for it again. */
import {
  HEX_NEIGHBOR_OFFSETS,
  cityExitEdges,
  evaluateHexForTileLaying,
} from "../components/hexGeometry";
import type { MapGridResponse } from "../components/hexContractTypes";
import { TILE_CATALOG_BY_ID } from "../components/hexTileCatalog";
import { neighbourAcross, traversalsFrom } from "./trackSegments";
import { STATIC_BOARD_HEXES, boardMemo, heraldHexFor } from "../components/hexBoardData";

/** `"q,r"` -- the key every consumer of this module indexes by. */
export function hexKey(q: number, r: number): string {
  return `${q},${r}`;
}

/* Design note #483: A NETWORK ENDS AT PORTS, NOT AT HEXES. #4 fixed HALF of this -- the BFS was made to walk
   `(hex, arrivalEdge)` states, so the walk itself is strict. What it produced was still a set of HEX keys, and
   everything downstream then asked that set the hex-as-a-node question all over again:
     `extensionNeighbours` offered a build across EVERY live edge of a network hex, so a corporation reaching
     edge 0 of a #20 crossover was offered lays beyond edges 1 and 4 -- the reported bug, one layer below the fix.
     `sandboxTileLegality`'s rotation filter did the same, asking whether a neighbour was in the network and
     carried rail to the shared edge -- true of the far arm of a crossover the corporation cannot reach.
   The strictness was being computed and then thrown away. A hex key cannot express "reached, but only on this
   rail", so any consumer holding one has to re-derive the missing half, and both of them re-derived it wrongly.
   A PORT IS THE MISSING VALUE: `"q,r:edge"`, produced by the same walk that produces the hex set, so the two
   cannot disagree. */
export function portKey(q: number, r: number, edge: number): string {
  return `${q},${r}:${edge}`;
}

const boardKeys = boardMemo(
  (board): ReadonlySet<string> => new Set(board.hexes.map((hex) => hexKey(hex.q, hex.r))),
);

/* `connectedNeighbours` is GONE with design note #4. It answered "which hexes does this one carry rail toward",
   which is the hex-as-a-node model that let a network bleed across a crossover's two separate straights.
   `trackSegments.neighbourAcross` keeps the both-sides rule; the missing half -- WHICH rail -- comes from
   `traversalsFrom`. Deleted rather than left unused so nothing can quietly start calling the old model again. */

/* Design note #3: A TILE LAY EXTENDS A ROUTE; IT DOES NOT TOUCH A HEX. This used to be all six neighbours of
   every network hex, on the reasoning that a lay extends a network so adjacency is the test. The first half of
   that is right and the conclusion does not follow: the lay still has to JOIN the network, and a network only
   offers a join where its own track ENDS AT AN EDGE. PRR on Altoona (printed track on edges 0 and 3) can extend
   west and east and nowhere else -- the other four sides are blank cardboard with no rail reaching them.
   Six lit hexes where two are legal is not a small over-count; it is the feature inverted.
   THE TEST IS ONE-SIDED, and that is the difference from the network walk: joining an EXISTING network needs
   both hexes to carry matching rail, while extending it needs only the network side to offer an edge, because
   the tile about to be laid supplies the other half. The two-sided test would light nothing on a fresh board.
   Design note #483: takes a PORT, not a hex. The old signature read `liveEdgesForHex` itself -- the line that
   offered builds across a crossover's far arm. The edge is now supplied by the walk that proved it reachable. */
function extensionAcross(
  q: number,
  r: number,
  edge: number,
): { q: number; r: number } | null {
  const offset = HEX_NEIGHBOR_OFFSETS[edge];
  if (!offset) return null;
  const nq = q + offset[0];
  const nr = r + offset[1];
  if (!boardKeys().has(hexKey(nq, nr))) return null;
  return { q: nq, r: nr };
}

/** A token, as `(q, r)` or -- when the chain recorded which slot it sits in
 *  (`gameState.ts` #560) -- as `(q, r, cityIndex)`.
 *
 *  Design note #686: THE THIRD ELEMENT IS THE FIX. `station_token_hexes` cannot
 *  say which of a two-city hex holds a token, so a walk starting from one had to
 *  assume both -- and on New York and every OO tile the two cities do not
 *  connect. `station_tokens` has carried the answer since #560; this is the
 *  first caller to ask for it.
 *  OPTIONAL, because a chain predating that field is a real state and the
 *  fallback is exactly the old behaviour. */
export type StationToken = readonly [number, number] | readonly [number, number, number];

export interface LayableHexInput {
  mapGrid: MapGridResponse;
  /** The acting corporation's station tokens. */
  stationHexes: ReadonlyArray<StationToken>;
  /** Design note #716: DOES A TILE ACTUALLY EXIST FOR THIS HEX?
   *
   *  Injected rather than imported, for the reason design note #7 gives about `certificateBreakdown`: the tile
   *  catalog and the legality filter live in `components/` and `utils/` may not import from there. Omitting it
   *  keeps the old behaviour, which every existing caller and fixture relies on -- and which is the
   *  conservative answer where there is no engine to ask. */
  hasPlaceableTile?: (
    q: number,
    r: number,
    /* The walk's own network and ports travel WITH the question. The picker filters its candidates by exactly
       these, so a callback that asked without them would answer a different question than the panel the click
       opens -- and the glow would offer hexes whose picker comes up empty. */
    network: ReadonlySet<string>,
    ports: ReadonlySet<string>,
  ) => boolean;
  /** Design note #729: cities this corporation may not run THROUGH -- tokened out by others. Injected for the
   *  same reason `hasPlaceableTile` is: the slot counts live in the tile catalog and the occupants live in
   *  game state, neither of which this module may read. See `reachableTrack`. */
  blocksThrough?: (q: number, r: number, cityIndex: number) => boolean;
}

export interface LayableHexResult {
  /** `hexKey` of every hex this corporation may build on -- the glow set. */
  hexes: ReadonlySet<string>;
  /* Design note #4: THE NETWORK IS SHOWN, NOT HIDDEN. The first cut veiled everything except the legal targets,
     which is the obvious reading of "dim what you cannot act on" and the wrong one: a player choosing WHERE to
     extend is reasoning about the route the extension would join, so dimming exactly that leaves the legal hexes
     lit and the reason for choosing between them in the dark.
     Three tiers rather than two -- the network at full brightness, the extensions lit and glowed, everything else
     receding -- returned from one walk, or the two halves of one picture would disagree about where it ends. */
  network: ReadonlySet<string>;
  /** Design note #483: the reachable edges of that network, `"q,r:edge"`.
   *  Carried out to the rotation filter, which needs to know WHICH edge of a
   *  network hex the corporation can join -- a question the hex set cannot
   *  answer and which every consumer that tried to re-derive it got wrong. */
  ports: ReadonlySet<string>;
  /** The connected network the set was grown from, for the caller's own
   *  messaging ("your network reaches N hexes"). */
  networkSize: number;
  /** True when the answer is "everything the board allows" rather than a
   *  real reach computation -- see `layableHexes`' fallback. A caller should
   *  NOT dim the board in that case: dimming nothing is honest, dimming
   *  everything-but-a-guess is not. */
  unconstrained: boolean;
}

/* Design note #2: WHY A CORPORATION WITH NO TOKEN IS UNCONSTRAINED. A floated corporation that has not placed
   its home token has no network, so a strict reading would return the empty set and dim the ENTIRE board with
   nothing lit -- telling the player, wordlessly, that they may not build anywhere. That is both wrong (their
   first lay is the home hex) and indistinguishable from a broken feature. The same applies before the first
   `GetGameState` resolves.
   So "I do not know where this network is" returns `unconstrained` and the caller leaves the board undimmed.
   The contract remains the authority either way; the only thing lost is the hint.
   `reachableNetwork` is exported because two features need the same walk and must not disagree about it -- the
   veil grows this set by one hex, and station placement tests membership directly. A second BFS with its own
   subtly different adjacency rule is exactly how "the board says I can build here but the token button says I
   cannot" happens.
   Design note #4: A NETWORK FOLLOWS RAILS, NOT HEX ADJACENCY. The walk was hex-to-hex, which treats a hex as a
   NODE where everything meets -- true of most tiles and false of exactly the ones this matters on. Measured on
   the real board before the fix: a three-hex patch with #20 in the middle reported the far hex as networked,
   across two rails with no connection between them.
   THE WALK IS OVER (HEX, ARRIVAL EDGE) STATES NOW, so a crossover is entered twice, once per straight, and each
   visit carries only its own onward reach.
   THE STATION HEXES THEMSELVES ARE UNRESTRICTED, and that is not a shortcut: a route starts AT a token, inside
   the city, so every rail leaving that city is available to it. There is no arrival edge to constrain a start. */
export interface ReachableTrack {
  /** Every hex the corporation's rails physically reach. */
  hexes: Set<string>;
  /* Design note #483: WHAT THE PORT SET IS FOR -- every edge the walk PROVED reachable. Two consumers need it and
     neither can derive it from `hexes`: the tile-lay extension (a build joins only across an edge the network
     actually reaches) and the rotation filter (an orientation survives only if a live edge faces a port, rather
     than merely facing a hex that happens to be in the network).
     INCLUDES EDGES WITH NOTHING BEYOND THEM, deliberately. `hexes` only grows across a two-sided join, because a
     network cannot flow into bare cardboard -- but bare cardboard is exactly where a tile gets laid, so the port
     survives where the hex does not. */
  ports: Set<string>;
  /** Design note #893: every CITY the network actually enters, as `"q,r:cityIndex"`. Distinct from `hexes`
   *  because an OO tile carries two circles whose spurs need not touch -- a token is placed in a city, and
   *  the hex-level answer says yes to both when the network reaches either. */
  cities: Set<string>;
}

/** The walk, with both of its results. `reachableNetwork` below is this
 *  function's `hexes` and exists because most callers want only that. */
/** Which city on `(q, r)` an arrival across `edge` lands in, or `null` for plain track.
 *
 *  Design note #729. Inverted from `cityExitEdges` rather than re-derived: that function already owns the
 *  rotation arithmetic and the landmark table, and a second reading of `cityGroups` here is how two answers
 *  about the same tile come to disagree. Tried in index order and the first match wins -- a tile whose two
 *  city groups shared an edge would be ambiguous, and no 1830 tile does. */
export function cityForArrival(
  mapGrid: MapGridResponse,
  q: number,
  r: number,
  edge: number,
): number | null {
  const all = cityExitEdges(mapGrid, q, r, null);
  for (let city = 0; city < 2; city += 1) {
    const edges = cityExitEdges(mapGrid, q, r, city);
    /* `cityExitEdges` FALLS BACK TO EVERY LIVE EDGE when the hex has fewer than two cities or the index is out
       of range, so an answer equal to `all` is "I do not know which city" and must not be read as "city 0
       reaches everything". Only a genuinely narrower answer identifies a city. */
    if (edges.length < all.length && edges.includes(edge)) return city;
  }
  /* One city, or none. `hexBlocksThrough` is asked anyway with index 0 -- a single-city hex is the ordinary
     blocking case and the caller decides whether a city exists there at all. */
  return all.includes(edge) ? 0 : null;
}

/** Which city on `hex` a route entering from the ADJACENT hex `from` passes through, or `null` for plain
 *  track and for a `from` that is not adjacent.
 *
 *  ==================================================================
 *   DESIGN NOTE 1022: THE ENTRY EDGE WAS AVAILABLE ALL ALONG
 *  ==================================================================
 *
 * REPORTED: "The auto-router correctly routes a D-train through an empty city in a Brown OO hex (E11).
 * However, because the other city in that same hex has a rival station, clicking 'Run Routes' throws an error
 * claiming the hex is tokened out, blocking the legal run."
 *
 * TWO WALKS, ONE RULE, AND ONLY ONE OF THEM KNEW WHICH CITY. `reachableTrack` and the route tracer both ask
 * `cityForArrival` and then `blocksThrough` about THAT city -- the specific circle the rail enters.
 * `routeBlockedCityReason`, the check on the submit path, looped `for (let city = 0; city < 2; city += 1)`
 * and refused if EITHER was shut. On a hex with one city that is the same question; on an OO hex it is a
 * different and stricter one, so the router offered a route the validator then rejected.
 *
 * `cityBypass.ts` WROTE THE REASON DOWN AND DID NOT NOTICE IT WAS SOLVABLE: "without an entry edge there is
 * no way to say which one a crossing would enter. On a two-city hex this is the strict direction." True of
 * `cityShutAt`, which is handed a bare hex. The submit-path validator walks an ORDERED LIST of points, so the
 * previous point IS the entry edge -- the information was in the caller's hands and never converted.
 *
 * THIS IS THAT CONVERSION, and it lives beside `cityForArrival` so both walks reach the city index through
 * one function. That is the whole of the report's second item: the router and the validator now share the
 * resolver, rather than sharing a rule they apply to different granularities. */
/* ==================================================================
    DESIGN NOTE 1319: WHICH STOP A RAIL ARRIVES AT
   ==================================================================
   RULED: "a city can only ever be visited once by a train", and a route may run through one city of a hex and
   then another city of the SAME hex, collecting both. Both rules need one answer: given the edge a train
   arrives by, which stop on the hex does it reach? `cityForArrival` answers for hexes whose cities are
   distinguished by `cityGroups`. This widens it to the double TOWNS, whose two stops are two separate rails
   with no groups -- the stop is the authored path that carries the arrival edge -- so a train may visit both
   towns of #1 or #630 and is refused a second visit to either. Everything else is one stop: index 0. */
export function stopForArrival(
  mapGrid: MapGridResponse,
  q: number,
  r: number,
  edge: number,
): number | null {
  const laid = mapGrid.tiles.find((tile) => tile.q === q && tile.r === r);
  const entry = laid ? TILE_CATALOG_BY_ID.get(laid.tile_id) : undefined;
  if (laid && entry && entry.terrain === "DoubleTown" && entry.paths) {
    const rot = ((laid.orientation % 6) + 6) % 6;
    const at = entry.paths.findIndex(([a, b]) => (a + rot) % 6 === edge || (b + rot) % 6 === edge);
    return at < 0 ? null : at;
  }
  return cityForArrival(mapGrid, q, r, edge);
}

/** `stopForArrival`, given the neighbour the train came from rather than the edge. `null` when the two hexes
 *  are not adjacent or the edge carries no rail into any stop. */
export function stopEnteredFrom(
  mapGrid: MapGridResponse,
  hex: { q: number; r: number },
  from: { q: number; r: number },
): number | null {
  const arrivalEdge = HEX_NEIGHBOR_OFFSETS.findIndex(
    (offset) => hex.q + offset[0] === from.q && hex.r + offset[1] === from.r,
  );
  if (arrivalEdge < 0) return null;
  return stopForArrival(mapGrid, hex.q, hex.r, arrivalEdge);
}

export function cityEnteredFrom(
  mapGrid: MapGridResponse,
  hex: { q: number; r: number },
  from: { q: number; r: number },
): number | null {
  const arrivalEdge = HEX_NEIGHBOR_OFFSETS.findIndex(
    (offset) => hex.q + offset[0] === from.q && hex.r + offset[1] === from.r,
  );
  /* NOT ADJACENT IS NOT AN EDGE. A drafted route can contain a jump -- the drawing surface does not enforce
     adjacency -- and `-1` fed to `cityForArrival` would index nothing and read as "plain track", which is the
     permissive answer to a question that was never asked. `null` says so instead, and the caller falls back
     to the conservative both-cities test. */
  if (arrivalEdge < 0) return null;
  return cityForArrival(mapGrid, hex.q, hex.r, arrivalEdge);
}

export function reachableTrack(
  mapGrid: MapGridResponse,
  stationHexes: ReadonlyArray<StationToken>,
  /** Design note #729: whether a city is tokened out against the corporation whose network this is.
   *
   *  REPORTED: "corporations' networks are not being blocked by tokened out cities. A network is defined in
   *  the rulebook as the hexes a theoretical infinite-length train could reach on its run, so tokened out
   *  hexes block this train as they should all other trains."
   *
   *  INJECTED, for #7's reason: the slot COUNTS live in the tile catalog under `components/`, which `utils/`
   *  may not import for its tables, and the OCCUPANTS live in game state this module has never seen. The
   *  caller holds both; this module holds the walk.
   *
   *  OMITTED MEANS NO BLOCKING, which reproduces every pre-#729 caller exactly -- and is the honest default
   *  for a caller that cannot see the tokens, since inventing a block would hide legal track. */
  blocksThrough?: (q: number, r: number, cityIndex: number) => boolean,
): ReachableTrack {
  const hexes = new Set<string>();
  const ports = new Set<string>();
  /* ==================================================================
      DESIGN NOTE 893: A HEX IS REACHED; A CITY IS ENTERED
     ==================================================================
     REPORTED: "on OO tiles, corporations are allowed to place stations on cities they don't actually have
     connectivity to (e.g., D10/E11) ... NYC has connectivity to exactly three hexes, but the Station Marker
     subphase allows it to place a station in almost any city on the board."
     `hexes` ANSWERS THE WRONG QUESTION FOR A TOKEN. It is the set of hexes the network reaches, which is
     exactly right for the tile-lay veil -- a lay is about a HEX -- and one granularity too coarse for a
     placement, because an OO tile carries two cities whose spurs need not touch. A corporation reaching the
     left circle of D10 has `D10` in `hexes`, and the token gate read that as permission to stand in the
     right one.
     #852 FOUND THIS EXACT THING IN THE ROUTE SEARCH -- "`[q, r]` IS NOT ENOUGH, AND NEW YORK PROVES IT" --
     and #686 found it in this walk's START. Both fixed the case in front of them and left the token gate,
     which is the third caller. Third instance of one rule stated in one authority and never asked in its
     sibling, in the same walk.
     KEYED `q,r:cityIndex`, so a caller that knows which circle it means can ask about that circle, and one
     that does not can still ask about the hex through `hexes`. */
  const cities = new Set<string>();
  /** `q,r:arrivalEdge` -- one hex may legitimately be entered several ways. */
  const visited = new Set<string>();
  const queue: Array<{
    q: number;
    r: number;
    arrivalEdge: number | null;
    /** Design note #686: which city this visit started in, for a start only.
     *  `null` once the walk is on rails -- an arrival edge is a stricter
     *  answer than a city index and supersedes it. */
    cityIndex: number | null;
  }> = [];

  for (const token of stationHexes) {
    const [q, r] = token;
    if (!boardKeys().has(hexKey(q, r))) continue;
    hexes.add(hexKey(q, r));
    /* `null` arrival: a station is entered from inside. Design note #686: from
       inside ONE CITY, though -- which is the part "every rail on it" got
       wrong on the hexes that carry two. */
    queue.push({
      q,
      r,
      arrivalEdge: null,
      cityIndex: token.length > 2 ? (token[2] ?? null) : null,
    });
  }

  while (queue.length > 0) {
    const at = queue.shift()!;
    /* Design note #686: a start is keyed by its CITY, so two tokens in the two
       cities of one hex are two distinct visits rather than one that dedupes
       the second away. */
    const stateKey = `${hexKey(at.q, at.r)}:${at.arrivalEdge ?? `start${at.cityIndex ?? ""}`}`;
    if (visited.has(stateKey)) continue;
    visited.add(stateKey);

    /* Design note #893: which circle this visit is standing in. A start is the city the token sits in
       (#686); an arrival is whichever city that rail lands in, which is what `cityForArrival` answers and
       what #730's blocking test already asks one block below.
       A BYPASS GUARD WAS DRAFTED HERE AND REMOVED, and the reason is worth keeping. The first version carried
       a `viaBypass` flag on the queue entry so a hex reached only by #737's bow would be in `hexes` and its
       city not in `cities`. It could never fire: the bow belongs to the transit LEAVING a hex, so both push
       sites had nothing to say about how the NEXT hex would be entered and both wrote `false`. The note above
       it described the intention as an accomplishment, which is a shape this codebase has produced before.
       AND IT WAS NOT NEEDED, which is the substantive half. `cityForArrival` is already the authority on
       whether an arrival lands in a city; where a bow and a city track join the same two edges, a walk
       arriving on that edge genuinely CAN take the city track, so answering "the city" is correct rather than
       merely convenient. The `null` return is what covers the arrivals that enter nothing. */
    const entered =
      at.arrivalEdge === null
        ? (at.cityIndex ?? 0)
        : cityForArrival(mapGrid, at.q, at.r, at.arrivalEdge);
    if (entered !== null) cities.add(`${hexKey(at.q, at.r)}:${entered}`);

    /* ==================================================================
     *  DESIGN NOTE 729: A TOKENED-OUT CITY IS A WALL, NOT A GAP
     * ==================================================================
     *
     * REPORTED: "A network is defined in the rulebook as the hexes a theoretical infinite-length train could
     * reach on its run, so tokened out hexes block this train as they should all other trains."
     *
     * THE WALK MODELLED TRACK AND IGNORED TOKENS ENTIRELY, so a corporation's network ran straight through
     * cities it may not pass -- offering tile lays on the far side of a wall, in a place no train of theirs
     * could ever run. The report's definition is the fix stated precisely: the network IS a run, so every rule
     * that stops a run stops it.
     *
     * REACHED, BUT NOT PASSED. The blocked city is still IN the network and `hexes.add` above has already
     * recorded it -- a train may end its run in a city it cannot pass through, and a corporation may still
     * upgrade that tile. What it may not do is continue. So this drops the EXITS and keeps the hex, which is
     * the whole of the difference between a wall and a hole.
     *
     * NEVER FROM A STATION. `arrivalEdge === null` is this corporation standing in its own city, and a
     * corporation is not blocked by its own token -- nor by anybody else's in a city it also occupies.
     * Starting nodes are exempt by construction rather than by a rule, because the caller only ever seeds the
     * walk from cities this corporation holds. */
    /* ==================================================================
     *  DESIGN NOTE 820: THE WALL HAS A DOOR IN IT, AND THIS WALK DID NOT KNOW
     * ==================================================================
     *
     * REPORTED: "during the Lay Track action, the corporation's veil and legal placement options are being
     * blocked when its network reaches Altoona, despite the bypass."
     *
     * THE SAME MISTAKE #808 FOUND IN THE ROUTE TRACER, in the other walk, and #729/#730 warned that these two
     * have to be fixed together: "they had to be fixed together or the board would have promised reach the
     * router then refused." #808 fixed the router half and left this one, so the promise now runs the other
     * way -- a route may cross Altoona and the network says the far side is unreachable.
     *
     * ASKED TOO EARLY, exactly as before. The answer is computed on ARRIVAL and used to `continue`, which
     * drops every exit -- and the bow is a property of the EXIT. H12's two tracks join the same two edges;
     * one enters the city and one goes round it, and a city full of other corporations' tokens has nothing to
     * say about track that never touches it.
     *
     * #729's "REACHED, BUT NOT PASSED" IS UNCHANGED for a hex with no bow: `hexes.add` above has already
     * recorded the blocked city, and filtering the exits to nothing leaves it in the network without a way
     * out, which is what the old `continue` achieved. What changes is only that a bow counts as a way out. */
    const blockedCity =
      at.arrivalEdge !== null && blocksThrough
        ? (() => {
            const city = cityForArrival(mapGrid, at.q, at.r, at.arrivalEdge);
            /* Design note #1323: A TOWN CAN BE BARRED TOO. `cityForArrival` is `null` where there is no city
               to enter, and the predicate was never asked -- right while every block was a full city, wrong
               the moment a hex could be shut on its own account (Coal River, unlicensed). Asked with city 0:
               `cityBlocksThrough` answers a town's zero slots with `false`, so nothing changes for an ordinary
               town, and a barred hex answers before slots are consulted. */
            if (city === null) return blocksThrough(at.q, at.r, 0) ? 0 : null;
            return blocksThrough(at.q, at.r, city) ? city : null;
          })()
        : null;

    /* Which edges may this visit leave by? From a station, all of them; having arrived on a rail, only the edges
       that rail reaches. `traversalsFrom` is the strict half -- it drops the pair when there is no authored rail
       joining the two edges, which is what makes two curves on one tile two curves rather than a junction.
       Design note #820: and when the city here is shut, only the ways through that miss it. */
    const exits: ReadonlyArray<{ exitEdge: number; bypass?: boolean }> =
      at.arrivalEdge === null
        ? cityExitEdges(mapGrid, at.q, at.r, at.cityIndex).map((exitEdge) => ({ exitEdge }))
        : traversalsFrom(mapGrid, at.q, at.r, at.arrivalEdge).filter(
            (t) => blockedCity === null || t.bypass === true,
          );

    for (const transit of exits) {
      const edge = transit.exitEdge;
      /* Design note #483: recorded BEFORE the two-sided join is tested. An
         edge the corporation's track runs to is reached whether or not
         anything sits beyond it -- and the case where nothing does is the
         one a tile lay is for. */
      ports.add(portKey(at.q, at.r, edge));

      const next = neighbourAcross(mapGrid, at.q, at.r, edge);
      if (!next) continue;
      hexes.add(hexKey(next.q, next.r));
      queue.push({
        q: next.q,
        r: next.r,
        arrivalEdge: next.arrivalEdge,
        cityIndex: null,
      });
    }
  }
  return { hexes, ports, cities };
}

/** Design note #893: the city-level companion to `reachableNetwork`. Keys are `"q,r:cityIndex"`.
 *
 *  A SEPARATE FUNCTION RATHER THAN A SECOND RETURN, because the two answer different questions and the
 *  callers do not overlap: a tile lay is about a hex and a station token is about a circle. Naming them
 *  apart is what stops the next caller reaching for whichever is nearer. */
export function reachableCities(
  mapGrid: MapGridResponse,
  stationHexes: ReadonlyArray<StationToken>,
  blocksThrough?: (q: number, r: number, cityIndex: number) => boolean,
): Set<string> {
  return reachableTrack(mapGrid, stationHexes, blocksThrough).cities;
}

export function reachableNetwork(
  mapGrid: MapGridResponse,
  stationHexes: ReadonlyArray<StationToken>,
  // Design note #729: passed straight through, so every caller of the short form gets the rule too.
  blocksThrough?: (q: number, r: number, cityIndex: number) => boolean,
): Set<string> {
  return reachableTrack(mapGrid, stationHexes, blocksThrough).hexes;
}

/** A corporation's tokens as the walk wants them: the recorded `(q, r, city)`
 *  triples when the chain has them, the bare `(q, r)` pairs otherwise.
 *
 *  Design note #686: ONE RESOLVER, THREE CALLERS. The tile-lay veil, the token
 *  placement highlight and `stationTokens`' connectivity refusal all ask this
 *  walk the same question, and all three read `station_token_hexes` today. Three
 *  copies of "prefer `station_tokens` when it is there" is three chances to keep
 *  the old field -- and a board where the veil knows about cities and the token
 *  gate does not is worse than one where neither does, because the two disagree
 *  in front of the player.
 *  `gameState.ts` #560's three states, honoured: absent means "use the
 *  heuristic", a shorter list means the same for the tokens it does not cover. */
export function stationTokensOf(company: {
  station_token_hexes: ReadonlyArray<readonly [number, number]>;
  station_tokens?: ReadonlyArray<readonly [number, number, number]> | null;
  /** Design note #1302: named so the herald can be found. Optional because older callers pass token lists. */
  company_id?: number;
}): StationToken[] {
  const recorded = company.station_tokens ?? [];
  const tokens: StationToken[] = company.station_token_hexes.map((hex) => {
    const match = recorded.find(([q, r]) => q === hex[0] && r === hex[1]);
    return match ?? hex;
  });
  /* ==================================================================
      DESIGN NOTE 1302: THE HERALD IS A ROOT, NOT A TOKEN
     ==================================================================
     1830+ prints PRR's herald on H12, a hex with no city. "PRR alone can (and must in its first turns) count
     this as its home station." Every question that begins "where does this corporation's network start" --
     the tile-lay veil, the station-placement reach, the route tracer's roots, the "can it run at all" check
     -- comes through THIS reader (#686's whole point), so the herald is added here, once, and every one of
     them sees a home without learning a rule. It is appended, not placed: `station_token_hexes` is untouched,
     so token counts, token drawing and city blocking do not see a token that does not exist. */
  const herald = company.company_id === undefined ? null : heraldHexFor(company.company_id);
  if (herald && !tokens.some(([q, r]) => q === herald.q && r === herald.r)) {
    tokens.push([herald.q, herald.r]);
  }
  return tokens;
}

export function layableHexes(input: LayableHexInput): LayableHexResult {
  const { mapGrid, stationHexes } = input;

  const roots = stationHexes.filter(([q, r]) => boardKeys().has(hexKey(q, r)));
  if (roots.length === 0) {
    return {
      hexes: new Set(),
      network: new Set(),
      ports: new Set(),
      networkSize: 0,
      unconstrained: true,
    };
  }

  const { hexes: network, ports } = reachableTrack(mapGrid, roots, input.blocksThrough);

  // A lay is legal on a hex the network REACHES: one already in the network (an upgrade of track the corporation
  // runs on) or one its track actually exits toward (an extension -- design note #3, where the "every surrounding
  // hex" bug lived). `evaluateHexForTileLaying` then removes what the static board forbids anywhere.
  // Design note #483: the extension candidates come from PORTS. This used to iterate the network's hexes and read
  // every live edge off each one, which re-introduced the hex-as-a-node model the walk had just finished
  // rejecting -- a crossover reached on one straight offered builds beyond the other.
  const candidates = new Set<string>(network);
  ports.forEach((port) => {
    const [coords, edgeText] = port.split(":");
    const [q, r] = coords.split(",").map(Number);
    const next = extensionAcross(q, r, Number(edgeText));
    if (next) candidates.add(hexKey(next.q, next.r));
  });

  /* Design note #716: THE GLOW PROMISED A TILE AND ONLY CHECKED THE GROUND.
     REPORTED: "on the yellow/green tiles the white border is everywhere and loses its signal ... tiles with no
     upgrades still appear with the white border that would suggest there's a legal tile placement on them."
     `evaluateHexForTileLaying` answers a question about the BOARD -- is this a hex, is it a red off-board, is
     it forbidden anywhere -- and never about the TRAY. So every hex the network touched that was not
     structurally banned glowed, including a green city with no brown upgrade printed. On an opening board the
     two sets are nearly identical, which is why this survived; on a large network almost everything qualifies
     and the mark stops meaning anything.
     ASK THE ENGINE, don't restate it. `hasPlaceableTile` is `filterSandboxPlacements` at the call site -- the
     same search the tile picker runs -- so the glow cannot offer a hex the picker would then open empty. The
     same discipline #707 used for the Run Routes obligation. */
  const hexes = new Set<string>();
  candidates.forEach((key) => {
    const [q, r] = key.split(",").map(Number);
    if (!evaluateHexForTileLaying(q, r, mapGrid).eligible) return;
    if (input.hasPlaceableTile && !input.hasPlaceableTile(q, r, network, ports)) return;
    hexes.add(key);
  });

  return { hexes, network, ports, networkSize: network.size, unconstrained: false };
}
