// Real-time chat transport over the game server's room-doc socket, plus one standalone view for the
// pre-game staging room.
//
// The primary export is `useRoomChat`, NOT the component: the dashboard's chat surface is `TopTicker`'s
// accordion fed by `mergeFeedItems`. Chat is off-chain and carries NO AUTHORITY -- no code path in this app
// parses a chat message.
//
// #1361a: THE TRANSCRIPT LIVES ON THE GAME SERVER. It was `games/{roomId}/chat` on Firestore (and
// `sandbox_rooms/{code}/chat` for a sandbox room, #644); Firestore is gone. The server keeps one transcript
// per room, capped at `CHAT_HISTORY_LIMIT`, persisted beside the room's log, and sends the WHOLE of it on
// every change -- so ordering is the server's clock and there is no pending-write window for a message to
// fall out of. The hook's contract is unchanged: `ChatMessage[]` oldest-first, `sendMessage`, `error`,
// `available`.
//
// See docs/ai_architecture/firebase_middleware.md, ChatBox.tsx #0 / #1 / #2.

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { backendConfigError } from "../config/backend";
import { seatLabel } from "../utils/lobby";
import { roomDocOnServer, sendChat, subscribeChat, type RoomChatEntry } from "../utils/roomDocLink";
import { colorForAuthor, type ChatMessage } from "../utils/feed";
import { CONTROL_PADDING, FONT_FAMILY, FONT_SIZE, RADIUS } from "../styles/typography";

/** How much scrollback a room keeps. Bounded because a transcript only ever grows and the server sends the
 *  whole of it on every change -- an unbounded one would re-send an entire game's chat per message. The
 *  server enforces it; this is the figure the client expects. */
export const CHAT_HISTORY_LIMIT = 200;

const MAX_MESSAGE_LENGTH = 500;

/* ------------------------------------------------------------------ */
/* Decoding                                                            */
/* ------------------------------------------------------------------ */

function decodeMessage(entry: RoomChatEntry): ChatMessage | null {
  const text = typeof entry.text === "string" ? entry.text.trim() : "";
  if (!text) return null;

  const address = typeof entry.author === "string" ? entry.author : "";
  const displayName = typeof entry.displayName === "string" ? entry.displayName : "";
  const timestampMs = typeof entry.at === "number" && Number.isFinite(entry.at) ? entry.at : Date.now();

  return {
    id: String(entry.id),
    author: seatLabel({ address, displayName }),
    text: text.slice(0, MAX_MESSAGE_LENGTH),
    timestamp: new Date(timestampMs).toLocaleTimeString(),
    timestampMs,
  };
}

/* ------------------------------------------------------------------ */
/* The hook -- design note #0                                          */
/* ------------------------------------------------------------------ */

export interface RoomChatResult {
  /** Oldest-first, matching the ordering convention `mergeFeedItems`
   *  documents and `TopTicker` renders against. */
  messages: ChatMessage[];
  /** Rejects empty/whitespace text. Resolves once the write is queued
   *  locally; the message is visible immediately (design note #2) and the
   *  server round-trip completes in the background. */
  sendMessage: (text: string) => Promise<void>;
  /** Non-null when chat is unavailable or a send failed. Surfaced rather
   *  than swallowed: a chat box that silently drops messages is worse than
   *  one that says it is offline. */
  error: string | null;
  /** `false` when the game server is unconfigured or no room is selected. */
  available: boolean;
}

/**
 * Subscribes to a room's transcript on the game server and returns it in the exact `ChatMessage[]` shape
 * `utils/feed.ts` already defines.
 *
 * @param roomId  The room the transcript hangs off -- a sandbox room code, or a staging room's id. Chat is
 *                an off-chain concern keyed to the off-chain room, which is what lets a staging room have a
 *                transcript before it has any on-chain identity at all. Pass `null` to subscribe to nothing.
 * @param address The sender's identity, stamped on outgoing messages: a wallet address, or the sandbox
 *                player id. `null` disables sending (but not reading).
 * @param displayName Denormalised onto each message on purpose: a player who later renames themselves should
 *                not retroactively rewrite the byline on things they already said.
 */
/* Design note #644: the sandbox had no chat, twice over. Two independent gates,
   either enough on its own: `App.tsx` passed `sandbox ? null : roomId` on design
   note #24 reasoning that has not been true since #578 (the sandbox is the
   multiplayer mode and already has a real room writing an action log); and
   `sendMessage` refuses when `address` is null, which in a sandbox it always is.

   AND A THIRD CASE THE FIX HAS TO COVER: a build with no game server configured at all, which is a supported
   way to run this app. There is no transport there and a Send button that silently does nothing is the worst
   of the three outcomes, so the hook falls back to keeping messages in memory -- what chat was before design
   note #22 moved it off the client, and honest for a session that is local by construction.

   THE ERROR STATE IS NOT THE FALLBACK. A configured server that REFUSES a write still reports the failure; it
   does not quietly divert to local state and leave a player believing the table saw their message. Local is
   for "there is no transport", never for "the transport said no". */
let nextLocalChatId = 1;

export function useRoomChat(
  roomId: string | null,
  address: string | null,
  displayName: string,
): RoomChatResult {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [localMessages, setLocalMessages] = useState<ChatMessage[]>([]);
  const [error, setError] = useState<string | null>(null);

  const onServer = roomDocOnServer();
  const available = onServer && roomId !== null;

  // Kept in a ref so `sendMessage` stays referentially stable across
  // renames -- `InlineQuickChat` receives it as an `onSend` prop, and an
  // identity that changed on every keystroke would defeat memoisation all
  // the way down that tree.
  const identityRef = useRef({ address, displayName });
  identityRef.current = { address, displayName };

  useEffect(() => {
    if (!onServer || !roomId) {
      setMessages([]);
      setError(onServer ? null : backendConfigError());
      return;
    }

    /* #1361a: the connection's identity is whoever this tab is -- the same claim the room document's
       subscription made for this room, so the two share one socket. `address` may be null for a reader. */
    const claim = identityRef.current.address ?? "";
    const unsubscribe = subscribeChat(
      roomId,
      claim,
      (entries) => {
        const decoded = entries
          .map(decodeMessage)
          .filter((message): message is ChatMessage => message !== null)
          .sort((a, b) => a.timestampMs - b.timestampMs);
        setMessages(decoded);
        setError(null);
      },
      (message) => {
        setError(`[server] Chat is unavailable: ${message}`);
      },
    );

    return unsubscribe;
    // Design note #644: switching rooms resubscribes rather than listening to the old one.
  }, [onServer, roomId]);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim().slice(0, MAX_MESSAGE_LENGTH);
      if (!trimmed) return;

      const { address: sender, displayName: name } = identityRef.current;
      /* Design note #644: no transport is not a failure, it is a local
         session. The message is kept in memory so the button does what it
         says, and the feed shows it exactly as a delivered one -- because
         within this browser it IS delivered; there is nobody else to reach. */
      if (!onServer || !roomId) {
        setLocalMessages((current) => [
          ...current,
          {
            id: `local-${nextLocalChatId++}`,
            /* Design note #765: THE SAME FUNCTION THE DELIVERED MESSAGE USES. This read `sender || name`,
               which prefers the ADDRESS over the display name -- so an offline echo was labelled with a
               wallet or a local player id even when a perfectly good name was in hand, and the same message
               would relabel itself if it ever round-tripped. `seatLabel` is what `decodeMessage` calls, so
               the optimistic line and the delivered one cannot disagree by construction.
               `sender ?? ""` because the ADDRESS is nullable here and `seatLabel` is not -- offline with no
               wallet is exactly the case this branch exists for, and it falls through to "You". */
            author: seatLabel({ address: sender ?? "", displayName: name }) || "You",
            text: trimmed,
            timestamp: new Date().toLocaleTimeString(),
            timestampMs: Date.now(),
          },
        ]);
        setError(null);
        return;
      }
      if (!sender) {
        setError("Connect a wallet before sending a message.");
        return;
      }

      try {
        /* #1361a: fire-and-forget, like every other write on this socket. The message is visible when the
           server's next `chat` frame arrives -- the server is the one clock and the one order. */
        sendChat(roomId, sender, trimmed, name);
        setError(null);
      } catch (sendError) {
        setError(
          `[server] Message not sent: ${
            sendError instanceof Error ? sendError.message : String(sendError)
          }`,
        );
      }
    },
    [onServer, roomId],
  );

  /* Design note #644: one list either way. A caller should not have to know
     which transport answered -- and on the local path `messages` is empty, so
     this is a concatenation rather than a choice. */
  const allMessages = useMemo(
    () => (localMessages.length === 0 ? messages : [...messages, ...localMessages]),
    [messages, localMessages],
  );

  return { messages: allMessages, sendMessage, error, available };
}

/* ------------------------------------------------------------------ */
/* Standalone view -- staging room only, design note #0                */
/* ------------------------------------------------------------------ */

export interface ChatBoxProps {
  roomId: string | null;
  address: string | null;
  displayName: string;
  /** Rendered above the transcript. */
  title?: string;
}

/**
 * A compact scrolling transcript + composer, for the pre-game staging room
 * in `Lobby.tsx`. NOT used on the dashboard -- see design note #0.
 */
export function ChatBox({ roomId, address, displayName, title = "Room chat" }: ChatBoxProps) {
  const { messages, sendMessage, error, available } = useRoomChat(roomId, address, displayName);
  const [draft, setDraft] = useState("");
  const listRef = useRef<HTMLDivElement>(null);

  // Scroll-to-bottom on new arrivals -- the same convention `TopTicker`'s
  // own design note #5 established for the accordion history, so both chat
  // surfaces behave identically.
  useEffect(() => {
    const node = listRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages.length]);

  const handleSend = useCallback(() => {
    const text = draft;
    setDraft(""); // cleared optimistically; the write is visible immediately
    void sendMessage(text);
  }, [draft, sendMessage]);

  const canSend = available && address !== null && draft.trim().length > 0;

  const body = useMemo(() => {
    if (!available) {
      return <p style={styles.hint}>Real-time chat is offline. {error ?? ""}</p>;
    }
    if (messages.length === 0) {
      return <p style={styles.hint}>No messages yet — say hello while the table fills up.</p>;
    }
    return messages.map((message) => (
      <div key={message.id} style={styles.message}>
        <div style={styles.messageHeader}>
          <span style={{ ...styles.messageAuthor, color: colorForAuthor(message.author) }}>
            {message.author}
          </span>
          <span style={styles.messageTime}>{message.timestamp}</span>
        </div>
        <div style={styles.messageText}>{message.text}</div>
      </div>
    ));
  }, [available, error, messages]);

  return (
    <section style={styles.root} aria-label={title}>
      <header style={styles.header}>
        <span>💬 {title}</span>
        {messages.length > 0 && <span style={styles.count}>{messages.length}</span>}
      </header>

      <div style={styles.list} ref={listRef}>
        {body}
      </div>

      {error && available && <p style={styles.error}>{error}</p>}

      <div style={styles.composer}>
        <input
          type="text"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              handleSend();
            }
          }}
          placeholder={address ? "Type a message..." : "Connect a wallet to chat"}
          aria-label="Room chat message"
          disabled={!available || address === null}
          style={styles.input}
        />
        <button type="button" onClick={handleSend} disabled={!canSend} style={styles.sendButton}>
          Send
        </button>
      </div>
    </section>
  );
}

export default ChatBox;

// Inline styles, matching this codebase's escape hatch (`TopTicker`,
// `InlineQuickChat`), on the same #0F172A / #1E293B recessed-surface palette so
// the staging room reads as part of the same application as the dashboard.

const styles: Record<string, React.CSSProperties> = {
  root: {
    display: "flex",
    flexDirection: "column",
    minHeight: 0,
    backgroundColor: "#0f0f0f",
    border: "1px solid #1c1c1c",
    borderRadius: RADIUS.layer,
    overflow: "hidden",
    fontFamily: FONT_FAMILY,
  },
  header: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "12px 16px",
    backgroundColor: "#1c1c1c",
    borderBottom: "1px solid #2a2a2a",
    fontSize: FONT_SIZE.control,
    fontWeight: 700,
    color: "#f2f0eb",
  },
  count: {
    fontSize: FONT_SIZE.small,
    fontWeight: 700,
    padding: "2px 8px",
    borderRadius: RADIUS.pill,
    backgroundColor: "#2a2a2a",
    color: "#a8a6a0",
  },
  list: {
    flex: 1,
    minHeight: "200px",
    maxHeight: "360px",
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    padding: "12px 16px",
  },
  hint: {
    fontSize: FONT_SIZE.body,
    color: "#6e6c68",
    margin: 0,
  },
  message: {
    borderLeft: "3px solid #2a2a2a",
    backgroundColor: "#1c1c1c",
    borderRadius: `0 ${RADIUS.card} ${RADIUS.card} ${RADIUS.card}`,
    padding: "6px 12px",
  },
  messageHeader: {
    display: "flex",
    alignItems: "baseline",
    gap: "8px",
  },
  messageAuthor: {
    fontSize: FONT_SIZE.body,
    fontWeight: 700,
  },
  messageTime: {
    fontSize: FONT_SIZE.small,
    color: "#6e6c68",
  },
  messageText: {
    fontSize: FONT_SIZE.body,
    color: "#c8c6c0",
    marginTop: "1px",
    overflowWrap: "anywhere",
  },
  error: {
    margin: 0,
    padding: "8px 16px",
    fontSize: FONT_SIZE.small,
    color: "#f0b0a8",
    backgroundColor: "#2a1614",
    borderTop: "1px solid #5a2a24",
  },
  composer: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    padding: "10px 16px",
    borderTop: "1px solid #1c1c1c",
  },
  input: {
    flex: 1,
    fontSize: FONT_SIZE.control,
    padding: CONTROL_PADDING.input,
    borderRadius: RADIUS.card,
    border: "1px solid #3a3a3a",
    backgroundColor: "#0f0f0f",
    color: "#f2f0eb",
    boxSizing: "border-box",
  },
  sendButton: {
    fontSize: FONT_SIZE.control,
    fontWeight: 600,
    padding: CONTROL_PADDING.button,
    borderRadius: RADIUS.card,
    border: "1px solid #3a3a3a",
    backgroundColor: "#1c1c1c",
    color: "#f2f0eb",
    cursor: "pointer",
    flexShrink: 0,
  },
};
