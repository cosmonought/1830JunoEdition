// frontend/src/components/tileTransition.ts
//
// VF-5: the tile-lay and tile-upgrade flourish -- the DESCRIPTION half. Pure: no canvas, no React, no Path2D.
// The painter is `tileTransitionCanvas.ts`; the staging (when a transition starts, what supersedes it, when
// the authoritative tile takes over) lives in `HexGridRenderer.tsx`.
//
// ==================================================================
//  DESIGN NOTE 1460: A TRANSITION IS TWO ARTWORKS AND THE GEOMETRY BETWEEN THEM
// ==================================================================
//
// ASKED FOR: a confirmed lay or upgrade that visibly transforms the old hex into the new one -- "existing
// infrastructure persists -> city geometry mutates where necessary -> genuinely new track rapidly constructs
// itself -> final geometry settles -> destination tile colour washes in as the completion cue".
//
// EVERYTHING HERE IS READ OFF THE ARTWORK THE BOARD ALREADY DRAWS, and nothing is read off a rule. A laid tile
// is `TILE_GRAPHICS_CATALOG` at its orientation; an unlaid hex is exactly what `HexGridRenderer`'s printed
// passes paint there (a landmark's printed track, an OO pair, a town or city designation, or nothing). Both
// become one `HexArt`: rails as sampled polylines and revenue centres as markers, in BOARD unit-hex space
// (rotation applied), so the two sides of a transition are comparable point for point.
//
// WHAT THIS MODULE DOES NOT DO, and must not grow into: decide whether an upgrade was legal, which orientation
// was chosen, where a token belongs, or which city a corporation's network reaches. The transition is built
// from an old/new pair that has already happened; tokens are positioned by the renderer from authoritative
// state and only MOVED here (#1466). If the artwork cannot describe either side the plan is `null` and the
// board simply draws the authoritative tile.
//
// ==================================================================
//  DESIGN NOTE 1461: A RAIL IS SPLIT AT ITS REVENUE CENTRES, AND ONLY UNMATCHED PIECES ARE BUILT
// ==================================================================
//
// THE UNIT OF COMPARISON IS A PIECE, not an authored track. Tile #57 authors ONE straight through its city;
// #14 authors FOUR spokes into it. Compared as tracks they share nothing; compared as pieces between nodes --
// an edge midpoint or a revenue centre -- #57 is `edge0<->city` and `city<->edge3`, and #14 carries both of
// those unchanged plus two more. So every authored rail is cut wherever a marker sits on it (every marker in
// the catalog lies on its own rail to within 0.002 unit, measured), and a piece is named by its two nodes.
//
// THREE CLASSES, and the renderer treats them three ways:
//   PERSISTENT    the same nodes and the same pixels -- drawn still, never redrawn as construction.
//   RECONFIGURED  the same nodes (after city correspondence, #1462) but different geometry: Baltimore's printed
//                 curve becoming #53's spokes, New York's stubs becoming #54's curves, two towns' rails
//                 straightening into #88's hub. Morphed point for point, never "built".
//   ADDED         no counterpart -- the only pieces that construct themselves (#1467, #1469).
// A piece of the OLD tile with no counterpart fades; a legal upgrade never produces one, and the arm exists so
// an unexpected pair resolves to the destination rather than leaving an orphaned stroke.
//
// PERSISTENCE OF NETWORK MEANING, NOT OF PIXELS: a reconfigured piece keeps its identity because its NODES
// persist, which is why a city that moves drags its rails with it instead of the rails being rebuilt.

import { TILE_CATALOG_BY_ID, type TileColorTier } from "./hexTileCatalog";
import {
  PILL_SLOT_SPACING,
  SLOT_RING_RATIO,
  STATION_RADIUS_RATIO,
  TILE_GRAPHICS_CATALOG,
  markerSizeFor,
  printedMarkersFor,
  printedTracksFor,
  slotOffsets,
  trackCrossingsFor,
  trackLayersFor,
  type TileArtworkMarker,
} from "./TileGraphics";
import {
  COLOR_TIER_STROKE,
  ERA_TILE_FILL,
  LANDMARK_HEXES,
  STATIC_BOARD_HEXES,
  STANDARD_TRACK_INK,
  TILE_TRACK_INK,
  YELLOW_OO_HEXES,
} from "./hexBoardData";
import { twoNodePositions } from "./hexGeometry";

/* ------------------------------------------------------------------ */
/* Geometry primitives                                                */
/* ------------------------------------------------------------------ */

export interface Vec {
  x: number;
  y: number;
}

/* Exact at both ends, so the first frame IS the old art and the last frame IS the new art -- no float residue for
   the hand-over to reveal. */
const lerp = (a: number, b: number, t: number) => (t <= 0 ? a : t >= 1 ? b : a + (b - a) * t);
const lerpVec = (a: Vec, b: Vec, t: number): Vec => (t <= 0 ? a : t >= 1 ? b : { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t) });
const dist = (a: Vec, b: Vec) => Math.hypot(a.x - b.x, a.y - b.y);
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const add = (a: Vec, b: Vec): Vec => ({ x: a.x + b.x, y: a.y + b.y });
const sub = (a: Vec, b: Vec): Vec => ({ x: a.x - b.x, y: a.y - b.y });
const scale = (a: Vec, s: number): Vec => ({ x: a.x * s, y: a.y * s });

/** Where `t` sits inside `[start, end]`, clamped to 0..1. */
export function windowProgress(t: number, start: number, end: number): number {
  if (end <= start) return t >= end ? 1 : 0;
  return clamp01((t - start) / (end - start));
}

export function smoothstep(u: number): number {
  const v = clamp01(u);
  return v * v * (3 - 2 * v);
}

/** A CSS-style cubic Bezier easing (x1, y1, x2, y2), solved for `x` by Newton steps with a bisection fallback. */
function cubicBezierEasing(x1: number, y1: number, x2: number, y2: number): (u: number) => number {
  const coord = (a: number, b: number, s: number) => 3 * a * s * (1 - s) * (1 - s) + 3 * b * s * s * (1 - s) + s * s * s;
  const slope = (a: number, b: number, s: number) =>
    3 * a * (1 - s) * (1 - s) + 6 * (b - a) * s * (1 - s) + 3 * (1 - b) * s * s;
  return (u: number) => {
    const x = clamp01(u);
    if (x === 0 || x === 1) return x;
    let s = x;
    for (let i = 0; i < 6; i += 1) {
      const error = coord(x1, x2, s) - x;
      const d = slope(x1, x2, s);
      if (Math.abs(error) < 1e-6) break;
      if (Math.abs(d) < 1e-6) break;
      s = clamp01(s - error / d);
    }
    if (Math.abs(coord(x1, x2, s) - x) > 1e-4) {
      let lo = 0;
      let hi = 1;
      for (let i = 0; i < 30; i += 1) {
        s = (lo + hi) / 2;
        if (coord(x1, x2, s) < x) lo = s;
        else hi = s;
      }
    }
    return coord(y1, y2, s);
  };
}

/* ==================================================================
 *  DESIGN NOTE 1464: THE TIMELINE -- GEOMETRY FIRST, COLOUR AS THE COMPLETION CUE
 * ==================================================================
 * Fractions of one transition. "Do not treat these as fixed percentages unless the architecture makes that
 * appropriate" -- they are named here so a playtest can move them in one place, and nothing else in the
 * module states a time.
 *
 * GEOMETRY RUNS TO THE END ON A LONG SETTLE. The ease is a soft-start, long-tail curve, so by the moment the
 * wash begins (0.68) roughly nine tenths of every movement has happened and what remains is settling. The
 * WASH and the SETTLE therefore finish on the same frame -- "the destination colour reaches full strength at
 * approximately the same moment the track and city geometry finish settling" -- and the wash is never a
 * separate pause after the geometry has stopped.
 *
 * CONSTRUCTION HAS SETTLED BY THE TIME THE WASH IS HALFWAY, so the destination colour is never established while a
 * rail is still being laid. */
export const TILE_TRANSITION_MS = 850;
/** Reduced motion: a quick local crossfade (#1465). */
export const TILE_TRANSITION_REDUCED_MS = 240;

export const TIMELINE = {
  /** A new lay's neutral foundation fades in under the construction. */
  foundation: [0.0, 0.12],
  /** A city gaining capacity, or merging, tenses briefly before it moves. */
  tension: [0.02, 0.18],
  /** City migration, reconfigured rails, and the enclosing outline. */
  geometry: [0.08, 1.0],
  outline: [0.12, 1.0],
  /** A single station slot pulses before it divides; several gather first. */
  pulse: [0.2, 0.42],
  gather: [0.14, 0.4],
  divide: [0.34, 1.0],
  /** Merging cities grow a shared neck. */
  fuse: [0.28, 1.0],
  /** Genuinely new rail. A construction wave travels each added piece from its origin; a piece that continues from
   *  where another arrives starts when that wave arrives, and every wave has settled by the end (#1467, #1469). */
  construct: [0.14, 0.84],
  /** The longest the wave takes to travel one piece -- shorter only when a chain of pieces must fit the window. */
  constructTravel: 0.34,
  /** One portion of new rail, from the front reaching it to settled at exactly the board's width. */
  constructSettle: 0.08,
  /** A revenue centre with no predecessor appears; one with no successor goes. */
  emerge: [0.16, 0.62],
  vanish: [0.1, 0.55],
  /** The destination tier's colour. */
  wash: [0.68, 1.0],
  /** The last fifth: the slot rings close into whole circles again, and the outlines of shapes that merged hand
   *  over to the one shape they became -- so the settled frame strokes everything exactly once, as the tile pass
   *  does, and the hand-over to it changes no line's weight. */
  settle: [0.8, 1.0],
} as const;

const settleEase = cubicBezierEasing(0.32, 0, 0.14, 1);

/** The easings the renderer needs outside the frame (token and reservation motion, badges). */
export interface TransitionEasings {
  geometry: number;
  slots: number;
  wash: number;
  foundation: number;
}

export function transitionEasings(plan: TileTransitionPlan, t: number): TransitionEasings {
  if (plan.reducedMotion) {
    const a = smoothstep(t);
    return { geometry: a, slots: a, wash: a, foundation: plan.foundation ? a : 0 };
  }
  return {
    geometry: settleEase(windowProgress(t, TIMELINE.geometry[0], TIMELINE.geometry[1])),
    slots: settleEase(windowProgress(t, TIMELINE.divide[0], TIMELINE.divide[1])),
    wash: smoothstep(windowProgress(t, TIMELINE.wash[0], TIMELINE.wash[1])),
    foundation: plan.foundation ? smoothstep(windowProgress(t, TIMELINE.foundation[0], TIMELINE.foundation[1])) : 0,
  };
}

/* ------------------------------------------------------------------ */
/* One hex's artwork, in board unit-hex space                          */
/* ------------------------------------------------------------------ */

export interface ArtMarker {
  kind: "city" | "town";
  /** Board unit-hex space, the tile's rotation applied. */
  at: Vec;
  /** Station slots; 1 for a town. */
  slots: number;
  /** The slot cluster's axis in board space -- the authored angle minus the tile's turn. */
  angle: number;
  layout: "pill" | "triangle" | "square";
  /** The marker size as a fraction of the hex (`markerSizeFor`), which is what every radius scales from. */
  scale: number;
}

export interface ArtTrack {
  /** The authored `d` string in the artwork's own (unrotated) space -- the layer and crossing derivations read it. */
  d: string;
  /** Dense uniform-parameter samples in board space. */
  samples: Vec[];
}

export interface HexArt {
  tracks: ArtTrack[];
  markers: ArtMarker[];
  /** The tile tier painted on the hex, or `null` where the board itself shows (an unlaid hex). */
  tier: TileColorTier | null;
  /** Degrees the authored artwork is turned by -- the tile's orientation times -60, or 0 for printed art. */
  turnDeg: number;
}

const TRACK_SAMPLES = 120;

function rotateVec(v: Vec, deg: number): Vec {
  if (deg === 0) return v;
  const radians = (deg * Math.PI) / 180;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  return { x: v.x * cos - v.y * sin, y: v.x * sin + v.y * cos };
}

/** Samples one authored rail. The catalog authors every rail as one `M` plus one `L` or `C` (#244); anything
 *  else returns `null`, which makes the whole plan `null` rather than a guessed shape. */
function sampleTrack(d: string, turnDeg: number): Vec[] | null {
  const n = (d.match(/-?\d+(?:\.\d+)?/g) ?? []).map(Number);
  let at: (t: number) => Vec;
  if (/\sL\s/.test(d) && n.length === 4) {
    at = (t) => ({ x: lerp(n[0], n[2], t), y: lerp(n[1], n[3], t) });
  } else if (/\sC\s/.test(d) && n.length === 8) {
    at = (t) => {
      const u = 1 - t;
      return {
        x: u * u * u * n[0] + 3 * u * u * t * n[2] + 3 * u * t * t * n[4] + t * t * t * n[6],
        y: u * u * u * n[1] + 3 * u * u * t * n[3] + 3 * u * t * t * n[5] + t * t * t * n[7],
      };
    };
  } else {
    return null;
  }
  const out: Vec[] = [];
  for (let i = 0; i <= TRACK_SAMPLES; i += 1) out.push(rotateVec(at(i / TRACK_SAMPLES), turnDeg));
  return out;
}

function markerFrom(marker: TileArtworkMarker, turnDeg: number, markerScale: number): ArtMarker {
  return {
    kind: marker.kind,
    at: rotateVec(marker.at, turnDeg),
    slots: marker.kind === "town" ? 1 : Math.max(1, marker.slots ?? 1),
    angle: (marker.angle ?? 0) + turnDeg,
    layout: marker.layout ?? "pill",
    scale: markerScale,
  };
}

function buildArt(
  tracks: readonly string[],
  markers: ArtMarker[],
  tier: TileColorTier | null,
  turnDeg: number,
): HexArt | null {
  const built: ArtTrack[] = [];
  for (const d of tracks) {
    const samples = sampleTrack(d, turnDeg);
    if (!samples) return null;
    built.push({ d, samples });
  }
  return { tracks: built, markers, tier, turnDeg };
}

/** A laid tile's artwork at its orientation, or `null` for an id with no authored artwork. */
export function hexArtForTile(tileId: number, orientation: number): HexArt | null {
  const art = TILE_GRAPHICS_CATALOG[tileId];
  const entry = TILE_CATALOG_BY_ID.get(tileId);
  if (!art || !entry) return null;
  const rot = ((orientation % 6) + 6) % 6;
  const turnDeg = -60 * rot;
  const markerScale = markerSizeFor(art.markers, 1);
  return buildArt(
    art.tracks,
    art.markers.map((marker) => markerFrom(marker, turnDeg, markerScale)),
    entry.color,
    turnDeg,
  );
}

/** What `HexGridRenderer` paints on an UNLAID hex, as artwork -- the same tables, in the same order its
 *  printed passes consult them: a landmark's printed track and stations, then the yellow OO pair, then a town
 *  or city designation, and otherwise nothing at all. Gray and off-board hexes are never laid on and are not
 *  described. `null` only for a label this board does not know. */
export function hexArtForPrinted(label: string): HexArt | null {
  const hex = STATIC_BOARD_HEXES.find((entry) => entry.label === label);
  const landmark = LANDMARK_HEXES.some((entry) => entry.label === label);
  if (!hex && !landmark) return null;

  if (landmark) {
    const markers = printedMarkersFor(label);
    const markerScale = markerSizeFor(markers, 1);
    return buildArt(
      printedTracksFor(label) ?? [],
      markers.map((marker) => markerFrom(marker, 0, markerScale)),
      null,
      0,
    );
  }
  const [node0, node1] = twoNodePositions({ x: 0, y: 0 }, 1);
  const point = (at: Vec, kind: "city" | "town", markerScale: number): ArtMarker => ({
    kind,
    at,
    slots: 1,
    angle: 0,
    layout: "pill",
    scale: markerScale,
  });
  // `drawOOCityMarkers`: two full-size circles on the shared diagonal, no track.
  if (hex && YELLOW_OO_HEXES.has(label)) {
    return buildArt([], [point(node0, "city", 1), point(node1, "city", 1)], null, 0);
  }
  // The designation passes: two dits at 0.85 on the diagonal, one dit or one circle at the centre.
  if (hex?.townDesignation === "double") {
    return buildArt([], [point(node0, "town", 0.85), point(node1, "town", 0.85)], null, 0);
  }
  if (hex?.townDesignation === "single") return buildArt([], [point({ x: 0, y: 0 }, "town", 1)], null, 0);
  if (hex?.cityDesignation) return buildArt([], [point({ x: 0, y: 0 }, "city", 1)], null, 0);
  return buildArt([], [], null, 0);
}

/** Whether an unlaid hex shows the board's own ground (and so needs a neutral foundation under a new lay),
 *  rather than a printed yellow tile the new one replaces. */
function unlaidHexShowsGround(label: string | null): boolean {
  if (label === null) return true;
  const hex = STATIC_BOARD_HEXES.find((entry) => entry.label === label);
  return hex?.printedColor === undefined;
}

/* ------------------------------------------------------------------ */
/* Pieces                                                             */
/* ------------------------------------------------------------------ */

export type PieceNode = { kind: "edge"; edge: number } | { kind: "marker"; index: number } | { kind: "free"; id: number };

export interface Piece {
  from: PieceNode;
  to: PieceNode;
  /** Arc-length resampled, oriented `from` -> `to`. */
  points: Vec[];
  /** Index into the art's `tracks`. */
  track: number;
}

const PIECE_POINTS = 24;
/** A marker counts as ON a rail within this distance; the catalog's worst is 0.0016 (#1461). */
const ON_RAIL = 0.02;
const EDGE_MIDPOINT_RADIUS = Math.sqrt(3) / 2;

function edgeAt(point: Vec): number | null {
  for (let edge = 0; edge < 6; edge += 1) {
    const angle = (-60 * edge * Math.PI) / 180;
    const mid = { x: EDGE_MIDPOINT_RADIUS * Math.cos(angle), y: EDGE_MIDPOINT_RADIUS * Math.sin(angle) };
    if (dist(point, mid) < 0.03) return edge;
  }
  return null;
}

function polylineLength(points: readonly Vec[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i += 1) total += dist(points[i - 1], points[i]);
  return total;
}

/** `count` points spaced evenly by arc length along `points`. */
export function resample(points: readonly Vec[], count: number): Vec[] {
  if (points.length === 0) return [];
  if (points.length === 1) return Array.from({ length: count }, () => points[0]);
  const cumulative = [0];
  for (let i = 1; i < points.length; i += 1) cumulative.push(cumulative[i - 1] + dist(points[i - 1], points[i]));
  const total = cumulative[cumulative.length - 1];
  const out: Vec[] = [];
  let segment = 1;
  for (let k = 0; k < count; k += 1) {
    const target = count === 1 ? 0 : (total * k) / (count - 1);
    while (segment < points.length - 1 && cumulative[segment] < target) segment += 1;
    const a = cumulative[segment - 1];
    const b = cumulative[segment];
    const u = b - a < 1e-12 ? 0 : (target - a) / (b - a);
    out.push(lerpVec(points[segment - 1], points[segment], clamp01(u)));
  }
  out[0] = points[0];
  out[count - 1] = points[points.length - 1];
  return out;
}

/** Every rail of `art`, cut at the markers that sit on it. */
export function piecesOf(art: HexArt): Piece[] {
  const pieces: Piece[] = [];
  let freeId = 0;
  art.tracks.forEach((track, trackIndex) => {
    const samples = track.samples;
    const last = samples.length - 1;
    const nodeAtEnd = (point: Vec): PieceNode => {
      const edge = edgeAt(point);
      if (edge !== null) return { kind: "edge", edge };
      const marker = art.markers.findIndex((m) => dist(m.at, point) < ON_RAIL);
      if (marker >= 0) return { kind: "marker", index: marker };
      freeId += 1;
      return { kind: "free", id: freeId };
    };
    const startNode = nodeAtEnd(samples[0]);
    const endNode = nodeAtEnd(samples[last]);

    const cuts: Array<{ index: number; marker: number }> = [];
    art.markers.forEach((marker, markerIndex) => {
      if (startNode.kind === "marker" && startNode.index === markerIndex) return;
      if (endNode.kind === "marker" && endNode.index === markerIndex) return;
      let best = -1;
      let bestDistance = Infinity;
      samples.forEach((point, index) => {
        const d = dist(point, marker.at);
        if (d < bestDistance) {
          bestDistance = d;
          best = index;
        }
      });
      if (best > 0 && best < last && bestDistance < ON_RAIL * 4) cuts.push({ index: best, marker: markerIndex });
    });
    cuts.sort((a, b) => a.index - b.index);

    const bounds: Array<{ index: number; node: PieceNode; at: Vec }> = [
      { index: 0, node: startNode, at: samples[0] },
      ...cuts.map((cut) => ({ index: cut.index, node: { kind: "marker", index: cut.marker } as PieceNode, at: art.markers[cut.marker].at })),
      { index: last, node: endNode, at: samples[last] },
    ];
    for (let b = 1; b < bounds.length; b += 1) {
      const from = bounds[b - 1];
      const to = bounds[b];
      if (to.index <= from.index) continue;
      const raw = samples.slice(from.index, to.index + 1);
      raw[0] = from.at;
      raw[raw.length - 1] = to.at;
      if (polylineLength(raw) < 0.02) continue;
      pieces.push({ from: from.node, to: to.node, points: resample(raw, PIECE_POINTS), track: trackIndex });
    }
  });
  return pieces;
}

/** Edges each marker reaches directly through one piece. */
function markerEdges(art: HexArt, pieces: readonly Piece[]): Array<Set<number>> {
  const edges = art.markers.map(() => new Set<number>());
  for (const piece of pieces) {
    const ends = [piece.from, piece.to];
    const marker = ends.find((node) => node.kind === "marker") as { kind: "marker"; index: number } | undefined;
    const edge = ends.find((node) => node.kind === "edge") as { kind: "edge"; edge: number } | undefined;
    if (marker && edge) edges[marker.index].add(edge.edge);
  }
  return edges;
}

/* ==================================================================
 *  DESIGN NOTE 1462: CITIES CORRESPOND BY THE RAILS THEY OWN, THEN BY WHERE THEY STAND
 * ==================================================================
 * A revenue centre on the old art is the SAME centre on the new art when the edges it reaches are still
 * reached by one centre of the same kind. That is the whole test, and it is geometry: it asks which edges a
 * marker's own pieces touch, which the drawing already fixes.
 *
 * WHAT FALLS OUT OF IT, rather than being listed:
 *   one city whose slot count changes -- CAPACITY (#57 -> #14, #63 -> #513, #53 -> #884);
 *   one city whose marker moves -- MIGRATION (Baltimore/Boston to #53, New York's stubs to #54, the OO spurs
 *     to the brown OO curves, #3's apex town to #141's hub);
 *   several centres whose edges all land on one, leaving fewer centres of their kind -- a GENUINE MERGE
 *     (#54 -> #883; every double town to #87/#88/#204);
 *   a centre with no predecessor -- it EMERGES. Of the transitions the placement filter currently accepts, only
 *     #59 -> brown OO facings that put both #59 cities' rails into one brown city produce one; fixed OO, the
 *     rule this implementation plays, keeps each #59 city its own brown city, so those facings are rules-illegal
 *     (VISUAL_FLOURISH_BACKLOG.md D-22). The matcher describes such a pair as its geometry reads, a merge beside
 *     an emergence; nothing here takes that as a merge.
 * Slot count is never how a city is identified: a two-slot city is one city, and #883's four slots are one.
 *
 * AN UNCONNECTED CENTRE HAS NO EDGES TO ASK -- the printed OO circles and the designation dits. Those pair
 * with the nearest unclaimed centre of their kind, one to one, which is a statement about where things are
 * drawn and nothing else. Tokens never follow this pairing; they follow authoritative state (#1466). */
export interface CityPlan {
  kind: "city" | "town";
  /** The destination marker (index into the destination art's markers). */
  dest: number;
  /** Source marker indices on the old art. */
  sources: number[];
  event: "static" | "migrate" | "capacity" | "reshape" | "merge" | "emerge";
  /** A capacity change that also moves. */
  migrates: boolean;
}

function assignMarkers(fromArt: HexArt, fromPieces: readonly Piece[], toArt: HexArt, toPieces: readonly Piece[]): Array<number | null> {
  const fromEdges = markerEdges(fromArt, fromPieces);
  const toEdges = markerEdges(toArt, toPieces);
  const mapping: Array<number | null> = fromArt.markers.map(() => null);

  fromArt.markers.forEach((marker, i) => {
    const own = fromEdges[i];
    if (own.size === 0) return;
    let best: { j: number; contains: boolean; overlap: number; d: number } | null = null;
    toArt.markers.forEach((candidate, j) => {
      if (candidate.kind !== marker.kind) return;
      const theirs = toEdges[j];
      let overlap = 0;
      own.forEach((edge) => {
        if (theirs.has(edge)) overlap += 1;
      });
      if (overlap === 0) return;
      const contains = overlap === own.size;
      const d = dist(marker.at, candidate.at);
      const better =
        best === null ||
        (contains && !best.contains) ||
        (contains === best.contains && (overlap > best.overlap || (overlap === best.overlap && d < best.d)));
      if (better) best = { j, contains, overlap, d };
    });
    if (best !== null) mapping[i] = (best as { j: number }).j;
  });

  // Unconnected centres: nearest unclaimed of their kind, one to one, closest pairs first.
  const claimed = new Set<number>();
  mapping.forEach((j) => {
    if (j !== null) claimed.add(j);
  });
  const pairs: Array<{ i: number; j: number; d: number }> = [];
  fromArt.markers.forEach((marker, i) => {
    if (mapping[i] !== null) return;
    toArt.markers.forEach((candidate, j) => {
      if (candidate.kind === marker.kind && !claimed.has(j)) pairs.push({ i, j, d: dist(marker.at, candidate.at) });
    });
  });
  pairs.sort((a, b) => a.d - b.d || a.i - b.i || a.j - b.j);
  const usedFrom = new Set<number>();
  for (const pair of pairs) {
    if (usedFrom.has(pair.i) || claimed.has(pair.j)) continue;
    mapping[pair.i] = pair.j;
    usedFrom.add(pair.i);
    claimed.add(pair.j);
  }
  // Anything still unpaired joins the nearest centre of its kind (a revenue centre persists; it does not vanish).
  fromArt.markers.forEach((marker, i) => {
    if (mapping[i] !== null) return;
    let bestJ: number | null = null;
    let bestD = Infinity;
    toArt.markers.forEach((candidate, j) => {
      if (candidate.kind !== marker.kind) return;
      const d = dist(marker.at, candidate.at);
      if (d < bestD) {
        bestD = d;
        bestJ = j;
      }
    });
    mapping[i] = bestJ;
  });
  return mapping;
}

/* ------------------------------------------------------------------ */
/* Station geometry                                                   */
/* ------------------------------------------------------------------ */

function slotSpacing(marker: ArtMarker): number {
  return PILL_SLOT_SPACING * marker.scale * STATION_RADIUS_RATIO;
}

/** Slot centres in board unit space, in the order `tileCitySlotPoints` returns them. */
export function slotCentres(marker: ArtMarker): Vec[] {
  if (marker.kind === "town" || marker.slots <= 1) return [marker.at];
  return slotOffsets(marker.slots, marker.layout, slotSpacing(marker), marker.angle).map((offset) => add(marker.at, offset));
}

/** The path the station outline is the fattened stroke of: one point for a circle, the two end slots for a
 *  pill, and the slot centres in cluster order (closed) for a triangle or square -- exactly what
 *  `drawStationCircle`, `drawStationPill` and `drawStationCluster` draw. */
export function outlineOf(marker: ArtMarker): { points: Vec[]; closed: boolean } {
  if (marker.kind === "town" || marker.slots <= 1) return { points: [marker.at], closed: false };
  const centres = slotCentres(marker);
  if (marker.layout === "triangle" || marker.layout === "square") return { points: centres, closed: true };
  return { points: [centres[0], centres[centres.length - 1]], closed: false };
}

/** Cheapest one-to-one pairing of `from` onto `to` (small sets: exhaustive up to 6, greedy beyond). */
function assignPoints(from: readonly Vec[], to: readonly Vec[]): number[] {
  const n = from.length;
  const m = to.length;
  if (n === 0) return [];
  if (n <= m && m <= 6) {
    let best: number[] = [];
    let bestCost = Infinity;
    const used: boolean[] = to.map(() => false);
    const current: number[] = [];
    const search = (i: number, cost: number) => {
      if (cost >= bestCost) return;
      if (i === n) {
        bestCost = cost;
        best = current.slice();
        return;
      }
      for (let j = 0; j < m; j += 1) {
        if (used[j]) continue;
        used[j] = true;
        current.push(j);
        search(i + 1, cost + dist(from[i], to[j]));
        current.pop();
        used[j] = false;
      }
    };
    search(0, 0);
    return best;
  }
  // More sources than targets (or large sets): each source to its nearest target.
  return from.map((point) => {
    let bestJ = 0;
    let bestD = Infinity;
    to.forEach((target, j) => {
      const d = dist(point, target);
      if (d < bestD) {
        bestD = d;
        bestJ = j;
      }
    });
    return bestJ;
  });
}

function centroid(points: readonly Vec[]): Vec {
  if (points.length === 0) return { x: 0, y: 0 };
  const total = points.reduce((sum, p) => add(sum, p), { x: 0, y: 0 });
  return scale(total, 1 / points.length);
}

/* ------------------------------------------------------------------ */
/* The plan                                                           */
/* ------------------------------------------------------------------ */

export type TrackClass = "persistent" | "reconfigured" | "added" | "removed";

export interface TrackPlan {
  cls: TrackClass;
  /** Destination piece (for persistent / reconfigured / added). */
  to: Piece | null;
  /** Source piece (for persistent / reconfigured / removed), oriented to match `to`. */
  from: Piece | null;
  /** Added pieces: construction window, and which end construction starts from. */
  start: number;
  duration: number;
  growsFromEnd: boolean;
  level: number;
}

export interface TileTransitionRequest {
  from: { kind: "tile"; tileId: number; orientation: number } | { kind: "printed"; label: string | null };
  to: { tileId: number; orientation: number };
  /** Board edges of this hex where a neighbour's rail arrives -- construction prefers to start there. */
  externalEdges?: readonly number[];
  reducedMotion?: boolean;
}

export interface TileTransitionPlan {
  fromArt: HexArt;
  toArt: HexArt;
  tracks: TrackPlan[];
  cities: CityPlan[];
  /** Old markers with no destination at all (only an unexpected pair produces one). */
  vanishing: number[];
  /** The source marker each old marker became, for token anchoring. */
  markerMapping: Array<number | null>;
  fromTier: TileColorTier | null;
  toTier: TileColorTier;
  /** A new lay on open ground lays a neutral foundation first. */
  foundation: boolean;
  reducedMotion: boolean;
  durationMs: number;
  /** Destination layer per destination track, and the destination's overpasses (board unit space). */
  destLayers: number[];
  destCrossings: Array<{ x: number; y: number; sinAngle: number; over: number }>;
}

const PERSIST_TOLERANCE = 0.015;

function nodeKey(node: PieceNode, mapping: ReadonlyArray<number | null> | null): string {
  if (node.kind === "edge") return `e${node.edge}`;
  if (node.kind === "free") return `f${node.id}`;
  if (mapping === null) return `m${node.index}`;
  const mapped = mapping[node.index];
  return mapped === null || mapped === undefined ? `o${node.index}` : `m${mapped}`;
}

function oriented(piece: Piece, mapping: ReadonlyArray<number | null> | null): { key: string; piece: Piece } {
  const a = nodeKey(piece.from, mapping);
  const b = nodeKey(piece.to, mapping);
  if (a <= b) return { key: `${a}|${b}`, piece };
  return {
    key: `${b}|${a}`,
    piece: { from: piece.to, to: piece.from, points: piece.points.slice().reverse(), track: piece.track },
  };
}

function maxPointDistance(a: readonly Vec[], b: readonly Vec[]): number {
  let worst = 0;
  for (let i = 0; i < Math.min(a.length, b.length); i += 1) worst = Math.max(worst, dist(a[i], b[i]));
  return worst;
}

/** The whole description of one old -> new transition, or `null` when either side has no artwork. */
export function planTileTransition(request: TileTransitionRequest): TileTransitionPlan | null {
  const fromArt =
    request.from.kind === "tile"
      ? hexArtForTile(request.from.tileId, request.from.orientation)
      : request.from.label === null
        ? buildArt([], [], null, 0)
        : hexArtForPrinted(request.from.label);
  const toArt = hexArtForTile(request.to.tileId, request.to.orientation);
  const toEntry = TILE_CATALOG_BY_ID.get(request.to.tileId);
  if (!fromArt || !toArt || !toEntry) return null;

  const fromPieces = piecesOf(fromArt);
  const toPieces = piecesOf(toArt);
  const mapping = assignMarkers(fromArt, fromPieces, toArt, toPieces);

  /* ---- cities ---- */
  const cities: CityPlan[] = toArt.markers.map((dest, j) => {
    const sources = mapping.flatMap((mapped, i) => (mapped === j ? [i] : []));
    let event: CityPlan["event"] = "static";
    let migrates = false;
    if (sources.length === 0) event = "emerge";
    else if (sources.length > 1) event = "merge";
    else {
      const source = fromArt.markers[sources[0]];
      migrates = dist(source.at, dest.at) > 0.01;
      if (dest.kind === "city" && source.slots !== dest.slots) event = "capacity";
      else if (migrates) event = "migrate";
      else if (dest.kind === "city") {
        const a = slotCentres(source);
        const b = slotCentres(dest);
        const order = assignPoints(a, b);
        const moved = a.some((point, k) => dist(point, b[order[k]]) > 0.005) || Math.abs(source.scale - dest.scale) > 1e-6;
        event = moved ? "reshape" : "static";
      }
    }
    return { kind: dest.kind, dest: j, sources, event, migrates };
  });
  const vanishing = mapping.flatMap((mapped, i) => (mapped === null ? [i] : []));

  /* ---- tracks ---- */
  const fromByKey = new Map<string, Piece[]>();
  fromPieces.forEach((piece) => {
    const { key, piece: o } = oriented(piece, mapping);
    fromByKey.set(key, [...(fromByKey.get(key) ?? []), o]);
  });
  const tracks: TrackPlan[] = [];
  const blank = { start: 0, duration: 0, growsFromEnd: false, level: 0 };
  toPieces.forEach((piece) => {
    const { key, piece: o } = oriented(piece, null);
    const candidates = fromByKey.get(key) ?? [];
    if (candidates.length === 0) {
      tracks.push({ cls: "added", to: o, from: null, ...blank });
      return;
    }
    let bestIndex = 0;
    let bestDistance = Infinity;
    candidates.forEach((candidate, index) => {
      const d = maxPointDistance(candidate.points, o.points);
      if (d < bestDistance) {
        bestDistance = d;
        bestIndex = index;
      }
    });
    const [match] = candidates.splice(bestIndex, 1);
    tracks.push({ cls: bestDistance < PERSIST_TOLERANCE ? "persistent" : "reconfigured", to: o, from: match, ...blank });
  });
  fromByKey.forEach((left) => left.forEach((piece) => tracks.push({ cls: "removed", to: null, from: piece, ...blank })));

  planConstruction(tracks, cities, request.externalEdges ?? []);

  const layers = trackLayersFor(toArt.tracks.map((track) => track.d));
  const destLayers = toArt.tracks.map(() => 0);
  layers.forEach((layer, layerIndex) => layer.forEach((trackIndex) => (destLayers[trackIndex] = layerIndex)));
  const destCrossings = trackCrossingsFor(
    toArt.tracks.map((track) => track.d),
    layers,
  ).map((crossing) => {
    const at = rotateVec({ x: crossing.x, y: crossing.y }, toArt.turnDeg);
    return { x: at.x, y: at.y, sinAngle: crossing.sinAngle, over: crossing.over };
  });

  const reducedMotion = request.reducedMotion === true;
  return {
    fromArt,
    toArt,
    tracks,
    cities,
    vanishing,
    markerMapping: mapping,
    fromTier: fromArt.tier,
    toTier: toEntry.color,
    foundation: request.from.kind === "printed" && unlaidHexShowsGround(request.from.label),
    reducedMotion,
    durationMs: reducedMotion ? TILE_TRANSITION_REDUCED_MS : TILE_TRANSITION_MS,
    destLayers,
    destCrossings,
  };
}

/* ==================================================================
 *  DESIGN NOTE 1467: CONSTRUCTION STARTS FROM WHAT ALREADY STANDS
 * ==================================================================
 * "Where there is a natural attachment to existing track or a city, construction should visually propagate
 * from that existing infrastructure toward the new destination." So an added piece grows from an ANCHORED
 * end, and its far end becomes an anchor once construction reaches it -- a fork's second arm starts where, and
 * when, the first one arrived.
 *
 * ANCHORS THAT STAND FROM THE START (level 0): every node a persistent or reconfigured piece touches; every
 * centre that has a predecessor; every edge where a neighbour's rail arrives (supplied by the renderer, which
 * alone can see the neighbours -- a picture of where the network comes from, not a connectivity verdict). When
 * both ends are anchored at the same level the CENTRE wins, so an upgraded city builds outward, then a rail
 * already inside the tile, then the neighbour's edge. A piece with no anchored end at all starts at its centre
 * if it has one, else at its lowest edge -- deterministic, and only reachable by an unconnected lay.
 *
 * WHEN EACH PIECE STARTS (#1469). A piece whose origin stands from the start begins with the construction
 * window, so branches from different anchors -- or several spokes from one city -- build at the same time
 * instead of queueing; so does an unconnected piece, which has nothing to wait for. A piece whose origin was
 * itself built begins the moment the wave arrives there, so the front passes from one piece into the next. The
 * travel time is the same for every piece of a transition, shortened only as far as the longest such chain
 * needs to settle inside the window. */
function planConstruction(tracks: TrackPlan[], cities: readonly CityPlan[], externalEdges: readonly number[]): void {
  const added = tracks.filter((track) => track.cls === "added" && track.to !== null);
  if (added.length === 0) return;
  type Anchor = { level: number; rank: number };
  // rank: 0 centre, 1 internal edge, 2 external edge
  const anchors = new Map<string, Anchor>();
  const anchor = (key: string, level: number, rank: number) => {
    const existing = anchors.get(key);
    if (!existing || level < existing.level || (level === existing.level && rank < existing.rank)) {
      anchors.set(key, { level, rank });
    }
  };
  for (const track of tracks) {
    if ((track.cls === "persistent" || track.cls === "reconfigured") && track.to) {
      [track.to.from, track.to.to].forEach((node) => anchor(nodeKey(node, null), 0, node.kind === "marker" ? 0 : 1));
    }
  }
  cities.forEach((city) => {
    if (city.sources.length > 0) anchor(`m${city.dest}`, 0, 0);
  });
  externalEdges.forEach((edge) => anchor(`e${edge}`, 0, 2));
  const standing = new Set(anchors.keys());

  // In picking order, so a node's arrival is known before any piece starts from it.
  const picks: Array<{ track: TrackPlan; near: string; far: string; unanchored: boolean }> = [];
  const pending = added.slice();
  let maxLevel = 0;
  while (pending.length > 0) {
    let pick = -1;
    let pickFromEnd = false;
    let pickAnchor: Anchor | null = null;
    pending.forEach((track, index) => {
      const piece = track.to as Piece;
      const ends: Array<{ key: string; fromEnd: boolean; isMarker: boolean; edge: number }> = [
        { key: nodeKey(piece.from, null), fromEnd: false, isMarker: piece.from.kind === "marker", edge: piece.from.kind === "edge" ? piece.from.edge : 9 },
        { key: nodeKey(piece.to, null), fromEnd: true, isMarker: piece.to.kind === "marker", edge: piece.to.kind === "edge" ? piece.to.edge : 9 },
      ];
      for (const end of ends) {
        const found = anchors.get(end.key);
        if (!found) continue;
        const better =
          pickAnchor === null ||
          found.level < pickAnchor.level ||
          (found.level === pickAnchor.level && found.rank < pickAnchor.rank);
        if (better) {
          pick = index;
          pickFromEnd = end.fromEnd;
          pickAnchor = found;
        }
      }
    });
    const unanchored = pick < 0;
    if (unanchored) {
      // Nothing anchored: start the first pending piece at its centre, else its lowest edge.
      pick = 0;
      const piece = pending[0].to as Piece;
      const fromRank = piece.from.kind === "marker" ? -1 : piece.from.kind === "edge" ? piece.from.edge : 99;
      const toRank = piece.to.kind === "marker" ? -1 : piece.to.kind === "edge" ? piece.to.edge : 99;
      pickFromEnd = toRank < fromRank;
      pickAnchor = { level: added.length === pending.length ? 0 : maxLevel + 1, rank: 0 };
    }
    const [track] = pending.splice(pick, 1);
    const piece = track.to as Piece;
    const level = (pickAnchor as Anchor).level;
    track.level = level;
    track.growsFromEnd = pickFromEnd;
    maxLevel = Math.max(maxLevel, level);
    const far = pickFromEnd ? piece.from : piece.to;
    const near = pickFromEnd ? piece.to : piece.from;
    anchor(nodeKey(near, null), level, near.kind === "marker" ? 0 : 1);
    anchor(nodeKey(far, null), level + 1, far.kind === "marker" ? 0 : 1);
    picks.push({ track, near: nodeKey(near, null), far: nodeKey(far, null), unanchored });
  }

  // How many pieces the wave crosses to finish each one: 1 from a standing (or unanchored) origin, one more than
  // the piece that reached a built origin first.
  const startsFresh = (pick: (typeof picks)[number]) => pick.unanchored || standing.has(pick.near);
  const depthAt = new Map<string, number>();
  let deepest = 1;
  for (const pick of picks) {
    const depth = startsFresh(pick) ? 1 : (depthAt.get(pick.near) ?? 0) + 1;
    depthAt.set(pick.far, Math.min(depthAt.get(pick.far) ?? Infinity, depth));
    deepest = Math.max(deepest, depth);
  }

  const [windowStart, windowEnd] = TIMELINE.construct;
  const settle = TIMELINE.constructSettle;
  const travel = Math.min(TIMELINE.constructTravel, (windowEnd - windowStart - settle) / deepest);
  const emergingCentres = new Set(cities.filter((city) => city.sources.length === 0).map((city) => `m${city.dest}`));
  const arrival = new Map<string, number>();
  for (const pick of picks) {
    let start = startsFresh(pick) ? windowStart : (arrival.get(pick.near) ?? windowStart);
    // A centre with no predecessor appears before rail leaves it.
    if (emergingCentres.has(pick.near)) start = Math.max(start, TIMELINE.emerge[0] + 0.1);
    start = Math.min(start, windowEnd - settle - travel);
    pick.track.start = start;
    pick.track.duration = travel + settle;
    if (pick.unanchored) arrival.set(pick.near, Math.min(arrival.get(pick.near) ?? Infinity, start));
    arrival.set(pick.far, Math.min(arrival.get(pick.far) ?? Infinity, start + travel));
  }
}

/* ------------------------------------------------------------------ */
/* Frames                                                             */
/* ------------------------------------------------------------------ */

export interface FrameFill {
  color: string;
  alpha: number;
}

/** The hex's one rim: its colour carried from the old tier's to the destination's by the wash, stroked once. */
export interface FrameRim {
  color: string;
  alpha: number;
}

export interface FrameTrack {
  points: Vec[];
  alpha: number;
  /** Destination track this belongs to (for layering and overpasses), or `null` for a fading old piece. */
  destTrack: number | null;
  /** Only on a portion of new rail that is still erupting (#1469): its pen -- outline and ink -- at this multiple of
   *  the board's, at `alpha`. Absent is the board's own pen. */
  widthScale?: number;
}

export interface FrameBlob {
  points: Vec[];
  closed: boolean;
  /** Station radius (centre to the middle of the rim), unit space. */
  radius: number;
  /** Absent is opaque. A merging city's own outline fades once the shape it joined has taken over (#1463). */
  alpha?: number;
}

export interface FrameRing {
  at: Vec;
  radius: number;
  lineScale: number;
  alpha: number;
}

export interface FrameCity {
  blobs: FrameBlob[];
  rings: FrameRing[];
  /** 1 while the slot rings are whole circles -- the old tile's before its slots move, the destination's once they
   *  settle -- and 0 while they are drawn as one dividing outline. */
  ringsWhole: number;
  /** Marker size fraction, for the rim width in pixels. */
  markerScale: number;
  alpha: number;
}

export interface FrameTown {
  at: Vec;
  radius: number;
  alpha: number;
}

export interface TileTransitionFrame {
  fills: FrameFill[];
  rim: FrameRim;
  tracks: FrameTrack[];
  crossings: Array<{ x: number; y: number; sinAngle: number; over: number }>;
  destLayers: number[];
  cities: FrameCity[];
  towns: FrameTown[];
  ink: string;
}

/** The neutral foundation a new lay is built on (#1464): unpainted board stock, light enough that the ink and
 *  the white stations read against it, and no tier's colour. */
export const FOUNDATION_FILL = "#c4bfb2";
export const FOUNDATION_STROKE = "#85806f";

function fillsAt(plan: TileTransitionPlan, easing: TransitionEasings): FrameFill[] {
  const fills: FrameFill[] = [];
  if (plan.fromTier) fills.push({ color: ERA_TILE_FILL[plan.fromTier], alpha: 1 });
  if (plan.foundation) fills.push({ color: FOUNDATION_FILL, alpha: easing.foundation });
  fills.push({ color: ERA_TILE_FILL[plan.toTier], alpha: easing.wash });
  return fills;
}

/* The fills are layers, because a wash over the old tier IS a crossfade. The rim is not: two rims stroked over each
   other antialias into a heavier line than either, so the settled frame would not be the tile pass's own stroke.
   One stroke, its colour mixed by the same wash. */
function rimAt(plan: TileTransitionPlan, easing: TransitionEasings): FrameRim {
  const to = COLOR_TIER_STROKE[plan.toTier];
  if (plan.fromTier) return { color: mixColor(COLOR_TIER_STROKE[plan.fromTier], to, easing.wash), alpha: 1 };
  if (plan.foundation) {
    return { color: mixColor(FOUNDATION_STROKE, to, easing.wash), alpha: Math.max(easing.foundation, easing.wash) };
  }
  return { color: to, alpha: easing.wash };
}

/** `#rrggbb` towards `#rrggbb`, exact at both ends. Anything else changes over at the midpoint. */
function mixColor(from: string, to: string, w: number): string {
  if (w <= 0) return from;
  if (w >= 1) return to;
  const hex = /^#[0-9a-fA-F]{6}$/;
  if (!hex.test(from) || !hex.test(to)) return w < 0.5 ? from : to;
  let out = "#";
  for (const offset of [1, 3, 5]) {
    const value = Math.round(lerp(parseInt(from.slice(offset, offset + 2), 16), parseInt(to.slice(offset, offset + 2), 16), w));
    out += (value < 16 ? "0" : "") + value.toString(16);
  }
  return out;
}

/* ==================================================================
 *  DESIGN NOTE 1469: NEW RAIL ERUPTS PORTION BY PORTION, BEHIND A TRAVELLING FRONT
 * ==================================================================
 * ASKED FOR: "a travelling eruption/construction wave, not a whole-path fade" -- from the piece's origin (#1467),
 * along its own geometry, successive small portions each fading rapidly in, briefly slightly larger and heavier,
 * then easing back to exactly the board's rail while the front moves on.
 *
 * A PIECE IS CUT BY ARC LENGTH, not by sample index, into portions about one rail-width long (the pen is 0.12 of
 * the hex size, and so is a portion): a curve builds along the curve at the same grain as a straight, and a
 * longer piece has more portions rather than longer ones. Never so few that the front pauses, though -- a
 * portion begins at most one settle after the one before it, so a short spur is cut finer instead of being built
 * in stutters. The count comes from the piece's own length, fixed for its whole life, so a piece stretched by a
 * migrating centre keeps its cuts as fractions of itself.
 *
 * The front reaches portion `i` of `n` at `start + travel * i / (n - 1)` -- the first erupts at the origin the
 * moment the piece starts, the last at the far node the moment the wave arrives there, which is when a piece
 * continuing from that node starts.
 *
 * A PORTION'S LOOK IS ITS AGE since the front reached it, in `constructSettle`s: hidden before, `eruption(age)`
 * during -- opacity up fast, width swelling to `1 + overshoot` and easing back to exactly 1 -- and SETTLED once
 * the age passes 1. Settled portions are always one prefix of the piece, pushed as ordinary rail with its
 * destination track, so layers and overpasses hold for everything already built; when the last portion
 * settles the piece is pushed as its whole polyline, the frame it always was.
 *
 * NOTHING IS MOVED TO MAKE THE ERUPTION. Every portion is a slice of the piece's own polyline -- its own points,
 * with an interpolated point at each cut -- so ends, curves and connections are the destination's exactly.
 * The overshoot is in the pen, not the path: the painter strokes an erupting portion's outline and ink wider,
 * butt-capped, so it swells across the rail, not along it. (Its one liberty is to start each portion half a pixel
 * back under the rail behind it, which closes an antialiasing seam and moves no cut.)
 *
 * The numbers are starting points for a playtest, not tuned values. */
export const CONSTRUCTION_WAVE = {
  /** Portion length along the piece, unit hex: about one rail width. */
  portion: 0.12,
  /** Peak extra width of an erupting portion, as a fraction of the board's pen. */
  overshoot: 0.15,
  /** Share of a portion's settle spent fading in. */
  fadeIn: 0.35,
  /** Share of a portion's settle at which it is widest. */
  peak: 0.3,
} as const;

/** How many portions a piece of `length` builds in when its wave travels for `travel` and each portion settles over
 *  `settle`: about one per rail width, and enough that consecutive portions begin no more than a settle apart. */
export function constructionPortions(length: number, travel: number, settle: number): number {
  const byLength = Math.round(length / CONSTRUCTION_WAVE.portion);
  const unbroken = settle > 0 ? Math.ceil(travel / settle - 1e-9) + 1 : 1;
  return Math.max(1, byLength, unbroken);
}

/** One portion's look at `age`: 0 as the front reaches it, 1 once it has settled to exactly the board's rail. */
export function eruption(age: number): { alpha: number; widthScale: number } {
  if (age <= 0) return { alpha: 0, widthScale: 1 };
  if (age >= 1) return { alpha: 1, widthScale: 1 };
  const { fadeIn, peak, overshoot } = CONSTRUCTION_WAVE;
  const swell = age < peak ? smoothstep(age / peak) : 1 - smoothstep((age - peak) / (1 - peak));
  return { alpha: smoothstep(age / fadeIn), widthScale: 1 + overshoot * swell };
}

/** The stretch of `points` between arc lengths `from` and `to`, cut at interpolated points on its own segments. */
export function slicePolyline(points: readonly Vec[], from: number, to: number): Vec[] {
  const out: Vec[] = [];
  let run = 0;
  for (let i = 1; i < points.length; i += 1) {
    const a = points[i - 1];
    const b = points[i];
    const step = dist(a, b);
    const next = run + step;
    if (next > from && run < to) {
      if (out.length === 0) out.push(step < 1e-12 ? a : lerpVec(a, b, (from - run) / step));
      if (next >= to) {
        out.push(step < 1e-12 ? b : lerpVec(a, b, (to - run) / step));
        return out;
      }
      out.push(b);
    }
    run = next;
  }
  return out;
}

/** An added piece at `t`, drawn from its origin (`points[0]`): the settled prefix, the portions erupting behind the
 *  front, and nothing beyond it (#1469). `restLength` is the piece's own length on the destination tile. */
function pushConstructionWave(
  frame: TileTransitionFrame,
  points: Vec[],
  restLength: number,
  destTrack: number,
  t: number,
  start: number,
  duration: number,
): void {
  if (t >= start + duration) {
    frame.tracks.push({ points, alpha: 1, destTrack });
    return;
  }
  const settle = Math.min(TIMELINE.constructSettle, duration / 2);
  const travel = duration - settle;
  const length = polylineLength(points);
  const count = constructionPortions(restLength, travel, settle);
  const ageOf = (i: number) => (t - (start + (count === 1 ? 0 : (travel * i) / (count - 1)))) / settle;
  let settled = 0;
  while (settled < count && ageOf(settled) >= 1) settled += 1;
  if (settled === count) {
    frame.tracks.push({ points, alpha: 1, destTrack });
    return;
  }
  const cut = (i: number) => (length * i) / count;
  if (settled > 0) frame.tracks.push({ points: slicePolyline(points, 0, cut(settled)), alpha: 1, destTrack });
  for (let i = settled; i < count; i += 1) {
    const age = ageOf(i);
    if (age <= 0) break;
    const look = eruption(age);
    frame.tracks.push({ points: slicePolyline(points, cut(i), cut(i + 1)), alpha: look.alpha, destTrack, widthScale: look.widthScale });
  }
}

function markerPositionAt(plan: TileTransitionPlan, city: CityPlan, geometry: number): Vec {
  const dest = plan.toArt.markers[city.dest];
  if (city.sources.length === 0) return dest.at;
  const source = centroid(city.sources.map((i) => plan.fromArt.markers[i].at));
  return lerpVec(source, dest.at, geometry);
}

function cityForMarker(plan: TileTransitionPlan, destMarker: number): CityPlan {
  return plan.cities[destMarker];
}

/** A small shake along `axis`, enveloped so it starts and ends at rest. */
function tension(t: number, axis: Vec): Vec {
  const u = windowProgress(t, TIMELINE.tension[0], TIMELINE.tension[1]);
  if (u <= 0 || u >= 1) return { x: 0, y: 0 };
  const amplitude = 0.014 * Math.sin(Math.PI * u) * Math.sin(Math.PI * 2 * 1.5 * u);
  return scale(axis, amplitude);
}

/** Circles' outline arcs that no other circle covers -- the ring system drawn as one shape while it divides. */
export function ringUnionArcs(rings: readonly FrameRing[]): Array<{ ring: number; start: number; end: number }> {
  const arcs: Array<{ ring: number; start: number; end: number }> = [];
  rings.forEach((ring, i) => {
    if (ring.alpha <= 0 || ring.radius <= 0) return;
    // Covered angular intervals, as [start, end] with start in [0, 2pi).
    const covered: Array<[number, number]> = [];
    let hidden = false;
    rings.forEach((other, j) => {
      if (i === j || other.alpha < 0.5 || other.radius <= 0) return;
      const d = dist(ring.at, other.at);
      if (d < 1e-6) {
        // Coincident: the earlier ring draws, the later is hidden.
        if (j < i) hidden = true;
        return;
      }
      if (d >= ring.radius + other.radius) return;
      if (d + ring.radius <= other.radius) {
        hidden = true;
        return;
      }
      if (d + other.radius <= ring.radius) return;
      const cosHalf = (ring.radius * ring.radius + d * d - other.radius * other.radius) / (2 * ring.radius * d);
      const half = Math.acos(Math.max(-1, Math.min(1, cosHalf)));
      const toward = Math.atan2(other.at.y - ring.at.y, other.at.x - ring.at.x);
      covered.push([toward - half, toward + half]);
    });
    if (hidden) return;
    if (covered.length === 0) {
      arcs.push({ ring: i, start: 0, end: Math.PI * 2 });
      return;
    }
    // Normalise, then walk the complement.
    const TAU = Math.PI * 2;
    const spans: Array<[number, number]> = [];
    covered.forEach(([a, b]) => {
      const s = ((a % TAU) + TAU) % TAU;
      const e = s + (b - a);
      if (e > TAU) {
        spans.push([s, TAU]);
        spans.push([0, e - TAU]);
      } else spans.push([s, e]);
    });
    spans.sort((a, b) => a[0] - b[0]);
    let cursor = 0;
    for (const [s, e] of spans) {
      if (s > cursor + 1e-6) arcs.push({ ring: i, start: cursor, end: s });
      cursor = Math.max(cursor, e);
    }
    if (cursor < TAU - 1e-6) arcs.push({ ring: i, start: cursor, end: TAU });
  });
  return arcs;
}

/** The arcs of each ring that `ringUnionArcs` leaves out -- where it runs inside another ring -- so a settling city
 *  can close its circles without stroking any arc twice. With the union: every drawn ring's full turn, once. */
export function ringCoveredArcs(
  rings: readonly FrameRing[],
  union: ReadonlyArray<{ ring: number; start: number; end: number }> = ringUnionArcs(rings),
): Array<{ ring: number; start: number; end: number }> {
  const TAU = Math.PI * 2;
  const arcs: Array<{ ring: number; start: number; end: number }> = [];
  rings.forEach((ring, i) => {
    if (ring.alpha <= 0 || ring.radius <= 0) return;
    const own = union.filter((arc) => arc.ring === i).sort((a, b) => a.start - b.start);
    let cursor = 0;
    for (const arc of own) {
      if (arc.start > cursor + 1e-6) arcs.push({ ring: i, start: cursor, end: arc.start });
      cursor = Math.max(cursor, arc.end);
    }
    if (cursor < TAU - 1e-6) arcs.push({ ring: i, start: cursor, end: TAU });
  });
  return arcs;
}

/* ==================================================================
 *  DESIGN NOTE 1463: STATION SLOTS DIVIDE, GATHER AND FUSE; THE CITY'S OUTLINE LEADS THEM
 * ==================================================================
 * THE OUTLINE MOVES FIRST, THE SLOTS FOLLOW. The enclosing shape begins extending at `outline`, the slot
 * rings pulse at `pulse` and separate over `divide`, and both finish on the destination's exact geometry --
 * "city begins extending -> station pulsates/splits slightly afterward -> city and slots settle together".
 *
 * THREE CHOREOGRAPHIES, chosen by the slot counts rather than by a tile id:
 *   ONE SLOT BECOMING MORE (1 -> 2, 1 -> 3): the lone ring pulses where it stands and divides; every
 *     destination slot starts from it. Mitosis.
 *   SEVERAL BECOMING ANOTHER NUMBER (2 -> 3, and #592's 2 -> 1): the rings gather toward the natural centre
 *     -- the city's own anchor as it moves -- pulse as one combined system, and reorganise outward. No
 *     existing ring is designated as the one that "creates" the new one.
 *   A MERGE: each source city's outline stretches toward the part of the destination nearest it, a neck
 *     grows between them (`fuse`) until the shapes are one, and existing slots travel directly to their
 *     nearest destination slots; slots the merged city adds emerge from its centre.
 * Everything is derived from the destination's own `slotOffsets` geometry -- the pill's axis, the triangle's
 * apex, the square's order -- so no shape is invented here.
 *
 * TOKENS ARE NOT SLOTS. Nothing in this section moves, splits, merges or creates a corporation token; the
 * renderer moves each token by itself from where it stood to where authoritative state puts it (#1466). */
function cityFrame(plan: TileTransitionPlan, city: CityPlan, t: number, easing: TransitionEasings): FrameCity {
  const dest = plan.toArt.markers[city.dest];
  const destOutline = outlineOf(dest);
  const destSlots = slotCentres(dest);
  const destRadius = dest.scale * STATION_RADIUS_RATIO;
  const destRingRadius = destRadius * SLOT_RING_RATIO;
  const sources = city.sources.map((i) => plan.fromArt.markers[i]);
  const outlineEase = settleEase(windowProgress(t, TIMELINE.outline[0], TIMELINE.outline[1]));
  const anchor = markerPositionAt(plan, city, easing.geometry);
  const destAxis = destSlots.length > 1 ? sub(destSlots[destSlots.length - 1], destSlots[0]) : { x: 1, y: 0 };
  const axisLength = Math.hypot(destAxis.x, destAxis.y) || 1;
  const axis = scale(destAxis, 1 / axisLength);
  const tense = city.event === "capacity" || city.event === "merge";
  const shake = tense ? tension(t, axis) : { x: 0, y: 0 };

  if (sources.length === 0) {
    // Emerges in place: the outline grows from its anchor.
    const grow = settleEase(windowProgress(t, TIMELINE.emerge[0], TIMELINE.emerge[1]));
    if (grow <= 0) return { blobs: [], rings: [], ringsWhole: 1, markerScale: dest.scale, alpha: 0 };
    return {
      blobs: [
        {
          points: destOutline.points.map((point) => lerpVec(dest.at, point, grow)),
          closed: destOutline.closed,
          radius: destRadius * grow,
        },
      ],
      rings:
        dest.slots > 1
          ? destSlots.map((slot) => ({ at: lerpVec(dest.at, slot, grow), radius: destRingRadius * grow, lineScale: 1, alpha: grow }))
          : [],
      ringsWhole: grow,
      markerScale: dest.scale,
      alpha: smoothstep(grow * 3),
    };
  }

  const radius = lerp(centroidScale(sources), dest.scale, easing.geometry) * STATION_RADIUS_RATIO;
  const markerScale = lerp(centroidScale(sources), dest.scale, easing.geometry);

  /* ---- outlines ---- */
  const blobs: FrameBlob[] = [];
  if (sources.length === 1) {
    blobs.push(morphOutline(outlineOf(sources[0]), destOutline, outlineEase, radius, shake));
  } else {
    // Partition the destination outline among the sources, nearest source anchor first.
    const nearestSource = (point: Vec) => {
      let best = 0;
      let bestD = Infinity;
      sources.forEach((source, s) => {
        const d = dist(point, source.at);
        if (d < bestD) {
          bestD = d;
          best = s;
        }
      });
      return best;
    };
    const owners = destOutline.points.map(nearestSource);
    const blobPoints: Vec[][] = sources.map(() => []);
    const allPoints: Vec[] = [];
    // Once the neck is the whole shape, each source's own outline is only a second stroke along part of it.
    const handOver = 1 - smoothstep(windowProgress(t, TIMELINE.settle[0], TIMELINE.settle[1]));
    sources.forEach((source, s) => {
      let subset = destOutline.points.filter((_, k) => owners[k] === s);
      if (subset.length === 0) {
        // More cities than outline points (two circles fusing into one): a source that owns no point of the
        // destination still travels to the nearest one and fuses there.
        let nearest = destOutline.points[0];
        destOutline.points.forEach((point) => {
          if (dist(point, source.at) < dist(nearest, source.at)) nearest = point;
        });
        subset = [nearest];
      }
      const morph = morphOutline(outlineOf(source), { points: subset, closed: destOutline.closed && subset.length >= 3 }, outlineEase, radius, shake);
      blobs.push({ ...morph, alpha: handOver });
      blobPoints[s] = morph.points;
    });
    // The neck: the destination outline, in destination order, through the owning blobs' current points.
    const cursor = sources.map(() => 0);
    destOutline.points.forEach((_, k) => {
      const s = owners[k];
      const points = blobPoints[s];
      allPoints.push(points[Math.min(cursor[s], points.length - 1)]);
      cursor[s] += 1;
    });
    // Blobs that own no destination point are joined to the neck at their own current position.
    sources.forEach((_, s) => {
      if (!owners.includes(s)) allPoints.push(blobPoints[s][0]);
    });
    const fuse = settleEase(windowProgress(t, TIMELINE.fuse[0], TIMELINE.fuse[1]));
    if (fuse > 0) blobs.push({ points: allPoints, closed: destOutline.closed || allPoints.length >= 3, radius: radius * fuse });
  }

  /* ---- rings ---- */
  const rings: FrameRing[] = [];
  const pulseU = windowProgress(t, TIMELINE.pulse[0], TIMELINE.pulse[1]);
  const pulse = pulseU > 0 && pulseU < 1 ? Math.sin(Math.PI * pulseU) : 0;
  const ringRadiusNow = lerp(centroidScale(sources), dest.scale, easing.geometry) * STATION_RADIUS_RATIO * SLOT_RING_RATIO;
  const sourceSlots = sources.flatMap((source) => slotCentres(source));
  const sourceHasRings = sources.some((source) => source.slots > 1);
  const destHasRings = dest.slots > 1;
  const changes = sourceSlots.length !== destSlots.length || city.event === "merge";
  // A ring is drawn on a multi-slot city only; a lone circle's slot is its whole face.
  const ringAlphaIn = sourceHasRings ? 1 : smoothstep(windowProgress(t, TIMELINE.pulse[0], TIMELINE.pulse[0] + 0.1));
  const ringAlphaOut = destHasRings ? 1 : 1 - smoothstep(windowProgress(t, TIMELINE.settle[0], TIMELINE.settle[1]));
  const ringAlpha = Math.min(changes ? ringAlphaIn : sourceHasRings ? 1 : 0, ringAlphaOut);

  if (!sourceHasRings && !destHasRings) {
    // One-slot cities on both sides -- migrating, or merging into one circle: a lone circle's slot is its whole
    // face, so there is no ring to draw and the outlines carry the whole change.
  } else if (city.event !== "merge" && sourceSlots.length === 1 && destSlots.length > 1) {
    // Mitosis.
    const divide = easing.slots;
    destSlots.forEach((slot) => {
      rings.push({
        at: add(lerpVec(anchor, slot, divide), shake),
        radius: ringRadiusNow * (1 + 0.14 * pulse),
        lineScale: 1 + 0.6 * pulse,
        alpha: ringAlpha,
      });
    });
  } else if (city.event !== "merge" && sourceSlots.length !== destSlots.length) {
    // Gather, pulse as one system, reorganise.
    const gather = smoothstep(windowProgress(t, TIMELINE.gather[0], TIMELINE.gather[1]));
    const divide = easing.slots;
    const gathered = sourceSlots.map((slot) => lerpVec(slot, anchor, 0.8 * gather));
    const order = assignPoints(destSlots.length >= gathered.length ? gathered : destSlots, destSlots.length >= gathered.length ? destSlots : gathered);
    const startFor: Vec[] = destSlots.map(() => anchor);
    if (destSlots.length >= gathered.length) {
      order.forEach((destIndex, sourceIndex) => (startFor[destIndex] = gathered[sourceIndex]));
    } else {
      order.forEach((sourceIndex, destIndex) => (startFor[destIndex] = gathered[sourceIndex]));
      // Sources that are not continued converge into the slot nearest them and fade.
      gathered.forEach((point, sourceIndex) => {
        if (order.includes(sourceIndex)) return;
        let nearest = 0;
        let nearestD = Infinity;
        destSlots.forEach((slot, k) => {
          const d = dist(point, slot);
          if (d < nearestD) {
            nearestD = d;
            nearest = k;
          }
        });
        rings.push({
          at: add(lerpVec(point, destSlots[nearest], divide), shake),
          radius: ringRadiusNow * (1 + 0.14 * pulse),
          lineScale: 1 + 0.6 * pulse,
          alpha: ringAlpha * (1 - divide),
        });
      });
    }
    const continued = new Set<number>(destSlots.length >= gathered.length ? order : destSlots.map((_, k) => k));
    // A slot the city gains appears out of the gathered system at the height of its pulse, never before.
    const emergence = smoothstep(windowProgress(t, TIMELINE.pulse[0] + 0.08, TIMELINE.pulse[1]));
    destSlots.forEach((slot, k) => {
      const gained = !continued.has(k);
      rings.push({
        at: add(lerpVec(startFor[k], slot, divide), shake),
        radius: ringRadiusNow * (1 + 0.14 * pulse) * (gained ? lerp(0.3, 1, emergence) : 1),
        lineScale: 1 + 0.6 * pulse,
        alpha: gained ? ringAlpha * emergence : ringAlpha,
      });
    });
  } else {
    // Same count, or a merge: slots travel directly; a merge's extra slots emerge from the centre.
    const travel = city.event === "merge" ? easing.slots : easing.geometry;
    const pairs = assignPoints(
      sourceSlots.length <= destSlots.length ? sourceSlots : destSlots,
      sourceSlots.length <= destSlots.length ? destSlots : sourceSlots,
    );
    const startFor: Array<Vec | null> = destSlots.map(() => null);
    if (sourceSlots.length <= destSlots.length) pairs.forEach((destIndex, sourceIndex) => (startFor[destIndex] = sourceSlots[sourceIndex]));
    else pairs.forEach((sourceIndex, destIndex) => (startFor[destIndex] = sourceSlots[sourceIndex]));
    const mergePulse = city.event === "merge" ? pulse : 0;
    if (sourceSlots.length > destSlots.length) {
      // Surplus source slots converge on their nearest destination slot and fade into it.
      sourceSlots.forEach((point, sourceIndex) => {
        if (pairs.includes(sourceIndex)) return;
        let nearest = 0;
        let nearestD = Infinity;
        destSlots.forEach((slot, k) => {
          const d = dist(point, slot);
          if (d < nearestD) {
            nearestD = d;
            nearest = k;
          }
        });
        rings.push({
          at: add(lerpVec(point, destSlots[nearest], travel), shake),
          radius: ringRadiusNow,
          lineScale: 1,
          alpha: ringAlpha * (1 - travel),
        });
      });
    }
    destSlots.forEach((slot, k) => {
      const start = startFor[k];
      const emerging = start === null;
      rings.push({
        at: add(emerging ? lerpVec(anchor, slot, travel) : lerpVec(start as Vec, slot, travel), shake),
        radius: ringRadiusNow * (emerging ? travel : 1) * (1 + 0.14 * mergePulse),
        lineScale: 1 + 0.6 * mergePulse,
        alpha: emerging ? Math.min(ringAlpha, travel) : ringAlpha,
      });
    });
  }

  /* Whole circles at both ends. A city that had rings starts from its own printed circles and lets their crossings go
     over the beat it tenses, as its slots begin to move; a city whose rings never move keeps them whole throughout;
     every city closes them again as it settles. */
  const departure = sourceHasRings
    ? city.event === "static"
      ? 1
      : 1 - smoothstep(windowProgress(t, TIMELINE.tension[0], TIMELINE.tension[1]))
    : 0;
  const settled = smoothstep(windowProgress(t, TIMELINE.settle[0], TIMELINE.settle[1]));
  return { blobs, rings, ringsWhole: Math.max(departure, settled), markerScale, alpha: 1 };
}

function centroidScale(sources: readonly ArtMarker[]): number {
  if (sources.length === 0) return 1;
  return sources.reduce((sum, source) => sum + source.scale, 0) / sources.length;
}

/** One outline becoming another: matched points travel, extra destination points extrude from the source's
 *  centre, surplus source points collapse onto their nearest destination point. Drawn in the destination's
 *  order, so the last frame is the destination's own path. */
function morphOutline(
  from: { points: Vec[]; closed: boolean },
  to: { points: Vec[]; closed: boolean },
  u: number,
  radius: number,
  shake: Vec,
): FrameBlob {
  if (to.points.length === 0) {
    return { points: from.points.map((point) => add(point, shake)), closed: from.closed, radius };
  }
  if (from.points.length <= to.points.length) {
    const order = assignPoints(from.points, to.points);
    const start: Vec[] = to.points.map(() => centroid(from.points));
    order.forEach((destIndex, sourceIndex) => (start[destIndex] = from.points[sourceIndex]));
    return {
      points: to.points.map((point, k) => add(lerpVec(start[k], point, u), shake)),
      closed: to.closed,
      radius,
    };
  }
  const order = assignPoints(from.points, to.points);
  return {
    points: from.points.map((point, k) => add(lerpVec(point, to.points[order[k]], u), shake)),
    closed: from.closed,
    radius,
  };
}

function townFrame(plan: TileTransitionPlan, city: CityPlan, easing: TransitionEasings, t: number): FrameTown[] {
  const dest = plan.toArt.markers[city.dest];
  const destRadius = dest.scale * 0.14;
  if (city.sources.length === 0) {
    const grow = settleEase(windowProgress(t, TIMELINE.emerge[0], TIMELINE.emerge[1]));
    return [{ at: dest.at, radius: destRadius * grow, alpha: 1 }];
  }
  // Each source dit travels to the destination; merging dits meet and fuse there -- and, once met, are one dit:
  // every dit after the first fades as the shape settles, so the settled frame draws the town once.
  const handOver = 1 - smoothstep(windowProgress(t, TIMELINE.settle[0], TIMELINE.settle[1]));
  return city.sources.map((i, k) => {
    const source = plan.fromArt.markers[i];
    return {
      at: lerpVec(source.at, dest.at, easing.geometry),
      radius: lerp(source.scale * 0.14, destRadius, easing.geometry),
      alpha: k === 0 ? 1 : handOver,
    };
  });
}

/** Moves a piece's point `k` so an end attached to a moving centre stays attached to it. */
function attachToMovingCentres(
  plan: TileTransitionPlan,
  piece: Piece,
  points: Vec[],
  geometry: number,
  fromStartOfPiece: boolean,
): Vec[] {
  const offsetFor = (node: PieceNode): Vec | null => {
    if (node.kind !== "marker") return null;
    const city = cityForMarker(plan, node.index);
    if (!city || city.sources.length === 0) return null;
    const now = markerPositionAt(plan, city, geometry);
    const final = plan.toArt.markers[node.index].at;
    const offset = sub(now, final);
    return Math.hypot(offset.x, offset.y) < 1e-6 ? null : offset;
  };
  const startOffset = offsetFor(piece.from);
  const endOffset = offsetFor(piece.to);
  if (!startOffset && !endOffset) return points;
  const count = PIECE_POINTS - 1;
  return points.map((point, index) => {
    // `index` counts along the drawn polyline; map it back onto the piece's own parameter.
    const along = fromStartOfPiece ? index / count : 1 - index / count;
    let moved = point;
    if (startOffset) moved = add(moved, scale(startOffset, 1 - along));
    if (endOffset) moved = add(moved, scale(endOffset, along));
    return moved;
  });
}

/** The picture at `t` in 0..1. `t >= 1` is the destination exactly; the renderer hands over before that. */
export function sampleTileTransition(plan: TileTransitionPlan, tRaw: number): TileTransitionFrame {
  const t = clamp01(tRaw);
  const easing = transitionEasings(plan, t);
  const ink = TILE_TRACK_INK[plan.toTier] ?? STANDARD_TRACK_INK;
  const frame: TileTransitionFrame = {
    fills: fillsAt(plan, easing),
    rim: rimAt(plan, easing),
    tracks: [],
    crossings: plan.destCrossings,
    destLayers: plan.destLayers,
    cities: [],
    towns: [],
    ink,
  };

  if (plan.reducedMotion) {
    const a = easing.wash;
    for (const track of plan.tracks) {
      if (track.from) frame.tracks.push({ points: track.from.points, alpha: 1 - a, destTrack: null });
      if (track.to) frame.tracks.push({ points: track.to.points, alpha: a, destTrack: track.to.track });
    }
    // Stations are opaque, so they swap at the midpoint rather than crossfading into a see-through pair.
    plan.fromArt.markers.forEach((marker) => pushStaticMarker(frame, marker, a < 0.5 ? 1 : 0));
    plan.toArt.markers.forEach((marker) => pushStaticMarker(frame, marker, a < 0.5 ? 0 : 1));
    return frame;
  }

  for (const track of plan.tracks) {
    if (track.cls === "removed" && track.from) {
      const fade = 1 - smoothstep(windowProgress(t, TIMELINE.vanish[0], TIMELINE.vanish[1]));
      if (fade > 0) frame.tracks.push({ points: track.from.points, alpha: fade, destTrack: null });
      continue;
    }
    const piece = track.to as Piece;
    if (track.cls === "persistent") {
      frame.tracks.push({ points: piece.points, alpha: 1, destTrack: piece.track });
    } else if (track.cls === "reconfigured" && track.from) {
      const from = track.from.points;
      frame.tracks.push({
        points: piece.points.map((point, k) => lerpVec(from[k], point, easing.geometry)),
        alpha: 1,
        destTrack: piece.track,
      });
    } else if (track.cls === "added") {
      if (t <= track.start) continue;
      const drawn = track.growsFromEnd ? piece.points.slice().reverse() : piece.points;
      const attached = attachToMovingCentres(plan, piece, drawn, easing.geometry, !track.growsFromEnd);
      pushConstructionWave(frame, attached, polylineLength(piece.points), piece.track, t, track.start, track.duration);
    }
  }

  for (const city of plan.cities) {
    if (city.kind === "town") frame.towns.push(...townFrame(plan, city, easing, t));
    else frame.cities.push(cityFrame(plan, city, t, easing));
  }
  const vanish = 1 - settleEase(windowProgress(t, TIMELINE.vanish[0], TIMELINE.vanish[1]));
  for (const index of plan.vanishing) {
    const marker = plan.fromArt.markers[index];
    if (vanish <= 0) break;
    if (marker.kind === "town") frame.towns.push({ at: marker.at, radius: marker.scale * 0.14 * vanish, alpha: 1 });
    else {
      const outline = outlineOf(marker);
      frame.cities.push({
        blobs: [{ points: outline.points, closed: outline.closed, radius: marker.scale * STATION_RADIUS_RATIO * vanish }],
        rings: [],
        ringsWhole: 1,
        markerScale: marker.scale,
        alpha: 1,
      });
    }
  }
  return frame;
}

function pushStaticMarker(frame: TileTransitionFrame, marker: ArtMarker, alpha: number): void {
  if (alpha <= 0) return;
  if (marker.kind === "town") {
    frame.towns.push({ at: marker.at, radius: marker.scale * 0.14, alpha });
    return;
  }
  const outline = outlineOf(marker);
  const radius = marker.scale * STATION_RADIUS_RATIO;
  frame.cities.push({
    blobs: [{ points: outline.points, closed: outline.closed, radius }],
    rings: marker.slots > 1 ? slotCentres(marker).map((at) => ({ at, radius: radius * SLOT_RING_RATIO, lineScale: 1, alpha: 1 })) : [],
    ringsWhole: 1,
    markerScale: marker.scale,
    alpha,
  });
}

/* ==================================================================
 *  DESIGN NOTE 1466: A TOKEN RIDES ITS CITY AND KEEPS ITS OWN IDENTITY
 * ==================================================================
 * A placed corporation token is an object with an owner, not a station slot. The renderer resolves where it
 * stood before (the old tile, the old city index) and where authoritative state puts it now, both through
 * the board's own token placement geometry, and hands the two points here. Nothing here decides a
 * destination.
 *
 * THE MOTION IS THE CITY'S, PLUS ITS OWN. The token travels with its city's anchor (so it never floats off a
 * migrating station) and separately moves from its old place in the city to its new one, in polar terms about
 * the anchor, so two tokens swapping sides of a reorganising city swing around it rather than through each
 * other. It never rides the gather of #1463: two tokens are never drawn pulled into one point, and a dividing
 * slot never draws a second copy of a token. */
export interface TokenMotion {
  from: Vec;
  fromRadius: number;
  /** The anchor of the city the token stood in, when known. */
  fromAnchor?: Vec;
  to: Vec;
  toRadius: number;
  toAnchor?: Vec;
}

export function tokenPositionAt(plan: TileTransitionPlan, t: number, motion: TokenMotion): { at: Vec; radius: number } {
  const easing = transitionEasings(plan, clamp01(t));
  if (plan.reducedMotion) {
    return easing.wash < 0.5 ? { at: motion.from, radius: motion.fromRadius } : { at: motion.to, radius: motion.toRadius };
  }
  const fromAnchor = motion.fromAnchor ?? motion.from;
  const toAnchor = motion.toAnchor ?? motion.to;
  const anchor = lerpVec(fromAnchor, toAnchor, easing.geometry);
  const a = sub(motion.from, fromAnchor);
  const b = sub(motion.to, toAnchor);
  const ra = Math.hypot(a.x, a.y);
  const rb = Math.hypot(b.x, b.y);
  let offset: Vec;
  if (ra < 0.02 || rb < 0.02) {
    offset = lerpVec(a, b, easing.slots);
  } else {
    const angleA = Math.atan2(a.y, a.x);
    let delta = Math.atan2(b.y, b.x) - angleA;
    while (delta > Math.PI) delta -= Math.PI * 2;
    while (delta < -Math.PI) delta += Math.PI * 2;
    const angle = angleA + delta * easing.slots;
    const r = lerp(ra, rb, easing.slots);
    offset = { x: Math.cos(angle) * r, y: Math.sin(angle) * r };
  }
  return { at: add(anchor, offset), radius: lerp(motion.fromRadius, motion.toRadius, easing.slots) };
}

/** A city's anchor on either side of the plan, by CITY index (towns excluded), for token motion. */
export function cityAnchor(plan: TileTransitionPlan, side: "from" | "to", cityIndex: number | undefined): Vec | undefined {
  if (cityIndex === undefined) return undefined;
  const art = side === "from" ? plan.fromArt : plan.toArt;
  const cities = art.markers.filter((marker) => marker.kind === "city");
  return cities[cityIndex]?.at;
}

/* ------------------------------------------------------------------ */
/* Presented-tile diffing, for the renderer's staging (#1465)          */
/* ------------------------------------------------------------------ */

export interface PresentedTile {
  tileId: number;
  orientation: number;
}

const TIER_RANK: Readonly<Record<TileColorTier, number>> = { Yellow: 0, Green: 1, Brown: 2, Gray: 3 };

/** Whether an old -> new change of the tile presented on a hex is one this flourish plays.
 *  A lay (nothing -> tile) and a replacement that does not drop a tier are; a removal, a downgrade, and a
 *  re-facing of the same tile (which only a replay or an undo produces) are not -- those snap. */
export function isAnimatableChange(from: PresentedTile | null, to: PresentedTile | null): boolean {
  if (to === null) return false;
  if (from === null) return true;
  if (from.tileId === to.tileId) return false;
  const a = TILE_CATALOG_BY_ID.get(from.tileId);
  const b = TILE_CATALOG_BY_ID.get(to.tileId);
  if (!a || !b) return false;
  return TIER_RANK[b.color] >= TIER_RANK[a.color];
}

/** Summary of a plan's classification -- what the batch report and the tests read. */
export function describeTransition(plan: TileTransitionPlan): {
  persistent: number;
  reconfigured: number;
  added: number;
  removed: number;
  cities: Array<{ kind: "city" | "town"; event: CityPlan["event"]; fromSlots: number[]; toSlots: number; migrates: boolean }>;
} {
  const count = (cls: TrackClass) => plan.tracks.filter((track) => track.cls === cls).length;
  return {
    persistent: count("persistent"),
    reconfigured: count("reconfigured"),
    added: count("added"),
    removed: count("removed"),
    cities: plan.cities.map((city) => ({
      kind: city.kind,
      event: city.event,
      fromSlots: city.sources.map((i) => plan.fromArt.markers[i].slots),
      toSlots: plan.toArt.markers[city.dest].slots,
      migrates: city.migrates,
    })),
  };
}
