// frontend/src/components/StockRoundPanel.tsx
//
// Stock Round action control panel -- a card per corporation carrying its prices, ownership table,
// operating snapshot and its own Buy/Sell/par controls. Renders above the Stock Market Matrix
// whenever a Stock Round is live. Buy/Sell ownership lives here entirely; `ContextualActionBar`'s
// Stock-Round button branch is empty so there are never two competing control surfaces.
//
// Presentational only -- `App.tsx` owns state and threads it down (design note #1) -- and adds no
// backend surface: `BuyStock`/`SellStock` already accept every parameter these controls produce.
//
// Design notes: see `docs/ai_architecture/stock_market.md`.

import PresidentCrown from "./PresidentCrown";
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type {
  PrivateCompanyState,
  PublicCompanyState,
  RoundType,
} from "../gameEngine/gameState";
import type { GamePhase, TierRustOutlook, TrainTier } from "../gameEngine/gamePhase";
// Design note #409: `TrainChips` is back, inline in the asset row. `CapacityPill` and
// `LastRoutePayout` stay out -- the train LIMIT is an Operating Round question, and the payout rides
// in the livery stripe (design note #392).
import { TrainChips } from "./TrainBadges";
// Design note #410: the corporate herald, shared with the action panel.
import { CorporateLogo } from "./CorporateLogo";
// Design note #1324: where the 20% standard certificate is, for its own buy button.
import { doubleCertificateAt, hasDoubleCertificate } from "../gameEngine/doubleCertificate";
// Design note #1323: the licence badge beside the herald.
import { KanawhaLicenseBadge } from "./KanawhaBadge";
import { licensesHeldBy } from "../gameEngine/kanawhaLicense";
// Design note #682: what a buy or a sale leaves the player holding, and which
// way it moves. The colour rule lives there because it is a claim about meaning.
import {
  describeTreasuryProjection,
  projectTreasury,
  type TreasuryProjection,
} from "../utils/treasuryProjection";
import {
  allowsMultipleBankPoolBuys,
  marketZoneForPrice,
  // Design note #712: the zone-tinted figure, shared with the dividend move line.
  ZonedPrice,
  PAR_BOX_PRICES,
} from "./StockMarketRenderer";
// Design note #791: the roster's one-word annotation -- "max", "tied", or nothing. Built on #780's
// `atHoldingCap`, which is shared with `sharePurchaseBlock` so the roster and the Buy button cannot disagree
// about whether a player has room.
import { holdingMarker } from "../utils/holdingMarkers";
// Design note #713: the sale's arithmetic and its two guards.
import { certificatesIn, saleProceeds } from "../gameEngine/shareSale";
// Design note #749: the float rule, shared with the reducer so the card and the board cannot disagree.
import {
  FLOAT_THRESHOLD_PERCENT,
  floatCostIn,
  metFloatThreshold,
  soldFromIpoPercent,
} from "../gameEngine/floatThreshold";
import { corporationFullName, corporationTitle } from "../utils/corporationNames";
// Design note #391/#395: the canonical rules text a private row expands to.
import { PRIVATE_COMPANY_CATALOG } from "../utils/privateCatalog";
import {
  applyCardOrder,
  openingCardOrder,
  operatingRoundCardOrder,
} from "../utils/corporationCardOrder";
import { StationTokenRow } from "./StationTokenRow";
import { stationTokenSlots } from "../gameEngine/stationTokens";
import { FONT_SIZE, RADIUS, VIEWPORT_RADIUS } from "../styles/typography";
// Design note #389: the same ink-on-fill helper the map's station
// tokens use, so a corporate colour is legible on the card for the
// same reason it is legible on the board.
import { bestContrastTextColor } from "./hexContractTypes";
import { corporationLiveryColor } from "../styles/corporationLivery";
import {
  CARD_BORDER,
  CARD_DIVIDER,
  CARD_HIGHLIGHT_BG,
  CARD_HIGHLIGHT_BORDER,
  CARD_HIGHLIGHT_INK,
  CARD_INK,
  CARD_INK_FAINT,
  CARD_INK_MUTED,
  CARD_SURFACE,
  CARD_SURFACE_MUTED,
  INK_VIEWPORT,
} from "../styles/palette";
import { showsCurseBesideName } from "../utils/carcosaCurse";
import CarcosaMark from "./CarcosaMark";
import { BO_LOCKED_CARD_NOTE } from "../gameEngine/gameVariants";
import { certificateCardsHeld, certificateCardsInPool } from "../gameEngine/doubleCertificate";
/* ==================================================================
    DESIGN NOTE 1451: THE CARD IS THE STAGE
   ==================================================================
   #1450's screen-space flight is gone. Slide-out movement across the shell is the TREASURY's vocabulary
   (#1272) and a certificate is not a dollar, so a stock transaction is now shown where it happens: inside the
   corporation card, as a border, a subdued table, and a percentage travelling between two rows of it.
   THE SEQUENCE IS PURE AND LIVES NEXT DOOR (`stockTransferFocus.ts`) -- which stage follows which, and how
   long each takes, is the part with real logic and the part a test can state. Everything below is the DRAWING
   of it: geometry measured off this panel's own DOM, and nothing leaves the card. */
import {
  buildFocusSequence,
  CROWN_OUT_MS,
  HANDOVER_MS,
  isStageParticipant,
  STOCK_TRANSFER_CSS,
  type FocusSequence,
  type FocusStage,
} from "./stockTransferFocus";
import {
  BANK_HOLDER,
  IPO_HOLDER,
  stagedOwnership,
  type AppliedSteps,
  type ShareHolder,
  type StockTransaction,
} from "../utils/stockTransaction";

export interface StockRoundPanelProps {
  /** Design note #1451: the stock transaction that just landed, for the affected card's own presentation.
   *  Forwarded straight to `CorporationRoster` -- #799's lesson, in one line: a prop declared on three
   *  interfaces and passed on two of them is invisible to `tsc` and silent at runtime. */
  transaction?: StockTransactionEvent | null;
  /** Design note #1457: the presidency cue, played by the shell on the beat this panel draws the crown. */
  onPresidencyCue?: () => void;
  publicCompanies: readonly PublicCompanyState[];
  /** Design note #712: why this purchase is illegal, or `null` if it is allowed. Resolved by `App`, which
   *  holds the whole board -- the certificate limit needs the private companies and the room's size, neither
   *  of which this panel is given. A FUNCTION rather than a precomputed string per card, because the answer
   *  depends on the source and quantity the player has selected HERE. */
  /** Design note #713: why this SALE is illegal, or `null`. Resolved by `App` for the same reason
   *  `purchaseBlockFor` is -- the successor rule reads every player's holdings. */
  saleBlockFor?: (companyId: number, percentage: number) => string | null;
  /** Design note #713: where the token lands after selling this many certificates, or `null` when the
   *  chart cannot say. The WALK lives in `projectShareSaleMove`, which owns the direction. */
  salePriceAfter?: (companyId: number, certificates: number) => number | null;
  /** ==================================================================
   *   DESIGN NOTE 1141: THE PANEL ASKS FOR THE CHART, IT DOES NOT DRAW IT
   *  ==================================================================
   *
   * The same split the action bar takes: this panel is given PRICES (`salePriceAfter` returns a number) and
   * has no cell coordinates and no other corporation's position. `App` owns the modal because `App` owns the
   * board -- see the note on `onPeekMarket` there. The certificate count travels with the call because the
   * size the player has selected is what decides how far the token falls. */
  onPeekSaleMarket?: (companyId: number, certificates: number) => void;
  purchaseBlockFor?: (
    companyId: number,
    source: "Ipo" | "Bank",
    quantity: number,
    certificate?: "double", // #1324
  ) => string | null;
  /** Design note #395: the room's private companies, so each card can list
   *  the ones its corporation owns. Optional -- a caller without game state
   *  simply renders no private rows. */
  privateCompanies?: readonly PrivateCompanyState[];
  /** Design note #398: the par selection for ONE corporation. A lookup
   *  rather than a value -- a single shared string made every card's ladder
   *  a view of the same selection, so pressing $90 on the PRR moved the
   *  B&O's ladder with it. */
  parValueFor: (companyId: number) => string;
  onSelectParValue: (companyId: number, value: string) => void;
  /** `App.tsx` design note #29: the target company travels with the click. Every card renders its own
   *  Buy/Sell, so there is no shared selection for these to read. */
  onBuyShare: (protocolId: number, source: "Ipo" | "Bank", quantity: number) => void;
  /** Design note #1324: the 20% standard certificate (ERIE, N&W under the Level Playing Field), bought whole. */
  onBuyDoubleCertificate?: (protocolId: number, source: "Ipo" | "Bank") => void;
  onSellShares: (protocolId: number, percentage: number) => void;
  sessionReady: boolean;
  isMyTurn: boolean;
  /* Design note #34: hotseat, and who is up. "Waiting for your turn..." named nobody, so on a shared
     keyboard it was a prompt to wait for yourself -- and every seat truncated to the same address
     (auction dashboard #31). `hotseat` shows the seat's NAME and drops the waiting framing entirely. */
  hotseat?: boolean;
  /** Whose turn it is, already resolved to a name. */
  activePlayerLabel?: string | null;
  /** Design note #682: the acting seat's own colour, for the treasury block.
   *  `null` when it is not known -- the block then falls back to the card's ink
   *  rather than inventing a seat, which is the same rule `playerLabel` follows
   *  for a name it cannot resolve. */
  actingSeatColor?: string | null;
  /** F-6: the connected wallet, needed to find THIS player's own stake in
   *  `player_holdings` and so bound the sell sizes to what they can actually
   *  cover. `null` when disconnected, which zeroes every option -- correct,
   *  since a disconnected viewer holds nothing to sell. */
  connectedAddress: string | null;
  /** Design note #356: the Stock Round's number. `1` bans selling. */
  macroRoundNumber?: number;
  /** Design note #357: what this player can actually spend. `null` when the
   *  room does not report it, which leaves the gate off. */
  playerCash?: number | null;
  /** Design note #8: live market price per `company_id`. A SEPARATE prop because on a real chain it is
   *  separate data -- `GetGameState` carries par and ownership, `GetMarketGrid` the live position.
   *  Missing/`null` means "no market position" and renders as a dash, never `0`. */
  marketPrices?: Readonly<Record<number, number | null>>;
  /** Optional address -> display name, so a roster can read "Alice" instead
   *  of `juno1abc...wxyz`. Returns `null` to fall back to truncation. Used
   *  by the sandbox; on a real chain there are no names to resolve yet. */
  playerLabel?: (address: string) => string | null;
  /** ==================================================================
   *   DESIGN NOTE 1110: THE ROSTER LEARNS WHO IS WHO
   *  ==================================================================
   *
   * ASKED: "printing the player names in their respective player colors, and perhaps using the player
   * colour to highlight the line for each player instead of yellow."
   *
   * SHAPED LIKE `playerLabel` DELIBERATELY -- same optional callback, same `null` for an address with no
   * seat. This panel cannot work the colour out for itself: `seatColor` falls back to the palette BY SEAT
   * INDEX, and the roster is ordered by holding, so asking here would hand row 3 seat 3's colour and be
   * confidently wrong. The shell owns the seating; it answers. */
  colorForAddress?: (address: string) => string | null;
  /** The room's derived phase (`gameEngine/gamePhase.ts`) for the operating snapshot -- train limit and which
   *  tier is about to rust. Optional: without it the capacity pill reads "n / ?", which is honest. */
  phase?: GamePhase | null;
  /** Per-tier rust countdown, so the card-front chips can say how far off a
   *  rust is -- see `TrainBadges.tsx` design note #4. */
  outlook?: Readonly<Record<TrainTier, TierRustOutlook>> | null;
  /** Why buying and selling are unavailable, or `null` when they are legal. Design note #32: the roster
   *  became a persistent tab (`App.tsx #41`), so it is reachable outside a Stock Round. */
  actionsLockedReason?: string | null;
  /** ==================================================================
   *   DESIGN NOTE 1173: A PRESS THIS PLAYER HAS MADE AND NOT YET SEEN LAND
   *  ==================================================================
   *
   * In a room an action is APPENDED and the board moves when the snapshot replays it, so for one round trip
   * a player who has already bought still reads their own turn as live. That is the window they clicked
   * twice in, and it is how one purchase became two.
   *
   * A SEPARATE CONDITION FROM `isMyTurn`, not a narrowing of it, because during this window it genuinely IS
   * their turn -- the state simply does not know yet that they have spent it. Folding the two together would
   * also make the header say "Waiting for your turn..." to the player whose turn it still is. */
  actionInFlight?: boolean;
  /** Design note #464: the round, so the card order is recomputed at the
   *  Operating Round boundary and held through the Stock Round. */
  roundType: RoundType | null;
  /** Design note #948: corporations whose whole card is inert -- the delayed auction's B&O lock. Forwarded
   *  to the roster; empty in a standard game. */
  lockedCompanyIds?: readonly number[];
}

// Design note #8: the corporation roster -- a card each, so "who controls what, and what would it
// cost me" can be answered without clicking through all eight.
// THE PRESIDENT IS THE POINT: presidency is the only thing conferring control, it changes hands
// silently, and it is marked twice over (gold row + the spelled-out word) because colour alone fails a
// colourblind player and a word alone is skimmed past. The crown glyph was the third channel and
// design note #490 removed it -- an emoji ignores `color`/`fontWeight` and cannot be styled to match.
// NEVER DERIVED: `president` is a contract field. 1830 presidency transfers only when someone strictly
// exceeds the incumbent, so the largest holder is not reliably the president.

/** One row of the per-company holdings table. */
interface RosterHolding {
  address: string;
  percentage: number;
  isPresident: boolean;
  isSelf: boolean;
  /** Design note #1454: a landing row for a transfer in progress. The player is a named participant of the
   *  current step who holds nothing in the STAGED board -- so the row exists to be an anchor, and says so by
   *  printing the card's absence dash rather than a holding. */
  pending: boolean;
}

/* ==================================================================
    DESIGN NOTE 1148: THE SAME FACT IN THE OTHER UNIT, ON THE BADGE THAT ALREADY STATES IT
   ==================================================================
   ASKED: "make the float progress in the colour stripe clickable to alternate to say something like
   '$[6xPar - sharesSold] of $[6xPar]'", and afterwards: "that can be a hoverable alternative display for
   non-touch devices, if possible."

   HOVER AND CLICK ARE THE SAME SWAP REACHED TWO WAYS, which is why this is one component and not two
   behaviours. A pointer that can hover gets the alternate for as long as it rests there and gives it back;
   a press -- the only gesture a touch screen has -- keeps it. Neither is the "real" control: the badge holds
   two readings of one number and either gesture turns it over.
   THE HOVER HALF IS CSS, because a `mouseenter` handler on a touch device fires on tap and then STICKS
   until something else is touched, which would make the press behave differently on the two device classes
   for no reason a player could learn. `@media (hover: hover) and (pointer: fine)` asks the browser the
   question directly, and `<style>` is this codebase's documented escape hatch for a rule inline styles
   cannot express (#46).

   WORDED "left of", NOT AS A BARE SLASH. The percentage reading is `sold / needed` -- PROGRESS -- and the
   money reading asked for is `remaining of total`, which is the opposite direction. Two readings that swap
   in one slot while silently reversing which end they measure from is a misreading waiting to happen, so
   the money form spends one word saying which it is. The percentages keep the slash they have always had.

   NO PAR, NO SECOND READING. An unparred corporation has no price, so there is no dollar figure to alternate
   to -- and the badge renders exactly as it did before this note, plain text with no affordance, rather than
   a control that turns over to show a blank. */
const FLOAT_BADGE_CSS = `
.float-badge-alt { display: none; }
@media (hover: hover) and (pointer: fine) {
  .float-badge:hover .float-badge-main { display: none; }
  .float-badge:hover .float-badge-alt { display: inline; }
}
`;

function FloatProgressBadge({
  company,
  liveryInk,
}: {
  company: Pick<PublicCompanyState, "ticker" | "par_value" | "ipo_pool_percentage">;
  liveryInk: string;
}) {
  const [showMoney, setShowMoney] = useState(false);
  const sold = soldFromIpoPercent(company);
  const par = company.par_value === null ? 0 : Number(company.par_value);
  const percentReading = `${sold}% / ${FLOAT_THRESHOLD_PERCENT}%`;
  const badgeStyle = { ...styles.rosterLiveryBadge, color: liveryInk, borderColor: liveryInk };

  if (!(par > 0)) {
    return (
      <span
        style={badgeStyle}
        title={`${sold}% has left the IPO; ${FLOAT_THRESHOLD_PERCENT}% floats this corporation.`}
      >
        {percentReading}
      </span>
    );
  }

  const { remaining } = floatCostIn(par, sold);
  /* ==================================================================
      DESIGN NOTE 1148a: "$268 LEFT OF $402" WAS AMBIGUOUS, AND THE FIX IS FEWER FIGURES
     ==================================================================
     REPORTED, of my own wording: "'$268 left of $402' is ambiguous/unclear to me, but I recognize your
     impulse as correct."
     THE IMPULSE WAS TO DISAMBIGUATE A DIRECTION. The percentage reading counts UP (`sold / needed`) and the
     money reading counts DOWN (what is still owed), and two readings that swap in one slot while silently
     reversing which end they measure from is a misreading waiting to happen -- so the money form had to say
     which it was. It said it by naming both ends, which resolved the direction and introduced a worse
     question: what IS the second number.
     THE TOTAL WAS NEVER THE POINT. Nobody at this table needs to know a float costs $402 in the abstract;
     they need to know what it still takes. Dropping it takes the ambiguity with it, and the one word that was
     doing the disambiguating -- "needed" -- does it just as well against a single figure.
     THE SAME SENTENCE AS THE PAR LADDER'S, deliberately. Both are `floatCostIn(...).remaining` on the same
     card, and at par-selection time they are numerically identical (nothing has left the IPO yet, so remaining
     IS the total). Two wordings for one quantity in one card is the fault this codebase keeps finding, so
     there is one wording. */
  const moneyReading = `$${remaining} needed to float`;
  /* The gesture decides which reading is RESTING; hover always shows the other one. So a player who has
     pressed the badge into money can still hover it for the percentage, rather than the affordance going
     dead once used. */
  const main = showMoney ? moneyReading : percentReading;
  const alt = showMoney ? percentReading : moneyReading;

  return (
    <button
      type="button"
      className="float-badge"
      style={{ ...badgeStyle, ...styles.floatBadgeButton }}
      onClick={() => setShowMoney((was) => !was)}
      aria-label={`${sold}% of ${FLOAT_THRESHOLD_PERCENT}% has left the IPO; ${moneyReading} to float. Activate to switch the reading.`}
      title={`${sold}% has left the IPO; ${FLOAT_THRESHOLD_PERCENT}% floats this corporation. ${moneyReading}.`}
    >
      <span className="float-badge-main">{main}</span>
      <span className="float-badge-alt">{alt}</span>
    </button>
  );
}

/* ==================================================================
 *  DESIGN NOTE 1451: THE CARD'S OWN ANIMATION MACHINERY, AND NO MORE THAN THAT
 * ==================================================================
 *
 * RULED: "Prefer the corporation-card rendering hierarchy to own the actual animation ... Do not create
 * another application-wide animation system."
 *
 * SO IT IS THREE HOOKS AND A CHIP, all in this file, none exported. The shell hands down a description of a
 * completed transaction and gets nothing back; everything between that prop and the pixels is here. There is
 * no registry, no layer, no portal and no shared vocabulary for some future effect to reuse -- if the route
 * animation wants a proxy, it can have its own, in its own file, measured against its own geometry.
 *
 * MEASURED IN LAYOUT PIXELS, WHICH IS WHY THERE IS NO SCALE ARITHMETIC ANYWHERE HERE. The shell's root
 * carries `zoom: uiScale` (#1144), so a `getBoundingClientRect` inside it reports VISUAL pixels and a length
 * written inside it is a LAYOUT pixel -- mixing the two is the trap that note exists for. `offsetTop` and
 * `offsetLeft` are layout pixels, the proxy is written in layout pixels, and both live inside the same zoomed
 * subtree. Nothing converts, so nothing can convert wrongly. #1450 had to reason about this constantly
 * because it drew outside the zoom; drawing inside the card makes the question disappear. */

/** What the shell hands down: the description, plus a token so two identical transactions in a row still
 *  replay rather than sitting finished (#1060's argument for the money machines' token). */
export interface StockTransactionEvent extends StockTransaction {
  token: number;
}

/** The house idiom, optional-chained twice because a test environment has a `window` and no `matchMedia`
 *  (`TreasuryMoneyMachine` #1272, `HexGridRenderer` #496). */
function prefersReducedMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches === true;
}

/** `node`'s position inside `ancestor`, in LAYOUT pixels. Walks the offset chain rather than trusting
 *  `offsetParent` to be the table: the viewer's own row carries a tint and a border (#1110), and a future
 *  positioned wrapper anywhere between would silently re-base every measurement below. */
function offsetWithin(node: HTMLElement, ancestor: HTMLElement): { left: number; top: number } {
  let left = 0;
  let top = 0;
  let current: HTMLElement | null = node;
  while (current && current !== ancestor) {
    left += current.offsetLeft;
    top += current.offsetTop;
    current = current.offsetParent as HTMLElement | null;
  }
  return { left, top };
}

/** The Shares cell belonging to `holder`, or `null`.
 *
 *  READ BY ATTRIBUTE RATHER THAN BY AN ATTRIBUTE SELECTOR: a key can be a player address, and addresses are
 *  not required to be safe inside a CSS selector's quotes. This is a loop over the ten-odd cells of ONE
 *  table, run at a stage change -- exact by construction, and cheaper than being right about a grammar. */
function stockCell(table: HTMLElement, holder: ShareHolder): HTMLElement | null {
  const cells = table.querySelectorAll<HTMLElement>("[data-stock-cell]");
  for (let index = 0; index < cells.length; index += 1) {
    if (cells[index].getAttribute("data-stock-cell") === holder) return cells[index];
  }
  return null;
}

/** The staged board before any beat has landed: `before`, whole. */
const NOTHING_APPLIED: AppliedSteps = { transfer: false, presidency: false };

/** Everything local to ONE sequence, held in a single value so that replacing the sequence replaces all of
 *  it at once and no part of one transaction can be read alongside another's. */
interface FocusProgress {
  sequence: FocusSequence | null;
  stageIndex: number;
  applied: AppliedSteps;
}

function startOfSequence(sequence: FocusSequence | null): FocusProgress {
  return { sequence, stageIndex: 0, applied: NOTHING_APPLIED };
}

/** The sequence, where it has got to, and how much of it the card has yet applied.
 *
 *  TWO CLOCKS OFF ONE LIST OF TIMERS. `stageIndex` drives what is MOVING and who is emphasised; `applied`
 *  drives what the figures SAY. They are deliberately not the same value -- the transfer's figures land
 *  three-quarters of the way through the transfer's own stage (#1452) -- and a single index could not
 *  express that without inventing half-stages nobody animates.
 *
 *  ==================================================================
 *   DESIGN NOTE 1456: THE RESET IS A RENDER, NOT AN EFFECT
 *  ==================================================================
 *
 *  REPORTED, of #1452's supersession: "That one-frame combination can reveal the new transaction's final
 *  ownership state before its animation begins."
 *
 *  IT COULD, AND THE CAUSE WAS WHERE THE RESET LIVED. `stageIndex` and `applied` were reset by a PASSIVE
 *  effect keyed on the sequence, and a passive effect runs after the commit. So a superseding transaction
 *  produced one full render -- paintable -- carrying the NEW sequence's snapshots with the OLD sequence's
 *  flags. If the superseded transaction had already resolved its transfer, `applied.transfer` was still true
 *  and `stagedOwnership` selected the new transaction's `after`: the finished board, a frame before its own
 *  animation started. The exact failure #1452 exists to prevent, arriving through the back door.
 *
 *  SO THE THREE VALUES BECAME ONE, AND IT IS ADJUSTED DURING RENDER. `FocusProgress` carries the sequence it
 *  belongs to, so "whose flags are these" is answerable rather than assumed; when it does not match, this
 *  render already uses a fresh one and `setProgress` tells React to re-run before committing anything. React
 *  discards the first pass, so the mismatched combination is never committed and cannot be painted.
 *  `live` IS RETURNED RATHER THAN `progress`, deliberately: the discarded pass is then correct too, so this
 *  does not depend on that discard for its result -- only for its efficiency.
 *
 *  THE TIMERS CARRY THEIR OWN GUARD BESIDES. Each updater checks the sequence before writing, so even a
 *  callback that somehow outlived its cleanup cannot advance a transaction that is no longer on screen. The
 *  superseded sequence is not queued and cannot resume: its timers are cleared and its progress is gone. */
function useStockTransferFocus(
  transaction: StockTransactionEvent | null,
  /** Design note #1457: fired ONCE per sequence, on the beat the arriving crown is drawn. */
  onCrownArrival?: () => void,
): {
  sequence: FocusSequence | null;
  stage: FocusStage | null;
  stageIndex: number;
  applied: AppliedSteps;
} {
  /* Keyed on the EVENT OBJECT, which the shell rebuilds per transaction -- so a new token is a new sequence
     and a re-render with the same event is not. */
  const sequence = useMemo(() => buildFocusSequence(transaction), [transaction]);
  const [progress, setProgress] = useState<FocusProgress>(() => startOfSequence(null));

  const live = progress.sequence === sequence ? progress : startOfSequence(sequence);
  if (live !== progress) setProgress(live);

  useEffect(() => {
    if (!sequence) return undefined;
    const timers: number[] = [];
    const advance = (at: number, step: (was: FocusProgress) => FocusProgress) => {
      timers.push(
        window.setTimeout(() => {
          /* Design note #1456: never write into a sequence this timer does not belong to. */
          setProgress((was) => (was.sequence !== sequence ? was : step(was)));
        }, at),
      );
    };
    sequence.stages.forEach((stage, index) => {
      if (index === 0) return;
      advance(stage.at, (was) => ({ ...was, stageIndex: index }));
    });
    sequence.applications.forEach((application) => {
      /* Design note #1453: EVERY key on this beat in ONE update. A first president arrives with the shares
         that bought the certificate, and two updates would be two renders with a paintable frame between
         them showing a board that never existed. */
      advance(application.at, (was) => {
        const applied = { ...was.applied };
        application.applies.forEach((field) => {
          applied[field] = true;
        });
        return { ...was, applied };
      });
    });
    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [sequence]);

  /* ==================================================================
      DESIGN NOTE 1457: THE PRESIDENCY CUE RIDES THE BEAT IT DESCRIBES
     ==================================================================
     RULED: "trigger this from the presentation event/beat that already controls `crownArrivesOn` / crown-in
     rather than separately trying to infer presidency changes from rendered DOM or authoritative state.
     There should be one semantic source for both."
     SO IT IS THE SAME TWO VALUES THE CROWN'S OWN CLASS READS: `crownArrivesOn` names the arrival and
     `applied.presidency` is the instant it lands. The sound cannot drift from the animation because there is
     nothing to keep in step -- one condition drives both.
     ONCE PER SEQUENCE, NOT PER RENDER. `cuedForRef` holds the sequence already announced, so a re-render at
     the same beat -- a poll, a resize, a parent update -- finds it spent. Sequence identity is the right key
     because a sequence IS one transaction's presentation: two identical takeovers in a row are two
     sequences and earn two cues.
     AND A SUPERSEDED SEQUENCE CANNOT FIRE LATE. Its timers are cleared and its progress discarded, so
     `applied.presidency` never becomes true for it; the ref moves on with the sequence rather than needing to
     be cleared. */
  const cuedForRef = useRef<FocusSequence | null>(null);
  const crownArrived = live.applied.presidency && sequence !== null && sequence.crownArrivesOn !== null;
  useEffect(() => {
    if (!crownArrived || sequence === null) return;
    if (cuedForRef.current === sequence) return;
    cuedForRef.current = sequence;
    onCrownArrival?.();
  }, [crownArrived, sequence, onCrownArrival]);

  return {
    sequence,
    stage: sequence ? (sequence.stages[live.stageIndex] ?? null) : null,
    stageIndex: live.stageIndex,
    applied: live.applied,
  };
}

interface ProxyPath {
  left: number;
  top: number;
  width: number;
  height: number;
  dx: number;
  dy: number;
}

interface StageProxies {
  stageIndex: number;
  forward: ProxyPath;
  /** The return leg, for the president's exchange only. */
  back: ProxyPath | null;
}

/** Where the current stage's proxy starts and how far it travels, measured after the commit.
 *
 *  A LAYOUT EFFECT, WHICH IS THE WHOLE TIMING ARGUMENT. The shell raises the event before React has painted
 *  the new board, so the destination row may not exist yet -- a player buying their first share of a
 *  corporation has no row in its table until this commit. A layout effect runs after the commit and before
 *  paint, so both cells are in the document and neither has been drawn in the wrong place first.
 *  `null` IS THE ORDINARY ANSWER, not an error: the wrong tab is open, the card is not rendered, or the
 *  reader has asked for reduced motion. The holdings underneath are already correct, which is the fallback.
 *
 *  ==================================================================
 *   DESIGN NOTE 1453/1454: WHY THIS MEASURES ONCE, AND WHY IT ALWAYS FINDS SOMETHING
 *  ==================================================================
 *  #1453's AUDIT FOUND A HOLE AND #1454 CLOSED IT, and both halves are worth keeping. The card stages from
 *  `before`, and `player_holdings` OMITS a holder at 0% (`gameState.ts`) -- so a player buying their FIRST
 *  share of a corporation, a par purchase included, had no destination row to measure and got no chip at
 *  all. That was the wrong fallback for one of the game's most common actions, and the roster draws a
 *  landing row for the step's participants now (#1454, on the roster build below). There is always
 *  something to aim at.
 *
 *  MEASURED ONCE PER STAGE, AND STILL NO RETRY. Two reasons, and the first outlived the hole: a purchase
 *  that overtakes a rival re-sorts the rows at the resolve beat, so a proxy re-measured mid-flight would
 *  jump. And a stage that genuinely cannot be measured -- the card is on another tab, or scrolled away --
 *  must not be launched late: a certificate arriving after the figures it was supposed to deliver is the
 *  exact ordering fault #1452 exists to remove. A late gesture is worse than none.
 *
 *  `null` REMAINS THE ORDINARY ANSWER for the cases above, and the holdings underneath are already correct,
 *  which is the whole fallback. */
function useTransferProxyGeometry(
  tableRef: React.MutableRefObject<HTMLDivElement | null>,
  sequence: FocusSequence | null,
  stage: FocusStage | null,
  stageIndex: number,
): StageProxies | null {
  const [proxies, setProxies] = useState<StageProxies | null>(null);

  useLayoutEffect(() => {
    const table = tableRef.current;
    const carriesAPercentage = stage !== null && (stage.kind === "transfer" || stage.kind === "exchange");
    if (!sequence || !table || !carriesAPercentage || prefersReducedMotion()) {
      setProxies(null);
      return;
    }
    const source = stockCell(table, stage.from);
    const target = stockCell(table, stage.to);
    if (!source || !target) {
      setProxies(null);
      return;
    }
    const from = offsetWithin(source, table);
    const to = offsetWithin(target, table);
    setProxies({
      stageIndex,
      forward: {
        left: from.left,
        top: from.top,
        width: source.offsetWidth,
        height: source.offsetHeight,
        dx: to.left - from.left,
        dy: to.top - from.top,
      },
      back:
        stage.kind !== "exchange"
          ? null
          : {
              left: to.left,
              top: to.top,
              width: target.offsetWidth,
              height: target.offsetHeight,
              dx: from.left - to.left,
              dy: from.top - to.top,
            },
    });
  }, [tableRef, sequence, stage, stageIndex]);

  /* Stamped with the stage it was measured for, so a render between a stage change and its measurement
     cannot draw the previous stage's proxy against the current stage's label. */
  return proxies !== null && proxies.stageIndex === stageIndex ? proxies : null;
}

/** The player rows bridging their old order and their new one.
 *
 *  A FLIP, AND IT IS GENERIC ON PURPOSE: this records where every row was at the last beat and animates
 *  whatever moved, rather than being told what moved it. Two things can: the crown landing (`applied
 *  .presidency` re-sorts the roster in exactly one commit) and a purchase overtaking a rival (`applied
 *  .transfer` does the same). Both get the same short glide, and nothing here has to agree with the sequence
 *  about which one it was looking at.
 *  INLINE STYLES, CLEARED ON A TIMER. An inline `transition` left behind would quietly apply to the next
 *  thing that moved this row, weeks later, in a file nobody is reading. */
function useRosterReorderFlip(
  tableRef: React.MutableRefObject<HTMLDivElement | null>,
  sequence: FocusSequence | null,
  stageIndex: number,
  /* Design note #1452: a dependency, because APPLYING a beat is what moves the rows now -- the crown lands
     with `applied.presidency` and a purchase can overtake a rival the moment `applied.transfer` lands. The
     stage index alone would have this measuring before the reorder and never after it. */
  applied: AppliedSteps,
  publicCompanies: readonly PublicCompanyState[],
): void {
  const rowTopsRef = useRef<Record<string, number> | null>(null);
  const cleanupRef = useRef<number | null>(null);

  useLayoutEffect(() => {
    const table = tableRef.current;
    if (!sequence || !table || prefersReducedMotion()) {
      rowTopsRef.current = null;
      return undefined;
    }
    const tops: Record<string, number> = {};
    const rows: Record<string, HTMLElement> = {};
    const cells = table.querySelectorAll<HTMLElement>("[data-stock-cell]");
    for (let index = 0; index < cells.length; index += 1) {
      const holder = cells[index].getAttribute("data-stock-cell");
      const row = cells[index].parentElement as HTMLElement | null;
      if (!holder || !row) continue;
      tops[holder] = offsetWithin(row, table).top;
      rows[holder] = row;
    }
    const previous = rowTopsRef.current;
    rowTopsRef.current = tops;
    if (!previous) return undefined;

    const moved: HTMLElement[] = [];
    for (const holder of Object.keys(tops)) {
      const was = previous[holder];
      if (was === undefined || was === tops[holder]) continue;
      const row = rows[holder];
      row.style.transition = "none";
      row.style.transform = `translateY(${was - tops[holder]}px)`;
      moved.push(row);
    }
    if (moved.length === 0) return undefined;

    const frame = window.requestAnimationFrame(() => {
      moved.forEach((row) => {
        row.style.transition = `transform ${HANDOVER_MS}ms cubic-bezier(0.22, 0.61, 0.36, 1)`;
        row.style.transform = "";
      });
    });
    if (cleanupRef.current !== null) window.clearTimeout(cleanupRef.current);
    cleanupRef.current = window.setTimeout(() => {
      moved.forEach((row) => {
        row.style.transition = "";
        row.style.transform = "";
      });
    }, HANDOVER_MS + 60);
    return () => window.cancelAnimationFrame(frame);
    /* `publicCompanies` is a dependency so a poll landing mid-sequence re-records the rows rather than
       leaving this comparing against a layout that has since changed underneath it. */
  }, [tableRef, sequence, stageIndex, applied, publicCompanies]);

  useEffect(
    () => () => {
      if (cleanupRef.current !== null) window.clearTimeout(cleanupRef.current);
    },
    [],
  );
}

/** `React.CSSProperties` plus the two custom properties the travel keyframe reads. Declared rather than cast,
 *  so the rest of the object is still checked. */
type ProxyStyle = React.CSSProperties & {
  "--stock-dx": string;
  "--stock-dy": string;
};

/** One percentage, in transit between two rows of one table. */
function TransferProxy({
  path,
  label,
  crowned,
  durationMs,
  color,
  ink,
}: {
  path: ProxyPath;
  label: string;
  /** The president's certificate, which is the one chip that is a particular card rather than an amount. */
  crowned: boolean;
  durationMs: number;
  color: string;
  ink: string;
}) {
  const travel: ProxyStyle = {
    left: `${path.left}px`,
    top: `${path.top}px`,
    width: `${path.width}px`,
    height: `${path.height}px`,
    animationDuration: `${durationMs}ms`,
    "--stock-dx": `${path.dx}px`,
    "--stock-dy": `${path.dy}px`,
  };
  return (
    /* TWO ELEMENTS: the outer travels, the inner fades and contracts. One element cannot do both, because
       both are `transform` -- and splitting them is also what lets the travel take an ease-out curve while
       the fade holds through the middle. */
    <span className="app-stock-proxy-travel" style={travel} aria-hidden="true">
      <span
        className="app-stock-proxy-chip"
        style={{
          ...styles.transferChip,
          backgroundColor: color,
          color: ink,
          animationDuration: `${durationMs}ms`,
        }}
      >
        {crowned && <PresidentCrown scale={0.85} label={null} />}
        {label}
      </span>
    </span>
  );
}

function CorporationRoster({
  publicCompanies,
  phase,
  outlook,
  marketPrices,
  roundType,
  connectedAddress,
  macroRoundNumber,
  playerCash,
  playerLabel,
  colorForAddress,
  privateCompanies,
  activeCompanyId,
  onActivateCompany,
  expandedPrivateId,
  setExpandedPrivateId,
  parValueFor,
  onSelectParValue,
  onBuyShare,
  onBuyDoubleCertificate,
  purchaseBlockFor,
  saleBlockFor,
  salePriceAfter,
  onPeekSaleMarket,
  onSellShares,
  controlsDisabled,
  controlsBlockedReason,
  actingSeatColor,
  tradingOpen,
  lockedCompanyIds = [],
  transaction,
  onPresidencyCue,
}: {
  publicCompanies: readonly PublicCompanyState[];
  /** Design note #713: why this SALE is illegal, or `null`. Resolved by `App` for the same reason
   *  `purchaseBlockFor` is -- the successor rule reads every player's holdings. */
  saleBlockFor?: (companyId: number, percentage: number) => string | null;
  /** Design note #713: where the token lands after selling this many certificates, or `null` when the
   *  chart cannot say. The WALK lives in `projectShareSaleMove`, which owns the direction. */
  salePriceAfter?: (companyId: number, certificates: number) => number | null;
  onPeekSaleMarket?: (companyId: number, certificates: number) => void;
  /** Design note #712: the zone rules, resolved by `App` against the whole board. */
  purchaseBlockFor?: (
    companyId: number,
    source: "Ipo" | "Bank",
    quantity: number,
    certificate?: "double", // #1324
  ) => string | null;
  phase?: GamePhase | null;
  outlook?: Readonly<Record<TrainTier, TierRustOutlook>> | null;
  marketPrices?: Readonly<Record<number, number | null>>;
  /** Design note #464: the round, so the card order can be recomputed at
   *  the Operating Round boundary and held everywhere else. */
  roundType: RoundType | null;
  connectedAddress: string | null;
  /** Design note #356: the Stock Round's number; `1` bans selling. */
  macroRoundNumber?: number;
  /** Design note #357: the acting player's spendable cash, for the buy gate. */
  playerCash?: number | null;
  playerLabel?: (address: string) => string | null;
  /** Design note #1110: the shell answers, because the seat order lives there. */
  colorForAddress?: (address: string) => string | null;
  /** Design note #395: the whole private roster; each card filters out its
   *  own. Optional so a caller without game state renders no private rows
   *  rather than needing a stub. */
  privateCompanies?: readonly PrivateCompanyState[];
  /** Design note #396: the card whose action bar is rendered. `null` means
   *  no card is active and no card shows Buy/Sell/Par. */
  activeCompanyId: number | null;
  onActivateCompany: (companyId: number | null) => void;
  /** Design note #395: which private's rules text is open, across all
   *  cards -- one at a time, like the active card but a separate cursor. */
  expandedPrivateId: number | null;
  setExpandedPrivateId: (privateId: number | null) => void;
  parValueFor: (companyId: number) => string;
  onSelectParValue: (companyId: number, value: string) => void;
  onBuyShare: (protocolId: number, source: "Ipo" | "Bank", quantity: number) => void;
  /** Design note #1324: the 20% standard certificate (ERIE, N&W under the Level Playing Field), bought whole. */
  onBuyDoubleCertificate?: (protocolId: number, source: "Ipo" | "Bank") => void;
  onSellShares: (protocolId: number, percentage: number) => void;
  controlsDisabled: boolean;
  /** Design note #681: why, when `controlsDisabled` is true. Threaded to the
   *  cards so a greyed control can answer for itself -- a button that cannot
   *  say why it is out reads as broken rather than as barred. */
  controlsBlockedReason: string | null;
  /** Design note #682: the acting seat's colour, for the treasury block. */
  actingSeatColor: string | null;
  /** Design note #417: `false` outside a Stock Round -- each card then
   *  renders no trading controls at all. */
  tradingOpen: boolean;
  /** Design note #948: corporations whose whole card is inert. Passed as DATA rather than derived here --
   *  `boIsLocked` already answers this in `sharePurchase`, and a panel re-asking it would be the second
   *  implementation of a rule, which is the fault this codebase keeps finding. Empty in a standard game. */
  lockedCompanyIds?: readonly number[];
  /** Design note #1451: the stock transaction that just landed, described by the shell from the message the
   *  reducer applied and the two states around it (`stockTransaction.ts`). PRESENTATION ONLY -- the card
   *  draws it and reports nothing back, and every figure on screen is the committed one whether or not this
   *  is set. A fresh `token` per event, so two identical transactions in a row still replay (#1060). */
  transaction?: StockTransactionEvent | null;
  /** Design note #1457: fired on the beat the arriving crown is drawn, once per transaction. The card owns
   *  the TIMING and the shell owns the PLAYING -- #1062's split for every cue in this app, which is what
   *  keeps the mute and the radio ducking in the one helper. */
  onPresidencyCue?: () => void;
}) {
  /* Design note #464: recomputed at the Operating Round BOUNDARY. `null` until the first one
     establishes an order, leaving the contract's own table order as a neutral start. `prevRoundRef`
     makes it an edge, not a level, so a mid-round poll cannot re-sort cards under a reader. */
  const [cardOrder, setCardOrder] = useState<number[] | null>(null);
  const prevRoundRef = useRef<RoundType | null>(null);
  useEffect(() => {
    const entering = roundType === "OperatingRound" && prevRoundRef.current !== "OperatingRound";
    prevRoundRef.current = roundType;
    if (!entering) return;
    setCardOrder(operatingRoundCardOrder(publicCompanies, marketPrices));
    // `publicCompanies`/`marketPrices` are read at the transition and
    // deliberately NOT dependencies -- including them would re-run this
    // every poll, which is the continuous re-sorting being removed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roundType]);

  /* ==================================================================
      DESIGN NOTE 1451: ONE FOCUS AT A TIME, HELD BY THE PANEL
     ==================================================================
     PANEL-LEVEL RATHER THAN PER CARD, for a structural reason as much as a design one: the cards are inline
     JSX inside a `.map`, so a card cannot hold hooks of its own without extracting a component from a file
     this large. It costs nothing -- exactly one transaction is ever being shown, so a second piece of state
     would only be a way for two cards to disagree about whose turn it is to glow.
     A NEW `token` SUPERSEDES WHATEVER WAS PLAYING. Rapid consecutive trades cannot corrupt anything: the
     timers are cleared, the stage index resets, and the holdings underneath were never waiting on any of it. */
  const { sequence, stage, stageIndex, applied } = useStockTransferFocus(
    transaction ?? null,
    onPresidencyCue,
  );
  /* The focused card's ownership table, for measuring inside it. Attached only to the card the sequence names
     (below), so a query from here cannot reach another card's rows. */
  const focusTableRef = useRef<HTMLDivElement | null>(null);
  const proxy = useTransferProxyGeometry(focusTableRef, sequence, stage, stageIndex);
  useRosterReorderFlip(focusTableRef, sequence, stageIndex, applied, publicCompanies);

  if (publicCompanies.length === 0) {
    return (
      <div style={styles.section}>
        {/* #1432: a real heading, at the level the Ledger and Tiles tabs use for their own page heading.
            The style is unchanged -- `margin: 0` is added to the style object so the element's own default
            margin cannot move anything. */}
        <h2 style={styles.sectionLabel}>Corporations</h2>
        <span style={styles.rosterEmpty}>
          No corporation data yet — waiting on the first GetGameState response.
        </span>
      </div>
    );
  }

  return (
    <div style={styles.section}>
      {/* Design note #1148: injected once for the whole roster rather than once per card, and
         unconditionally -- #18's convention for this codebase's inline-style escape hatch (#46). */}
      <style>{FLOAT_BADGE_CSS}</style>
      {/* Design note #1451: injected beside the badge's rules and for the same reason -- once for the whole
         roster, unconditionally, since `<style>` is this codebase's escape hatch for what inline styles
         cannot express (#46). */}
      <style>{STOCK_TRANSFER_CSS}</style>
      <h2 style={styles.sectionLabel}>Corporations</h2>
      <div style={styles.rosterGrid}>
        {/* Design note #464 (supersedes #446): the order is HELD. #446 sorted floated companies to the front
           on every render -- right about the order, wrong about the moment, since buying is what causes floats
           and the act of using the screen rearranged it. `cardOrder` is recomputed only when an Operating Round
           begins (`utils/corporationCardOrder.ts`) and held until the next one. */}
        {/* #1350: before the first Operating Round, the spectrum order rather than the state's numbering. */}
        {applyCardOrder(publicCompanies, cardOrder ?? openingCardOrder(publicCompanies)).map((committed) => {
          /* ==================================================================
              DESIGN NOTE 1452: THE CARD RENDERS THE STAGED BOARD, NOT THE COMMITTED ONE
             ==================================================================
             RULED: "the affected corporation card should temporarily render a presentation snapshot derived
             from `before` and advance that visual state through the transaction steps until it reaches
             `after` ... The animation should cause the visible final state, not fire on top of it."
             ONE REBINDING DOES THE WHOLE JOB. `company` below is the card's view of this corporation, and
             while a transaction is being shown it is the committed company with four ownership fields
             replaced by the staged selection. Every reader further down -- the ownership rows, the
             certificate counts, the roster sort, the crown, the float badge -- picks that up without knowing
             anything has happened, which is the only version of this that could not leave one figure
             behind. `committed` stays in scope and is deliberately unused: nothing on this card should be
             reading past the staged view while it is up.
             AND IT IS A SELECTION, NOT A MUTATION (`stagedOwnership`): the fields come whole from one
             authoritative snapshot or the other, so the card cannot draw a number the reducer never made.
             THE FALLBACK IS THE ABSENCE OF THE OVERLAY. No transaction, a transaction this card is not the
             subject of, or a descriptor the shell could not build -- in all three `staged` is `null` and
             this is the committed company, unchanged, exactly as it renders today. */
          const focusedHere = sequence !== null && sequence.companyId === committed.company_id;
          const staged = focusedHere ? stagedOwnership(transaction ?? null, applied) : null;
          const company = staged ? { ...committed, ...staged } : committed;
          const color = tickerColor(company.company_id);
          /* Design note #447: the field is optional and `gameState.ts` is explicit that `undefined` means
             "this build cannot tell you" while "0" means "it earned nothing" -- and a company that never
             operated reports "0" too. The honest test is a positive figure; anything else is a dash.

             ==================================================================
              DESIGN NOTE 1028: THE PERSISTENT FIGURE FIRST
             ==================================================================
             REPORTED: "all corporation cards on the Stock tab have 'Last Run --' during an Operating Round ...
             it was only printing the Last Run value of the last corporation to run."

             `last_route_revenue` IS TURN-SCOPED and #777 clears it on every turn change, so the only card
             still holding a figure was whichever corporation was mid-turn. This panel was rendering the field
             faithfully; the field does not mean what "Last run" means.

             THE LIVE FIGURE STILL WINS WHERE IT EXISTS, which is the corporation currently operating: its run
             has happened and has not yet been filed away, and showing the stale one there would be a card
             disagreeing with the board in front of the player. `last_completed_run_revenue` answers for
             everybody else. */
          const liveRun = Number(company.last_route_revenue ?? 0) || 0;
          const filedRun = Number(company.last_completed_run_revenue ?? 0) || 0;
          const lastRun = liveRun > 0 ? liveRun : filedRun;
          const hasRunRoutes = lastRun > 0;
          // Design note #389: derived from the fill, so every corporation's
          // stripe is legible without a per-company decision.
          const liveryInk = bestContrastTextColor(color);
          /* Design note #393: `owned_trains` is nullable on the wire and the
             badges this row replaced absorbed that internally. Normalised
             once here rather than guarded at each of the three reads. */
          const trains = company.owned_trains ?? [];
          /* Design note #490: `tokensPlaced` is gone -- `StationTokenRow` has always drawn the same fact as
             circles, so the count was a second, worse rendering of the row beside it.
             Design note #395: the same `corporationPrivateCompanies` predicate, filtered here rather than
             imported because that helper takes a whole `GameStateResponse` and this panel gets only the roster. */
          const ownedPrivates = (privateCompanies ?? []).filter(
            (priv) => !priv.closed && priv.owner_protocol_id === company.company_id,
          );
          const isActive = company.company_id === activeCompanyId;
          const market = marketPrices?.[company.company_id] ?? null;

          /* ==================================================================
           *  DESIGN NOTE 790: THE PRESIDENT SITS FIRST, ALWAYS
           * ==================================================================
           *
           * REPORTED: "when players become tied for control of a corporation (e.g., P1 holds 30%, P2 holds
           * 20% and buys a 10% share), the ordering on the corporation card switches president P1 with P2. I
           * think the president of the corporation should always appear first, even if they're tied."
           *
           * THE NOTE THIS REPLACES ARGUED THE OPPOSITE, and is kept because it was not stupid: "the president
           * is NOT forced to the top: seeing them sitting second on an equal stake is precisely the situation
           * a player needs to notice, and hoisting them would hide it." The thing it wanted to surface is
           * real -- a tie means somebody is one certificate from the presidency.
           *
           * IT CHOSE THE WRONG CARRIER FOR THAT SIGNAL. Row order in a table sorted by stake means "who holds
           * more", and on a tie it means nothing at all -- so the old arrangement did not say "these two are
           * level", it just moved a row, which reads as the presidency having changed. In 1830 a tie does NOT
           * transfer the presidency; the challenger must EXCEED the incumbent. So the card was animating a
           * transfer that the rules had not made.
           *
           * AND THE CROWN IS THE THING THAT MARKS THE PRESIDENT (#552), which is exactly why the position can
           * be spent on something else: first row now means "this is the President", the crown confirms it,
           * and the two agree instead of competing.
           *
           * STABLE BENEATH THE TWO KEYS. `Array.prototype.sort` has been required to be stable since ES2019,
           * so equal stakes keep `player_holdings`' own order -- which the reducer builds deterministically
           * and identically on every client. That matters more here than tidiness: two browsers rendering one
           * roster in two orders is a bug report nobody would know how to describe. */
          /* Design note #1451: the routing story in one line -- the shell names ONE corporation and the card
             whose id matches lights up. Every other card renders exactly as it always has, and a transaction
             for a corporation that is not on screen simply has no card to answer it. */
          const focusSequence = focusedHere ? (sequence as FocusSequence) : null;
          /* Design note #1455: where the OUTGOING crown starts fading. The stage, not the application --
             a buy takeover pays before it is crowned, and the incumbent's crown must stay solid through the
             purchase rather than dimming from the first frame of the transaction. */
          const crownOutIndex = focusSequence
            ? focusSequence.stages.findIndex((entry) => entry.kind === "crown-out")
            : -1;
          /* Subdued unless this row is one of the two the CURRENT stage is about. Called with no holder for
             the parts of the table that are never a participant -- the header, the rules, the private rows. */
          const rowClass = (holder?: ShareHolder) =>
            focusedHere && !(holder !== undefined && isStageParticipant(stage, holder))
              ? "app-stock-row app-stock-row-dim"
              : "app-stock-row";

          /* ==================================================================
              DESIGN NOTE 1454: A TRANSFER NEEDS SOMEWHERE REAL TO LAND
             ==================================================================
             REPORTED, of #1453's fallback: "Skipping the travelling stock proxy whenever the buyer has no row
             in the `before` snapshot is not an acceptable normal-case fallback ... it would make the
             stock-transfer animation disappear at some of the most important ownership-establishing moments."
             Right, and the fallback was the wrong shape: `player_holdings` omits a 0% holder, so a player's
             FIRST purchase of a corporation -- a par purchase included -- had no destination cell to measure.
             THE TRANSACTION NAMES THE BUYER, so the row is drawn for them. It is a PRESENTATION AFFORDANCE,
             not a claim: it prints the card's own absence dash (`--`, the same glyph an unparred price and an
             unrun corporation use), carries no crown, and holds no percentage. Nothing about it says the
             player owns anything, and at the resolve beat the staged snapshot switches to `after` and the row
             simply becomes the ordinary one it was always going to be.
             SCOPED TO THE STEP THAT NEEDS IT, not to the union of `before` and `after`. Only the two entities
             the CURRENT stage is about, only while that stage's figures have not yet landed, and only when
             the staged board really has no row for them. So a seller who sells out keeps their row for the
             whole outbound transfer -- the staged holdings are still `before` -- and loses it at the resolve
             beat, which is the order the brief asks for and is already what the staged snapshot does.
             ONLY A TRANSFER STAGE CAN NEED ONE, and that is worth writing down rather than leaving to be
             rediscovered: the participants of a presidency step are the outgoing and incoming presidents, and
             both hold at least the President's block by definition of the crown (#596b), so neither can be
             missing from any board on which the step is playing. */
          const anchorHolders: string[] = [];
          if (focusedHere && stage !== null && stage.kind === "transfer" && !applied.transfer) {
            [stage.from, stage.to].forEach((holder) => {
              if (holder === IPO_HOLDER || holder === BANK_HOLDER) return;
              if (anchorHolders.indexOf(holder) !== -1) return;
              if (company.player_holdings.some((entry) => entry.player === holder)) return;
              anchorHolders.push(holder);
            });
          }

          const rosterEntries = company.player_holdings.map((entry) => entry);
          /* `percentage: 0` so the one sort below handles them without a second code path -- every real
             holding is above zero, so a landing row sorts last, which is where a holder of nothing belongs. */
          anchorHolders.forEach((player) => rosterEntries.push({ player, percentage: 0 }));

          const holdings: RosterHolding[] = rosterEntries
            .sort((a, b) => {
              /* Design note #1452: `company.president` IS the staged president while a transaction is up --
                 the overlay replaced it. One field, one reader, no exception to remember. */
              const presidency =
                Number(company.president === b.player) - Number(company.president === a.player);
              return presidency !== 0 ? presidency : b.percentage - a.percentage;
            })
            .map((h) => ({
              address: h.player,
              percentage: h.percentage,
              /* A landing row can never be crowned, and not by a special case: a president holds at least the
                 20% block, so they always have a real holding to be found under. */
              isPresident: company.president === h.player,
              isSelf: connectedAddress !== null && h.player === connectedAddress,
              pending: anchorHolders.indexOf(h.player) !== -1,
            }));

          const cardFace = (
            <>
                {/* Design notes #16/#26: the ENTIRE surface is the toggle. A caret is a ~20px target on a ~300px card
                   that is itself the thing being chosen. Design note #396: the click makes this card ACTIVE, and
                   clicking it again deactivates -- so there is always a way back to a board with no controls on it. */}
                <button
                  type="button"
                  /* Design note #948: a locked card's face is not a control. The wrapper already refuses the
                     pointer; this refuses the KEYBOARD, which `pointerEvents` does not touch -- a tab-and-enter
                     would otherwise expand a card the mouse cannot. */
                  disabled={lockedCompanyIds.includes(company.company_id)}
                  onClick={() => onActivateCompany(isActive ? null : company.company_id)}
                  aria-expanded={isActive}
                  aria-label={
                    lockedCompanyIds.includes(company.company_id)
                      ? `${company.ticker} — ${BO_LOCKED_CARD_NOTE}`
                      : `${company.ticker} — ${isActive ? "hide" : "show"} share actions`
                  }
                  style={styles.rosterCardToggle}
                >
                {/* Design note #389: THE HEADER IS THE LIVERY. A corporation's colour was a 16px tint on the ticker
                   glyphs, while the same colour is a FIELD on the map token, the route ribbon and the chart token --
                   so eight cards distinguished by four coloured letters made the player read to identify a card.
                   `tickerColor` is the same lookup those surfaces use (design note #428 finally made that ONE table in
                   `styles/corporationLivery.ts`; there were three hand-kept copies when this was written).
                   THE INK IS COMPUTED, NOT CHOSEN -- `bestContrastTextColor`, the same helper the map's tokens use.
                   TD-3, checked against the live palette rather than remembered: three of the eight take black and five
                   take white, so any fixed choice is wrong for at least three corporations. White fails on ERIE's yellow
                   `#f5cd3a`; black fails on B&O's dark blue `#12408f`. (An earlier version of this note cited C&O's
                   amber and CPR's purple -- both stale since design note #408 replaced the palette with the board's.) */}
                <div style={{ ...styles.rosterLivery, backgroundColor: color, color: liveryInk }}>
                  {/* Design note #501: the mark and the handle, ONE line. `rosterNameStack` is a column and #465 added the
                     acronym as its second child -- so "beside the logo", which is what that note asked for and what its own
                     text says, came out underneath it. The stack keeps its column for the FULL NAME, which is read second,
                     needs the card's width and already ellipsises. */}
                  <span style={styles.rosterNameStack}>
                    <span style={styles.rosterIdentityRow}>
                    {/* Design note #410: the historical herald replaces the acronym. 26px against ~33px of text content, so
                       it sits INSIDE the existing height rather than setting a new one. The fallback keeps the old typography
                       exactly, so a missing file is indistinguishable from the previous design rather than a visible hole. */}
                    <CorporateLogo
                      ticker={company.ticker}
                      size={26}
                      color={liveryInk}
                      title={corporationTitle(company.ticker)}
                      fallbackStyle={styles.rosterLiveryTicker}
                    />
                    {/* Design note #1378: the Kanawha Licence LEFT THE STRIPE -- it is a cell on the price row now. */}
                    {/* Design note #465: THE ACRONYM COMES BACK, beside the herald rather than instead of it. #410 traded
                       one for the other and the trade was not even -- a herald is unmistakable once you know it and
                       unreadable until you do, and the full name is too long to serve as the quick label. "PRR" is what a
                       player says out loud and what every other surface calls the company.
                       `CorporateLogo`'s text fallback would double the ticker when a file is missing -- only in the failure
                       case, and a doubled ticker is a better failure than a nameless card. */}
                      <span style={styles.rosterLiveryAcronym}>{company.ticker}</span>
                      {/* Design note #1091: only once the train is gone -- while it is held, the chip's own sign says it. */}
                      {showsCurseBesideName(company) && <CarcosaMark meaning="corporation" size={12} />}
                    </span>
                    {corporationFullName(company.ticker) && (
                      <span style={styles.rosterLiveryName}>
                        {corporationFullName(company.ticker)}
                      </span>
                    )}
                  </span>
                  {/* Float status rides in the stripe too. Both badges take their ink FROM the stripe rather than carrying
                     their own, so neither can become unreadable on a corporation whose colour they were not designed
                     against. */}
                  {/* Design note #392: THE PAYOUT RIDES IN THE STRIPE. It was one of four stacked label/value cells, each
                     spending a caption line on a single figure; last payout is the one a share buyer weighs most directly.
                     Not the same thing as the float badge beside it -- the badge says whether the company is trading at
                     all, the payout says what it paid when it did. */}
                  {/* Design note #447: THE PAYOUT LEAVES THE STRIPE. #392's "the stripe had unused width" stopped holding
                     the moment the herald replaced the acronym (#410): a bare figure beside a logo, aligned to nothing and
                     uncaptioned, reads as part of the corporation's identity, and "$0" beside a herald looks like an error.
                     It moves to the value row, where three labelled figures make a table. */}
                  {/* Design note #488: THE STRIPE CARRIES ONE FACT NOW. #465's "captioned by position" means captioned by
                     nothing. Last Run moves down beside Market and IPO/Par, which sit under real captions.
                     WHAT STAYS is float PROGRESS -- the one fact about a corporation that is neither a price nor permanent,
                     and which disappears the moment it is answered. An unfloated company has no market price, no last run
                     and no treasury worth reading, so the stripe is where its only live number belongs. */}
                  {/* Design note #503: ONE SLOT, TWO LIVES. This reverses #488, and #488's objection deserves an answer:
                     a naked figure beside a herald is captioned by nothing. True of that version, not of this one -- the
                     figure goes IN the badge, with its border and an explicit caption inside it.
                     The two facts are mutually exclusive in time and identical in role: an unfloated corporation's one live
                     number is how close it is to floating, a floated one's is what it last earned. A slot holding exactly
                     one of them is the shape of the data, which is also why #488's "empty slot" complaint disappears.
                     "--" NOT "$0" for a corporation that has never run (design note #465): "0" is reported both by a
                     company that earned nothing and by one that has never turned a wheel. */}
                  <span style={styles.rosterLiveryRight}>
                    {company.is_floated ? (
                      <span
                        style={{ ...styles.rosterLiveryBadge, color: liveryInk, borderColor: liveryInk }}
                        title={
                          hasRunRoutes
                            ? `${company.ticker} last ran its trains for $${lastRun}.`
                            : `${company.ticker} has floated but has not yet run its trains.`
                        }
                      >
                        <span style={styles.rosterLiveryBadgeCaption}>Last run</span>
                        {hasRunRoutes ? `$${lastRun}` : "--"}
                      </span>
                    ) : (
                      /* Design note #1148: the unfloated slot carries two readings of one number now, so it
                         is a component with its own state rather than an expression. */
                      <FloatProgressBadge company={company} liveryInk={liveryInk} />
                    )}
                  </span>
                </div>

                {/* The two prices, side by side and labelled. Market is the
                    live figure and gets the emphasis; par is what it floated
                    at and is the reference point for judging it. */}
                <div style={styles.rosterPriceRow}>
                  {/* Design note #387: NO PAR, NO MARKET FIGURE. The price table had been seeded from a mid-game fixture
                     regardless of scenario, so a Zero State corporation showed a price for a share nobody can own at a
                     valuation nothing set. The market price is DEFINED as where the token stands, and a company with no
                     par has no token -- asserted here as well as in the seed and the chart's filter. */}
                  {/* Design note #502: the `$`. Treasury has carried one since #489 and these two did not, so one line
                     held three dollar figures of which only the rightmost said so. The dash stays bare -- "$--" would put
                     a currency on an absent value. */}
                  <div style={styles.rosterPrice}>
                    {/* Design note #712: THE ZONE, ON THE FIGURE. Reported: "when a corporation is in
                        yellow/orange/brown zones, its Market Price on the corp cards reflects that."
                        It did not, and the omission was the same shape as the rules bug beside it -- the
                        chart knew, and the card a player actually reads did not. `ZonedPrice` has tinted the
                        dividend line since #197 for precisely this reason ("a player reading this panel is
                        looking at a NUMBER, not the chart"), so this is that component reaching the surface
                        it was always describing.
                        THE INK, NOT A BOX: the report offered either, and a filled swatch here would compete
                        with the eight corporation liveries this roster already carries (#13's argument for
                        colouring the ticker's ink rather than its cell). */}
                    <span style={styles.rosterPriceValue}>
                      {company.par_value === null || market === null ? (
                        "--"
                      ) : (
                        <ZonedPrice price={market} />
                      )}
                    </span>
                    <span style={styles.rosterPriceLabel}>market</span>
                  </div>
                  <div style={styles.rosterPrice}>
                    <span style={styles.rosterPriceValueMuted}>
                      {company.par_value === null ? "--" : `$${company.par_value}`}
                    </span>
                    <span style={styles.rosterPriceLabel}>IPO / par</span>
                  </div>
                  {/* Design note #503: Last Run is GONE from this row -- it
                      is in the livery stripe, in the slot the float badge
                      vacates. See that slot for the reasoning. */}
                  {/* Design note #489: TREASURY BELONGS WITH THE MONEY. It sat on the asset row, filed with what the
                     corporation OWNS -- a defensible taxonomy and the wrong one for a share buyer, who was reading cash in
                     a different row, type size and alignment from every other number on the card.
                     FLUSH RIGHT, not fourth in the line: Market, IPO/Par and Last Run are PER-SHARE facts that read as a
                     sequence, while treasury is the corporation's own money. `marginLeft: auto` also absorbs the slack so
                     four evenly-spaced columns cannot drift apart on a wide card. */}
                  {/* ==================================================================
                       DESIGN NOTE 1378: THE LICENCE IS A FACT ABOUT THE CORPORATION, NOT PART OF ITS NAME
                      ==================================================================
                      REPORTED: "The pickaxe License icon placement on the corporation cards is wrong. Right now it
                      sits between the herald and the acronym on the corp card color stripe. It needs to move
                      down: on the Market IPO/PAR Treasury line, add a LICENSE spot with the icon above it for
                      corporations that have purchased one."
                      #1323 PUT IT IN THE STRIPE beside the herald, which is where the identity lives -- and a licence
                      is not identity, it is a holding, like the market price and the treasury it now sits beside.
                      A CELL LIKE THE OTHERS: the icon where the figure goes, the word under it in the row's own
                      caption face, and nothing at all for a corporation without one -- an empty "LICENSE" cell on
                      seven of nine cards would be a column of absences. Between IPO/par and the treasury, so the
                      treasury stays flush right (#489). */}
                  {licensesHeldBy(company) > 0 && (
                    <div style={styles.rosterPrice}>
                      <span style={styles.rosterPriceValue}>
                        <KanawhaLicenseBadge count={licensesHeldBy(company)} color={CARD_INK} size={18} />
                      </span>
                      <span style={styles.rosterPriceLabel}>license</span>
                    </div>
                  )}
                  <div style={{ ...styles.rosterPrice, ...styles.rosterTreasury }}>
                    <span style={styles.rosterPriceValue}>${company.treasury}</span>
                    <span style={styles.rosterPriceLabel}>treasury</span>
                  </div>
                </div>

                {/* Design note #393: ONE LINE OF ASSETS. #31 put this data on the front for a reason that still holds --
                   whether a corporation is one purchase from losing its trains changes what a share is worth before you
                   look at the price. What it got wrong was the FORMAT: four caption/value cells plus two badge sets,
                   times eight cards, to say three numbers.
                   Design note #409: `TrainChips` came BACK, inline. #393 argued the rust colouring could go because "on a
                   Stock Round card the question is what does it own" -- contradicted by its own second paragraph. Rust is
                   the difference between a fleet and a pile of scrap, and the Stock Round is when it is being priced.
                   `CapacityPill` stays gone: the train LIMIT is about what may be bought NEXT, an Operating Round
                   decision. Station tokens are shown as placed-over-limit, which neither old cell showed at all. */}
                {/* Design note #490: THE WORDS, NOT THE PICTOGRAMS. #393's "the icons are the captions" was wrong twice.
                   AN EMOJI IS NOT TYPOGRAPHY -- it renders in the platform's colour font at its own weight, ignoring
                   `color`, `fontWeight` and the type scale, so the one element meant to be a caption is the only one that
                   cannot be styled as one, and three saturated pictograms out-shout the numbers they label.
                   A TOOLTIP IS NOT A LABEL -- it needs a pointer, a hover and a wait, and is unreachable on touch.
                   `TrainChips` and `StationTokenRow` remain the values; only the captions change. Treasury left this row
                   entirely (#489), which is what made room for two spelled-out labels without wrapping. */}
                {/* Design note #504: CAPTION UNDER VALUE, BOTH ROWS. #490 put the words beside the values because it
                   inherited an inline row, so the card captioned its two rows in opposite orders. `assetItem` becomes a
                   column matching `rosterPrice`'s shape.
                   The label keeps `assetLabel`, not `rosterPriceLabel`: #490 already tuned it to that caption treatment,
                   and swapping the style would change the type scale of a caption sitting under a chip row. */}
                <div style={styles.assetRow}>
                  <span style={styles.assetItem}>
                    {/* Design note #409: the real chips, with the rust colouring a share buyer is pricing -- `compact` and
                       the light surface, matching the Operating Round's own rendering so the two screens cannot disagree.
                       Design note #490: the empty case gets WORDS too. "none" says the corporation owns none, which is the
                       fact that decides whether it is about to be forced into an emergency purchase. */}
                    {trains.length > 0 ? (
                      <TrainChips
                        trains={trains}
                        phase={phase ?? null}
                        surface="light"
                        compact
                        outlook={outlook}
                        reprieved={company.pending_rust_trains}
                        // Design note #1088: the Carcosa gift, so its chip shows the sign rather than a locomotive.
                        ghosts={company.carcosan_trains}
                      />
                    ) : (
                      <span style={styles.assetEmpty}>none</span>
                    )}
                    <span style={styles.assetLabel}>Trains</span>
                  </span>
                  <span style={styles.assetDivider} aria-hidden="true">|</span>
                  {/* Design note #424: THE CAPACITY, DRAWN. `2/4` is a count, and the row that replaces it answers three
                     questions the fraction cannot: which tokens are spent, where the home one sits, and -- the one that
                     decides a purchase -- what the NEXT one costs.
                     THE SAME COMPONENT, not a second one that looks like it: both surfaces describe one corporation's
                     allowance, and this file has been bitten by two renderers of one fact drifting apart (#423).
                     THE INKS ARE THE CARD'S. `StationTokenRow` takes its colours as props precisely because it sits on the
                     bar's livery and on this card's light paper; the bar's near-white ink would vanish here. */}
                  <span style={styles.assetItem}>
                    <StationTokenRow
                      slots={stationTokenSlots(company)}
                      color={tickerColor(company.company_id)}
                      ink={CARD_INK}
                      inkMuted={CARD_INK_MUTED}
                      homeHexLabel={company.home_hex_label}
                      emptyLabel="none"
                    />
                    {/* Design note #504: under the value, like every other
                        caption on this card. */}
                    <span style={styles.assetLabel}>Stations</span>
                  </span>
                </div>

                {/* Design note #378: ONE OWNERSHIP TABLE, IN 18xx ORDER. It was two readouts describing one thing -- a
                   player list here and the IPO/Bank Pool counts underneath in a different format with no shared columns
                   -- so "where are the nine certificates" had its answer split across two shapes that did not line up.
                   One table, in the order the physical game keeps its certificates: the two BANKS first, a rule, then the
                   PLAYERS. The rule is the line between shares nobody owns and shares somebody does.
                   THREE COLUMNS: shareholder, certificates, percentage. Certificates first because that is the physical
                   unit a player moves, and because the president's 20% being ONE certificate is what a percentage hides.
                   SORTED DESCENDING, and the president is NOT hoisted -- seeing them second on an equal stake is exactly
                   what a player needs to notice. */}
                <div
                  style={styles.ownershipTable}
                  role="table"
                  aria-label={`${company.ticker} ownership`}
                  /* Design note #1451: only the focused card's table is reachable from the panel's
                     measurement, so a query for a row cannot cross into another corporation's. */
                  ref={focusedHere ? focusTableRef : undefined}
                >
                  {/* Design note #1451: the travelling percentage. Absolutely positioned INSIDE this table --
                      it cannot leave the card, which is the constraint the whole treatment exists to honour.
                      `aria-hidden` throughout: the figures either side of it are the accessible record, and a
                      screen reader announcing a proxy of a number it is about to read anyway is noise. */}
                  {focusedHere && proxy !== null && stage !== null && (
                    <>
                      <TransferProxy
                        path={proxy.forward}
                        label={`${stage.percentage}%`}
                        crowned={stage.kind === "exchange"}
                        durationMs={stage.durationMs}
                        color={color}
                        ink={bestContrastTextColor(color)}
                      />
                      {/* The other half of the president's exchange: 20% of ordinary shares going back the
                          other way. Two chips crossing is the only honest picture of a swap in which NOBODY'S
                          PERCENTAGE MOVES (`presidencyTransfer.ts` #596a) -- one chip would say a stake
                          changed hands, which is exactly what did not happen. The crown on the outgoing one
                          is what distinguishes the president's certificate from the shares it buys. */}
                      {proxy.back !== null && (
                        <TransferProxy
                          path={proxy.back}
                          label={`${stage.percentage}%`}
                          crowned={false}
                          durationMs={stage.durationMs}
                          color={CARD_SURFACE_MUTED}
                          ink={CARD_INK}
                        />
                      )}
                    </>
                  )}
                  {/* Design note #394: ENTITY / SHARES / PRICE. The old third column was `%`, so the header described the
                     banks and the players identically while the two rows answered different questions: a player's
                     percentage is their STAKE, the IPO's is INVENTORY, and what a buyer wants beside inventory is cost.
                     So the percentage moves in beside the count -- `7 (70%)` -- and the freed column carries price.
                     THE TWO PRICES ARE DIFFERENT, and that is 1830: an IPO share costs the PAR price the president set, a
                     Bank Pool share the CURRENT MARKET price. One price for both rows would be wrong for most of the game.
                     A PLAYER ROW'S PRICE IS BLANK, deliberately, not a dash -- there is no price at which a player's shares
                     are for sale, and printing the market figure there would read as an offer. */}
                  <div style={styles.ownershipHeadRow} role="row" className={rowClass()}>
                    <span style={styles.ownershipName} role="columnheader">Entity</span>
                    <span style={styles.ownershipNum} role="columnheader">Shares</span>
                    <span style={styles.ownershipNum} role="columnheader">Price</span>
                  </div>

                  {/* The two banks, always shown -- an IPO at 0% means the
                      company is fully distributed, which is worth as much
                      as any other figure here. */}
                  <div style={styles.ownershipRow} role="row" className={rowClass(IPO_HOLDER)}>
                    <span style={styles.ownershipName} role="cell">IPO</span>
                    {/* Design note #448: NINE CERTIFICATES, NOT TEN -- one 20% President's Certificate plus eight 10% shares.
                       `percentage / 10` counts PERCENT BLOCKS, so a full IPO read "10" for a stack of nine pieces of card,
                       and the extra digit is what clipped the column. `certificateCount` already knew this and the player
                       rows already used it; the two bank rows were doing raw division beside them, so one table counted in
                       two units. WHILE THE PRESIDENCY IS UNSOLD the 20% certificate sits in the IPO, which is why this cannot
                       be a constant 9. */}
                    <span style={styles.ownershipNum} role="cell" data-stock-cell={IPO_HOLDER}>
                      {certificateCardsInPool(company, "Ipo")} ({company.ipo_pool_percentage}%)
                    </span>
                    <span
                      style={styles.ownershipNum}
                      role="cell"
                      title="IPO shares are bought at the par price set when this corporation was floated."
                    >
                      {company.par_value === null ? "--" : `$${company.par_value}`}
                    </span>
                  </div>
                  <div style={styles.ownershipRow} role="row" className={rowClass(BANK_HOLDER)}>
                    <span style={styles.ownershipName} role="cell">Bank Pool</span>
                    {/* Design note #448: the same unit as every other row. A President's Certificate cannot reach the Bank
                       Pool -- a president must dump the presidency before selling out -- so `false` is not a simplification. */}
                    <span style={styles.ownershipNum} role="cell" data-stock-cell={BANK_HOLDER}>
                      {certificateCardsInPool(company, "Bank")} ({company.bank_pool_percentage}%)
                    </span>
                    <span
                      style={styles.ownershipNum}
                      role="cell"
                      title="Bank Pool shares are bought at the current market price."
                    >
                      {/* Design note #387: no par, no market figure. */}
                      {company.par_value === null || market === null ? "--" : `$${market}`}
                    </span>
                  </div>

                  {/* Design note #378: the line between unowned and owned. */}
                  <hr style={styles.ownershipRule} className={rowClass()} />

                  {holdings.length === 0 ? (
                    <span style={styles.rosterNoHoldings} className={rowClass()}>No shares held by players</span>
                  ) : (
                    /* Design note #421: the highlight follows the READER, not the president. The crown already marks the
                       presidency unmistakably, so an amber row behind it emphasised a fact needing none -- while the one
                       row a reader scans for was marked by a pale pill in the weakest position. The two swap weights and
                       the "you" tag is deleted rather than moved. `isSelf` needs an address, so hotseat highlights none. */
                    holdings.map((holding) => {
                    /* Design note #780: AT THE CAP, SAID HERE. Reported after a purchase was refused at 60%
                       with nothing on screen explaining it -- the rule lived in a disabled button's tooltip,
                       which is invisible on touch and easy to miss anywhere.
                       ZONE-AWARE THROUGH THE SHARED PREDICATE, not a local `>= 60`: Orange and Brown waive
                       this cap, and a roster printing "max" where the Buy button correctly allows the
                       purchase would be the two-surfaces-one-question bug this project keeps finding. */
                    /* Design note #791: "tied" joins "max", and they cannot both apply -- two players at the
                       60% cap would be 120% of a 100% corporation. `holdingMarker` returns ONE word, so the
                       cell cannot print both even if that arithmetic were ever wrong. */
                    /* Design note #1451: which half of the handoff this row is. Only the two players in
                       the exchange animate; every other crown on the board is a standing fact. */
                    /* ==================================================================
                        DESIGN NOTE 1455: THE ARRIVAL IS KEYED ON THE FIGURES, THE DEPARTURE ON THE STAGE
                       ==================================================================
                       THE CROWN DRAWS IN WHEREVER IT LANDS, and that is now one branch covering two
                       procedures: a two-player handoff and a corporation's first president. `crownArrivesOn`
                       names the destination in both, and `applied.presidency` is the moment the staged board
                       starts calling that player president -- which is the very render in which their crown
                       first exists, so the animation plays from mount rather than being switched on a frame
                       later. A first president used to POP, because the old test asked for a `handover`
                       stage and that sequence has none.
                       THE DEPARTURE STILL NEEDS THE STAGE, and the asymmetry is the procedure rather than an
                       oversight: a buy is paid for before it is crowned, so the incumbent holds a solid crown
                       through the purchase and only begins to lose it when the `crown-out` beat opens. Keying
                       that on `!applied.presidency` alone would fade it from the first frame of the
                       transaction, which would announce the takeover before the shares that caused it. */
                    const crownClass =
                      focusSequence === null
                        ? ""
                        : applied.presidency && holding.address === focusSequence.crownArrivesOn
                          ? "app-stock-crown-in"
                          : !applied.presidency &&
                              crownOutIndex !== -1 &&
                              stageIndex >= crownOutIndex &&
                              holding.address === focusSequence.presidency?.from
                            ? "app-stock-crown-out"
                            : "";
                    const crownAnimationStyle: React.CSSProperties = {
                      display: "inline-flex",
                      /* #970's rule: the duration is the constant, not a copy of it in the stylesheet. */
                      animationDuration: `${
                        crownClass === "app-stock-crown-out" ? CROWN_OUT_MS : HANDOVER_MS
                      }ms`,
                    };
                    const marker = holdingMarker(
                      holding.percentage,
                      marketZoneForPrice(market),
                      company.player_holdings,
                    );
                    return (
                      <div
                        key={holding.address}
                        role="row"
                        className={rowClass(holding.address)}
                        title={
                          marker === "max"
                            ? `${playerLabel?.(holding.address) ?? truncateHolder(holding.address)} holds the maximum ${holding.percentage}% of this corporation. The Orange and Brown zones lift this cap.`
                            : marker === "tied"
                              ? /* Design note #791: the title carries the RULE, which is the half a bare word
                                   cannot: a tie does not move the presidency, so a reader who sees two equal
                                   figures needs telling that nothing has changed hands yet. */
                                `Level at ${holding.percentage}% for the largest holding. A tie does not move the presidency — a challenger must EXCEED the President's holding.`
                              : undefined
                        }
                        style={{
                          ...styles.ownershipRow,
                          /* ==================================================================
                              DESIGN NOTE 1110: THE HIGHLIGHT IS THE VIEWER'S OWN COLOUR
                             ==================================================================
                             The gold row said "this one is yours" with a highlighter. A tint of the
                             viewer's own seat colour says the same thing in the language the rest of the
                             app already uses for identity -- and it says it without spending the accent.
                             THE INK STAYS DARK AND NEUTRAL, which is the half worth writing down: tinting
                             the row AND inking it in the same hue collapses the contrast by construction
                             (3.6:1 at worst, measured). Tint carries identity, ink carries legibility --
                             13.2:1 at worst this way, and every tint sits 6-11 dE off plain paper, so it
                             still reads as a highlight rather than as a slightly different paper.
                             FALLS BACK TO THE GOLD ROW when the shell cannot name a colour, so a seatless
                             viewer is highlighted rather than unmarked. */
                          ...(holding.isSelf
                            ? selfRowTint(colorForAddress?.(holding.address) ?? null)
                            : {}),
                        }}
                      >
                        <span
                          style={{
                            ...styles.ownershipName,
                            /* Design note #1110: each name in its own player's colour. The crown beside it
                               stays uniform gold -- gold marks a ROLE, the seat colour marks an IDENTITY,
                               and a crown in the player's colour would stop saying "president" and start
                               repeating what the name already said. */
                            ...(colorForAddress?.(holding.address)
                              ? { color: colorForAddress(holding.address) as string }
                              : {}),
                          }}
                          role="cell"
                        >
                          {/* Design note #552: the WORD is gone and the crown is back, as our own drawing. #490 removed the emoji
                             because a platform pictogram in a platform colour font could not be relied on to mean anything, and the
                             word that replaced it is nine characters wide in a column that must also fit a name. An inline SVG is
                             the same shape everywhere, takes the row's ink, and announces "President" to a screen reader. */}
                          {/* ==================================================================
                               DESIGN NOTE 1451: THE CROWN IS TAKEN AWAY BEFORE IT IS GIVEN
                              ==================================================================
                              Wrapped rather than given a prop: `PresidentCrown` takes `style` and not
                              `className` (#552), and a component whose whole job is to be the same drawing
                              everywhere should not grow an animation vocabulary because one caller wants
                              one. The span is the animated thing; the crown inside it is untouched.
                              THE OUTGOING CROWN IS STILL RENDERED while it fades, because the STAGED
                              `company.president` (#1452) still names its player until the handover beat.
                              `animation-fill-mode: forwards` holds it invisible through the exchange, so the
                              row is visibly vacated for the whole of the swap rather than for ninety
                              milliseconds of it. */}
                          {holding.isPresident && (
                            <span
                              className={crownClass}
                              style={crownClass === "" ? undefined : crownAnimationStyle}
                            >
                              <PresidentCrown style={styles.presidentTag} scale={0.95} />
                            </span>
                          )}
                          {playerLabel?.(holding.address) ?? truncateHolder(holding.address)}
                        </span>
                        <span
                          style={styles.ownershipNum}
                          role="cell"
                          data-stock-cell={holding.address}
                        >
                          {/* "5 (60% max)" rather than "5 (60%, max)": the comma buys nothing and this
                             column is fixed-width (#466), so every character is a real constraint. */}
                          {/* Design note #1454: a landing row prints the card's absence dash -- the same
                              glyph an unparred price and a corporation that has never run already use --
                              rather than "0 (0%)", which would be a holding of nothing stated as a figure. */}
                          {holding.pending ? (
                            "--"
                          ) : (
                            <>
                              {certificateCardsHeld(company, holding.address)} (
                              {holding.percentage}%{marker === null ? "" : ` ${marker}`})
                            </>
                          )}
                        </span>
                        {/* Design note #394: blank, not a dash. */}
                        <span style={styles.ownershipNum} role="cell" />
                      </div>
                    );
                    })
                  )}

                  {/* Design note #395: THE PRIVATES THIS COMPANY OWNS. They belong in the ownership table because they ARE
                     holdings -- a private inside a corporation is an asset the shareholders own a piece of, and it pays into
                     the treasury every Operating Round.
                     THE ELLIPSIS IS LOAD-BEARING: "Champlain & St. Lawrence" is 24 characters and the card is fixed-width
                     (#22), so without `textOverflow` every card carrying it grows a line. Clipping is acceptable only
                     BECAUSE the row expands.
                     EXPANSION IS PER PRIVATE and independent of which card is active: reading what the D&H does is a
                     reference lookup, not an action, so it must not compete with the selection that governs Buy and Sell. */}
                  {ownedPrivates.length > 0 && (
                    <>
                      <hr style={styles.ownershipRule} className={rowClass()} />
                      {ownedPrivates.map((priv) => {
                        const open = expandedPrivateId === priv.private_id;
                        const entry = PRIVATE_COMPANY_CATALOG[priv.private_id];
                        return (
                          <div key={priv.private_id} style={styles.privateRowGroup} className={rowClass()}>
                            <button
                              type="button"
                              style={styles.privateRow}
                              aria-expanded={open}
                              onClick={(event) => {
                                // The card behind this is itself a click
                                // target (design note #396); reading a
                                // private must not also activate the card.
                                event.stopPropagation();
                                setExpandedPrivateId(open ? null : priv.private_id);
                              }}
                              title={open ? priv.name : `${priv.name} — click for its rules text.`}
                            >
                              <span style={open ? styles.privateNameOpen : styles.privateName}>
                                {priv.name}
                              </span>
                              <span style={styles.privateRevenue}>
                                +${priv.revenue_per_or}
                              </span>
                            </button>
                            {open && (
                              <p style={styles.privateRules}>
                                {entry?.ability ?? "No recorded special power."}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </>
                  )}

                </div>

                {/* Design note #345: ONE FLOAT READOUT, NOT TWO. #17 put a progress bar in the collapsed body for a good
                   reason, and then the pill badge arrived above it answering the same question in one line -- eight cards
                   each spending a track, a fill, a threshold tick and a caption on a figure printed six pixels higher.
                   The pill wins because it is already IN the header row a player reads first. */}

                {/* Design note #445: THE RULE THIS NAMED DOES NOT EXIST. Reported as critical: the codebase assumes a
                   corporation can float during the Auction Round.
                   THE REDUCER WAS ALREADY RIGHT -- `grantBOPresidency` moves 20%, the presidency and par, and leaves
                   `is_floated` alone; the fixture ships B&O unfloated. WHAT WAS WRONG WAS THIS LABEL, and it TAUGHT the
                   rule: a badge reading "Auto-floated by the B&O private" tells every player such a route exists.
                   So no cause is named. If `is_floated` is true below 60% the flag and the arithmetic disagree, and that
                   is a data fault to surface rather than a rule to rationalise. */}
                {/* Design note #749: the banner stays and its ARITHMETIC changed. #445's reasoning is intact
                   -- a floated flag the 60% rule cannot account for is a data fault to surface rather than a
                   rule to rationalise -- but it was asking how much sat in players' hands, so it fired on
                   every corporation with 40%-plus in the Bank Pool. Those are floated and operating
                   normally, so the card was reporting a contradiction that was its own.
                   AND THE WORDING NAMES THE MEASURE NOW. "40% sold" said nothing about which pile. */}
                {company.is_floated && !metFloatThreshold(company) && (
                  <span style={styles.floatMismatchNote}>
                    Floated flag set with only {soldFromIpoPercent(company)}% out of the IPO &middot;
                    expected {FLOAT_THRESHOLD_PERCENT}%
                  </span>
                )}

              </button>
            </>
          );

          const cardActions = (
            <CompanyActions
              company={company}
              // Design note #387: an unparred company has no market price,
              // so the controls that branch on one (the Brown-zone
              // multi-buy) see the same `null` the card displays.
              marketPrice={company.par_value === null ? null : market}
              purchaseBlockFor={purchaseBlockFor}
              saleBlockFor={saleBlockFor}
              salePriceAfter={salePriceAfter}
              onPeekSaleMarket={onPeekSaleMarket}
              connectedAddress={connectedAddress}
              macroRoundNumber={macroRoundNumber}
              playerCash={playerCash}
              parValue={parValueFor(company.company_id)}
              onSelectParValue={onSelectParValue}
              onBuyShare={onBuyShare}
              onBuyDoubleCertificate={onBuyDoubleCertificate}
              onSellShares={onSellShares}
              controlsDisabled={controlsDisabled}
              controlsBlockedReason={controlsBlockedReason}
              actingSeatColor={actingSeatColor}
              // Design note #417: no Stock Round, no controls at all.
              tradingOpen={tradingOpen}
            />
          );

          /* Design note #388: the flip is gone; every action renders on the card front.
             #26 chose it because an expanding card reflowed the grid, and a rotated card does not -- but hiding
             the numbers behind the decision meant a parallel render of the same corporation that had to be kept
             in agreement (#355), plus a `stopPropagation` guard that then swallowed clicks on padding.
             The front deletes the parallel render, the guard and the fixed 460px frame; the reflow is handled by
             cards keeping their own height, with actions rendering for the EXPANDED card only. */

          /* ==================================================================
              DESIGN NOTE 948: A LOCKED CARD IS DEAD, NOT MERELY REFUSING
             ==================================================================
             REPORTED: "the B&O corporation card is clickable/expandable, but the 'Buy' button is greyed out
             with a tooltip. This is a false affordance."
             AND IT IS THE SECOND TIME THIS EXACT SHAPE HAS BEEN REPORTED HERE. #417's own note in this file
             already settled the principle -- "a disabled control claims the action is available here and
             fixable" -- and chose absence over disabling for out-of-round controls. #904b then made the B&O
             refusal loud, which was right for a player who ACTS, and left the card itself fully alive for a
             player who has not: expandable, clickable, offering a panel whose every control refuses.
             SO THE WHOLE SURFACE GOES QUIET. Not the button, not the panel -- the card. It cannot be expanded,
             it does not take a click, and it says why in its own footer instead of in a tooltip nobody hovers.
             `pointerEvents: "none"` ON THE CARD rather than `disabled` on the toggle, because the toggle is
             the entire card face (#16/#26) and a disabled button inside a live card still shows a cursor and
             a focus ring. `aria-disabled` carries the same fact to a screen reader, which `pointerEvents`
             alone cannot. */
          const locked = lockedCompanyIds.includes(company.company_id);

          return (
            <div
              key={company.company_id}
              className="app-stock-card"
              style={{
                ...styles.rosterCard,
                ...(company.is_floated ? {} : styles.rosterCardUnfloated),
                ...(isActive ? styles.rosterCardActive : {}),
                /* Design note #1345 (feedback 5): the pink 1px edge on the selected card is gone. It was the
                   brand pink (`CARD_BORDER_ACTIVE`) on one surface only, too slight to read as a state and
                   too odd to read as anything but a mistake; the selected card already expands, and keeps
                   #1109's lift (`rosterCardActive`) -- a shadow, not a colour. */
                borderColor: CARD_BORDER,
                /* ==================================================================
                    DESIGN NOTE 1451: THE BORDER IS THE WHOLE CARD-LEVEL CUE
                   ==================================================================
                   RULED: "a restrained temporary border/outline/accent ... Do not use a large glow, repeated
                   pulsing, dramatic scaling, flashing", and "The border should be subordinate to the
                   ownership-transfer animation."
                   THE CARD'S OWN LIVERY, not a generic accent. The colour already means this corporation on
                   this card -- it is the stripe two inches above -- so the border says WHICH without
                   introducing a hue that has to be learnt. And it is a colour change on an edge that is
                   already there: no new geometry, nothing that moves, nothing that competes with the two rows
                   the reader is supposed to be looking at.
                   HELD FOR THE WHOLE SEQUENCE, which is the half that carries the procedure. A takeover is
                   two steps with different participants, and the unbroken border is what says they are one
                   transaction rather than two things that happened. */
                ...(focusedHere ? { borderColor: color } : {}),
                ...(locked ? styles.rosterCardLocked : {}),
              }}
              aria-disabled={locked ? true : undefined}
            >
              {cardFace}
              {locked && (
                /* THE NOTE IS PART OF THE CARD, not a tooltip and not a toast: it is a standing fact about
                   this corporation for the whole of the early game, and the player it is for is the one who
                   has NOT clicked. */
                <p style={styles.rosterCardLockedNote}>{BO_LOCKED_CARD_NOTE}</p>
              )}
              {/* Design note #396: ONE CARD HOLDS THE CONTROLS. This reverses #388, left standing above rather than
                 edited away. That note argued a control needing a click to reveal is one the player must remember is
                 there -- sound, and it did not weigh the MULTIPLIER: eight corporations x ~twenty controls is roughly
                 160 controls on one screen, at which density nothing is discoverable because the eye has nowhere to land.
                 The reversal is narrow and #388's real point survives: the actions still render on the FRONT, in place,
                 under the numbers they act on. Only eight copies became one. Clicking again clears it, which is one
                 fewer control than a close button. */}
              {/* Design note #948: and never the panel, even if something else set this card active -- a
                  `RevertTo` that rewinds into a round where it was open would otherwise restore controls the
                  lock has since taken away. */}
              {isActive && !locked && cardActions}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/** The buy/sell controls for ONE corporation -- design note #10. Scoping them to a card means each
 *  control is unambiguously about the company whose numbers are directly above it, and the float bar,
 *  par ladder and sell bounds are all computed from THAT company. */
function CompanyActions({
  company,
  marketPrice,
  connectedAddress,
  macroRoundNumber,
  playerCash,
  parValue,
  onSelectParValue,
  onBuyShare,
  onBuyDoubleCertificate,
  purchaseBlockFor,
  saleBlockFor,
  salePriceAfter,
  onPeekSaleMarket,
  onSellShares,
  controlsDisabled,
  controlsBlockedReason,
  actingSeatColor,
  tradingOpen,
}: {
  company: PublicCompanyState;
  /** This company's live market price, or `null` when it has no position.
   *  Design note #33: decides whether the Brown-zone quantity selector
   *  appears at all. */
  marketPrice: number | null;
  connectedAddress: string | null;
  macroRoundNumber?: number;
  playerCash?: number | null;
  /** This company's own par selection -- design note #398. */
  parValue: string;
  onSelectParValue: (companyId: number, value: string) => void;
  onBuyShare: (protocolId: number, source: "Ipo" | "Bank", quantity: number) => void;
  /** Design note #1324: the 20% standard certificate (ERIE, N&W under the Level Playing Field), bought whole. */
  onBuyDoubleCertificate?: (protocolId: number, source: "Ipo" | "Bank") => void;
  /** Design note #713: why this SALE is illegal, or `null`. Resolved by `App` for the same reason
   *  `purchaseBlockFor` is -- the successor rule reads every player's holdings. */
  saleBlockFor?: (companyId: number, percentage: number) => string | null;
  /** Design note #713: where the token lands after selling this many certificates, or `null` when the
   *  chart cannot say. The WALK lives in `projectShareSaleMove`, which owns the direction. */
  salePriceAfter?: (companyId: number, certificates: number) => number | null;
  onPeekSaleMarket?: (companyId: number, certificates: number) => void;
  /** Design note #712: why this purchase is illegal, or `null`. Resolved by `App` against the whole board. */
  purchaseBlockFor?: (
    companyId: number,
    source: "Ipo" | "Bank",
    quantity: number,
    certificate?: "double", // #1324
  ) => string | null;
  onSellShares: (protocolId: number, percentage: number) => void;
  controlsDisabled: boolean;
  /** Design note #681: why, when `controlsDisabled` is true. */
  controlsBlockedReason: string | null;
  /** Design note #682: the acting seat's colour, for the treasury block. */
  actingSeatColor: string | null;
  /** Design note #417: whether shares can be traded AT ALL right now, i.e.
   *  whether this is a Stock Round. `false` renders no controls -- not
   *  disabled ones. */
  tradingOpen: boolean;
}) {
  /* Design note #18: BUY SOURCE IS LOCAL. A single `App.tsx`-owned `source` flipped IPO/Bank on all
     eight cards at once, so the toggle a player set on PRR governed the purchase they made from B&M.
     The previous pass removed the shared COMPANY selection for this exact bug and left the toggle --
     "which company" and "which source" are the same kind of per-card decision. */
  const [source, setSource] = useState<"Ipo" | "Bank">("Ipo");
  const [buyQuantity, setBuyQuantity] = useState(1);

  // Design note #33: Brown is the only zone that permits several bank-pool
  // shares in one turn, and the pool itself is the ceiling. `marketPrice`
  // is `null` for an unfloated company, which `marketZoneForPrice` reports
  // as no zone -- so an unfloated card can never show the selector.
  const zone = marketZoneForPrice(marketPrice);
  const multiBuyMax =
    allowsMultipleBankPoolBuys(zone) && source === "Bank"
      ? Math.max(1, Math.floor(company.bank_pool_percentage / 10))
      : 1;
  const effectiveQuantity = Math.min(Math.max(1, buyQuantity), multiBuyMax);

  /* Design note #712: THE RULES THE CHART ALREADY DESCRIBED. The chart's own tooltips have told players for a
     long time that the Orange zone lifts the 60% cap and that Yellow-and-up certificates are exempt from the
     limit -- which implies both rules exist everywhere else, and neither was ever checked. The Buy button's
     conditions were "is it your turn" and "can you afford it".
     RESOLVED BY `App`, because the certificate limit needs the private roster and the room's size and this
     panel is given neither. Asked with the source and quantity SELECTED HERE, since the answer depends on
     both. */
  const purchaseBlock =
    purchaseBlockFor?.(company.company_id, source, multiBuyMax > 1 ? effectiveQuantity : 1) ?? null;

  /* Design note #35: the buy button always prices itself. The label only showed a price while unfloated,
     so the suffix vanished exactly when two sources appeared and a price mattered most.
     IPO costs the corporation's PAR price; the Bank Pool costs the current MARKET price.
     Par comes from `company.par_value` once set -- `parValue` is the ladder SELECTION, a control rather
     than a fact, and only what the first buyer pays. */
  const parPrice = company.par_value != null ? Number(company.par_value) : Number(parValue);
  const unitPrice = source === "Bank" ? marketPrice : parPrice;
  const priceKnown = unitPrice != null && Number.isFinite(unitPrice);

  /* The first purchase is NOT a 10% share: whoever buys into a corporation with no president takes the
     President's Certificate -- 20% at DOUBLE par -- so quoting "@ $67" for a $134 transaction is a wrong
     number discovered after signing. Keyed on `president === null`, a contract field, not on arithmetic.
     Design note #36: the gate is BOTH conditions. Holders-with-no-president cannot occur in a legal
     position, but `sandboxState.ts #6` proved how easily an illegal one slips in, so a malformed state
     degrades to the conservative answer rather than advertising a certificate that cannot exist.
     Design note #587: the real test is "has this been STARTED" -- the Camden & Amboy hands out a
     certificate before anyone founds the company, and `par_value` is the field that says so. */
  const isPresidentPurchase = company.president === null && company.par_value === null;
  const buyLabel = (() => {
    if (!priceKnown) {
      // No market position and no par yet -- nothing honest to quote.
      return isPresidentPurchase ? "Buy President's Certificate (20%)" : "Buy 1 share";
    }
    const price = unitPrice as number;
    if (isPresidentPurchase) {
      return `Buy President's Certificate (20%) @ $${price * 2}`;
    }
    const quantity = multiBuyMax > 1 ? effectiveQuantity : 1;
    if (quantity === 1) return `Buy 1 share @ $${price}`;
    return `Buy ${quantity} shares @ $${price} ($${price * quantity})`;
  })();

  /* Design note #20: SELL SIZE IS LOCAL TOO, and this is what fixes the highlight sticking on 10%.
     A shared `sellPercentage` changed the size on all eight cards -- and on a card where the viewer holds
     nothing every size is disabled, so the click never fires and the highlight never moves, which looks
     like a broken toggle rather than "you have no shares here". */
  const [sellPercentage, setSellPercentage] = useState<number>(SELL_PERCENTAGE_OPTIONS[0]);

  /** Design note #21: only sources that actually hold certificates. */
  const availableSources = ([] as Array<"Ipo" | "Bank">).concat(
    company.ipo_pool_percentage > 0 ? ["Ipo"] : [],
    company.bank_pool_percentage > 0 ? ["Bank"] : [],
  );

  // Keeps the local choice legal as pools drain under it -- otherwise a card
  // left on "Bank" after the pool empties would dispatch against a source
  // that no longer has anything to sell.
  useEffect(() => {
    if (availableSources.length > 0 && !availableSources.includes(source)) {
      setSource(availableSources[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [availableSources.join(","), source]);

  // F-6: this player's own stake, which bounds the sell sizes.
  // `player_holdings` OMITS anyone holding exactly 0% (see `gameState.ts`),
  // so an absent entry means zero, not missing data.
  const playerHoldingPercent =
    company.player_holdings.find((holding) => holding.player === connectedAddress)?.percentage ?? 0;
  /* Design note #356: `macroRoundNumber` is 1 for the first Stock Round.
     `undefined` -- a room that does not report it -- permits the sale
     rather than blocking it: the contract refuses an illegal one, and a
     UI that hid Sell on missing data would hide it for the whole game. */
  const sellingForbidden = macroRoundNumber === 1;

  /* Design note #357: a player cannot spend what they do not have. The button gated on turn and session
     readiness, never on price; the sandbox reducer's `adjustCash` floors at zero rather than refusing, so
     a $74 player bought an $82 share and read $0 instead of -$8.
     Gates the TOTAL cost, not the unit price -- a presidency is double par and a Brown multibuy is n
     times the price. `null` cash leaves the gate OFF: a room that does not report a balance is not a room
     where the player is broke. */
  const totalCost = (() => {
    if (!priceKnown) return null;
    const price = unitPrice as number;
    if (isPresidentPurchase) return price * 2;
    return price * (multiBuyMax > 1 ? effectiveQuantity : 1);
  })();
  const cannotAfford =
    playerCash != null && totalCost != null && totalCost > playerCash;
  const bankPoolPercent = company.bank_pool_percentage;
  /* Design note #713: THE SUCCESSOR RULE, WHICH THIS CONTROL NEVER ASKED ABOUT. `sellOptionState` checked
     that the player held enough and that the pool had room, and would sell a presidency into nobody's hands.
     `sellableHoldings` has computed the rule since #6 -- "some OTHER single player already holds enough to
     take the certificate" -- and no sell control consulted it.
     RESOLVED BY `App`, because the rule reads EVERY player's holdings and this card is handed only its own
     company. The local `sellOptionState` still answers first: its two messages are about the bundle the
     player just picked, and they are the ones a player hits most. */
  const localSellState = sellOptionState(sellPercentage, playerHoldingPercent, bankPoolPercent);
  const saleBlock = saleBlockFor?.(company.company_id, sellPercentage) ?? null;
  const selectedSellState: { enabled: boolean; reason?: string } = localSellState.enabled
    ? saleBlock
      ? { enabled: false, reason: saleBlock }
      : localSellState
    : localSellState;

  /* Design note #683: whether a treasury projection is attached beneath each action, hoisted because THREE
     things read it -- the block itself, and the two controls above it that square their bottom corners to meet
     it. Written three times these drift, and the visible failure is a button squared off above nothing, which
     reads as a clipping bug rather than as a missing figure.
     BOTH ARE SILENT WITHOUT A PRICE OR A BALANCE: there is no subtraction to show, and inventing "$0 left" is
     the failure this codebase keeps removing. The sell side is silent in SR1 too -- quoting proceeds beside a
     button banned for the round would price an action nobody can take (#577). */
  const showBuyProjection =
    priceKnown && typeof playerCash === "number" && totalCost !== null;
  const showSellProjection =
    !sellingForbidden &&
    selectedSellState.enabled &&
    typeof playerCash === "number" &&
    // Design note #713: the SALE's price, which is the market's and not the buy toggle's.
    typeof marketPrice === "number";

  /* Design note #417: outside a Stock Round there are no controls -- hidden, not disabled.
     #32 argued a disabled button beats a rejected transaction; the real choice is between a disabled
     button and NO button, and a disabled control claims the action is available here and fixable. The
     roster is a REFERENCE surface for most of the game. `actionsLockedReason` states why once, at the top.
     GUARDED HERE, NOT AT THE CALL SITE: this component holds hooks, so an early return above them would
     change hook order between rounds. Every hook has run by this line; only the render is skipped. */
  if (!tradingOpen) return null;

  return (
    <div style={styles.cardActions}>
      {/* Design note #397: PAR COMES BEFORE THE PRESIDENT'S SHARE. It sat below, sharing a row with the Sell
         selector, because both are the same KIND of control (#22) -- and pairing by control TYPE is what put
         them out of rulebook order. You set a par price and THEN buy the certificate at it, in one motion.
         The sell block loses nothing: par is only offered while `par_value === null`, and a corporation nobody
         has parred has no shares to sell. The two were never on screen together. */}

        {company.par_value === null && (
          <div style={styles.numericRowBlock}>
            <span style={styles.cardActionsLabel}>Par</span>
            <div style={styles.sellSlashRow} role="group" aria-label="Par value">
              {PAR_VALUE_LADDER.map((value, index) => (
                <React.Fragment key={value}>
                  {index > 0 && (
                    <span style={styles.sellSlash} aria-hidden="true">
                      /
                    </span>
                  )}
                  <button
                    type="button"
                    aria-pressed={parValue === value}
                    style={{
                      ...styles.sellSlashOption,
                      ...(parValue === value ? styles.sellSlashOptionActive : {}),
                    }}
                    // Design note #398: says WHICH company's ladder moved.
                    onClick={() => onSelectParValue(company.company_id, value)}
                  >
                    {value}
                  </button>
                </React.Fragment>
              ))}
            </div>
            {/* ==================================================================
                 DESIGN NOTE 1148: WHAT THE RUNG THE PLAYER IS ON WOULD COST
                ==================================================================
                ASKED: "when a player is parring a company, it would be highly useful to know the dollar
                amount required to float."
                LIVE UNDER THE LADDER, WHICH IS THE POINT. A toggle elsewhere would give the same number a
                click later and hide the percentage to do it; here the figure moves as the player moves across
                the rungs, so the ladder stops being a row of prices and becomes the choice it actually is --
                $67 asks $402 of the table, $100 asks $600 for a richer treasury.
                WORDED AS THE CORPORATION'S REQUIREMENT, NOT THE READER'S BILL. The president buys the 20%
                certificate and the other 40% must come from ANYBODY, so "you need $402" would be false -- and
                falsely discouraging at exactly the moment a player is deciding how ambitious to be. "Needed"
                is impersonal and says nothing about whose money it is, which is the whole reason it is the
                word here. See `floatCostIn` for the arithmetic and the same warning where it is computed.
                #1148a: and this is the badge's sentence too, to the letter -- one quantity, one wording.
                SILENT WITH NO RUNG SELECTED, on this file's own rule against inventing a figure: there is no
                par yet, so there is no cost, and "$0 to float" would be a number that is not true. */}
            {parValue !== "" && Number(parValue) > 0 && (
              <span style={styles.parFloatNote}>
                {`$${floatCostIn(Number(parValue), soldFromIpoPercent(company)).remaining} needed to float`}
              </span>
            )}
          </div>
        )}

      {/* Buy */}
      <div style={styles.cardActionsBlock}>
        <span style={styles.cardActionsLabel}>Buy share</span>
        {/* Design note #36: BOTH SOURCES, ALWAYS -- disabled, not absent. Three branches (two buttons, or one of
           two plain-text hints) meant a card changed SHAPE as pools drained, which on a grid of eight reads as
           flicker. #21 removed the empty source to avoid a rejected transaction: right about the CLICK, wrong
           about the CONTROL, since a disabled button refuses just as firmly while still saying the pool exists
           and is empty. It also keeps both buttons in place, so the Buy button underneath never moves. */}
        {/* Design note #346: THE SOURCE IS A SWITCH, NOT TWO BUTTONS. #36's argument for keeping an empty source
           visible still holds; what it got wrong was the WEIGHT -- two full-width padded buttons above Buy made
           choosing a source look like three primary actions rather than one action with a setting.
           A segmented switch says the same thing in one row at a third of the height, with the empty option struck
           through and its reason on hover, sitting ON the Buy row so it reads as one sentence.
           THE DEFAULT is handled by the effect below, which re-points `source` at the first stocked pool and runs
           on mount, covering the "one is empty" case at first render. */}
        {/* Design note #683: computed once, because THREE things depend on it -- whether the block renders,
           whether the button squares its bottom corners, and whether the source toggle does. Written three
           times, they drift, and the failure is a button squared off above nothing. */}
        {/* Design note #683: the row and its projection share an edge, so they need a container that does NOT
           space them -- `cardActionsBlock`'s 6px gap is right between the label and the controls and wrong
           between a control and the base attached to it. */}
        <div style={styles.attachedGroup}>
        <div style={styles.buyRow}>
          <div
            style={{
              ...styles.sourceSwitch,
              ...(showBuyProjection ? styles.attachedAbove : {}),
            }}
            role="group"
            aria-label="Share source"
          >
            {(["Ipo", "Bank"] as const).map((option) => {
              const available = option === "Ipo"
                ? company.ipo_pool_percentage > 0
                : company.bank_pool_percentage > 0;
              return (
                <button
                  key={option}
                  type="button"
                  aria-pressed={source === option}
                  /* Design note #681 (sweep): it computed a look for an EMPTY source and none for a
                     disabled one, so off-turn -- or before the session key was ready -- the toggle stayed
                     fully lit while refusing every click. Both reasons grey it now, and `controlsBlockedReason`
                     answers when the source itself is fine and the moment is not. */
                  style={{
                    ...styles.sourceSwitchOption,
                    ...(source === option && available ? styles.sourceSwitchOptionActive : {}),
                    // Inline styles cannot express `:disabled` (Lobby.tsx
                    // design note #3), so the disabled look is computed.
                    ...(available ? {} : styles.sourceSwitchOptionEmpty),
                    ...(controlsDisabled ? styles.actionButtonDisabled : {}),
                  }}
                  disabled={controlsDisabled || !available}
                  title={
                    !available
                      ? option === "Ipo"
                        ? "The IPO Warehouse is empty."
                        : "The Bank Pool is empty."
                      : (controlsBlockedReason ??
                        (option === "Ipo"
                          ? `Buy from the IPO at par. ${company.ipo_pool_percentage}% left.`
                          : `Buy from the Bank Pool at market price. ${company.bank_pool_percentage}% left.`))
                  }
                  onClick={() => setSource(option)}
                >
                  {option === "Ipo" ? "IPO" : "Pool"}
                </button>
              );
            })}
          </div>

          {/* Design note #347: SOLD OUT IS A STATE, NOT A DISABLED BUY. The button was already disabled but still
             read "Buy 1 share @ $67" -- a control describing an action that cannot happen, which a player reads as
             "I cannot afford it" or "it is not my turn".
             Both pools empty means every certificate is in players' hands: a permanent fact about the company for
             the rest of the round, not a temporary block, so it gets its own label and its own neutral grey. */}
          {availableSources.length === 0 ? (
            <button
              type="button"
              style={{
                ...styles.actionButton,
                ...styles.buyButtonFill,
                ...(showBuyProjection ? styles.attachedAbove : {}),
                ...styles.soldOutButton,
              }}
              disabled
              title={`Every ${company.ticker} certificate is held by players — the IPO and the Bank Pool are both empty.`}
            >
              Sold Out
            </button>
          ) : (
            <button
              type="button"
              onClick={() =>
                onBuyShare(company.company_id, source, multiBuyMax > 1 ? effectiveQuantity : 1)
              }
              /* Design note #466: greyed as well as disabled -- `disabled` alone leaves a button at full contrast
                 that silently refuses the click. Inline styles cannot express `:disabled` (`Lobby.tsx #3`). */
              style={{
                ...styles.actionButton,
                ...styles.buyButtonFill,
                ...(showBuyProjection ? styles.attachedAbove : {}),
                ...(controlsDisabled || cannotAfford || purchaseBlock
                  ? styles.actionButtonDisabled
                  : {}),
              }}
              disabled={controlsDisabled || cannotAfford || purchaseBlock !== null}
              /* Design note #681: #466 got the LOOK right here and left the tooltip saying nothing
                 for every reason but affordability. Cost leads because it is the specific one; the
                 shared reason answers the rest.
                 Design note #712: a RULE beats a price. "You cannot afford it" is advice to come back with
                 more cash; "no player may hold more than 60%" is advice to do something else entirely, and a
                 player told only the first would keep saving toward a purchase the rules forbid. */
              title={
                purchaseBlock
                  ? purchaseBlock
                  : cannotAfford
                    ? `Insufficient funds — costs $${totalCost}, you hold $${playerCash}.`
                    : (controlsBlockedReason ?? undefined)
              }
            >
              {/* Design note #35: one computed label, so the price cannot
                  disappear depending on which branch built the string. */}
              {buyLabel}
            </button>
          )}
          {/* ==================================================================
               DESIGN NOTE 1324: THE 20% CERTIFICATE HAS ITS OWN BUTTON
              ==================================================================
              ERIE's and N&W's standard 20% card (Level Playing Field) is one certificate at twice the share
              price, and it is bought WHOLE -- so it is a second control beside the ordinary buy, shown only
              while the card sits in the source the player has selected, and greyed with the gate's own
              sentence otherwise. A quantity of two on the ordinary button would be two 10% cards, which is a
              different purchase with a different certificate count. */}
          {onBuyDoubleCertificate &&
            !isPresidentPurchase &&
            hasDoubleCertificate(company) &&
            doubleCertificateAt(company) === source &&
            (() => {
              const doubleBlock = purchaseBlockFor?.(company.company_id, source, 1, "double") ?? null;
              const doubleCost = priceKnown ? (unitPrice as number) * 2 : null;
              const doubleUnaffordable =
                playerCash != null && doubleCost != null && doubleCost > playerCash;
              const blocked = controlsDisabled || doubleUnaffordable || doubleBlock !== null;
              return (
                <button
                  type="button"
                  onClick={() => onBuyDoubleCertificate(company.company_id, source)}
                  style={{
                    ...styles.actionButton,
                    ...styles.buyButtonFill,
                    ...(blocked ? styles.actionButtonDisabled : {}),
                  }}
                  disabled={blocked}
                  title={
                    doubleBlock
                      ? doubleBlock
                      : doubleUnaffordable
                        ? `Insufficient funds — costs $${doubleCost}, you hold $${playerCash}.`
                        : (controlsBlockedReason ??
                          "One certificate of 20%, at twice the share price. Counts as one toward the certificate limit.")
                  }
                >
                  {doubleCost === null
                    ? "Buy 20% certificate"
                    : `Buy 20% certificate @ $${doubleCost}`}
                </button>
              );
            })()}
        </div>

        {/* Design note #682: #577's figure, moved out of the button row and given a shape. Its own reasoning is
           unchanged and still right -- the price is on the button, and this is the thing the button cannot say.
           Silent without a price or a balance: there is no subtraction to show, and inventing "$0 left" is the
           failure this codebase keeps removing. */}
        {showBuyProjection && (
          <TreasuryProjectionBlock
            projection={projectTreasury(playerCash as number, -(totalCost as number))}
            seatColor={actingSeatColor}
            action="purchase"
          />
        )}
        </div>

        {/* Design note #33: the Brown zone's multi-buy. Brown is the only zone where a player may take several
           bank-pool shares in one turn, so the quantity selector appears there and nowhere else. The ceiling is
           the pool itself, and it applies only to the Bank source -- the IPO is not what the Brown rule relaxes.
           HONEST LIMITATION, and it is a contract one: `BuyStock` has no quantity parameter, so buying three
           shares is three transactions fired in sequence, stopping at the first failure. Three log entries is
           accurate -- it really is three purchases. Batching would be a contract change. */}
        {multiBuyMax > 1 && (
          <div style={styles.multiBuyRow}>
            <span style={styles.cardActionsLabel}>Quantity</span>
            {/* Design note #681 (sweep): a `<select>` needs this as much as a button does. A form control
                with an authored background does not take the browser's own disabled rendering, so this was
                the third control in the file passing `disabled` and looking available. */}
            <select
              style={{
                ...styles.multiBuySelect,
                ...(controlsDisabled ? styles.actionButtonDisabled : {}),
              }}
              value={Math.min(buyQuantity, multiBuyMax)}
              onChange={(event) => setBuyQuantity(Number(event.target.value))}
              disabled={controlsDisabled}
              title={controlsBlockedReason ?? undefined}
              aria-label="Number of bank pool shares to buy"
            >
              {Array.from({ length: multiBuyMax }, (_, index) => index + 1).map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
            <span style={styles.multiBuyHint}>
              Brown zone — up to {multiBuyMax} from the Bank Pool
            </span>
          </div>
        )}

      </div>

      {/* Design note #466: THE REASON MOVES ONTO THE CONTROL. The button was already disabled; what it lacked
         was the greyed LOOK, so it read as live and refused silently. #357 answered that with a red line
         underneath -- sound, and it treated the symptom by adding a second element to explain the first.
         Greying it removes the premise: a visibly disabled control looks unavailable rather than broken, and the
         red line was costing a row on every card whose owner was short of cash, which is most of them. */}

      {/* Design note #22: par and sell share a line where the card is wide enough -- both are the same KIND of
         control, and `flexWrap` stacks them on a narrow card.
         Design note #29: the par row is gated on `par_value === null`, not `!isFloated`, which was too loose.
         Par is chosen once, by whoever buys the President's share, and from that moment the company HAS a price
         -- so a parred-but-unfloated company (the sandbox B&O) was showing a live ladder for a settled decision. */}
      <div style={styles.numericRowPair}>
        {/* Design note #25: no holding, no Sell -- a control for shares you do not own is an action that cannot
           succeed, and on eight cards where a player typically holds three that is five cards of dead controls.
           Design note #356: NOBODY SELLS IN STOCK ROUND 1. 1830 forbids it -- allowing it would let a player park
           cash in a company and withdraw it before anyone could react.
           HIDDEN, not disabled, and deliberately the opposite call from #36's source buttons: an empty Bank Pool
           is a fact about the BOARD that a buyer wants, while the SR1 ban is a fact about the RULES that cannot
           change this round. A permanently disabled control teaches the player to ignore that region of the card. */}
        {playerHoldingPercent > 0 && !sellingForbidden && (
        <div style={styles.numericRowBlock}>
          <span style={styles.cardActionsLabel}>Sell</span>
        {/* Design note #19: ONE control block, not five buttons. Five bordered chips read as five separate
           decisions and cost a row of vertical space on a card that has to fit eight to a screen. The separators
           are `aria-hidden`, so a screen reader hears five options rather than "10 percent slash 20 percent". */}
        <div style={styles.sellSlashRow} role="group" aria-label="Sell size">
          {SELL_PERCENTAGE_OPTIONS.map((pct, index) => {
            const state = sellOptionState(pct, playerHoldingPercent, bankPoolPercent);
            const active = sellPercentage === pct;
            return (
              <React.Fragment key={pct}>
                {index > 0 && (
                  <span style={styles.sellSlash} aria-hidden="true">
                    /
                  </span>
                )}
                <button
                  type="button"
                  // `title` carries the reason on hover. Native tooltip
                  // rather than a custom one: a disabled button does not
                  // fire pointer events in every browser, so a JS-driven
                  // tooltip is unreliable in exactly the state it is needed.
                  title={state.reason ?? controlsBlockedReason ?? undefined}
                  aria-pressed={active}
                  style={{
                    ...styles.sellSlashOption,
                    ...(active ? styles.sellSlashOptionActive : {}),
                    ...(state.enabled ? {} : styles.sellSlashOptionDisabled),
                    // Design note #681 (sweep): the size buttons had a look for
                    // an illegal SIZE and none for a blocked moment.
                    ...(controlsDisabled ? styles.actionButtonDisabled : {}),
                  }}
                  disabled={controlsDisabled || !state.enabled}
                  onClick={() => setSellPercentage(pct)}
                >
                  {pct}%
                </button>
              </React.Fragment>
            );
          })}
        </div>
        {/* The reason the CURRENT selection cannot be sold, stated inline.
            The per-button tooltip only appears on hover, which a player who
            has already committed to a size will not think to do. */}
        {!selectedSellState.enabled && (
          <span style={styles.sellHint}>{selectedSellState.reason}</span>
        )}
        </div>
        )}
      </div>

      {/* Design note #418: THE SR1 BAN REACHED THE SELECTOR, NOT THE BUTTON. #356 applied `sellingForbidden` to
         the size selector and stopped there, so in SR1 the sizes vanished and a live "Sell 10% Bundle" button
         remained, wired straight to `onSellShares`. The ban was visible and not enforced.
         DISABLED, NOT HIDDEN, and deliberately the opposite of #417 one screen over: the discriminator is
         whether the player can ever act here. Outside a Stock Round the answer is no; in SR1 selling is a real
         action of this panel, barred for one round and legal in every round after, so a disabled button carrying
         the reason teaches a rule the player will need next round.
         THE REASON IS ON THE BUTTON, not only in a tooltip -- the label itself changes. */}
      {/* Design note #679: AND IT HAS TO LOOK BARRED. Reported: "Selling Opens in SR2" is the same colour as the
         Buy buttons beside it, so a rule the panel is trying to teach reads as a control the player simply has
         not pressed yet.
         #418 above got the ENFORCEMENT right and stopped one line short of the appearance -- the button passes
         `disabled` and spread no disabled style, which is the exact failure #466 names two hundred lines down
         ("inline styles cannot express `:disabled`, so every disabled control here computes its own look") and
         #619 found three of in the action bar. The style already existed; the Buy button beside it already used
         it.
         ONE EXPRESSION, TWO USES. The condition is hoisted rather than written twice, because the two copies
         drifting apart -- a button greyed but live, or live but grey -- is a worse bug than either state and is
         how this one arrived. */}
      {/* Design note #683: the sell button's own zero-gap group, same reasoning as the buy row above. */}
      <div style={styles.attachedGroup}>
      {playerHoldingPercent > 0 && (() => {
        const sellDisabled =
          controlsDisabled || sellingForbidden || !selectedSellState.enabled;
        return (
          <button
            type="button"
            style={{
              ...styles.actionButton,
              // Design note #682: the same fill as Buy, so the two sides of the
              // card present one shape.
              ...styles.buyButtonFill,
              ...(showSellProjection ? styles.attachedAbove : {}),
              ...(sellDisabled ? styles.actionButtonDisabled : {}),
            }}
            onClick={() => onSellShares(company.company_id, sellPercentage)}
            disabled={sellDisabled}
            title={
              sellingForbidden
                ? "No selling in the first Stock Round — Project 18XX opens the market to sales from SR2 onward."
                : (controlsBlockedReason ?? undefined)
            }
          >
            {sellingForbidden ? "Selling Opens in SR2" : `Sell ${sellPercentage}% Bundle`}
          </button>
        );
      })()}

      {/* Design note #577, the other direction: a sale RAISES cash, answering the same question. Shown only when
         the sale is genuinely available -- quoting proceeds beside a button banned in SR1 would price an action
         nobody can take.
         Design note #682: the same block as the buy side, so a player reads one shape for both directions and
         the only difference on screen is which way the arrow's colour goes. */}
      {showSellProjection && (
          <TreasuryProjectionBlock
            /* Design note #713: AT THE MARKET PRICE, not `unitPrice`. `unitPrice` follows the IPO/Bank toggle
               above -- a BUY control -- so with the toggle on its default "Ipo" a sale was quoted at the
               corporation's PAR. Par is what the IPO charges; a sale always settles against the chart.
               `saleProceeds` also states rule (i): every certificate in the bundle fetches today's price,
               because the sale settles before the token moves. */
            projection={projectTreasury(
              playerCash as number,
              saleProceeds(marketPrice as number, sellPercentage),
            )}
            seatColor={actingSeatColor}
            action="sale"
            /* Design note #951: the price move joins the cash move rather than sitting under it. `after`
               equal to the current price IS the floor case -- `projectShareSaleMove` returns today's price
               when the token cannot drop -- so it is normalised to `null` here and the row says so. */
            onPeekMarket={
              onPeekSaleMarket
                ? () => onPeekSaleMarket(company.company_id, certificatesIn(sellPercentage))
                : undefined
            }
            marketMove={(() => {
              if (!salePriceAfter || marketPrice === null) return null;
              const after = salePriceAfter(
                company.company_id,
                certificatesIn(sellPercentage),
              );
              if (after === null) return null;
              return {
                ticker: company.ticker,
                before: marketPrice,
                after: after === marketPrice ? null : after,
              };
            })()}
          />
      )}

      {/* Design note #951: THE STANDALONE PRICE ROW LIVED HERE. #713 built it and #743a taught it to speak
          at the floor; both survive, inside `TreasuryProjectionBlock` above. What is gone is the separate div
          and its `saleMarket*` styles -- two rows about one transaction, styled by two rule sets, which is
          how the reported "unformatted, lacks spacing, default system font" happened. */}
      </div>

    </div>
  );
}

// Design note #26 (superseded by #388): this file carried a comparison of two card paradigms behind a
// `USE_FLIP_UI` flag. It was settled -- the flag is deleted rather than left switchable, because a flag
// nobody will flip back is just a second code path to keep working.
// Design note #24/#445: FLOAT IS THE 60% RULE, WITH NO EXCEPTIONS. No auto-float route exists and no
// corporation floats during the Auction Round -- the auction sells PRIVATES. Winning the B&O private
// grants the presidency and prompts a par choice; the B&O then floats on the ordinary 60% condition.
// `auction.rs` setting `is_floated` is a CONTRACT BUG on the audit list, and a frontend that explains a
// bug in the language of a rule is how the bug becomes the rule. The badge still reads `is_floated`, but
// when it disagrees with the 60% math the card reports the DISAGREEMENT and names no cause.

/* Design note #749: BOTH OF THESE ARE GONE, and the pair is why the bug survived. This file had a
   `soldToPlayersPercent` computing `100 - ipo - bank`; `sandboxSession` had one summing `player_holdings`.
   Two files, two spellings, one wrong quantity, and each looked right where it stood. `floatThreshold.ts`
   now owns the arithmetic and names it for what it measures -- `soldFromIpoPercent` -- so the next reader
   has to notice that "out of the IPO" and "in players' hands" are different questions.

   REPORTED: "floating is only contingent on 60% of shares being out of the IPO; if there are 20% in IPO, 20%
   in player, and 60% in market, that corporation is floated and operational the same as a corporation with
   40% in IPO and 60% in player." */

/** How many PHYSICAL certificates a holding represents -- NOT `percentage / 10`. A President's Share is
 *  a 20% double certificate, so a president on 60% holds five, not six. The certificate LIMIT is per
 *  certificate, so counting six overstates their position by one per presidency.
 *  `isPresident` comes from the contract, never from who holds the most (design note #8).
 *  #1374: NO LONGER WHAT THE TABLE RENDERS. It cannot see the 20% standard certificate (#1324), so the
 *  ownership rows count through `doubleCertificate.ts` now; this stays for the printed-game callers and
 *  tests that read it. */
export function certificateCount(percentage: number, isPresident: boolean): number {
  return Math.max(0, percentage / 10 - (isPresident ? 1 : 0));
}

/** 8/4 truncation, matching `utils/lobby.ts`'s `truncateAddress` so one
 *  player reads as the same string here as in the lobby seat list. */
function truncateHolder(address: string): string {
  return address.length <= 14 ? address : `${address.slice(0, 8)}...${address.slice(-4)}`;
}

/* Design note #428: the local `TICKER_COLORS` is gone. The table lives in
   `styles/corporationLivery.ts`, so a recolour cannot reach one surface and miss another. */
const tickerColor = corporationLiveryColor;

/* Design note #389 said "one table, not a second palette that looks close",
   and this file was the second palette. It is now literally true. */

/** Standard 1830 par ladder. Exported since design note #399: the B&O prompt offers the same six rungs.
 *  Design note #415: DERIVED from `StockMarketRenderer.PAR_VALUE_LADDER`. A hand-written list left two
 *  ladders -- prices a player may CHOOSE and prices the board has BOXES for -- and the failure when they
 *  differ is silent: `parBoxCellFor` returns `null`, so a seventh rung here would par a company onto no
 *  cell at all. `String` because this feeds a radio group; the coordinates table is numeric. */
export const PAR_VALUE_LADDER: readonly string[] = PAR_BOX_PRICES.map(String);

/** Every sell-bundle size 1830 can express: 10% blocks up to the 50% Bank Pool cap (F-6). It was
 *  `[10, 20, 30, 40]`, which made a legal move unreachable -- a 60% holder could not dump 50%, and a
 *  president executing a legal dump-and-transfer had no control at all.
 *  Illegal entries render greyed WITH a reason: an absent control teaches nothing, a disabled one that
 *  says "would exceed the 50% Bank Pool cap" teaches the rule when it applies. */
const SELL_PERCENTAGE_OPTIONS: readonly number[] = [10, 20, 30, 40, 50];

/** The 1830 Bank Pool cap: no company may have more than 50% of its shares
 *  sitting in the pool at once. Mirrors the backend's own bound. */
const BANK_POOL_CAP_PERCENT = 50;

/** Whether one sell size is legal, and if not, why. TWO independent limits, reported separately because
 *  they call for different actions: HOLDINGS cannot change this turn, while the POOL CAP moves as other
 *  players buy out of the pool -- so a player who knows the reason knows to wait.
 *  Holdings is checked first: a pool-cap message about shares you never had is less useful. */
function sellOptionState(
  percentage: number,
  playerHoldingPercent: number,
  bankPoolPercent: number,
): { enabled: boolean; reason?: string } {
  if (percentage > playerHoldingPercent) {
    return {
      enabled: false,
      reason: `You hold ${playerHoldingPercent}% — not enough for a ${percentage}% bundle`,
    };
  }
  const poolRoom = Math.max(0, BANK_POOL_CAP_PERCENT - bankPoolPercent);
  if (percentage > poolRoom) {
    return {
      enabled: false,
      reason:
        `Bank Pool is at ${bankPoolPercent}% and caps at ${BANK_POOL_CAP_PERCENT}% — ` +
        `only ${poolRoom}% more can be sold into it`,
    };
  }
  return { enabled: true };
}

/* Design note #682: THE CONSEQUENCE, UNDER THE BUTTON THAT CAUSES IT.

   #577 put this figure beside the Buy button as running micro text, and it was
   reported as unclear -- "a plain-looking text string ... having no styling", so
   a reader who did not already know why it was there could not tell what it was
   claiming. The information was right and the rendering said "aside".

   THREE THINGS CHANGED, and each answers a different half of that:
     BELOW, NOT BESIDE. Under the button it reads as the result of pressing it.
     Beside a button that already carries a price, it read as more label.
     THE SEAT'S OWN COLOUR says whose money this is without a caption -- the one
     question a bare pair of figures could not answer, and the reason the report
     asked for it.
     A DIRECTION, in green or amber. Money moving is the point, and an arrow
     alone is a glyph the reader has to interpret.

   IT IS NOT A SECOND PRICE. The button says what the action costs; this says
   what the player is left with. Two figures that look alike would be worse than
   one, which is why the label leads with `Treasury` and the price never appears
   here. */
function TreasuryProjectionBlock({
  projection,
  seatColor,
  action,
  marketMove = null,
  onPeekMarket,
}: {
  projection: TreasuryProjection;
  /** The acting seat's colour, or `null` when it is not known -- the block then
   *  falls back to the card's own ink rather than inventing a seat. */
  seatColor: string | null;
  /** "purchase" or "sale", for the sentence a tooltip and a screen reader get. */
  action: string;
  /* ==================================================================
      DESIGN NOTE 951: THE OTHER CONSEQUENCE MOVED INTO THE SAME TABLE
     ==================================================================
     REPORTED: "Below the 'Sell' buttons, the string `Share price$76↓$71` is unformatted, lacks spacing, and
     renders in a default system font. Move this information directly into the single-row transaction table
     that currently shows the player's cash changes ... so all consequences of the sale (personal cash and
     corporate stock value) are unified in one readable transaction preview."
     AND THE FORMATTING COMPLAINT AND THE PLACEMENT COMPLAINT HAVE ONE CAUSE. #713 built the price move as a
     SEPARATE div below the block, with its own `saleMarket*` styles -- which never picked up the block's
     figure treatment (tabular numerals, sized label, the gap between label and figures). Two rows that were
     always about one transaction were styled by two sets of rules, so they drifted immediately.
     ONE BLOCK, TWO ROWS, ONE SET OF STYLES. The price row reuses `projectionLabel` and `projectionFigures`
     exactly, which is what makes it inherit the app's font and spacing rather than needing its own copy.
     PASSED AS DATA, NOT AS A NODE. The block renders `ZonedPrice` itself so the zone tooltip #713 argued for
     survives the move -- handing in a ready-made element would have put the formatting back at the call site,
     which is the thing being fixed. */
  /** Design note #1141: opens the mini-camera for this sale, or absent where there is no chart to show. */
  onPeekMarket?: () => void;
  marketMove?: {
    /** The corporation, so the row can say WHOSE share value moved -- the cash row above it is the player's,
     *  and two unlabelled rows in one block would be ambiguous about that. */
    ticker: string;
    before: number;
    /** `null` when the token cannot fall any further; the row then says so instead of drawing an arrow. */
    after: number | null;
  } | null;
}) {
  const tint =
    projection.direction === "short"
      ? styles.projectionShort
      : projection.direction === "up"
        ? styles.projectionUp
        : styles.projectionDown;
  return (
    <div
      style={{
        ...styles.projectionBlock,
        ...(seatColor ? { borderTopColor: seatColor } : {}),
      }}
      title={describeTreasuryProjection(projection, action)}
    >
      <span
        style={{
          ...styles.projectionLabel,
          ...(seatColor ? { color: seatColor } : {}),
        }}
      >
        {/* ==================================================================
             DESIGN NOTE 743: CASH IS A PLAYER'S, TREASURY IS A CORPORATION'S
           ==================================================================

           REPORTED: "listing the player's money as 'Cash' in the action bar and 'Treasury' on the corp card is
           confusing. I think we need to tighten up our language: Cash is what a player has, Treasury is what a
           corporation has."

           THIS BLOCK PROJECTS `playerCash` AND CALLED IT TREASURY, which is the confusion at its source: a
           player watching their own money move read the word the corporation cards use for THEIRS. The module
           behind it is named `treasuryProjection` and stays that way -- it is generic arithmetic over a
           balance, used by both -- but the WORD a player reads has to name whose balance it is.

           1830 makes this distinction load-bearing rather than stylistic. A president's cash and their
           corporation's treasury are separate piles that may not be mixed, except in the one emergency the
           rules carve out; a UI that uses one word for both is teaching the opposite of the rule. */}
        Cash
      </span>
      <span style={styles.projectionFigures}>
        <span style={styles.projectionBefore}>${projection.before}</span>
        {/* The arrow takes the direction's colour with the figure it points at,
            so the pair reads as one movement rather than as a symbol and a
            number that happen to be adjacent. */}
        <span style={{ ...styles.projectionArrow, ...tint }} aria-hidden="true">
          →
        </span>
        <span style={{ ...styles.projectionAfter, ...tint }}>${projection.after}</span>
      </span>
      {projection.short !== null && (
        <span style={styles.projectionShortNote}>${projection.short} short</span>
      )}
      {marketMove && (
        /* Design note #951: the second row, in the same block and the same styles. `width: 100%` breaks the
           line so the two rows stack inside a `flexWrap` container that was built for one -- the alternative
           was a second nested flex, which would have given the price row its own box model again. */
        <span style={styles.projectionRowBreak}>
          <span style={styles.projectionLabel}>{marketMove.ticker} Share Value</span>
          <span style={styles.projectionFigures}>
            <span style={styles.projectionBefore}>
              <ZonedPrice price={marketMove.before} />
            </span>
            {marketMove.after === null ? (
              /* #743a'S RULE, KEPT WORD FOR WORD: "An absent row cannot be told from a missing feature." The
                 token is on the bottom of its column and the sale cannot lower it, and that is a fact about
                 the board rather than a reason to render nothing. */
              <span style={styles.projectionFloorNote}>
                already at the bottom of its column — this sale cannot lower it
              </span>
            ) : (
              <>
                {/* Design note #713: DOWN, not right. The cash row's arrow is horizontal because money moves
                    along a line; a sale moves the token one row DOWN per certificate. Using one glyph for
                    both would flatten the only difference between them a player has to know. */}
                <span
                  style={{ ...styles.projectionArrow, ...styles.projectionDown }}
                  role="img"
                  aria-label={`falls to $${marketMove.after}`}
                >
                  ↓
                </span>
                <span style={styles.projectionAfter}>
                  <ZonedPrice price={marketMove.after} />
                </span>
              </>
            )}
            {/* ==================================================================
                 DESIGN NOTE 1141: THE SAME DOOR, ON THE SALE'S OWN READOUT
                ==================================================================
                RULED alongside the dividend columns: the inline figures stay exactly as they are and gain a
                trigger. It sits INSIDE `projectionFigures` rather than after the row, so it reads as part of
                the price statement rather than as a control the row acquired.
                OFFERED EVEN AT THE FLOOR, unlike the dividend line's -- and deliberately. #743a's note above
                is about a sale that cannot lower the price, which is precisely the moment a player might want
                to SEE why: the chart shows the token sitting on the bottom row with nothing beneath it. */}
            {onPeekMarket && (
              <button
                type="button"
                style={styles.marketPeekButton}
                onClick={onPeekMarket}
                aria-label="See this sale on the market chart"
                title="See this sale on the market chart"
              >
                <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true" focusable="false">
                  <circle cx="5" cy="5" r="3.4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                  <path
                    d="M7.6 7.6L10.5 10.5"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  />
                </svg>
              </button>
            )}
          </span>
        </span>
      )}
    </div>
  );
}

// Design note #749: the local `60` is gone -- one constant, beside the arithmetic that uses it.
export { FLOAT_THRESHOLD_PERCENT } from "../gameEngine/floatThreshold";

export function StockRoundPanel({
  publicCompanies,
  privateCompanies,
  parValueFor,
  onSelectParValue,
  onBuyShare,
  onBuyDoubleCertificate,
  onSellShares,
  /* Design note #799: destructured at last. These three were declared on `StockRoundPanelProps`, forwarded
     from `CorporationRoster` to `CompanyActions`, and asked for by `App` -- and never taken out of `props`
     here, so the value stopped one component short of the button that needed it. */
  purchaseBlockFor,
  saleBlockFor,
  salePriceAfter,
  onPeekSaleMarket,
  sessionReady,
  isMyTurn,
  hotseat = false,
  activePlayerLabel = null,
  actingSeatColor = null,
  connectedAddress,
  macroRoundNumber,
  playerCash,
  marketPrices,
  playerLabel,
  colorForAddress,
  phase,
  outlook,
  actionsLockedReason,
  actionInFlight = false,
  roundType,
  lockedCompanyIds,
  transaction,
  onPresidencyCue,
}: StockRoundPanelProps) {
  /* Design note #32: out of phase counts as "controls disabled" exactly the
     same way an unready session does -- one flag, so no control can be
     wired to one condition and miss the other.

     Design note #681: AND SO DOES SOMEBODY ELSE'S TURN.

     REPORTED, after the SR1 sell button: "let's grey out the buttons when it
     isn't a player's turn so that there is no confusion about what they can be
     doing." The panel already RECEIVED `isMyTurn` -- it had since #34 -- and
     spent it on one header hint. Nothing else read it, so on another seat's turn
     every Buy and Sell button looked and felt completely live, and the refusal
     arrived from `App`'s dispatcher after the click as "It is not your turn."
     The turn gate was real and enforced and entirely invisible until you hit it.
     THE FLAG IS WHY THIS IS ONE LINE. #32's whole argument is that a second
     condition wired control-by-control will miss one; adding the third to the
     flag reaches all five at once and cannot miss.
     THE CARDS ARE NOT GATED, deliberately. `controlsDisabled` feeds action
     controls only -- the roster stays fully readable, and expanding a card to
     study a rival's holdings on their turn is exactly when a player has time to
     do it. Browsing is not acting. */
  /* Design note #1173: THE FOURTH CONDITION, added to the flag rather than to the controls -- which is #32's
     whole argument above and #681's when it added the third. Five controls inherit it and none can miss it. */
  const controlsDisabled =
    !sessionReady || actionsLockedReason != null || !isMyTurn || actionInFlight;

  /* Design note #681: WHY, in one sentence, for whichever control is asked.
     A greyed button that cannot say why is the failure #619 describes from the
     other side -- it looks broken rather than barred. Ordered by precedence, so
     the answer is the first thing that would stop the click rather than the
     last one checked. */
  const controlsBlockedReason: string | null = !sessionReady
    ? "Initialize the session key to act."
    : (actionsLockedReason ??
      (!isMyTurn
        ? `It is ${activePlayerLabel ?? "another player"}'s turn.`
        : /* Design note #1173: LAST in the precedence, because it is the only one of the four that is about
             to resolve itself. A player reading this is being told to wait a moment rather than that they
             may not act -- which is why it is phrased as a report on their own press. */
          actionInFlight
          ? "Sending your last action — one moment."
          : null));
  /* Design note #396: the ACTIVE card -- the one whose action bar renders.
     Renamed from `expandedCompanyId`: it no longer expands anything, it
     decides where the controls live. */
  const [activeCompanyId, setActiveCompanyId] = useState<number | null>(null);
  /* Design note #395: a separate cursor for the private rules text, so
     reading what the D&H does never moves the action bar off the card the
     player was working on. */
  const [expandedPrivateId, setExpandedPrivateId] = useState<number | null>(null);

  /* Design note #348: a flipped card belongs to whoever flipped it. `expandedCompanyId` survived the
     re-render where the turn moved, so in hotseat Bob found Alice's card open on her holdings.
     Keyed on the TURN, not on a purchase -- a player can flip, read and pass without buying, and the turn
     moving is the moment the surface stops belonging to one person. Keyed on the label, which is what
     this component is given and is already resolved per seat. */
  useEffect(() => {
    setActiveCompanyId(null);
    // Design note #395: the private text closes with the turn too. It is
    // reference material for the player who opened it, not a view the next
    // seat inherits.
    setExpandedPrivateId(null);
  }, [activePlayerLabel]);

  /* Design note #10: ACTIONS LIVE IN THE CARD. The global panel was five sections keyed to a pill
     selector, so eight cards showed the position while a separate stack acted on one of them. Expansion
     is now the selection and the pill row is gone.
     ACCORDION HERE, FLAT IN THE AUCTION, deliberately: an auction card has one legal action and six cards
     to compare (dashboard #17), a corporation card has ~twenty controls and there are eight of them.
     The rule is about content volume, not house style. */
  return (
    <div style={styles.root}>
      <div style={styles.headerRow}>
        <span style={styles.headerTitle}>Stock Round</span>
        {/* Design note #34: name the seat rather than address an absent
            "you". Online the wallet check still decides; in hotseat the
            question is only ever which seat is up. */}
        {hotseat
          ? activePlayerLabel !== null && (
              <span style={styles.headerActive}>
                <span style={styles.headerActiveLabel}>Now acting</span>
                <span style={styles.headerActiveName}>{activePlayerLabel}</span>
              </span>
            )
          : !isMyTurn && <span style={styles.headerHint}>Waiting for your turn...</span>}
      </div>

      {/* ---- Corporation roster + per-card actions (design notes #8/#10) */}
      {actionsLockedReason && (
        <span style={styles.readOnlyNotice}>{actionsLockedReason}</span>
      )}

      <CorporationRoster
        lockedCompanyIds={lockedCompanyIds}
        /* Design note #1451: the one hop #799 was written about. */
        transaction={transaction}
        onPresidencyCue={onPresidencyCue}
        publicCompanies={publicCompanies}
        phase={phase}
        outlook={outlook}
        marketPrices={marketPrices}
        // Design note #464: the round drives the card-order boundary.
        roundType={roundType}
        connectedAddress={connectedAddress}
        macroRoundNumber={macroRoundNumber}
        playerCash={playerCash}
        playerLabel={playerLabel}
        colorForAddress={colorForAddress}
        privateCompanies={privateCompanies}
        activeCompanyId={activeCompanyId}
        onActivateCompany={setActiveCompanyId}
        expandedPrivateId={expandedPrivateId}
        setExpandedPrivateId={setExpandedPrivateId}
        parValueFor={parValueFor}
        onSelectParValue={onSelectParValue}
        onBuyShare={onBuyShare}
        onBuyDoubleCertificate={onBuyDoubleCertificate}
        onSellShares={onSellShares}
        /* ==================================================================
           DESIGN NOTE 799: THREE INTERFACES DECLARED IT AND NOBODY PASSED IT
           ==================================================================

           REPORTED: "P1 is at max certificate limit for B&O, but when they open the B&O corp card on a Stock
           Round, the Buy 1 Share button is not grayed out. When they click it, the activity log correctly
           REFUSED the action."

           THE PANEL AND THE REDUCER NEVER DISAGREED -- the panel was never asked. `purchaseBlockFor` is
           declared on `StockRoundPanelProps`, on `CorporationRosterProps` and on `CompanyActionsProps`; the
           roster forwards it to the actions; `App` passes it to the panel. This element, the one hop in the
           middle, did not. So `CompanyActions` called `purchaseBlockFor?.(...) ?? null`, got `null`, and read
           it as "no rule objects" -- which is what an optional callback with an optional-call operator says
           when it is absent.

           #712 SAID IT HAD DONE THIS. "Enforce them on the panel and in the reducer" -- and the reducer half
           landed, which is why the log said REFUSED. The panel half was written, typed, threaded through two
           components, and never connected. A missing optional prop is invisible to `tsc`, silent at runtime
           and indistinguishable from a rule that simply does not fire.

           WHICH IS WHY THIS IS THE THIRD REPORT FROM ONE CAUSE: #778's phantom purchase in the log, #784's
           "no notification that the player was at certificate limit", and now the button itself. I read the
           first two as a panel/reducer disagreement and wrote that down twice. They agreed all along; one of
           them was simply never consulted.

           `saleBlockFor` AND `salePriceAfter` ARE WIRED HERE FOR THE SAME REASON -- both are declared on all
           three interfaces and neither was passed, so the sell side had the identical hole. Nobody has
           reported it yet, which is not evidence that it works. */
        purchaseBlockFor={purchaseBlockFor}
        saleBlockFor={saleBlockFor}
        salePriceAfter={salePriceAfter}
        controlsDisabled={controlsDisabled}
        controlsBlockedReason={controlsBlockedReason}
        actingSeatColor={actingSeatColor}
        /* Design note #417: shares trade in a Stock Round and nowhere else. Derived from
           `actionsLockedReason` -- the sentence rendered directly above -- so the notice and the controls answer
           to one condition rather than two that can disagree. */
        tradingOpen={actionsLockedReason == null}
      />

      {/* Design note #13: the Pass button lives in the global action bar (`App.tsx #30`). Pass and Undo are
         turn-level actions available in every phase, and a second copy here would put two Pass buttons on
         screen -- one of which a player would learn to ignore. */}
    </div>
  );
}

export default StockRoundPanel;

/* Design note #507: ONE WIDTH, WRITTEN TWICE, UPDATED ONCE. The numeric column was encoded in the grid
   tracks (46px) and in the cell's `minWidth` (68px). #466 widened the second -- correctly, "9 (100%)"
   was wrapping -- and a grid item cannot shrink below its `min-width` while a track does not clip, so
   each cell spilled 22px and the Price column ended up 44px off the card.
   Neither site looked wrong alone; they were only wrong together. Both now read one constant, so "the
   track is at least as wide as its content" is true by construction. The space comes from the entity
   column, the only track that can give and one that already ellipsises. */
/* Design note #466: wide enough for the longest value it can hold -- was "9 (100%)" at 68px.
   Design note #780 widened it for "9 (100% max)", the new longest, because the report asked for exactly
   this: "make sure to leave enough room on that column for it to live on one line instead of spilling into
   a second". The name column is `minmax(0, 1fr)` and ellipsises, so it absorbs the difference.
   Design note #791: "tied" is one letter longer than "max" and does NOT extend the longest cell, because a
   tie cannot occur above 50% -- two players sharing the largest holding is at most 50% each. So the widest
   pair is `9 (100% max)` and `4 (50% tied)`, both twelve characters (`holdingMarkers.ts` derives this rather
   than asserting it). Nudged to 100px anyway: the COUNT matches and the letterforms do not, and eight pixels
   of slack is cheaper than re-measuring a proportional font against a fixed cell. */
const OWNERSHIP_NUM_WIDTH = "100px";
const OWNERSHIP_GRID = `minmax(0, 1fr) ${OWNERSHIP_NUM_WIDTH} ${OWNERSHIP_NUM_WIDTH}`;

/* ==================================================================
    DESIGN NOTE 1110: THE VIEWER'S ROW, TINTED IN THEIR OWN COLOUR
   ==================================================================
   86% toward the card's paper. Measured rather than guessed: at that mix every one of the six seats lands
   13.2:1 or better against `CARD_INK` and 6-11 dE away from plain `CARD_SURFACE` -- readable, and visibly
   a highlight. A heavier mix starts to compete with the corporation livery beside it; a lighter one stops
   being seen at all.
   INTEGER CHANNEL MATH, per the project's standing no-floats rule for anything that could round differently
   between engines. Colour is not money, but the rule costs nothing to keep here.
   `null` FALLS BACK TO THE GOLD ROW, so a viewer the shell cannot seat is still marked. */
const SELF_ROW_TINT_PERCENT = 86;

function selfRowTint(seat: string | null): React.CSSProperties {
  if (!seat || !/^#[0-9a-fA-F]{6}$/.test(seat)) {
    return styles.rosterHoldingRowSelf;
  }
  const channel = (i: number) => {
    const from = parseInt(seat.slice(i, i + 2), 16);
    const to = parseInt(CARD_SURFACE.slice(i, i + 2), 16);
    return Math.round(from + ((to - from) * SELF_ROW_TINT_PERCENT) / 100);
  };
  const tint = `#${[1, 3, 5].map((i) => channel(i).toString(16).padStart(2, "0")).join("")}`;
  return {
    backgroundColor: tint,
    color: CARD_INK,
    fontWeight: 800,
    borderWidth: "1px",
    borderStyle: "solid",
    borderColor: seat,
  };
}

const styles: Record<string, React.CSSProperties> = {
  /* Design note #8: the corporation roster.
     Design note #11: responsive without a media query -- `auto-fit` plus a 300px floor gives the same
     ladder a `grid-cols-1 md:grid-cols-2 xl:grid-cols-4` chain expresses, but driven by the space
     actually available. These cards sit inside a padded pane, so a viewport breakpoint would switch a
     column too early. (Inline styles cannot host `@media` at all -- `Lobby.tsx #3`.) */
  rosterGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "12px",
    // Design note #23: `start`, NOT `stretch`. With the accordion back, one open card stretched all seven
    // collapsed ones to its height, leaving dead space INSIDE each card that looked clickable-but-dead.
    // Cards now hug their content.
    alignItems: "start",
  },
  rosterEmpty: { fontSize: FONT_SIZE.small, color: "#6e6c68" },
  /** An unfloated corporation: nothing to trade yet, so dimmer paper. */
  rosterCardUnfloated: { backgroundColor: CARD_SURFACE_MUTED },
  /** The header block, which is the accordion toggle -- design note #23: `width: 100%` plus the card's own
   *  padding puts every pixel of the collapsed body inside the button. */
  rosterCardToggle: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    padding: 0,
    margin: 0,
    border: "none",
    background: "transparent",
    font: "inherit",
    color: "inherit",
    textAlign: "left",
    cursor: "pointer",
    width: "100%",
    // Fills whatever height the card has, so there is never a dead strip
    // below the content inside a collapsed card.
    flex: "1 1 auto",
  },
  /* ---- Per-company action drawer (design note #10) ---- */
  cardActions: {
    display: "flex",
    flexDirection: "column",
    gap: "14px",
    // Design note #15: pushes the whole action block to the bottom of the
    // card, so the Buy and Sell controls land on the same line across every
    // card regardless of how many shareholders sit above them.
    marginTop: "auto",
    paddingBottom: "2px",
    paddingTop: "12px",
    borderTopWidth: "1px",
    borderTopStyle: "solid",
    borderTopColor: CARD_DIVIDER,
  },
  cardActionsBlock: { display: "flex", flexDirection: "column", gap: "6px" },
  /* Design note #683: a control and the projection attached beneath it. Zero gap is the whole job -- the
     seat-coloured seam only reads as one object if there is no paper showing between the two. */
  attachedGroup: { display: "flex", flexDirection: "column", gap: 0 },
  cardActionsLabel: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    fontSize: FONT_SIZE.micro,
    fontWeight: 800,
    letterSpacing: "0.5px",
    textTransform: "uppercase",
    color: CARD_INK_FAINT,
  },
  /* Design note #1148: the float cost, under the rung that sets it. `CARD_INK_MUTED` rather than the label's
     `CARD_INK_FAINT` -- this is a FIGURE the player is reading, not a caption naming a control, and the two
     weights are what keep the ladder the loudest thing in the block. Not uppercased for the same reason. */
  /* Design note #1148: a button that must weigh exactly what the span it replaced weighed. Every visual
     property still comes from `rosterLiveryBadge`; this only undoes what a `<button>` brings with it --
     the user-agent font (the badge sets size and weight but never the family), its own background, and the
     text alignment that would fight the badge's `inline-flex`. `cursor` is the only thing ADDED, because it
     is the affordance: the badge has to look pressable or nobody will press it. */
  floatBadgeButton: {
    appearance: "none",
    background: "none",
    fontFamily: "inherit",
    lineHeight: "inherit",
    textAlign: "center",
    cursor: "pointer",
  },
  parFloatNote: {
    fontSize: FONT_SIZE.micro,
    color: CARD_INK_MUTED,
    fontVariantNumeric: "tabular-nums",
  },
  /* ---- Pass row (design note #10: the one global action) ---- */
  passRow: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    flexWrap: "wrap",
  },
  passHint: { fontSize: FONT_SIZE.small, color: "#6e6c68" },
  /* Design note #9: paper cards, matching the auction's private-company treatment (dashboard #15). A dark
     card on a dark panel is a rectangle you have to hunt for, and these eight are what the round is about.
     Every child colour is re-derived for dark-on-light; the president row needed a real rework. */
  rosterCard: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    padding: "12px 14px",
    // Design note #23: no forced height. Content decides.
    boxSizing: "border-box",
    backgroundColor: CARD_SURFACE,
    borderWidth: "2px",
    borderStyle: "solid",
    borderRadius: RADIUS.card,
    // Design note #389: the livery stripe bleeds to the card's edges, so
    // the card clips it back inside the corner radius.
    overflow: "hidden",
    cursor: "pointer",
    textAlign: "left",
    font: "inherit",
    color: CARD_INK,
    boxShadow: "0 3px 12px rgba(0,0,0,0.4)",
  },
  rosterCardHeader: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px" },
  /* Design note #389: the corporate livery stripe. Negative margins cancel the card's padding exactly so
     it reads as a painted band rather than a coloured box inside one; `overflow: hidden` on the card keeps
     the square stripe corners inside the radius. */
  rosterLivery: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "8px",
    margin: "-12px -14px 0",
    padding: "9px 14px",
    minWidth: 0,
  },
  rosterLiveryTicker: {
    fontSize: FONT_SIZE.heading,
    fontWeight: 800,
    letterSpacing: "0.5px",
    // Inherits the computed ink; stated so nothing downstream re-tints it.
    color: "inherit",
  },
  /* Design note #465: the readable handle, beside the herald. Monospace
     and tracked out so it reads as a TICKER rather than as the first word
     of the full name that follows it. */
  rosterLiveryAcronym: {
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
    fontSize: FONT_SIZE.strong,
    fontWeight: 800,
    letterSpacing: "0.04em",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  rosterLiveryName: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 600,
    letterSpacing: "0.01em",
    color: "inherit",
    // Design note #22's uniform card width still governs: a long name
    // ellipsises rather than widening the card.
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    opacity: 0.85,
  },
  /** Design note #392: the right-hand cluster in the stripe -- payout then
   *  float status. Grouped so the pair stays together when a long
   *  corporate name pushes on them. */
  rosterLiveryRight: {
    display: "flex",
    alignItems: "center",
    gap: "7px",
    flexShrink: 0,
  },
  rosterLiveryPayout: {
    fontSize: FONT_SIZE.strong,
    fontWeight: 800,
    fontVariantNumeric: "tabular-nums",
    letterSpacing: "0.01em",
  },
  /* ---- Design note #393: the one-line asset row ----
     A single flex line directly under the stripe. `tabular-nums` on the
     values so the figures line up down a column of eight cards, which is
     most of what makes a dense grid scannable. */
  assetRow: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    flexWrap: "wrap",
    fontSize: FONT_SIZE.micro,
    color: CARD_INK,
    lineHeight: 1.35,
  },
  /* Design note #504: a COLUMN, value over caption -- `rosterPrice`'s exact shape, so both rows of the
     card caption their values the same way round. `alignItems: flex-start` because the chips are wider
     than their captions and centring would float each word under the middle of its chip row. */
  assetItem: {
    display: "inline-flex",
    flexDirection: "column",
    alignItems: "flex-start",
    gap: "3px",
    /* Design note #490: `cursor: "help"` is gone. It advertised a tooltip
       that carried the caption, and the caption is now on the card. A help
       cursor over content that explains itself is a promise of more. */
  },
  /* Design note #490: the word that replaced the pictogram. Set to match
     `rosterPriceLabel` -- uppercase, faint, letter-spaced -- so the two
     rows of the card caption their values the same way instead of one using
     typography and the other using pictures. */
  assetLabel: {
    fontSize: FONT_SIZE.micro,
    color: CARD_INK_FAINT,
    textTransform: "uppercase",
    letterSpacing: "0.4px",
    fontWeight: 700,
  },
  /* "none", where a value would be. Italic and muted so an empty holding
     reads as an answer rather than as a component that failed to render. */
  assetEmpty: {
    fontSize: FONT_SIZE.micro,
    color: CARD_INK_MUTED,
    fontStyle: "italic",
  },
  assetValue: {
    fontWeight: 700,
    fontVariantNumeric: "tabular-nums",
  },
  assetDivider: {
    color: CARD_DIVIDER,
    fontWeight: 400,
  },
  /* ---- Design note #395: corporate-owned private rows ---- */
  privateRowGroup: {
    display: "flex",
    flexDirection: "column",
  },
  privateRow: {
    display: "flex",
    alignItems: "baseline",
    justifyContent: "space-between",
    gap: "8px",
    width: "100%",
    padding: "2px 4px",
    margin: 0,
    border: "none",
    borderRadius: RADIUS.control,
    background: "transparent",
    font: "inherit",
    fontSize: FONT_SIZE.micro,
    color: CARD_INK,
    textAlign: "left",
    cursor: "pointer",
  },
  /** Collapsed: one line, clipped. The card is a fixed width (design note
   *  #22) and "Champlain & St. Lawrence" is longer than it. */
  privateName: {
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    minWidth: 0,
  },
  /** Expanded: the same text, allowed to wrap to its full length. */
  privateNameOpen: {
    whiteSpace: "normal",
    fontWeight: 700,
    minWidth: 0,
  },
  privateRevenue: {
    flexShrink: 0,
    fontWeight: 700,
    color: "#1d7a45",
    fontVariantNumeric: "tabular-nums",
  },
  privateRules: {
    margin: "1px 4px 5px",
    fontSize: FONT_SIZE.micro,
    lineHeight: 1.45,
    color: CARD_INK_MUTED,
  },
  /* ==================================================================
      DESIGN NOTE 948: DESATURATED AND DEAF
     ==================================================================
     RULED: "Change it so the entire card is desaturated and entirely unclickable/unexpandable."
     `filter: grayscale` RATHER THAN A FLAT OVERLAY, because the card's identity IS its colour -- the livery
     header, the market chip, the president crown. Draining the saturation leaves every one of those legible
     as shape and position while removing the thing that makes the card look live beside seven that are.
     `opacity` ON TOP, lightly: grayscale alone leaves a card at full contrast, which still competes for the
     eye even after the hue has gone.
     `pointerEvents: "none"` IS THE UNCLICKABLE HALF, and it is on the CARD rather than the button. The whole
     face is the toggle (#16/#26), so disabling the button alone would leave the padding around it live and
     the cursor still changing over it. The button is `disabled` as well -- that one is for the keyboard,
     which pointer events cannot reach. */
  rosterCardLocked: {
    filter: "grayscale(1)",
    opacity: 0.55,
    pointerEvents: "none",
  },
  /** The standing sentence, sized as a footnote rather than a warning: this is a fact about the game's
   *  shape, not something the player did wrong. Muted amber keeps it findable without reading as an error --
   *  the same reasoning #619 gives for the must-buy-a-train notice being amber and not red. */
  rosterCardLockedNote: {
    margin: 0,
    padding: "6px 10px 8px",
    fontSize: FONT_SIZE.micro,
    lineHeight: 1.35,
    color: "#c8b070",
    textAlign: "center",
  },
  /** Design note #396: the active card carries the controls, so it is
   *  lifted off the grid rather than merely outlined. */
  rosterCardActive: {
    boxShadow: "0 0 0 1px rgba(77,142,224,0.35), 0 6px 18px rgba(0,0,0,0.28)",
  },
  /** Float status inside the stripe. Outlined in the stripe's own ink
   *  rather than filled, so it reads as a badge without introducing a
   *  third colour onto a band that is already carrying two. */
  rosterLiveryBadge: {
    flexShrink: 0,
    display: "inline-flex",
    alignItems: "baseline",
    gap: "5px",
    fontSize: FONT_SIZE.micro,
    fontWeight: 800,
    letterSpacing: "0.04em",
    padding: "2px 7px",
    borderRadius: RADIUS.pill,
    borderWidth: "1px",
    borderStyle: "solid",
    fontVariantNumeric: "tabular-nums",
  },
  /* Design note #503: the caption inside the badge, answering #488's "captioned by position means
     captioned by nothing". `color: "inherit"` with alpha rather than a fixed grey -- this badge sits on
     eight different corporate fills and takes its ink from the stripe (see `ContextualActionBar #236`). */
  rosterLiveryBadgeCaption: {
    fontWeight: 600,
    letterSpacing: "0.02em",
    textTransform: "uppercase",
    color: "inherit",
    opacity: 0.75,
  },
  /* Design note #490: the crown's replacement -- a tag rather than running text, so it is skimmable.
     Design note #552: this now sizes a drawing, so the type properties went with the text; `color` stays
     and is load-bearing, since the crown fills with `currentColor`.
     Design note #577: the balance after the purchase, in tabular figures so the two numbers line up either
     side of the arrow rather than jittering as the quantity selector moves.
     Design note #682: `cashAfter`/`cashAfterShort` are GONE with the inline string they drew. An orphaned style
     for a rendering somebody has just asked us to stop using is how it comes back -- the rule `palette.ts`
     records for its deleted colour token, and this file's own #466 for `cannotAffordNote`. */
  /* Design note #682: the projection block. A BORDER carries the seat colour rather than a fill: these cards
     are warm near-white paper (`palette.ts`), and a saturated seat colour behind text would need its own
     contrast rule across eight hues -- which is what `bestContrastTextColor` exists for, and is far more
     machinery than a two-figure row deserves. A 3px edge is legible at every hue against paper and needs none.

     Design note #683: ATTACHED, NOT ADJACENT. #682 rendered this as its own box with a 6px gap above it, and
     it was reported as still not reading like part of the button that causes it -- "I thought the button itself
     could be vertically expanded to have a player color segment".
     THE SEAT COLOUR MOVED TO THE TOP EDGE, which is the whole trick: flush against the control above, a 3px
     seat-coloured bar reads as the SEAM of one taller object rather than as the frame of a second one. The
     bottom corners are rounded and the top ones square, so the block finishes the shape the button started.

     WHY NOT INSIDE THE BUTTON, which is what was actually asked for: a disabled control must grey out (#681,
     and #619 before it), and greying this would dim a figure that is still true -- including in the
     insufficient-funds case, where it is the figure EXPLAINING the refusal. A readout inside a control also
     makes part of a click target inert. Attached gets the single-object reading; separate keeps the number
     legible when the button is not. */
  projectionBlock: {
    display: "flex",
    alignItems: "baseline",
    flexWrap: "wrap",
    gap: "8px",
    padding: "6px 10px",
    backgroundColor: "rgba(0, 0, 0, 0.05)",
    borderTop: "3px solid",
    borderTopColor: CARD_INK_MUTED,
    borderRadius: `0 0 ${RADIUS.card} ${RADIUS.card}`,
  },
  projectionLabel: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    color: CARD_INK_MUTED,
  },
  /* Tabular figures so the pair does not jitter as the quantity selector moves
     -- #577's own observation, and the part of it that needed no change. */
  projectionFigures: {
    display: "inline-flex",
    alignItems: "baseline",
    gap: "5px",
    fontVariantNumeric: "tabular-nums",
    whiteSpace: "nowrap",
  },
  /* Design note #951: the line break inside the block's `flexWrap` row, so the price row stacks under the
     cash row rather than needing a nested flex of its own. `width: 100%` is the whole mechanism. */
  projectionRowBreak: {
    width: "100%",
    display: "flex",
    alignItems: "baseline",
    gap: "8px",
    flexWrap: "wrap",
  },
  /* #743a's sentence, at the label's own scale -- it is an explanation, not a figure. */
  projectionFloorNote: {
    fontSize: FONT_SIZE.micro,
    color: CARD_INK_MUTED,
    fontStyle: "italic",
    whiteSpace: "normal",
  },
  projectionBefore: { fontSize: FONT_SIZE.small, fontWeight: 700, color: CARD_INK_MUTED },
  projectionArrow: { fontSize: FONT_SIZE.small, fontWeight: 700 },
  projectionAfter: { fontSize: FONT_SIZE.body, fontWeight: 800 },
  /* Design note #682: green up, amber down, red only for a genuine block. `cashDelta.ts` #670 settled the
     amber -- red in this app marks a contested auction and an error toast, and money leaving a player's hand
     to buy a share is neither. Spending is ordinary and reads as ordinary, which also keeps red meaning "you
     cannot do this", as it already did on this card. */
  projectionUp: { color: "#2f7d52" },
  projectionDown: { color: "#8a6a1f" },
  projectionShort: { color: "#a4442f" },
  projectionShortNote: { fontSize: FONT_SIZE.micro, fontWeight: 700, color: "#a4442f" },
  presidentTag: {
    color: CARD_HIGHLIGHT_BORDER,
    marginRight: "5px",
    flexShrink: 0,
  },
  rosterTicker: { fontSize: FONT_SIZE.heading, fontWeight: 800, letterSpacing: "0.5px" },
  rosterNameStack: { display: "flex", flexDirection: "column", gap: "1px", minWidth: 0 },
  /* Design note #501: the herald and the acronym, side by side -- a ROW inside the column stack so the
     full name keeps its own line. `minWidth: 0` because a flex item otherwise refuses to shrink below its
     content and a long acronym would push the name's ellipsis out of the card. */
  rosterIdentityRow: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: "7px",
    minWidth: 0,
  },
  rosterFullName: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 600,
    color: CARD_INK_MUTED,
    letterSpacing: "0.01em",
    // Long names (New York, New Haven & Hartford) must not widen the card
    // -- every roster card is one uniform size by design note #22.
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  rosterFloatedBadge: {
    fontSize: FONT_SIZE.micro, fontWeight: 700, padding: "2px 8px", borderRadius: RADIUS.pill,
    backgroundColor: "#d9f0e1", color: "#14522f",
  },
  rosterUnfloatedBadge: {
    fontSize: FONT_SIZE.micro, fontWeight: 700, padding: "2px 8px", borderRadius: RADIUS.pill,
    backgroundColor: CARD_HIGHLIGHT_BG, color: "#6b4e05",
  },
  // Design note #32: says WHY the controls are dead. A grid of greyed-out
  // buttons with no explanation reads as a broken panel.
  // Design note #36: an empty pool's button stays put and stops responding.
  multiBuyRow: { display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" },
  multiBuySelect: {
    fontSize: FONT_SIZE.small,
    fontWeight: 700,
    padding: "3px 8px",
    borderRadius: RADIUS.control,
    borderWidth: "1px",
    borderStyle: "solid",
    borderColor: CARD_DIVIDER,
    backgroundColor: CARD_SURFACE_MUTED,
    color: CARD_INK,
  },
  multiBuyHint: { fontSize: FONT_SIZE.micro, color: CARD_INK_FAINT },
  readOnlyNotice: {
    fontSize: FONT_SIZE.small,
    color: "#c9a94c",
    fontWeight: 600,
  },
  rosterPriceRow: { display: "flex", gap: "18px", alignItems: "flex-end" },
  /* Design note #31: the front-face operating snapshot. A bordered strip rather than three loose pairs, so
     it reads as one block distinct from the prices above and the holdings below. `flexWrap` because a
     corporation at its Phase 2 limit can hold four chips. */
  rosterPrice: { display: "flex", flexDirection: "column", gap: "1px" },
  /* Design note #489: flush right via `marginLeft: auto`, not `space-between` -- the row's other three
     cells must stay grouped as a sequence, or treasury looks like the fourth in a series instead of the
     balance it is. `alignItems: flex-end` ends the figure flush with the card edge. */
  rosterTreasury: { marginLeft: "auto", alignItems: "flex-end", textAlign: "right" },
  rosterPriceValue: {
    fontSize: FONT_SIZE.heading, fontWeight: 800, color: CARD_INK,
    fontVariantNumeric: "tabular-nums", lineHeight: 1.1,
  },
  rosterPriceValueMuted: {
    fontSize: FONT_SIZE.strong, fontWeight: 700, color: CARD_INK_MUTED,
    fontVariantNumeric: "tabular-nums", lineHeight: 1.1,
  },
  rosterPriceLabel: {
    fontSize: FONT_SIZE.micro, color: CARD_INK_FAINT,
    textTransform: "uppercase", letterSpacing: "0.4px",
  },
  /* Design note #378: the ownership table is a GRID, not a flex row per line. `space-between` let the gap
     vary with the name's length, so a column of percentages did not line up -- the one thing a table of
     numbers exists to do. `rosterHoldings` went with the list it styled. */
  ownershipTable: {
    /* Design note #1451: the box the transfer proxy is positioned inside. It is also what makes
       `offsetWithin` terminate on the table rather than walking out of the card. */
    position: "relative",
    display: "flex", flexDirection: "column", gap: "1px",
    borderTopWidth: "1px", borderTopStyle: "solid", borderTopColor: CARD_DIVIDER,
    paddingTop: "7px",
  },
  ownershipRow: {
    display: "grid",
    gridTemplateColumns: OWNERSHIP_GRID,
    alignItems: "baseline",
    gap: "6px",
    fontSize: FONT_SIZE.small,
    color: CARD_INK,
    padding: "2px 4px",
    borderRadius: RADIUS.control,
  },
  ownershipHeadRow: {
    display: "grid",
    gridTemplateColumns: OWNERSHIP_GRID,
    alignItems: "baseline",
    gap: "6px",
    padding: "0 4px 2px",
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    letterSpacing: "0.05em",
    textTransform: "uppercase",
    color: CARD_INK_FAINT,
  },
  ownershipName: {
    display: "inline-flex", alignItems: "center", gap: "5px",
    minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
  },
  /* Design note #466: wide enough for the longest value it can hold -- "9 (100%)", a full IPO, which
     wrapped because the column was sized by content. `whiteSpace: nowrap` alone would have overflowed. */
  ownershipNum: {
    textAlign: "right",
    fontVariantNumeric: "tabular-nums",
    flex: "0 0 auto",
    minWidth: OWNERSHIP_NUM_WIDTH,
    whiteSpace: "nowrap",
  },
  /* Design note #789: THE WORD IS THE MARKER, and #780's bold-plus-amber is gone.
     REPORTED: "I'm not sure '5 (60% max)' needs to be bolded and turned amber. One counter against the bold
     is that the display already renders the player's holdings in bold; a counter to the amber is that the
     active player's highlight is a yellow box, so amber on it is somewhat odd."
     BOTH LAND, AND THE SECOND IS THE ONE I SHOULD HAVE CAUGHT. #421 highlights the reader's own row in a warm
     box -- so the row a player looks at FIRST is exactly where an amber figure had the least contrast and the
     most competition. A signal that is weakest on the row it matters most on is not a signal.
     THE BOLD WAS ALSO REDUNDANT: `ownershipRow` already carries the holdings at weight, so #780's "bold is
     easy to miss in a column of figures" was arguing against a column this is not.
     AND TEXT BEATS BOTH ON #732's OWN TERMS. That note says colour alone is not a distinction every player
     can read; "max" is a word, which every player can read and no palette can clash with. Losing the styling
     makes the marker MORE accessible rather than less -- the rare case where the smaller change is also the
     better one. The style key is deleted rather than left unused, per #772: a `Record<string, CSSProperties>`
     hides an orphan from both `tsc` and ESLint. */
  /* Design note #378: the line between shares nobody owns and shares
     somebody does. Reset from the browser default, which is an inset 3D
     bevel that reads as a separator between SECTIONS rather than as a rule
     inside a table. */
  ownershipRule: {
    height: 0,
    margin: "3px 0",
    border: "none",
    borderTop: `1px solid ${CARD_DIVIDER}`,
  },
  rosterNoHoldings: { fontSize: FONT_SIZE.small, color: CARD_INK_FAINT, fontStyle: "italic" },
  /* Design note #1451: the travelling percentage. A small piece of coloured card -- which is what a
     certificate is -- at the size of the type it leaves and lands on. No glow, no outline beyond a hairline
     of shadow to lift it off the row it passes over. */
  transferChip: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 800,
    lineHeight: 1.1,
    padding: "1px 5px",
    borderRadius: RADIUS.control,
    fontVariantNumeric: "tabular-nums",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.3)",
  },
  // Design note #8: gold + bold, the second of the president's markers.
  // Design note #421: the amber row is the VIEWER's. Renamed rather than repointed -- the old name
  // described the thing it was wrong about, and a later reader would put it back on the crown.
  rosterHoldingRowSelf: {
    backgroundColor: CARD_HIGHLIGHT_BG,
    color: CARD_HIGHLIGHT_INK,
    fontWeight: 800,
    borderWidth: "1px",
    borderStyle: "solid",
    borderColor: CARD_HIGHLIGHT_BORDER,
  },
  rosterHoldingName: {
    display: "inline-flex", alignItems: "center", gap: "5px",
    minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
  },
  /* `rosterYouTag` DELETED by design note #421. The row fill says "yours"
     now; a pill saying it again beside the name is the duplication that
     note removed from the president. Deleted rather than left unused --
     an orphaned style is an invitation to render it again. */
  rosterHoldingPercent: { flexShrink: 0, fontVariantNumeric: "tabular-nums" },
  /** Design note #28: the call to action on an unparred company. */
  setParPrompt: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    color: CARD_HIGHLIGHT_INK,
    backgroundColor: CARD_HIGHLIGHT_BG,
    borderRadius: RADIUS.control,
    padding: "3px 7px",
    alignSelf: "flex-start",
  },
  /** Design note #24: the contract-state-vs-math disagreement note. */
  /* Design note #445: renamed from `autoFloatNote`. It no longer marks a
     float route; it marks a flag that disagrees with the share counts. */
  floatMismatchNote: {
    fontSize: FONT_SIZE.micro,
    fontStyle: "italic",
    color: CARD_INK_FAINT,
  },
  rosterPoolRow: {
    display: "flex", justifyContent: "space-between",
    fontSize: FONT_SIZE.micro, color: CARD_INK_FAINT,
  },

  root: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    width: "100%",
    padding: "14px 20px",
    // Design note #1117: the one viewport ground, shared by every tab.
    backgroundColor: INK_VIEWPORT,
    border: "1px solid #2a2a2a",
    // Design note #1257: square on top, where the tab strip attaches.
    borderRadius: VIEWPORT_RADIUS,
    boxSizing: "border-box",
  },
  headerRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: {
    fontSize: FONT_SIZE.strong,
    fontWeight: 700,
    color: "#f2f0eb",
  },
  /* Design note #34: the active seat, stated positively. Green because it
     is an invitation to act, not a warning -- `headerHint` below is the
     grey "wait" treatment it replaces in hotseat. */
  headerActive: { display: "inline-flex", alignItems: "center", gap: "6px" },
  headerActiveLabel: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    color: "#8a8a86",
  },
  headerActiveName: {
    fontSize: FONT_SIZE.strong,
    fontWeight: 800,
    color: "#7ee0a1",
  },
  headerHint: {
    fontSize: FONT_SIZE.small,
    color: "#a8a6a0",
  },
  section: {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
    flex: 1,
  },
  sectionInactive: {
    opacity: 0.55,
  },
  sectionLabel: {
    /* Rendered as an `h2` (#1432): zeroed so the heading occupies exactly the space the span did. */
    margin: 0,
    display: "flex",
    alignItems: "center",
    gap: "8px",
    fontSize: FONT_SIZE.small,
    fontWeight: 700,
    color: "#a8a6a0",
    textTransform: "uppercase",
    letterSpacing: "0.03em",
  },
  companyPillRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: "6px",
  },
  companyPill: {
    display: "inline-flex",
    alignItems: "center",
    gap: "4px",
    fontSize: FONT_SIZE.body,
    fontWeight: 700,
    padding: "6px 12px",
    borderRadius: RADIUS.pill,
    border: "1.5px solid",
    backgroundColor: "transparent",
    cursor: "pointer",
  },
  floatedDot: {
    display: "inline-block",
    width: "6px",
    height: "6px",
    borderRadius: RADIUS.circle,
    backgroundColor: "currentColor",
  },
  emptyHint: {
    fontSize: FONT_SIZE.body,
    color: "#6e6c68",
  },
  floatBadge: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    padding: "2px 8px",
    borderRadius: RADIUS.pill,
    backgroundColor: "#2a2a2a",
    color: "#a8a6a0",
  },
  floatBadgeActive: {
    backgroundColor: "#1d4a34",
    color: "#6fdc9b",
  },
  /** Wrapper for the collapsed-body float bar -- design note #17. */
  controlsRow: {
    display: "flex",
    gap: "18px",
    flexWrap: "wrap",
  },
  parGrid: {
    display: "flex",
    flexWrap: "wrap",
    gap: "6px",
  },
  parCell: {
    fontSize: FONT_SIZE.body,
    fontWeight: 600,
    padding: "6px 10px",
    borderRadius: RADIUS.control,
    border: "1px solid #3a3a3a",
    /* Design note #1117: was #161616, a well one step under the old #1c1c1c ground. The ground moved
       DOWN to #141414 and #161616 landed on top of it -- a well at the same lightness as its floor is
       not a well. Dropped to the panel step so it still reads as inset. */
    backgroundColor: "#0f0f0f",
    color: "#c8c6c0",
    cursor: "pointer",
  },
  parCellActive: {
    backgroundColor: "#2a2a2a",
    borderColor: "#4a6a92",
    color: "#f2f0eb",
  },
  /* Design note #346: Buy and its source on one row. The switch does not
     grow; the Buy button takes the rest, so the price stays readable at
     every card width. */
  buyRow: { display: "flex", alignItems: "stretch", gap: "8px" },
  /* Design note #682: the Buy button takes the width the figure beside it used to occupy. With the projection
     moved below, the row holds a source toggle and a button -- and a button stopping short of the card edge
     leaves a ragged gap exactly where a number used to be, which reads as something failing to render. */
  buyButtonFill: { flex: "1 1 auto", textAlign: "center" },
  /* Design note #683: squares the bottom corners of a control that has the projection block attached beneath
     it, so the two share an edge instead of leaving paper visible in the corner notches. Applied only when a
     projection is actually rendering -- a squared-off button with nothing under it looks like a clipping bug. */
  attachedAbove: { borderBottomLeftRadius: 0, borderBottomRightRadius: 0 },
  sourceSwitch: {
    display: "flex",
    flexShrink: 0,
    borderRadius: RADIUS.control,
    borderWidth: "1px",
    borderStyle: "solid",
    borderColor: "#3a3a3a",
    overflow: "hidden",
  },
  sourceSwitchOption: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    padding: "0 9px",
    border: "none",
    /* Design note #1117: was #161616, a well one step under the old #1c1c1c ground. The ground moved
       DOWN to #141414 and #161616 landed on top of it -- a well at the same lightness as its floor is
       not a well. Dropped to the panel step so it still reads as inset. */
    backgroundColor: "#0f0f0f",
    color: "#8a8a86",
    fontFamily: "inherit",
    cursor: "pointer",
  },
  sourceSwitchOptionActive: {
    backgroundColor: "#2a2a2a",
    color: "#f2f0eb",
  },
  /* Struck through rather than merely faded: an empty pool is not "not
     chosen", it is "nothing here to buy", and the two look identical at
     40% opacity. */
  sourceSwitchOptionEmpty: {
    opacity: 0.45,
    cursor: "not-allowed",
    textDecoration: "line-through",
  },
  /* Design note #347: neutral grey, deliberately NOT the primary button desaturated -- this is a state of
     the company, not a control waiting to become available.
     Design note #466: the greyed treatment for a refused Buy. Inline styles cannot express `:disabled`
     (`Lobby.tsx #3`), so every disabled control here computes its own look. */
  actionButtonDisabled: {
    opacity: 0.45,
    cursor: "not-allowed",
  },
  /* `cannotAffordNote` deleted by design note #466 -- it explained a Buy button that looked enabled, and
     the button is greyed now. An orphaned refusal style is an invitation to render a second one. */
  soldOutButton: {
    backgroundColor: "#1c1c1c",
    borderColor: "#3a3a3a",
    color: "#8a8a86",
    cursor: "not-allowed",
  },
  /* Design note #19: the slashed sell row, superseding the five-chip stepper -- as a non-wrapping flex row
     the 50% chip rendered outside the card border entirely, since flex does not shrink past content and
     nothing clipped it. A row of text-weight options wraps as text instead.
     Design note #22: paired numeric rows. */
  numericRowPair: { display: "flex", flexWrap: "wrap", gap: "10px", alignItems: "flex-start" },
  numericRowBlock: { display: "flex", flexDirection: "column", gap: "4px", flex: "1 1 auto", minWidth: 0 },
  sellSlashRow: {
    display: "flex",
    // Design note #30: NO WRAP. Five options plus four separators is a fixed width with nothing to reflow,
    // and wrapping only ever dropped "50%" onto its own line, reading as a sixth control. Padding and gap
    // are tightened to buy the width back.
    flexWrap: "nowrap",
    alignItems: "center",
    gap: "1px",
    padding: "5px 6px",
    borderRadius: RADIUS.card,
    borderWidth: "1px",
    borderStyle: "solid",
    borderColor: CARD_DIVIDER,
    backgroundColor: "rgba(0,0,0,0.03)",
  },
  sellSlash: { color: CARD_INK_FAINT, fontSize: FONT_SIZE.small, opacity: 0.5 },
  sellSlashOption: {
    background: "transparent",
    border: "none",
    // Design note #30: 6px -> 3px horizontal. Across five options and four
    // separators that is 30px reclaimed, which is what makes one line fit.
    padding: "2px 3px",
    whiteSpace: "nowrap",
    borderRadius: RADIUS.control,
    fontSize: FONT_SIZE.small,
    fontWeight: 700,
    fontVariantNumeric: "tabular-nums",
    color: CARD_INK_MUTED,
    cursor: "pointer",
  },
  sellSlashOptionActive: { backgroundColor: CARD_HIGHLIGHT_BG, color: CARD_HIGHLIGHT_INK },
  // Inline styles cannot express `:disabled` (Lobby.tsx design note #3), so
  // the disabled look is computed.
  sellSlashOptionDisabled: { opacity: 0.35, cursor: "not-allowed", textDecoration: "line-through" },
  sellHint: {
    fontSize: FONT_SIZE.micro,
    lineHeight: 1.4,
    color: "#c8a24a",
  },
  actionButton: {
    fontSize: FONT_SIZE.body,
    fontWeight: 700,
    padding: "9px 14px",
    borderRadius: RADIUS.card,
    border: "1px solid #3a3a3a",
    backgroundColor: "#1c1c1c",
    color: "#f2f0eb",
    cursor: "pointer",
  },
  passButton: {
    fontSize: FONT_SIZE.body,
    fontWeight: 700,
    padding: "9px 18px",
    borderRadius: RADIUS.card,
    border: "1px solid #4a3f3f",
    backgroundColor: "#2c2020",
    color: "#e8c7c7",
    cursor: "pointer",
  },
};
