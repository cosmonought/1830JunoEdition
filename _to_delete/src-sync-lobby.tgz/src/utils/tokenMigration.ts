// Where a station token ends up when the tile under it changes.
//
// Design note #0: the report has two halves with different causes. THE
// VISIBILITY HALF is an omission -- the radial confirm ring ghosts the tile and
// says nothing about the pieces already standing on the hex. THE CONTROL HALF
// was blocked by a shape that no longer exists: `sandboxState.ts` noted that
// `station_token_hexes` had no slot index, and Audit G-12 added `station_tokens`
// as `(q, r, city_index)`. The destination IS expressible now.
//
// Design note #1: PRESERVE THE INDEX, AND SAY SO. `LayTile` carries a tile and
// an orientation and nothing else, so a UI letting the president pick would
// collect an answer it cannot send and the contract would apply its own rule
// regardless -- the worst of the three outcomes, because the player would have
// been asked. So the mapping is DECLARED: a token in city `i` stays in city `i`,
// which is the ordinary 18xx upgrade rule and what `tileCityAnchors` already
// draws against.
//
// WHERE THE MAPPING IS GENUINELY AMBIGUOUS -- a one-city hex becoming a two-city
// tile -- this reports it as ambiguous rather than pretending index 0 was
// chosen. Closing that needs `LayTile` to accept a token destination, which is a
// contract change.
//
// See docs/ai_architecture/hex_tile_math.md, tokenMigration.ts #0 / #1.

import { cityExitEdges, liveEdges, rotateConnections, tileCityCount, tileCityEdges } from "../components/hexGeometry";
import { TILE_CATALOG_BY_ID } from "../components/hexTileCatalog";
import { fitStationsToUpgrade, type StationAnchor } from "./stationConnectivity";
import { archetypeForHex } from "../components/hexGeometry";
import { printedArtworkEdgePairs, tileCitySlotCounts } from "../components/TileGraphics";
import { STATIC_BOARD_HEXES } from "../components/hexBoardData";
import { tokenCityIndex, type StationTokenCompany } from "../components/hexContractTypes";
import type { MapGridResponse } from "../components/hexContractTypes";

/** One corporation's token on the hex being upgraded. */
export interface TokenMigration {
  companyId: number;
  ticker: string;
  /** The city it occupies now. `null` when the chain has not said -- an
   *  older contract without `station_tokens`, which must not be reported as
   *  city 0. */
  fromCityIndex: number | null;
  /** The city it will occupy after the lay. */
  toCityIndex: number;
  /** How many cities the new tile carries, for "city 1 of 2". */
  toCityCount: number;
}

export interface TokenMigrationPreview {
  migrations: TokenMigration[];
  /** The hex gains city nodes, so the destination is one of several and the
   *  president would have a real choice if the message could carry it --
   *  design note #1. */
  ambiguous: boolean;
  /** Cities before and after, for the caption. */
  fromCityCount: number;
  toCityCount: number;
}

/* ==================================================================
 *  DESIGN NOTE 824: THE INDEX WAS OURS, NOT THE BOARD'S
 * ==================================================================
 *
 * REPORTED: "when players place a station on the preprinted yellow ERIE hex, they have no idea what the
 * upgrade tile looks like or where their station will end up. When the tile finally gets upgraded to green,
 * they may discover that they want an orientation that forces a city into the gray E9 hex, which was unlikely
 * to have been their intention."
 *
 * AND THEN THE ARGUMENT THAT SETTLES IT: "in an actual physical game, when a player upgrades ERIE's home hex,
 * the station is removed from the board to place the new tile, then the player sets their token where they
 * want it. Because there is no marking for 'City 1' vs 'City 2' on the preprinted yellow hex, there is no way
 * to debate whether one city or the other is the correct one for the station marker when the Green tile is
 * laid."
 *
 * THAT IS NOT A HOUSE RULE, IT IS THE ABSENCE OF ONE. Design note #1 above declared "a token in city `i`
 * stays in city `i`, which is the ordinary 18xx upgrade rule" -- and it is, wherever `i` names something. On
 * a LAID tile it does: the two circles are drawn in different places and a marker sits visibly in one of
 * them. On the PREPRINTED yellow OO hex nothing distinguishes them. `tokenCityIndex` returns a number there
 * because our data model has to store the token somewhere, and #1 then enforced that bookkeeping artefact as
 * though the cardboard had said it.
 *
 * SO THIS IS THE SAME FAILURE AS EVERY OTHER ONE THIS WEEK, in its purest form yet: a surface asserting
 * something the board never said. The difference is that here the assertion was in a rule module and had a
 * design note defending it.
 *
 * WHAT IT COST, in the report's own words: "ERIE's president may lock themselves out of an orientation they
 * want and either have to accept suboptimal placement or force the game to undo back into a previous
 * Operating Round."
 *
 * THE REMEDY IS THE ONE THE REPORT ASKED FOR: "let players click through every possible Green tile upgrade
 * with the station marker on one city, then do it again on the other city." One extra dimension on the
 * rotation cycle, and no new control to learn.
 *
 * DESIGN NOTE #1'S OTHER HALF IS STILL TRUE AND IS THE REAL WORK: "`LayTile` carries a tile and an
 * orientation and nothing else, so a UI letting the president pick would collect an answer it cannot send."
 * That is why this was deferred rather than overlooked. It is fixed by carrying the answer -- `token_city` on
 * the message, flagged as a contract gap exactly like #808's `bypass`, and applied by the sandbox reducer
 * that is the authority today.
 */

/** How many distinct city nodes the hex carries right now. */
function currentCityCount(mapGrid: MapGridResponse, q: number, r: number): number {
  switch (archetypeForHex(mapGrid, q, r)) {
    case "SingleCity":
      return 1;
    case "DoubleCity":
      return 2;
    default:
      return 0;
  }
}

/** Where every token on `(q, r)` lands if `tileId` is laid there.
 *
 *  `null` when nothing is standing on the hex, which is the common case and the
 *  one where the ring should say nothing at all -- a caption about token
 *  migration on an empty hex is noise on every ordinary tile lay. */
/** SUPERSEDED BY `planTokenUpgrade` (design note #878) AND KEPT ONLY AS THE RECORD OF THE OLD RULE.
 *
 *  It answers "which city index did this token have" and preserves it, which is not a question the board can
 *  answer -- "city 0" names a different corner at each of six orientations, and this function takes no
 *  orientation at all. Nothing in the app calls it. Do not wire it to anything: a token's destination is
 *  whichever city still owns its edges, which is what `planTokenUpgrade` computes. */
export function previewTokenMigration(
  mapGrid: MapGridResponse,
  q: number,
  r: number,
  companies: readonly StationTokenCompany[],
  tileId: number,
): TokenMigrationPreview | null {
  const here = companies.filter((company) =>
    company.station_token_hexes.some(([tq, tr]) => tq === q && tr === r),
  );
  if (here.length === 0) return null;

  const slots = tileCitySlotCounts(tileId);
  const toCityCount = slots.length;
  // A tile this build cannot describe: say nothing rather than guess a
  // destination. The ghost preview is already drawn from the same catalog,
  // so a gap here means the player is not seeing the tile either.
  if (toCityCount === 0) return null;

  const fromCityCount = currentCityCount(mapGrid, q, r);

  const migrations = here.map((company) => {
    const from = tokenCityIndex(company, q, r) ?? null;
    /* Design note #1: the index is PRESERVED. Clamped rather than allowed
       to overflow -- a two-city hex downgrading to one city is not a legal
       1830 lay, but a clamp costs nothing and a token drawn at city 1 of a
       one-city tile would be drawn nowhere. */
    const to = Math.min(Math.max(from ?? 0, 0), toCityCount - 1);
    return {
      companyId: company.company_id,
      ticker: company.ticker,
      fromCityIndex: from,
      toCityIndex: to,
      toCityCount,
    };
  });

  return {
    migrations,
    // Only a GAIN in city nodes creates a choice. A one-to-one upgrade puts
    // the token where the only city is, which is not a decision.
    ambiguous: toCityCount > Math.max(1, fromCityCount),
    fromCityCount,
    toCityCount,
  };
}

/** The city indices a president may choose between when `tileId` is laid on `(q, r)`.
 *
 *  Design note #824. One entry is not a choice -- it is the preserved index, and every ordinary upgrade in
 *  the game returns exactly that. Two entries mean the board has never distinguished the token's city, so the
 *  president picks now, which is what the physical game does by lifting the marker off before laying.
 *
 *  EMPTY when nothing is standing here: no token, no question.
 *
 *  ==================================================================
 *   DESIGN NOTE 824a: I GENERALISED FROM THE SHAPE, NOT THE REASON
 *  ==================================================================
 *
 *  The first version tested "is there a laid tile" and said so proudly: "a preprinted double-city hex with no
 *  tile on it has two indistinguishable cities whoever owns the token -- which covers New York as well as
 *  Dunkirk & Buffalo." That is false, and it was corrected on report: "NY should not get the same treatment
 *  because the NNH home station is on a city with a route to it, and the connectivity of that station must be
 *  preserved. It would make no sense for NNH's station to be able to 'jump' to the disconnected city."
 *
 *  THE BOARD SAYS IT PLAINLY AND I COULD HAVE ASKED BEFORE GENERALISING. `printedArtworkEdgePairs` returns
 *  `[[1, null], [4, null]]` for G19 -- two cities, each with its OWN edge stub -- and `[]` for E11, which
 *  prints no track at all. New York's cities are told apart by what they connect to. Dunkirk & Buffalo's are
 *  two bare circles with nothing to tell apart.
 *
 *  SO THE TEST IS CONNECTIVITY, which is the real 1830 rule and was in the report all along: "a station can
 *  only be placed where there is route connectivity, and that connectivity must be preserved with every
 *  upgrade." A city with a connection keeps its token. A hex that prints nothing has no connection to
 *  preserve, which is why the physical game simply lifts the marker off.
 *
 *  IT SELECTS EXACTLY ONE HEX ON THIS BOARD, and the report said that too: "this situation in 1830 can only
 *  ever arise when the ERIE home station is placed before its hex has been upgraded from yellow to green."
 *  Still stated as a property rather than a name -- but no longer claiming more hexes qualify than do.
 *
 *  THE LESSON, and it is the second correction in two passes: I generalised from the SHAPE I had noticed (a
 *  preprinted double city) instead of from the REASON (nothing to preserve), and the shape caught a hex where
 *  the reason does not hold. A generalisation is only safe when what is general is the rule. */
export function tokenDestinationChoices(
  mapGrid: MapGridResponse,
  q: number,
  r: number,
  companies: readonly StationTokenCompany[],
  tileId: number,
): number[] {
  const preview = previewTokenMigration(mapGrid, q, r, companies, tileId);
  if (!preview || preview.migrations.length === 0) return [];

  const preserved = [preview.migrations[0].toCityIndex];

  /* A laid tile's circles are drawn in different places and the marker is visibly in one of them, so #1's
     preserve-the-index rule is a statement about the board rather than about our storage. */
  if (mapGrid.tiles.some((tile) => tile.q === q && tile.r === r)) return preserved;
  if (currentCityCount(mapGrid, q, r) < 2) return preserved;

  /* Design note #824a: AND THE CONNECTIVITY TEST, which is the one that matters. Any printed track on the hex
     means at least one city is reached by something, and a token in a connected city may not leave it. New
     York prints one stub per city; ERIE's home prints none. */
  const label = STATIC_BOARD_HEXES.find((hex) => hex.q === q && hex.r === r)?.label;
  if (label === undefined) return preserved;
  if (printedArtworkEdgePairs(label).length > 0) return preserved;

  /* Every city the NEW tile carries. A green OO upgrade has two; if a future tile had three this needs no
     edit, which is the point of counting rather than assuming. */
  return Array.from({ length: preview.toCityCount }, (_, index) => index);
}

/** One line for the radial confirm ring, or `null` when there is nothing worth
 *  saying. Phrased as a statement of where the piece goes, because that is the
 *  question a president has when they see their own token on the hex they are
 *  about to rebuild.
 *
 *  ==================================================================
 *   DESIGN NOTE 823: NOTHING CALLS THIS, AND THAT IS THE POINT
 *  ==================================================================
 *
 *  REQUESTED: "there is a tooltip that says 'Station marker on city 1 of 2' but nobody playing the game knows
 *  what that means. We can remove that string and have the preview render the station marker."
 *
 *  IT WAS ALWAYS STANDING IN FOR A PICTURE. "City 1 of 2" is an INDEX, and the two cities on an OO tile are
 *  told apart by where they sit rather than by an order anybody can see. The sentence existed because the
 *  preview could not show the answer; #822 made it able to, so the drawing replaces the coordinate.
 *
 *  KEPT RATHER THAN DELETED, which is the opposite of what #660a usually argues, and deliberately: the
 *  MIGRATION ARITHMETIC above it is live -- every radial thumbnail asks it where a token lands -- and this is
 *  the one place that arithmetic is stated in words. `tokenMigration.test.ts` reads it, which is a real
 *  reader even if no player is. If a future surface needs to SAY where a token goes rather than draw it, this
 *  is the wording, already argued over.
 *  The line it printed, for the record: "This tile splits the hex into 2 cities. ERIE to city 1 of 2 — the
 *  tile lay cannot choose a different one." */
export function describeTokenMigration(preview: TokenMigrationPreview | null): string | null {
  if (!preview) return null;
  const { migrations, ambiguous, toCityCount } = preview;
  const named = migrations
    .map((entry) => `${entry.ticker} to city ${entry.toCityIndex + 1} of ${toCityCount}`)
    .join(", ");
  if (!ambiguous) {
    // One city on the far side: worth confirming the token survives, not
    // worth explaining a choice that does not exist.
    return toCityCount === 1 ? `Station token stays put (${named}).` : `Station token: ${named}.`;
  }
  return `This tile splits the hex into ${toCityCount} cities. ${named} — the tile lay cannot choose a different one.`;
}

/* ==================================================================
    DESIGN NOTE 878: THE CONNECTIVITY-AWARE REPLACEMENT
   ==================================================================

   `previewTokenMigration` above is SUPERSEDED and kept only so its note stays readable beside the thing that
   corrects it. Its rule was `to = clamp(from)` -- "the index is PRESERVED" -- and it took no ORIENTATION,
   which is the tell: connectivity is a property of a tile AS LAID, so a signature with no rotation in it
   cannot express the question. Reported as "upgrades to OO tiles are not preserving corporation station
   network connectivity."

   THIS ONE ASKS THE BOARD. Each token's city has live edges today (`cityExitEdges`, #852); the destination is
   whichever city of the candidate still owns them (`fitStationToUpgrade`, #878). `null` for the whole thing
   means this orientation strands somebody and is not a legal upgrade. */


export interface TokenLanding {
  companyId: number;
  ticker: string;
  fromCityIndex: number | null;
  /** Where connectivity puts it, or `null` when it has none to preserve and the president may choose. */
  toCityIndex: number | null;
}

export interface UpgradeTokenPlan {
  landings: readonly TokenLanding[];
  /** True when at least one token is unanchored, so the president still has a say (ERIE's first upgrade). */
  anyFree: boolean;
}

/** Where every token on `(q, r)` lands if `tileId` is laid at `orientation`, or `null` if one is stranded.
 *
 *  `null` IS ALSO THE LEGALITY ANSWER, which is why the rotation filter and the preview can share one call:
 *  an orientation that cannot seat every standing token is not an upgrade a president may choose. */
export function planTokenUpgrade(
  mapGrid: MapGridResponse,
  q: number,
  r: number,
  companies: readonly StationTokenCompany[],
  tileId: number,
  orientation: number,
): UpgradeTokenPlan | null {
  const here = companies.filter((company) =>
    company.station_token_hexes.some(([tq, tr]) => tq === q && tr === r),
  );
  // No token, no constraint -- and no plan to draw. Every orientation stays legal.
  if (here.length === 0) return { landings: [], anyFree: false };

  const cityCount = tileCityCount(tileId);
  const stations = tileCitySlotCounts(tileId);

  /* ==================================================================
      DESIGN NOTE 1315: A SINGLE-CITY CANDIDATE STILL GETS A FIT
     ==================================================================
     The branch below this one treated "fewer than two distinguished cities" as "nothing to decide" and
     handed back `null` destinations. True for the commonest lay -- a yellow city to a green one -- and
     wrong for the one the Project 18XX+ tile set adds: New York's #62 (two two-station cities) to #883 (one
     four-station city). Tokens carrying city index 1 landed on a tile with no city 1: `citySlotCount` answered
     zero slots for them, and a zero-slot city with an occupant reads as a WALL to every other corporation's
     routes. So a candidate with exactly one city goes through the same fit as a two-city one, with that city
     owning every edge of the tile -- every token lands at index 0, and the fit refuses an orientation that
     would overfill it. */
  if (stations.length === 1 && cityCount < 2) {
    const entry = TILE_CATALOG_BY_ID.get(tileId);
    const everyEdge = entry ? liveEdges(rotateConnections(entry.connections, orientation)) : [];
    const anchors: StationAnchor[] = here.map((company) => ({
      companyId: company.company_id,
      edges: cityExitEdges(mapGrid, q, r, tokenCityIndex(company, q, r) ?? null),
    }));
    const landing = fitStationsToUpgrade(anchors, [everyEdge], stations);
    if (landing === null) return null;
    return {
      landings: here.map((company) => ({
        companyId: company.company_id,
        ticker: company.ticker,
        fromCityIndex: tokenCityIndex(company, q, r) ?? null,
        toCityIndex: 0,
      })),
      anyFree: false,
    };
  }
  /* A CANDIDATE THIS BUILD CANNOT DESCRIBE says nothing rather than guessing, and specifically does not
     REFUSE: a single-city upgrade distinguishes no cities, every token lands in the only one there is, and
     calling that illegal would forbid the commonest lay in the game. */
  if (cityCount < 2) {
    return {
      landings: here.map((company) => ({
        companyId: company.company_id,
        ticker: company.ticker,
        fromCityIndex: tokenCityIndex(company, q, r) ?? null,
        toCityIndex: cityCount === 1 ? 0 : null,
      })),
      anyFree: false,
    };
  }

  const candidate: number[][] = [];
  for (let city = 0; city < cityCount; city++) {
    candidate.push(tileCityEdges(tileId, orientation, city) ?? []);
  }

  const anchors: StationAnchor[] = here.map((company) => ({
    companyId: company.company_id,
    /* THE TOKEN'S OWN CITY, not the hex's. `cityExitEdges` returns every live edge when it cannot tell which
       city a token is in -- which would over-constrain rather than under-constrain, and is the safe direction:
       a president is refused an orientation rather than silently handed a severed network. */
    edges: cityExitEdges(mapGrid, q, r, tokenCityIndex(company, q, r) ?? null),
  }));

  const landing = fitStationsToUpgrade(anchors, candidate, stations);
  if (landing === null) return null;

  return {
    landings: here.map((company) => ({
      companyId: company.company_id,
      ticker: company.ticker,
      fromCityIndex: tokenCityIndex(company, q, r) ?? null,
      toCityIndex: landing.get(company.company_id) ?? null,
    })),
    anyFree: here.some((company) => landing.get(company.company_id) == null),
  };
}

/* ==================================================================
    DESIGN NOTE 885: THE MAP THE LAY ACTUALLY SENDS
   ==================================================================
   #880 derived every token's destination and then assembled the wire map inline in the confirm handler --
   the newest rule in `App.tsx` and, like the six before it, reachable only by grep. It decides two things
   worth holding: that EVERY standing token's answer travels (not just the actor's), and that the president's
   rotation choice overrides exactly one case.
   THE OVERRIDE IS THE SUBTLE HALF. A token the plan left FREE has no derived city -- ERIE's, on a board that
   never distinguished the two -- so the choice the president made by rotating is the answer. An ANCHORED
   token ignores that choice, because connectivity already decided and there was no choice to make. Letting
   the choice win there would put #878's superseded rule back through a side door. */

/* ==================================================================
    DESIGN NOTE 1400: THE UPGRADER CHOOSES FOR EVERY FREE TOKEN, NOT ONLY ITS OWN
   ==================================================================
   REPORTED: "When upgrading the ERIE home station tile to Green and the home station is placed, the
   tileselector is supposed to rotate through all possible combinations with ERIE in one city, then repeat it
   with ERIE in the other city. At one time this worked when ERIE was the one upgrading its home station hex,
   but N&W is trying to upgrade it and only gets the first set of rotations with ERIE's station in one city."
   IT ONLY EVER WORKED FOR ERIE, BY DESIGN -- #885 wrote "a free token belonging to anyone else is omitted
   rather than guessed: this president is not choosing for them", and the shell's `ownIsFree` asked only
   about the ACTING corporation's token. Both halves were the same decision, and it was the wrong one: the
   corporation laying the tile is the one placing the tokens on it. That is how connectivity is preserved
   for everybody (#880), and where connectivity says nothing -- an unbuilt home -- the same president makes
   the call for the same reason. So the rotation's second dimension (#824) opens whenever ANY standing token
   is free, and the chosen city fills in every free token. Anchored tokens still ignore the choice (#878). */

/** `[company_id, city_index]` for every token whose destination is known.
 *
 *  A FREE TOKEN -- anybody's -- takes the city the president chose by rotating (#1400); one with no choice
 *  yet made is omitted rather than guessed, and the reducer leaves it where the chain recorded it. */
export function tokenLandingsFor(input: {
  plan: UpgradeTokenPlan | null;
  /** Kept for the callers' shape; since #1400 the choice is not scoped to it. */
  actingCompanyId: number | null;
  /** What the president chose by rotating, where the plan left a token free. */
  chosenCity: number | undefined;
}): Array<[number, number]> {
  const { plan, chosenCity } = input;
  return (plan?.landings ?? []).flatMap((entry) => {
    const anchored = entry.toCityIndex;
    const chosen = anchored === null ? chosenCity : anchored;
    return chosen === undefined || chosen === null
      ? []
      : [[entry.companyId, chosen] as [number, number]];
  });
}
