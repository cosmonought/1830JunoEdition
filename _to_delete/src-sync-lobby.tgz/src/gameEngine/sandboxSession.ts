// frontend/src/utils/sandboxSession.ts
//
// The sandbox's local reducer. NOT a rules engine: the CosmWasm contract owns
// every 1830 rule, and nothing here may become a second opinion about one.
//
// It moves only what can move without knowing a rule -- turn pointers, the
// pass streak, the OR cursor, and cash/shares by the amount the CALLER states.
// Every function returns a NEW state object (React identity), and it is driven
// by the real GameplayExecuteMsg union so a new variant cannot bypass it.
//
// Charter and full history: docs/ai_architecture/sandbox_reducer.md
// -- sandboxSession.ts #0, #1, #2

import type {
  GameStateResponse,
  PublicCompanyState,
  RoundType,
  TileColor,
  WaterfallMiniAuctionStatus,
  WaterfallPrivateStatus,
  WaterfallStateResponse,
} from "./gameState";
import { bankIsBroken } from "./endgame";
import {
  BANK,
  creditPlayer,
  creditTreasury,
  debitBank,
  transfer,
  type LedgerResult,
} from "./cashLedger";
import {
  DELAYED_AUCTION_TRIGGER_TIER,
  /* Design note #1051: the pre-#1051 die, for logs written before the roll was recorded. The reducer never
     DRAWS -- it runs on every client for every replay, so a draw here would be four boards and a fifth on
     reload -- it only reads what the log holds, or reconstructs what an older log implied. */
  legacyTurnSeed,
  resolveVariants,
  sellBuySellInForce,
  rollTurnRevenue,
} from "./gameVariants";
// Design note #723: the terrain fee is charged on the FIRST build of a hex and never again.
import { terrainFeeDue, withTerrainPaid } from "./terrainFee";
// Design note #736: which arriving tier closes the private companies.
import { closesPrivateCompanies } from "./depotSchedule";
// Design note #979: which train the limit takes is a rule, and it lives with the other train-limit rules.
import { trimToTrainLimit } from "./trainLimit";
// actingSeatIndex lives in gameState.ts, not here: it asks about CONTRACT state and the
// live dashboard needs it too. See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0
import type { GameplayExecuteMsg } from "../utils/sessionKey";
// Design note #1100: numerals name tiers, words count trains.
import { namedTrains as sayTrains } from "./trainPhrasing";
/* Design note #1189: the lifecycle messages the shell used to own. `gameSetup.ts` imports nothing from this
   module, so the edge is one-way and there is no cycle to introduce. */
import {
  dealSandboxGame,
  isAnswerPrivatePurchaseMsg,
  isAnswerPrivateTradeMsg,
  isAnswerTrainPurchaseMsg,
  isBuyKanawhaLicenseMsg,
  isCloseRoomMsg,
  isExchangePrivateMsg,
  isOpenStockRoundMsg,
  isPlaceHomeStationMsg,
  isProposePrivatePurchaseMsg,
  isProposePrivateTradeMsg,
  isProposeTrainPurchaseMsg,
  isRescindPrivatePurchaseMsg,
  isRescindPrivateTradeMsg,
  isRescindTrainPurchaseMsg,
  isSetBoParMsg,
  isSetupGameMsg,
  waterfallForRoster,
} from "./gameSetup";
import { BO_TICKER, SV_PRIVATE_ID, eraForPhase } from "./gameConstants";
/* Design note #1580 (Batch 7.3): the private auction's one authority. Asked ABOVE the auction atom, because
   that atom runs before the board -- see `applySandboxActionOnBoard`. */
import { auctionRefusal, isAuctionMessage } from "./auctionAuthority";
/* Design notes #1590-#1595 (Batch 7.4): the ordinary offers' one hold and their three authorities -- the
   corporation's private purchase, the intercorporate train sale, and the player <-> player private trade --
   asked here by identity and at ingress with the sentence, the #1570/#1580 shape. */
import {
  allocateOfferInstance,
  legacyOfferMessageRefusal,
  pendingOfferBlock,
  privateSettlementMatches,
  trainSettlementMatches,
} from "./pendingOfferHold";
import {
  answerPrivatePurchaseRefusal,
  currentPrivateOwner,
  privatePurchaseRefusal,
  proposePrivatePurchaseRefusal,
  rescindPrivatePurchaseRefusal,
} from "./privatePurchaseAuthority";
import {
  answerTrainPurchaseRefusal,
  proposeTrainPurchaseRefusal,
  rescindTrainPurchaseRefusal,
  sellerPresident,
  trainSaleRefusal,
} from "./trainSaleAuthority";
import {
  answerPrivateTradeRefusal,
  proposePrivateTradeRefusal,
  rescindPrivateTradeRefusal,
  stockRoundSeat,
} from "./privateTradeAuthority";
import { CA_BONUS_TICKER, CA_PRIVATE_ID, applyPrivateExchange } from "./privateExchange";
import type { MapGridResponse, MapTileEntry } from "../components/hexContractTypes";
// Design note #1325: a corporation's home hexes on the board in effect (two for the LPF's C&O).
import { homeHexesFor } from "../components/hexContractTypes";
import { TILE_CATALOG_BY_ID, type TileColorTier } from "../components/hexTileCatalog";
import { archetypeForHex, hexValueForEra } from "../components/hexGeometry";
import { depotInventory, derivePhase, openDepotTiers, TIER_ORDER, trainTier, type GamePhase } from "./gamePhase";
// Design note #712: the market-zone purchase rules, shared with the Stock Round panel.
import { sharePurchaseBlock, type PriceZone } from "./sharePurchase";
import { hasActedThisTurn } from "./turnAction";
// Design note #1184: the bid minimum, in one place the button and the board both read.
import { MIN_BID_INCREMENT, minimumBidFor } from "./auctionEscrow";
import { roundEndSoldOutRises } from "./soldOutRise";
import { shareSaleBlock } from "./shareSale";
import { metFloatThreshold, FULL_CAPITALISATION_MULTIPLE } from "./floatThreshold";
// Design note #763: a float is not finished until its home token is on the board.
import { homeTokenBlock } from "./homeTokenGate";
import { dividendRefusal, dividendRefused } from "./dividendGate";
import { operatingIdentityRefusal } from "./operatingIdentity";
import { stationPlacementRefusal } from "./stationPlacementGate";
import { cheapestPurchasableTrain, trainObligationRefusal } from "./trainAvailability";
import { discardTrainRefusal, pendingDiscardBlock } from "./trainDiscard";
import {
  declareBankruptcyRefusal,
  emergencyFundingBlock,
  emergencyFundingFor,
  emergencyPurchaseRefusal,
  forcedSaleRefusal,
  fundingPrivateAnswerRefusal,
  fundingPrivateOfferRefusal,
  fundingPrivateRescindRefusal,
} from "./emergencyFunding";
// Design note #1019: the purchase gate the reducer never had.
import { trainPurchaseRefusal } from "./trainPurchaseGate";
import { dividendSplit } from "./dividendSplit";
import { dividendAmountRefusal, evaluateRouteSet, routeSetRefusal, routeSkipRefusal } from "./routeAuthority";
import { layEndsTrackStep } from "./bonusLay";
import { stationTokenPrice } from "./stationTokens";
// Design note #660: the B&O private's two rules, in one place.
import { isSellableToCorporation, settleBaoPrivate } from "./baltimorePrivate";
// Design note #656: the cursor's rules, in a module the reducer can reach.
import {
  nextSubPhase,
  openingSubPhase,
  settleSubPhase,
  type OperatingSubPhase,
} from "./operatingCursor";
// Design note #596: the president's certificate changes hands.
import { settlePresidencies } from "./presidencyTransfer";
import type { SandboxMarketMark, SandboxMarketPrices } from "./sandboxState";
// Design note #646: every marker landing is stamped with its arrival here,
// so the operating-order tie-break has a history to read.
import { reconcileParMarks, withArrival } from "./sandboxState";
import { soldOutRises } from "./soldOutRise";
import {
  OFFBOARD_LABELS,
  OFFBOARD_REVENUE,
  STATIC_BOARD_HEXES,
  boardMemo,
  heraldAt,
  heraldHexFor,
  offboardValueForEra,
  terrainBuildFeeAt,
} from "../components/hexBoardData";
import { withRules } from "./boardSelection";
import { stopEnteredFrom } from "./trackReach";
/* Design note #1570 (Batch 7.2): the one authority for stock transaction legality and pricing. Asked by the
   core (identity), by the market step's `saleRefused` closure (#748a) and at ingress (`turnAuthority`). */
import {
  chartContextFromState,
  parLadderRefusal,
  priceStockPurchase,
  purchaseIntentOf,
  stockPurchaseRefusal,
  stockSaleRefusal,
  type StockChartContext,
} from "./stockTransactionAuthority";
/* Design note #1324: the 20% standard certificate. #1570: `DOUBLE_CERTIFICATE_PERCENT` left this import with
   the arithmetic -- the BuyStock arm no longer computes a percentage, it is handed one by
   `priceStockPurchase`, which is where the constant is read now. */
import {
  doublePurchaseRefusal,
  doubleSaleEffect,
  withDoubleAt,
} from "./doubleCertificate";
// Design note #1320: the Level Playing Field's entities, applied by the `SetupGame` arm.
import { JK_PRIVATE_ID, withLevelPlayingFieldEntities } from "./levelPlayingField";
import { runWithoutTrain } from "./yellowSign";
// Design note #1323: the Kanawha Licence -- its purchase, its grant and the hex it unlocks.
import {
  JK_TILE_ABILITY_KEY,
  KANAWHA_LICENSE_COST,
  jkHalfFee,
  jkTileRefusal,
  kanawhaLicenseRefusal,
  kanawhaLicensesInPlay,
  licensesHeldBy,
  mayCrossCoalRiver,
  routeCrossesCoalRiver,
} from "./kanawhaLicense";
import { tileCitySlotCounts } from "../components/TileGraphics";
import { DIESEL_TIER, dieselExchangeCostFor, dieselExchangeRefusal } from "./dieselExchange";
import { numberedPrivate } from "./privateOrdinal";

/** A nominal share price, applied so a `BuyStock`/`SellStock` visibly moves
 *  the cash column. NOT a computed price -- see design note 0. The real
 *  figure depends on par value, market position and whether the purchase is
 *  the 20% President's Certificate, none of which this file knows. */
export const SANDBOX_NOMINAL_SHARE_PRICE = 67;

/** A nominal train cost, same reasoning as the share price above. */
export const SANDBOX_NOMINAL_TRAIN_COST = 80;

/* SANDBOX_NOMINAL_TILE_COST deleted: the fee belongs to the GROUND (terrainBuildFeeAt), not the tile.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #432 */

/** A nominal station-token / private-purchase cost. */
export const SANDBOX_NOMINAL_TOKEN_COST = 40;

/** One certificate, as a percentage of the corporation. 1830's ordinary
 *  share is 10%; the President's 20% double certificate is a rule this
 *  reducer does not model and the contract does. */
export const SANDBOX_SHARE_PERCENTAGE = 10;

/** Design note #351: the President's Certificate is a DOUBLE share -- 20%
 *  of the company, for twice par. Named rather than written as `10 * 2` so
 *  the two places that need it (the equity moved, and the certificate count
 *  the ledger derives) cannot drift apart. */
export const SANDBOX_PRESIDENT_PERCENTAGE = 20;

/** What a full round of passes knocks off the cheapest private -- design
 *  note #271. `auction::MIN_BID_INCREMENT`'s own $5 step, reused because the
 *  markdown and the bid increment are the same unit of money in this
 *  auction and two different literals would drift. */
export const WATERFALL_PASS_MARKDOWN = 5;

/** A nominal figure for what one route earns, so the Operating Round table's
 *  revenue column visibly fills in. Not a traced route value -- real revenue
 *  comes from `pathfinding.rs`'s search over actual laid track. */
export const SANDBOX_NOMINAL_ROUTE_REVENUE = 90;

/* ==================================================================
    DESIGN NOTE 1560 (here): THE THREE FLOORED ADJUSTERS ARE GONE
   ==================================================================
   `adjustCash`, `adjustBank` and `adjustTreasury` lived here and all three ended `Math.max(0, current +
   delta)`. That clamp minted money on every unaffordable purchase, hid every debit with no recipient, and
   made the bank's balance a fiction after the break. Every movement below now goes through `cashLedger.ts`,
   which is the whole of Batch 7.1: one debit, one matching credit, whole non-negative amounts, and a REFUSAL
   -- never a floor, never a throw -- when an account cannot cover what it is asked for.

   THE CALL SHAPE CHANGED ON PURPOSE. `adjustTreasury(state, id, -cost)` could be written anywhere and always
   returned a state; `transfer(state, { corporation: id }, BANK, cost)` returns a RESULT the caller must
   handle, so a new money movement cannot be added without deciding, at the call site, what happens when it
   cannot be made. That is the property the old helpers could not have.

   WHERE A GATE ALREADY STANDS IN FRONT (the depot and pool train purchases #1019/#1512, the station gate
   #1511, the terrain fee #891, the Kanawha licence #1323, the Diesel exchange, the Batch-5 emergency paths),
   the ledger's refusal is UNREACHABLE and the game is unchanged. Where one does not exist yet -- the stock
   purchase, the ordinary private purchase, the intercorporate train sale -- the ledger refuses instead of
   minting, and Batches 7.2 and 7.4 put the rule in front of it. */

/** The ledger's answer, or the board we were handed. #778's identity refusal, spelled once. */
function settleMoney(fallback: GameStateResponse, result: LedgerResult): GameStateResponse {
  return result.ok ? result.state : fallback;
}

/** Advance the seat and clear the pass streak -- mirrors trading::advance_turn.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0 */
/** #1443: the Sell-Buy-Sell stage of the current Stock Round turn. */
export function stockTurnStage(
  state: Pick<GameStateResponse, "bought_this_turn" | "stock_turn_stage">,
): "sell" | "buy" | "sell_again" {
  if ((state.bought_this_turn ?? 0) > 0) return "sell_again";
  return state.stock_turn_stage === "buy" ? "buy" : "sell";
}

function advanceSeat(state: GameStateResponse): GameStateResponse {
  const count = state.player_addresses.length;
  if (count === 0) return state;
  return {
    ...state,
    active_player_index: (state.active_player_index + 1) % count,
    consecutive_passes: 0,
    /* Design note #745: the flag is about THE TURN NOW IN PROGRESS, so it dies with the turn. Cleared in both
       seat-moving functions rather than in the arms that call them -- an arm can be added, and the next one
       will inherit this without its author knowing the flag exists. */
    turn_action_taken: false,
    // Design note #1172: the purchase count has the same life and is cleared on the same rule.
    bought_this_turn: 0,
    // Design note #1570: and the corporation it was spent on -- the Brown continuation's other half (S7-18).
    bought_this_turn_company: undefined,
    stock_turn_stage: undefined, // #1443: the Sell-Buy-Sell stage clears with the seat
  };
}

/* Design note #1530: `buildOperatingOrder` lives in `operatingOrder.ts` now (the discard module needs it and
   cannot import this file); re-exported so every caller keeps its import. */
export { buildOperatingOrder } from "./operatingOrder";
import { buildOperatingOrder } from "./operatingOrder";

/** Keep the seat pointer in step during an OR so actingSeatIndex and the raw pointer agree. Left untouched when the presidency cannot be resolved.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #411 */
function syncSeatToActingCorporation(state: GameStateResponse): GameStateResponse {
  const companyId = state.active_operating_order[state.active_corporation_index];
  if (companyId === undefined) return state;
  const president = state.public_companies.find(
    (company) => company.company_id === companyId,
  )?.president;
  if (!president) return state;
  const seat = state.player_addresses.indexOf(president);
  if (seat === -1 || seat === state.active_player_index) return state;
  return { ...state, active_player_index: seat };
}

/* 1830's OR counts by phase: Yellow 1, Green 2, Brown 3. Derived from the TRAINS in play, not from current_global_era. null yields 1 -- the safe direction.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #431 */
export function operatingRoundsForPhase(phase: GamePhase | null): number {
  switch (phase?.tint) {
    case "green":
      return 2;
    case "brown":
      return 3;
    case "yellow":
    default:
      return 1;
  }
}

/** Exported because two callers need it; a second hand-written copy is how the queue came to be built by neither of them.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #411 */
/** Open an Operating Round: build its order AND pay the private income that opening one owes.
 *
 *  ==================================================================
 *   DESIGN NOTE 1015: ONE OPENING, ONE PAYOUT, TWO CALLERS
 *  ==================================================================
 *
 *  `beginOperatingRound` BUILDS A ROUND AND IS CALLED THREE TIMES: twice to open one, and once by
 *  `advanceCorporation` to repair an operating order that came out empty. Only the first two are openings, and
 *  #685 wired the payout to just one of them -- so a set's second and third rounds began without paying.
 *
 *  THE SPLIT IS THE FIX. `beginOperatingRound` keeps its single job and the repair path keeps calling it; the
 *  two real openings call this instead. Naming them apart is what stops the next caller reaching for whichever
 *  is nearer -- `trackReach.ts` #893's argument for `reachableCities` beside `reachableNetwork`, and the same
 *  hazard: the two differ by whether money moves, which is not visible at a call site.
 *
 *  PURE AND REPLAYABLE, per #685: it derives the payment from the state it is handed and nothing else, so
 *  every client replaying the same log opens the round with the same treasuries. */
export function openOperatingRound(
  state: GameStateResponse,
  priceFor?: (companyId: number) => number | null,
  markFor?: (companyId: number) => { x: number; y: number; enteredAt?: number } | null | undefined,
  continuingSequence = false,
): GameStateResponse {
  const opened = beginOperatingRound(state, priceFor, markFor, continuingSequence);
  return applyPrivateRevenue(opened)?.state ?? opened;
}

export function beginOperatingRound(
  state: GameStateResponse,
  priceFor?: (companyId: number) => number | null,
  /** Design note #646: the arrival lookup the tie-break reads. */
  markFor?: (companyId: number) => { x: number; y: number; enteredAt?: number } | null | undefined,
  /* The sequence length is stamped ONCE when a cycle opens; a mid-cycle phase change takes effect next cycle. continuingSequence tells the two callers apart.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #511 */
  continuingSequence = false,
): GameStateResponse {
  const order = buildOperatingOrder(state, priceFor, markFor);
  return syncSeatToActingCorporation({
    ...state,
    current_round_type: "OperatingRound",
    active_operating_order: order,
    active_corporation_index: 0,
    consecutive_passes: 0,
    operating_round_just_ended: false,
    /* Written, not read -- the fixtures hardcoded 2 and nothing ever set it. #511: stamped once per cycle.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #431 */
    operating_round_sequence_length: continuingSequence
      ? operatingRoundSequenceLength(state)
      : operatingRoundsForPhase(derivePhase(state)),
    /* sub_round_index is stamped here too. Nobody wrote it, so every phase ran exactly one extra round. All three opening values are now written together.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #621 */
    ...(continuingSequence ? {} : { sub_round_index: 1 }),
  });
}

/** Falls back to the phase's count for an absent or nonsensical field; Math.max(1, ...) so a stored zero can never end a cycle before it runs.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #511 */
export function operatingRoundSequenceLength(state: GameStateResponse): number {
  const stored = Number(state.operating_round_sequence_length);
  if (!Number.isFinite(stored) || stored < 1) {
    return operatingRoundsForPhase(derivePhase(state));
  }
  return Math.max(1, Math.floor(stored));
}

/** Wrap is an EVENT, not a loop: run the queue again if the locked sequence has another round in it, otherwise raise the flag. A cycling queue is a round with no exit.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #431 */
function advanceCorporation(
  state: GameStateResponse,
  priceFor?: (companyId: number) => number | null,
  // Design note #646: carried through so a rebuilt queue keeps the tie-break.
  markFor?: (companyId: number) => { x: number; y: number; enteredAt?: number } | null | undefined,
): GameStateResponse {
  /* An empty queue is RECOVERED by rebuilding it, not tolerated by returning unchanged -- that was the infinite round in one line.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #411 */
  if (state.active_operating_order.length === 0) {
    const rebuilt = beginOperatingRound(state, priceFor, markFor);
    return rebuilt.active_operating_order.length > 0
      ? rebuilt
      : { ...state, operating_round_just_ended: true };
  }

  const next = state.active_corporation_index + 1;
  if (next < state.active_operating_order.length) {
    return syncSeatToActingCorporation({ ...state, active_corporation_index: next });
  }

  /* The LOCKED value decides, not a live re-derivation: a 3-train bought mid-cycle must not turn a one-round Yellow cycle into a two-round Green one.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #511 */
  const sequenceLength = operatingRoundSequenceLength(state);
  if (state.sub_round_index < sequenceLength) {
    /* ==================================================================
       DESIGN NOTE 1015: THE PRIVATES PAY EVERY OPERATING ROUND, NOT EVERY SET
       ==================================================================
       REPORTED, of the toast that follows the payout: "the private company payout toast only fired during the
       very first Operating Round and never appeared again in subsequent rounds ... Audit the state flag or
       trigger that tracks whether private companies have paid out."

       AND THE TOAST WAS TELLING THE TRUTH. It fires when the money moves, so its absence was not a display
       fault -- the money was not moving. `applyPrivateRevenue` was called from exactly one place, the
       `stock_round_just_ended` branch of `settleRoundTransitions`, which is the boundary that opens the FIRST
       Operating Round of a set. This line opens the second and the third, and it did not pay.

       SO THE RULE WAS WRONG, NOT JUST THE NOTIFICATION. 1830 pays private income at the start of every
       Operating Round; from Phase 3 a set has two and from Phase 5 it has three, so a table was losing one or
       two rounds of private income per set and had no way to see it -- the only surface that would have said
       so is the toast that was also missing.

       #685 PUT THE PAYOUT IN THE REDUCER AND THAT IS UNTOUCHED. Its argument stands exactly: "one place, on
       the one transition that opens an Operating Round, replayed identically by every client." What it had
       wrong was the count of such transitions -- there are two, and it knew about one. `openOperatingRound`
       below is now the one place, and both openings go through it.

       THE RECOVERY PATH DELIBERATELY DOES NOT. `advanceCorporation`'s empty-queue repair above rebuilds an
       order for a round that is ALREADY OPEN; paying there would hand out a second round of income for a
       round the table has been playing. An opening and a repair look alike and are not. */
    return syncSeatToActingCorporation({
      /* `true`: this is the SECOND round of an existing cycle, so it keeps
         the cycle's locked count rather than re-deriving from a phase that
         may have moved. */
      ...openOperatingRound(state, priceFor, markFor, true),
      sub_round_index: state.sub_round_index + 1,
    });
  }

  return { ...state, operating_round_just_ended: true };
}

/* Priority Deal goes to the seat LEFT of the last trader; nothing in GameStateResponse records that, so it is kept ON THE STATE (an undo snapshot copies state, a module variable would survive it).
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #352 */
function markTrader(state: GameStateResponse, actor: string | null): GameStateResponse {
  if (!actor) return state;
  const index = state.player_addresses.indexOf(actor);
  return index === -1 ? state : { ...state, last_trader_index: index };
}

/** The Stock Round now actually ends: Priority Deal moves and the next player is seated. The sold-out rise and lockout clearing stay with market.rs/trading.rs -- those are rules about VALUE, this is pacing.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #353 */
function recordPass(state: GameStateResponse): GameStateResponse {
  const count = state.player_addresses.length;
  if (count === 0) return state;

  const streak = state.consecutive_passes + 1;
  const advanced: GameStateResponse = {
    ...state,
    active_player_index: (state.active_player_index + 1) % count,
    consecutive_passes: streak,
    // Design note #745: this moves the seat too, so it clears the turn flag on the same rule as `advanceSeat`.
    turn_action_taken: false,
    // Design note #1172: and the purchase count with it.
    bought_this_turn: 0,
    bought_this_turn_company: undefined, // #1570: and the corporation it was spent on
    stock_turn_stage: undefined, // #1443: the Sell-Buy-Sell stage clears with the seat
  };

  if (streak < count) return advanced;

  // A full round of passes. In the auction this runs the waterfall (the
  // `WaterfallPass` arm handles it before reaching here); in a Stock Round
  // it ends the round.
  if (state.current_round_type !== "StockRound") {
    return { ...advanced, consecutive_passes: 0 };
  }

  /* Left of the last trader is the direction advanceSeat moves. Nobody traded means nothing to reorder.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #352 */
  const priority =
    state.last_trader_index === null || state.last_trader_index === undefined
      ? state.priority_deal_index
      : (state.last_trader_index + 1) % count;

  return {
    ...advanced,
    consecutive_passes: 0,
    priority_deal_index: priority,
    // The Priority Deal holder opens the next round, which is what makes it
    // worth holding.
    active_player_index: priority,
    last_trader_index: null,
    stock_round_just_ended: true,
  };
}

/** Applies one message; unknown variants fall through to the turn-advancing default. Route revenue TOTALS printed stop values -- it checks no connectivity, distance or token rule.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0 */
const hexCoordsByLabel = boardMemo(
  (board): ReadonlyMap<string, { q: number; r: number }> =>
    new Map(board.hexes.map((hex) => [hex.label, { q: hex.q, r: hex.r }])),
);

/* Price a hex through hexGeometry.hexRouteValue, the board's own answer. A third private copy scored preprinted gray hexes at $0 and let revenue:"0" short-circuit the printed value.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #190 */

/** A route runs between two CITIES (or off-board reds); towns are passed through. archetypeForHex asks what the hex IS rather than what it pays.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #264 */
/* ==================================================================
    DESIGN NOTE 1302: A HERALD IS A CENTRE FOR ONE CORPORATION
   ==================================================================
   1830+ prints PRR's herald on H12 at $10. For PRR it is a revenue centre and a place a route may end; for
   every other corporation the hex is the plain green tile it carries. So the three questions below take the
   corporation asking (`forCompanyId`), and answer the herald only to its owner. Absent means "no corporation
   in particular", which is every pre-#1302 caller and every hex without a herald -- unchanged.
   THE OWNER MAY DECLINE IT: "on subsequent rounds PRR can opt not to include it". A waypoint carrying
   `bypass: true` is already how a route says "passed, not counted" (#737), and it means exactly that here. */
function heraldValueFor(hexLabel: string, forCompanyId: number | undefined): number | null {
  if (forCompanyId === undefined) return null;
  const herald = heraldAt(hexLabel);
  return herald && herald.companyId === forCompanyId ? herald.revenue : null;
}

export function isRevenueCentreHex(
  mapGrid: MapGridResponse,
  hexLabel: string,
  forCompanyId?: number,
): boolean {
  if (OFFBOARD_LABELS[hexLabel]) return true;
  if (heraldValueFor(hexLabel, forCompanyId) !== null) return true;
  const coords = hexCoordsByLabel().get(hexLabel);
  if (!coords) return false;
  const archetype = archetypeForHex(mapGrid, coords.q, coords.r);
  return archetype !== "Plain";
}

export function isRouteTerminusHex(
  mapGrid: MapGridResponse,
  hexLabel: string,
  forCompanyId?: number,
): boolean {
  /* Design note #1320 said a warehouse is "a revenue centre, never a terminus". RULED OTHERWISE (design note
     #1286): "unlike small towns the warehouses are also valid termini for routes" -- and they must count as
     such. A warehouse can be run TO and run THROUGH (`isOffboardTerminal` excludes it, so passing stays
     legal); what it can never be is tokened. So every red area is a terminus, warehouse or not.
     ==================================================================
      DESIGN NOTE 1555: A TOWN IS A TERMINUS (S6-10, owner ruling 2026-09-15: follow the 2018 rulebook)
     ==================================================================
     THIS PREDICATE ANSWERED `SingleCity || DoubleCity` FOR YEARS, and "unlike small towns" in #1286 restated
     that as though it were a rule. The rulebook says otherwise: §6.4 "for the purposes of running trains and
     choosing routes, 'city' refers to a large city, a small city, or an off-board red hex", §6.4.2 a route "may
     begin or end at any city". A small city is a town. #1286's warehouse half stands (a warehouse is a valid
     terminus under the LPF rule); its "unlike small towns" clause is withdrawn -- towns are valid termini
     under the base rule, and warehouses are as well, not instead.
     ONE PREDICATE, EVERY READER: the auto-tracer records a run only where this is true, so it can now draft a
     town-ended route; `hasLegalRouteFor` (the Batch-4 forced-purchase gate) and `maxRouteRevenueFor` (the
     auto-skip and the Run-Trains skip refusal) search through the tracer, so they see one; the route authority
     (`routeAuthority.ts`) judges endpoints by it; the shell's `endsOffTerminus` and the draft editor's first
     click ask it. A terminus is therefore exactly a revenue centre: a stop that counts against the train's
     number is a stop a route may end on. */
  return isRevenueCentreHex(mapGrid, hexLabel, forCompanyId);
}

export function hexStopValue(
  mapGrid: MapGridResponse,
  hexLabel: string,
  era: TileColorTier,
): number {
  /* Design note #741: DELEGATED. This function used to hold the ladder -- chain revenue, then catalog revenue,
     then the printed override, then the board's own answer -- and the hex TOOLTIP held a shorter one that
     stopped at the terrain category. Reported as the tooltip not updating when a tile was laid.
     The ladder moved down into `hexGeometry`, where every table it consults already lives and where the
     tooltip can reach it: this file imports FROM `components/`, so the tooltip could never have imported from
     here without a cycle. What is left is the label-to-coordinate lookup, which is this module's own concern.
     ONE FUNCTION, ONE ANSWER -- the specific failure this codebase keeps finding, closed for hex values. */
  const coords = hexCoordsByLabel().get(hexLabel);
  if (!coords) {
    /* An unknown label may still be an off-board terminal: those are keyed by NAME in `OFFBOARD_REVENUE` and
       need no coordinates. Asked here rather than inside the ladder so the ladder can stay coordinate-based. */
    const offboard = OFFBOARD_LABELS[hexLabel];
    const tiers = offboard ? OFFBOARD_REVENUE[offboard] : undefined;
    return tiers ? offboardValueForEra(tiers, era) : 0;
  }
  return hexValueForEra(mapGrid, coords.q, coords.r, era);
}

/* An N-train visits N REVENUE CENTRES and may cross any amount of plain track. The old code compared against hop count, the classic 18xx misreading.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #156 */
export interface SandboxRouteBreakdown {
  /** Total printed value of the distinct stops. */
  revenue: number;
  /** Distinct stops that actually PAY -- the figure a train's number caps.
   *  Mirrors `pathfinding.rs`'s `is_revenue_centre: !value.is_zero()`. */
  centres: number;
  /** Distinct hexes touched, paying or not. Reported alongside because it
   *  is what a player sees themselves clicking, and showing only the centre
   *  count would look like the app had lost track of half their route. */
  hexes: number;
  /* Stops carry their own figures in route order, so the arithmetic is on screen. Deduplicated exactly as revenue is, so the list always sums to it.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #274 */
  stops: ReadonlyArray<{ hex: string; value: number }>;
}

/** One walk, three figures -- see design note #156. */
export function sandboxRouteBreakdown(
  mapGrid: MapGridResponse,
  path: readonly { hex: string; city_node?: number; bypass?: boolean }[],
  era: TileColorTier,
  /** Design note #1302: the corporation running, so its herald (if the board prints one) pays. */
  forCompanyId?: number,
): SandboxRouteBreakdown {
  /* ==================================================================
      DESIGN NOTE 1318: REVENUE IS PER CITY -- NOT PER STATION, AND NOT PER HEX
     ==================================================================
     RULED: "the rule for revenue is not per station, it's per city, and cities can have multiple stations. So
     a route that runs through one double-station city ... does not receive 2x revenue. However, if a route
     runs through one city and then another city on the same hex, it does collect the revenue twice."
     THE FIRST HALF WAS ALREADY TRUE and is asserted rather than assumed: a tile's `revenue` is one figure,
     and nothing here has ever multiplied it by slots. THE SECOND HALF WAS NOT. This walk deduplicated by hex
     label, so a route that left an OO, NY or TO hex and came back into its OTHER city -- legal, and exactly
     what `routeDraftEdit`'s rail-level rule 5 permits -- was paid once for two cities. So the key is the
     CITY VISITED: the waypoint's own `city_node` when the router said, otherwise the city the route entered by
     (`cityEnteredFrom`, from the neighbouring waypoint), and city 0 where a hex has only one -- which is every
     ordinary hex, and keeps the old once-per-hex behaviour there byte for byte. Two visits to the SAME city are
     still one payment. */
  const seenHexes = new Set<string>();
  const seenCities = new Set<string>();
  const stops: { hex: string; value: number }[] = [];
  let revenue = 0;
  for (let index = 0; index < path.length; index += 1) {
    const stop = path[index];
    seenHexes.add(stop.hex);
    const visitKey = `${stop.hex}:${cityVisitedAt(mapGrid, path, index)}`;
    if (seenCities.has(visitKey)) continue;
    seenCities.add(visitKey);

    /* ==================================================================
     *  DESIGN NOTE 737: A BYPASS PAYS NOTHING AND COSTS NO STOP
     * ==================================================================
     *
     * REPORTED of Altoona: "there seems to be no way to get a train to use the bypass around Altoona's measly
     * $10 revenue center."
     *
     * THE ROUTER COULD NOT FIND IT AND THIS FUNCTION COULD NOT PRICE IT, and the second half is the one that
     * made the first pointless to fix alone. Revenue was computed from a list of HEX LABELS: a route said
     * which hexes it touched and nothing about HOW, so a train crossing H12 on the bow was indistinguishable
     * from one stopping at the station. The bypass was not merely unrouted, it was inexpressible.
     *
     * `variant` IS THAT MISSING WORD. It names which authored rail chain the route took through this hex, and
     * a chain that never reaches the marker earns nothing there -- which is the entire point of the bow on
     * cardboard.
     *
     * AND IT COSTS NO STOP EITHER, which matters more than the $10: a 2-train that had to spend one of its two
     * stops on Altoona could not reach past it. Skipping the `stops.push` below is what makes the bypass worth
     * having. */
    /* A FLAG, NOT A RE-DERIVATION. The first draft of this tried to recover the rail chain from the hex label
       here, and could not: a stop knows WHICH hex, never which edges the route entered and left by. The tracer
       does know -- it chose the variant -- so the answer travels with the stop. Recomputing a fact at a point
       that has lost the inputs is how a second, disagreeing answer gets invented. */
    if (stop.bypass === true) continue;

    // #1302: the running corporation's own herald pays its printed figure and counts as a centre.
    const heraldValue = heraldValueFor(stop.hex, forCompanyId);
    if (heraldValue !== null) {
      revenue += heraldValue;
      stops.push({ hex: stop.hex, value: heraldValue });
      continue;
    }

    revenue += hexStopValue(mapGrid, stop.hex, era);
    /* Count the ARCHETYPE, not the value: fourteen printed cities and seven towns pay $0 until a tile is laid, and a $0 city still costs a train a stop.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #289 */
    const centre = isRevenueCentreHex(mapGrid, stop.hex);
    if (centre) stops.push({ hex: stop.hex, value: hexStopValue(mapGrid, stop.hex, era) });
  }
  return { revenue, centres: stops.length, hexes: seenHexes.size, stops };
}

/** Design note #1318: which city of its hex the route's `index`-th waypoint stands in. The router's own
 *  `city_node` wins; otherwise the city entered from the previous waypoint (or, for the first, left toward
 *  the next); `0` for a hex with one city, no neighbour, or no track between the two. */
function cityVisitedAt(
  mapGrid: MapGridResponse,
  path: readonly { hex: string; city_node?: number }[],
  index: number,
): number {
  const stop = path[index];
  if (stop.city_node !== undefined) return stop.city_node;
  const here = hexCoordsByLabel().get(stop.hex);
  if (!here) return 0;
  const neighbourLabel = path[index - 1]?.hex ?? path[index + 1]?.hex;
  const neighbour = neighbourLabel === undefined ? undefined : hexCoordsByLabel().get(neighbourLabel);
  if (!neighbour) return 0;
  // #1319: the STOP the rail arrives at -- a city by its group, or a town by its own rail on a double town.
  return stopEnteredFrom(mapGrid, here, neighbour) ?? 0;
}

/** Total the selected stops. Exported for the route value readout, which
 *  previews the figure before anything is dispatched. */
export function sandboxRouteRevenue(
  mapGrid: MapGridResponse,
  path: readonly { hex: string; city_node?: number }[],
  era: TileColorTier,
  forCompanyId?: number,
): number {
  return sandboxRouteBreakdown(mapGrid, path, era, forCompanyId).revenue;
}

/** Optional board context. Only RunManualRoute reads it, and only to total printed stop values.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0 */
export interface SandboxActionContext {
  /* The author travels WITH the action. Resolving it from the local turn cursor made the reducer a function of local state rather than of the log -- a silent per-client divergence.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #549 */
  actor?: string | null;
  /* ==================================================================
      DESIGN NOTE 1197: THE CHART'S GEOMETRY, AND ONLY ITS GEOMETRY
     ==================================================================
     THE DISTINCTION PHASE 1 TURNS ON. What arrives here is the price ladder's SHAPE -- where a token lands
     when it steps -- which is a static board definition identical in every browser, no more dangerous to
     inject than `hexTileCatalog`. What no longer arrives is where the tokens ARE: that is
     `state.market_positions` now (#1196), because positions are the half two clients could disagree about.
     `dividendRefused` AND `saleRefused` ARE DELIBERATELY NOT ACCEPTED. #748a and #774 asked for them because
     the chart atom ran outside the reducer and had to be TOLD what the board would refuse; in here the
     reducer already holds the state those predicates read, so it asks for itself. A caller that could still
     supply them could still supply the wrong ones, which is exactly how #1194 rearranged an operating order
     and cost half a day finding it. */
  marketContext?: Omit<SandboxMarketContext, "dividendRefused" | "saleRefused">;
  /** #1193/#415: the par box resolver, so a corporation parred BY this action has its token before the next
   *  queue is built. Geometry, like the projections beside it. */
  parCellFor?: (parPrice: number) => { x: number; y: number } | null;
  mapGrid?: MapGridResponse;
  /* `resetRouteRevenue` REMOVED by design note #777, and it is worth recording WHY rather than deleting
     quietly: it was a dispatch-time option meant to zero `last_route_revenue` on a turn's first route
     message, and `appendSandboxAction` writes only the message into the log -- so no replay ever saw it, and
     every client applies by replaying. An option the authority can never receive is worse than no option:
     it reads at the call site as a rule that is being enforced. The zeroing is a turn-change event now. */
  /** Scales red off-board terminals, whose value rises with the era. */
  era?: TileColorTier;
  /** Market price injected by the caller: the chart is a separate atom this reducer must not reach into. Omitted falls back to par.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #411 */
  marketPriceFor?: (companyId: number) => number | null;
  /** Design note #646: when a corporation's marker reached its current cell,
   *  for the operating-order tie-break. Travels beside the price for the same
   *  reason the price does -- the chart is a separate atom the reducer must
   *  not reach into. */
  /* Design note #746a: WIDENED TO THE WHOLE MARK. It was declared `{x, y, enteredAt?}` while every caller
     already returned a `SandboxMarketMark` -- the `price` was being passed and thrown away by the type. The
     sold-out rise needs it, to report what a token rose FROM. */
  marketMarkFor?: (companyId: number) => SandboxMarketMark | null | undefined;
  /** Design note #746a: `projectRiseMove`, injected on #7's rule -- `utils/` may not import the chart, and
   *  the chart is where the cells live. Absent means no rise is computed, which is the honest answer for a
   *  caller with no market. */
  projectRise?: (
    from: SandboxMarketMark,
  ) => { x: number; y: number; price: number } | null | undefined;
  /** Design note #757: whether this tile at this rotation is an ILLEGAL placement, injected on #7's rule --
   *  the legality engine lives in `components/` and `utils/` may not import it.
   *
   *  Absent means "no opinion", which is the honest answer for a caller with no board rules to hand and the
   *  reason this cannot make an existing test stricter by accident. */
  layRefused?: (q: number, r: number, tileId: number, orientation: number) => boolean;
  /** Share price injected for the same reason (#272). Omitted falls back to the flat nominal.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
  sharePrice?: number;
  /** Design note #351: the par ladder's current selection, for the founding
   *  purchase that sets it. Ignored on every other buy -- once
   *  `par_value` is set the company has a price and the ladder is locked.
   *
   *  DESIGN NOTE 1570: NOTHING READS THIS ANY MORE. Batch 7.2 prices the founding purchase from the message's
   *  own `par_value`, validated against the chart's par boxes (`priceStockPurchase`), so the last reader of
   *  this field is gone. It is left declared rather than deleted because three callers still supply it
   *  (`App.tsx`, `replayLog`, the CLI) and removing it is a signature change for no rules reason -- but it is
   *  now INERT, and #777's warning applies to it in full: "an option the authority can never receive is worse
   *  than no option: it reads at the call site as a rule that is being enforced." Retiring it and its three
   *  call sites is S10-8's kind of cleanup, recorded rather than smuggled into this batch. */
  parValue?: number;
  /** Design note #363: resolves a home hex label to `(q, r)`. Injected --
   *  the board table lives in `components/`, which `utils/` must not
   *  import. Omitted, corporations still float without their token. */
  homeHexToAxial?: (label: string) => readonly [number, number] | null;
  /** Design note #712: the market-zone rules, injected for the same reason the price is -- the price-to-zone
   *  table lives in `components/` and this module may not import it.
   *  OMITTED MEANS UNENFORCED, deliberately: a caller with no chart cannot tell a Normal price from an Orange
   *  one, and guessing would either forbid a legal purchase or wave an illegal one through. Every live path
   *  supplies it; the fixtures that do not are exercising other rules. */
  marketZoneFor?: (companyId: number) => PriceZone;
  /** Live prices per company, for the certificate limit's zone exemption. */
  marketPricesByCompany?: Readonly<Record<number, number | null>> | null;
  zoneForPrice?: (price: number | null | undefined) => string | null;
}

/** Pure bookkeeping: clamps the pool at zero rather than validating, because refusing would be enforcing a rule.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0 */
function moveShares(
  state: GameStateResponse,
  companyId: number,
  holder: string | null,
  pool: "Ipo" | "Bank",
  percentage: number,
): GameStateResponse {
  return {
    ...state,
    public_companies: state.public_companies.map((company) => {
      if (company.company_id !== companyId) return company;
      const key = pool === "Bank" ? "bank_pool_percentage" : "ipo_pool_percentage";
      const available = company[key];
      // Taking more than exists is capped to what exists; returning shares
      // (negative) is never capped.
      const moved = percentage > 0 ? Math.min(percentage, available) : percentage;
      if (moved === 0) return company;

      const holdings = [...company.player_holdings];
      if (holder) {
        const index = holdings.findIndex((entry) => entry.player === holder);
        if (index >= 0) {
          const next = holdings[index].percentage + moved;
          if (next <= 0) holdings.splice(index, 1);
          else holdings[index] = { ...holdings[index], percentage: next };
        } else if (moved > 0) {
          holdings.push({ player: holder, percentage: moved });
        }
      }

      return {
        ...company,
        [key]: available - moved,
        player_holdings: holdings,
        // Kept consistent with the holdings so the Ledger's own totals add
        // up; the contract derives this the same way.
        total_shares_issued: Math.max(
          0,
          company.total_shares_issued + (pool === "Ipo" ? moved / SANDBOX_SHARE_PERCENTAGE : 0),
        ),
      };
    }),
  };
}

/** Rewrites one corporation's `owned_trains`. Pure plumbing behind the two
 *  train helpers below, so neither has to restate the map. */
function withTrains(
  state: GameStateResponse,
  companyId: number,
  next: (trains: readonly string[]) => string[],
): GameStateResponse {
  return {
    ...state,
    public_companies: state.public_companies.map((company) =>
      company.company_id === companyId
        ? { ...company, owned_trains: next(company.owned_trains ?? []) }
        : company,
    ),
  };
}

/* A bank purchase must consume depot stock and charge the real tier price -- depotInventory derives remaining stock from what corporations OWN, so a purchase adding no train froze the supply.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #194 */

/** Rust order, cheapest first -- the discard preference too. */
const TIER_SEQUENCE: readonly string[] = ["2", "3", "4", "5", "6", "D"];

const TIER_COST: Readonly<Record<string, number>> = {
  "2": 80, "3": 180, "4": 300, "5": 450, "6": 630, D: 1_100,
};

/** Inverted from gamePhase.ts's RUSTED_BY rather than restated -- a second copy is a second thing to keep in step with 1830.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #284 */
function tiersRustedBy(tier: string): string[] {
  const rusted: string[] = [];
  for (const candidate of TIER_SEQUENCE) {
    if (RUSTS_ON[candidate] === tier) rusted.push(candidate);
  }
  return rusted;
}

/** `gamePhase.ts`'s `RUSTED_BY`, mirrored -- see `tiersRustedBy`. */
const RUSTS_ON: Readonly<Record<string, string | undefined>> = {
  "2": "4",
  "3": "6",
  "4": "D",
};

/** The train limit once `tier` is the phase -- `TIER_PRESENTATION`'s own
 *  figures, which `depotInventory` already reports per tier. */
function limitForTier(state: GameStateResponse, tier: string): number {
  return depotInventory(state).find((row) => row.tier === tier)?.trainLimit ?? Infinity;
}

/** #1530: the train limit of the phase in force -- `null` when the board reports no phase. */
function limitInForce(state: GameStateResponse): number | null {
  const phase = derivePhase(state);
  return phase && phase.known ? phase.trainLimit : null;
}

/* ==================================================================
 *  DESIGN NOTE 909: WHAT A STOCK ROUND OPENING WIPES, IN ONE PLACE
 * ==================================================================
 *
 * REPORTED: "If the sell-then-buy lock does not clear when a new Stock Round opens, players are permanently
 * locked out of legal purchases for the remainder of the game."
 *
 * AND THERE WERE TWO OPENINGS, WHICH IS THE ACTUAL BUG. `settleRoundTransitions` has cleared `sold_this_round`
 * at the end of an Operating Round set since #744 -- correct, and for a long time the only way a Stock Round
 * could begin. #905 added a second: under the delayed-auction variant the private auction hands off to Stock
 * Round 3 through `OpenStockRound`, which set the round type and cleared nothing. A player who sold PRR in
 * Stock Round 2 would have been refused the buy-back for the rest of the game, and the refusal names the
 * sell-then-buy rule, so it would have read as a correct rule misfiring rather than as a missing reset.
 *
 * THE SHAPE IS THIS PROJECT'S COMMONEST: one rule, two authorities, and the newer one never told. So the
 * answer is not to add a second copy of the reset but to name the SET OF FACTS a Stock Round opening
 * invalidates, once, and have both openings spread it.
 *
 * WHY THESE FIVE. Each is scoped to "the round that just finished" and means something false the moment a new
 * one begins: the sell-then-buy lock (#744) bars a rebuy within ONE Stock Round; the pass streak counts toward
 * one round's termination; the last trader decides that round's Priority Deal; the turn flag belongs to a seat
 * that is being moved; and the Priority Deal holder opens the new round (#353).
 *
 * See docs/ai_architecture/sandbox_reducer.md, sandboxSession.ts #909. */
export function openingStockRoundReset(
  state: GameStateResponse,
): Pick<
  GameStateResponse,
  | "sold_this_round"
  | "stock_turn_stage"
  | "consecutive_passes"
  | "last_trader_index"
  | "turn_action_taken"
  | "bought_this_turn"
  | "bought_this_turn_company"
  | "active_player_index"
> {
  return {
    /* Design note #744: THE LOCKOUT ENDS HERE, and this is the only event that ends it. A player who sold PRR
       last round may buy it again now -- the rule bars a sell-then-rebuy within ONE Stock Round, which is the
       window in which the price crater they made is still there to exploit. */
    sold_this_round: {},
    consecutive_passes: 0,
    last_trader_index: null,
    /* Design note #745: the seat is being MOVED without going through either seat-moving function. A stale
       `true` here would let the Priority Deal holder's opening Pass slip out of the streak. */
    turn_action_taken: false,
    /* Design note #1172: the third clearing site, and the one #745's comment above predicted -- "the seat is
       being MOVED without going through either seat-moving function". */
    bought_this_turn: 0,
    bought_this_turn_company: undefined, // #1570: and the corporation it was spent on
    stock_turn_stage: undefined, // #1443: the Sell-Buy-Sell stage clears with the seat
    // The Priority Deal holder opens the Stock Round -- design note #353.
    active_player_index: state.priority_deal_index,
  };
}


/** The first Diesel starts the doom clock for every Carcosan 5 and 6 still in play.
 *
 *  ==================================================================
 *   DESIGN NOTE 1089: THE TRIGGER IS THE D, THE DEADLINE IS AN OR SET LATER
 *  ==================================================================
 *
 *  RULED: "A Carcosan 5 or 6 begins this doom clock countdown the moment the first D-train is purchased ...
 *  any Carcosan train will survive until the exact conclusion of the next full set of Operating Rounds after
 *  its rust condition is triggered."
 *
 *  NOT `RUSTS_WHEN_NEXT_TIER_ARRIVES`, and that is the point of the whole rule. In this codebase's 1830 a 5,
 *  a 6 and a Diesel are PERMANENT -- `gamePhase.ts` says so in as many words -- so an ordinary 5 outlives
 *  every phase. The gift is a curse precisely because it does not.
 *
 *  IDEMPOTENT, because the clock must not restart. A second Diesel purchase re-enters this function, and a
 *  corporation whose deadline is already set keeps the deadline it had -- otherwise every D bought would push
 *  the fog back another OR set and the gift would become immortal by being popular. */
function startCarcosanDoomClock(state: GameStateResponse): GameStateResponse {
  const deadline = (state.macro_round_number ?? 0) + 1;
  let touched = false;
  const companies = (state.public_companies ?? []).map((company) => {
    if ((company.carcosan_trains?.length ?? 0) === 0) return company;
    if (company.carcosan_doom_after_macro_round !== undefined) return company;
    touched = true;
    return { ...company, carcosan_doom_after_macro_round: deadline };
  });
  return touched ? { ...state, public_companies: companies } : state;
}

/* Design note #1092: `expireCarcosanTrains` IS DELETED. It removed the train at the Stock Round boundary,
   which was right while the fog was a rust and wrong once it became a narrated stage -- there is no run at a
   boundary, so nothing there could carry the clause or the cue. Its two jobs moved: the DUE DATE is
   `yellowSign.ts` #1092's `fogIsDue`, and the REMOVAL is the `stage === "fog"` arm of `YellowSignEvent`
   above, beside the two stages that already worked that way.
   DELETED RATHER THAN LEFT UNCALLED: an exported reducer helper with no caller is a second way to take the
   train, waiting for somebody to find it. */

/** Ghost trains become ordinary at the end of an Operating Round, and the fleet is trimmed if that puts a
 *  corporation over the limit -- design note #1046. */
function expireGhostTrains(state: GameStateResponse): GameStateResponse {
  const hasGhost = (state.public_companies ?? []).some(
    (company) => (company.ghost_trains?.length ?? 0) > 0,
  );
  if (!hasGhost) return state;
  const limit = limitForTier(state, derivePhase(state)?.tier ?? "2");
  return {
    ...state,
    public_companies: state.public_companies.map((company) => {
      if ((company.ghost_trains?.length ?? 0) === 0) return company;
      const trimmed = trimToTrainLimit({
        owned: company.owned_trains ?? [],
        reprieved: company.pending_rust_trains ?? [],
        limit,
        cost: (model) => TIER_COST[model] ?? 0,
      });
      return {
        ...company,
        ...(company.owned_trains == null ? {} : { owned_trains: [...trimmed.owned] }),
        ghost_trains: [],
      };
    }),
  };
}

/** Applies a phase change's consequences; unchanged state when the purchase triggers nothing.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #284 */
export function applyPhaseChange(
  state: GameStateResponse,
  arrivingTier: string,
): GameStateResponse {
  /* Design note #1089: THE DIESEL ALSO STARTS A CLOCK. A Carcosan 5 or 6 is not rusted by the D -- neither
     tier appears in `RUSTS_WHEN_NEXT_TIER_ARRIVES`, and that is why the gift is a curse -- so it is marked
     here and taken an OR set later by `expireCarcosanTrains`. Placed at the TOP because the sweep below
     rebuilds `public_companies` and a mark written after it would be discarded. */
  const state2 = arrivingTier === "D" ? startCarcosanDoomClock(state) : state;
  state = state2;
  const doomed = new Set(tiersRustedBy(arrivingTier));
  const limit = limitForTier(state, arrivingTier);

  /* ==================================================================
   *  DESIGN NOTE 897: #232'S RULE APPLIED TO THE ROSTER ITSELF, NOT ONLY TO ITS CONTENTS
   * ==================================================================
   *
   * REPORTED: `fleetDiscard.test.ts` crashed with "Cannot read properties of undefined (reading 'map')" on
   * every case whose arriving tier was 5 -- seven of its fourteen.
   *
   * AND THE FIXTURE WAS RIGHT. It builds a state carrying `public_companies` and nothing else, which is a
   * legitimate partial state under this codebase's own rule: `undefined` is "the chain did not say", never
   * "there are none". This function already honours that rule ONE LEVEL DOWN -- `owned_trains == null` returns
   * the company untouched, three lines below, with a comment saying why. What it did not do is ask the same
   * question of the lists themselves.
   *
   * SO THE BUG IS THE RULE APPLIED AT ONE DEPTH AND NOT THE OTHER, which is this project's commonest shape
   * seen from a new angle: not two surfaces disagreeing, but one surface asking a question of a field and not
   * of the field's container. #736 added the privates arm long after #284 wrote the fleet arm, and inherited
   * the coordinates without the caution.
   *
   * ABSENT IS NOT EMPTY, AND THE FALLBACK MUST NOT SAY IT IS. `?? []` is only safe here because the result is
   * never written back: an empty roster produces no changes, so the guarded spread below leaves the field
   * absent exactly as it found it. Writing `public_companies: []` into the returned state would convert "the
   * chain did not say" into "there are none" -- the precise error #232 exists to prevent, committed by the
   * fix for it.
   *
   * TWO GUARDS, TWO JOBS, AND THE FIRST DRAFT OF THIS NOTE CREDITED THE WRONG ONE. It claimed the `!= null`
   * check below was what kept the field from being invented. It is not: a negative control replacing it with
   * `?? []` left every assertion passing, because an empty list changes nothing and `privatesChanged` stays
   * false. What actually protects the field is the CONDITIONAL SPREAD in the return -- a control that writes
   * `private_companies` unconditionally fails immediately.
   * So: the `!= null` check stops the THROW, and the conditional spread stops the LIE. Recorded because a note
   * naming the wrong mechanism is worse than no note -- the next person deletes the guard it praised and keeps
   * the one it did not mention.
   *
   * See docs/ai_architecture/sandbox_reducer.md, sandboxSession.ts #897. */
  /* ==================================================================
   *  DESIGN NOTE 906: GENTLE RUST GIVES THE TRAIN A REPRIEVE, NOT AN EXEMPTION
   * ==================================================================
   *
   * REQUESTED: "trains that would normally rust instead enter a 'pending rust' state, granting them exactly
   * one final Operating Round run before obsolescence."
   * RULED: the pending train "dies at the exact end of that specific corporation's next Operating Round turn
   * (immediately after it generates its final revenue)", and it does NOT occupy a train-limit slot.
   *
   * SO THE RUST ARM SPLITS AND THE TRIM ARM DOES NOT. A doomed train is moved out of `owned_trains` and into
   * `pending_rust_trains` rather than destroyed -- it is still run, still priced, and still gone at the end of
   * that turn. Everything downstream that counts trains keeps counting `owned_trains`, which is what makes the
   * ruling "no limit slot" fall out of the move instead of needing a rule of its own.
   *
   * AND THAT IS WHY THE TRIM STILL SEES THE SMALLER FLEET. The two consequences of a phase change are ordered
   * -- rust, then trim to the limit (#284) -- and under this variant the rust step removes the doomed trains
   * from the countable fleet just the same. A corporation holding three 2-trains and a 4 when the first 4
   * arrives is at one countable train afterwards either way; the difference is that three of them still run
   * once more.
   *
   * THE DEATH IS NOT HERE. This function only marks; `settleRoundTransitions` clears the marks at the end of
   * that corporation's turn -- see #906a -- because "the end of its next turn" is a fact about the cursor and
   * this function does not know where the cursor is. */
  const variants = resolveVariants(state.variants);
  const gentle = variants.gentleRust;

  let changed = false;
  const companies = (state.public_companies ?? []).map((company) => {
    const owned = company.owned_trains;
    // `undefined` means the chain does not report rosters. Trimming a fleet
    // this build cannot see would invent one.
    if (owned == null) return company;

    /* 1. Rust.
       ==================================================================
        DESIGN NOTE 1032: A TRAIN ALREADY UNDER SENTENCE IS NOT SENTENCED AGAIN
       ==================================================================
       REPORTED: modals "listing trains and quantities that didn't always make sense".
       THIS FILTER ASKED ONLY WHETHER THE MODEL IS DOOMED, never whether this particular train had already
       been marked -- so a corporation holding two marked 2-trains, met by a second `applyPhaseChange` for the
       same tier, left with `pending_rust_trains` of `["2","2","2","2"]`: four sentences for two trains.
       `describeFleetLosses` diffs that list to find the rust event, so it reported two fresh rusts for trains
       already awaiting execution, and `trimToTrainLimit` then read four reprieved slots against a fleet
       holding two.
       THE INVARIANT IS THAT `pending_rust_trains` IS A SUB-MULTISET OF `owned_trains`, and this is the write
       that could break it. Stated as a multiset walk rather than a `Set` for the reason every other list in
       this file is: two 2-trains are two trains, one of which may be marked while the other is not. */
    const alreadyMarked = [...(company.pending_rust_trains ?? [])];
    const rustedNow =
      doomed.size === 0
        ? []
        : owned.filter((model) => {
            if (!doomed.has(model)) return false;
            const at = alreadyMarked.indexOf(model);
            if (at >= 0) {
              alreadyMarked.splice(at, 1);
              return false;
            }
            return true;
          });
    /* ==================================================================
        DESIGN NOTE 979: THE REPRIEVE IS A MARK ON THE TRAIN, NOT A PLACE IT GOES
       ==================================================================
       #906 MOVED THE DOOMED TRAIN OUT OF `owned_trains`, and its own harness explains why: "Every surface
       that counts trains counts that array, so this is what implements 'a pending-rust train occupies no
       train-limit slot' without any of them being told."
       CORRECTED: "Gently rusted trains do count toward the limit until they are permanently retired at the
       end of their grace run."
       AND THE OLD MECHANISM WAS TAKING MORE THAN THE LIMIT SLOT WITH IT. Every surface reads `owned_trains`
       -- including `ownedTrainRoster`, which is what the route planner draws its trains from. A train moved
       out of that array has no roster entry, so it has no route draft, so it cannot be run. #906's headline
       promise -- "exactly one final Operating Round run before obsolescence" -- has therefore never been
       reachable: the train was simply deleted a turn later than it would have been, invisibly. Nothing in
       the suite could see it, because `pending_rust_trains` was written by this function, cleared by
       `settleOperatingCursor`, and READ BY NOTHING ELSE IN THE APP.
       SO THE TRAIN STAYS PUT AND IS MARKED. Counting it against the limit then needs no rule, for the same
       reason not counting it needed none -- and it appears in the roster, in the chips and in the route
       planner, which is what "one more run" required all along. */
    const fleetAfterRust = gentle
      ? [...owned]
      : doomed.size === 0
        ? [...owned]
        : owned.filter((model) => !doomed.has(model));
    /* Appended to any existing marks rather than replacing them, because two phase changes can land between
       one corporation's turns and the older reprieve is still owed its run. */
    const reprievedAfterRust = gentle && rustedNow.length > 0
      ? [...(company.pending_rust_trains ?? []), ...rustedNow]
      : (company.pending_rust_trains ?? []);

    /* ==================================================================
        DESIGN NOTE 1530: THE LIMIT IS NOT ENFORCED HERE ANY MORE -- IT IS OWED
       ==================================================================
       "2. Trim to the limit" stood here from #284 to Batch 4: `trimToTrainLimit`, cheapest-first, reprieved
       exempt, and (from #1513) the trimmed train into the Bank Pool. Rulebook 6.6.1 gives the CHOICE to the
       president, so the trim is gone: a corporation this phase change leaves over the new limit simply stays
       over it, `pendingTrainDiscards` (`trainDiscard.ts`) reads that off the board, the reducer refuses every
       other message until the president's `DiscardTrain`s bring the fleet down, and each discard is its own
       log entry. `limit` is still computed above because `expireGhostTrains` (#1046) keeps its own trim at
       the round boundary, which is a variant ruling and not this note's. Rules-engine version 2 (#1520). */
    const fleet = fleetAfterRust;
    const trimmed = { reprieved: reprievedAfterRust as readonly string[] };
    /* ==================================================================
        #232: THE FIELD APPEARS WHEN THERE IS SOMETHING TO SAY, AND NOT BEFORE
       ==================================================================
       `reprievedAfterRust` normalises `undefined` to `[]` so the trim can walk it, and that normalisation
       must not leak back into the state: writing `pending_rust_trains: []` onto every company on every phase
       change would put an empty answer where the record had no answer -- #897's fault, one field over, and on
       a state that may not be playing this variant at all.
       BUT AN EMPTY LIST IS A REAL ANSWER ONCE MARKS HAVE EXISTED. A corporation whose reprieved trains were
       all taken by the trim in this very call genuinely holds none, and this reducer is the only writer of
       the field -- so `[]` there is a fact rather than an invention. The distinction is whether THIS call
       created a mark, which is exactly `gentle && rustedNow.length > 0`. */
    const markedThisPhase = gentle && rustedNow.length > 0;
    const reprieved =
      company.pending_rust_trains === undefined && !markedThisPhase
        ? undefined
        : trimmed.reprieved;
    const sameReprieve =
      reprieved === company.pending_rust_trains ||
      (reprieved !== undefined &&
        company.pending_rust_trains !== undefined &&
        reprieved.length === company.pending_rust_trains.length &&
        reprieved.every((model, at) => model === company.pending_rust_trains?.[at]));
    const reprieveChanged = !sameReprieve;

    if (fleet.length === owned.length && !reprieveChanged) return company;
    changed = true;
    return {
      ...company,
      // `PublicCompanyState.owned_trains` is mutable; `trimToTrainLimit` returns a readonly view.
      owned_trains: [...fleet],
      ...(reprieveChanged ? { pending_rust_trains: reprieved } : {}),
    };
  });

  /* ==================================================================
   *  DESIGN NOTE 736: PHASE 5 CLOSES THE PRIVATES, IN CODE
   * ==================================================================
   *
   * REPORTED: "a 5-train has been purchased, but ... the private companies are still displayed (and counting
   * toward certificates) ... moreover, the private companies are still paying out to players. We need to
   * enforce the closure in code, not just design diary notes."
   *
   * TEN READERS, NO WRITER. `closed` is consulted correctly all over this codebase -- `applyPrivateRevenue`
   * skips a closed private, `PrivateTradePanel` hides it, `PrivatePowerPanel` greys it, `activeReservations`
   * drops its hex badge -- and not one line anywhere ever set it. The rule lived in a caption and a schedule
   * entry, which is exactly the failure this project keeps finding, in its purest form yet: every consumer
   * right, the producer missing.
   *
   * HERE, BECAUSE THIS IS WHERE THE PHASE TURNS. The alternative was a `BuyHardwareFromPool` arm, and it would
   * have been wrong twice over -- `EmergencyBuyHardware` buys trains too, and a phase reached by any other
   * route would skip the closure. `applyPhaseChange` is called for the arriving tier however it arrived, and
   * it already owns the other two consequences of a phase turning (rust, then trim). Closure is the third.
   *
   * IDEMPOTENT, which matters because the Undo path replays the whole log: closing an already-closed private
   * changes nothing, so a rebuild produces the same state as the play did. */
  /* Design note #897: AND A STATE THAT NEVER MENTIONED PRIVATES CLOSES NONE. Written as a guard rather than as
     `?? []` because this list IS returned when it changes -- the empty-array trick that is safe for the
     roster above would, here, be one step from writing "there are no privates" onto a state that merely never
     said. `knownPrivates` stays exactly what the state held, absent included. */
  const knownPrivates = state.private_companies;
  let privates = knownPrivates;
  let privatesChanged = false;
  if (closesPrivateCompanies(arrivingTier) && knownPrivates != null) {
    privates = knownPrivates.map((priv) => (priv.closed ? priv : { ...priv, closed: true }));
    privatesChanged = privates.some((priv, at) => priv !== knownPrivates[at]);
  }

  /* Design note #1314: A RETURNED TRAIN RUSTS IN THE DEPOT TOO. "provided it hasn't rusted" -- a traded-in
     4-train sitting in the bank when the first Diesel arrives is scrapped like every other 4-train. No
     reprieve: Gentle Rust is a final run, and a train in the depot has nobody to run it. Absent stays
     absent (#232); an emptied list is written as empty, because "was here, now gone" is a fact. */
  const returnedBefore = state.returned_trains;
  const survivingReturned =
    returnedBefore && doomed.size > 0 ? returnedBefore.filter((model) => !doomed.has(model)) : returnedBefore;
  /* ==================================================================
      DESIGN NOTE 1513: A DISCARDED TRAIN GOES TO THE BANK POOL
     ==================================================================
     RULEBOOK 6.6.1: "the president chooses a train to discard. The discarded train goes to the Bank Pool and
     the corporation receives no payment." The trim above took the train and DROPPED it (audit C6): it left
     `owned_trains` and entered nothing, and because the depot derives stock from what is owned, it came back
     as printed stock a tier below the queue's head -- visible to nobody, purchasable by nobody. It is put in
     the pool now, at face value, where any corporation may buy it (`buyReturnedTrain`).
     WHICH TRAIN WAS STILL THE TRIM'S CHOICE -- cheapest-first -- and that was the half the rulebook gives to
     the president. #1530 (Batch 4.6) replaced the trim with the president's `DiscardTrain`; the pool entry
     is written by that arm now, and this function no longer discards. */
  /* #1530: nothing is discarded here any more; the pool only LOSES trains at a phase change (rust). The
     president's `DiscardTrain` is what puts a train in. */
  const returnedAfter = survivingReturned;
  const returnedChanged = returnedAfter !== returnedBefore && returnedAfter?.length !== returnedBefore?.length;

  if (!changed && !privatesChanged && !returnedChanged) return state;
  return {
    ...state,
    ...(changed ? { public_companies: companies } : {}),
    ...(privatesChanged ? { private_companies: privates } : {}),
    ...(returnedChanged ? { returned_trains: returnedAfter } : {}),
  };
}

/** Every private company closed by the arriving tier, for the Activity Log.
 *
 *  Design note #736: SAID OUT LOUD. A player's income silently dropping is the kind of change that reads as a
 *  bug -- and this one takes a certificate off their limit too, which they will notice three turns later and
 *  misattribute. Named separately from the closure so `applyPhaseChange` stays a pure state function and the
 *  shell does the narrating, per #400/#685. */
/** Which privates closed in this transition, with the number every other surface prints.
 *
 *  ==================================================================
 *   DESIGN NOTE 1058: A CLOSURE IS NOT ALWAYS A PHASE CHANGE
 *  ==================================================================
 *
 *  REPORTED, of the B&O private closing when the B&O corporation bought its first train: "the 'Phase Change'
 *  line is written improperly: it is true BO closes as soon as B&O buys a train, but this is not a phase
 *  change and private companies DO continue paying out revenue."
 *
 *  TWO EVENTS WERE SHARING ONE SENTENCE, and the sentence is correct for exactly one of them. When Phase 5
 *  arrives EVERY private closes and every one of them stops paying -- #736's line says so and is right. When
 *  a single private closes on its own trigger, nothing about the phase has moved and the other five keep
 *  paying every Operating Round. The shared sentence told a player that their remaining income had stopped.
 *
 *  THIS FUNCTION STILL ONLY OBSERVES. It reports what closed; deciding WHY belongs to the caller, which is
 *  the only place that can see whether the phase tier moved in the same transition. Returning the id along
 *  with the name is what lets that caller print "6. Baltimore & Ohio" in the form the Ledger, the player
 *  cards, the auction dashboard and the action bar already use (#1052). */
export function describePrivateClosures(
  before: GameStateResponse,
  after: GameStateResponse,
): { privateId: number; name: string }[] {
  /* Design note #897: THE SAME GUARD, AND IT IS NOT DEFENSIVE PADDING. `App.tsx` calls this in the same block
     as `describeFleetLosses`, immediately after the reducer that just stopped throwing -- so a state that
     reaches `applyPhaseChange` without a privates list reaches this too, and this would have been the very
     next crash. Naming NO closures for a list nobody reported is the honest answer: a closure that cannot be
     observed must not be announced. */
  const closed: { privateId: number; name: string }[] = [];
  for (const priv of after.private_companies ?? []) {
    if (!priv.closed) continue;
    const was = (before.private_companies ?? []).find(
      (entry) => entry.private_id === priv.private_id,
    );
    if (was && !was.closed) closed.push({ privateId: priv.private_id, name: priv.name });
  }
  return closed;
}

/** What one corporation lost when the phase turned. */
export interface FleetLoss {
  companyId: number;
  ticker: string;
  /** Destroyed by the arriving tier -- 2s on the first 4, 3s on the first 6, 4s on the first Diesel. */
  rusted: readonly string[];
  /** Returned to bring the fleet under the new, lower train limit. Cheapest first. */
  discarded: readonly string[];
}

/** The gently-rusted trains this dispatch finally destroyed.
 *
 *  ==================================================================
 *   DESIGN NOTE 1002: THE MODAL MOVES TO THE MOMENT THE TRAIN ACTUALLY DIES
 *  ==================================================================
 *
 *  RULED: "For the Gentle Rust variant, the Rust modal must no longer trigger globally upon the purchase of
 *  the phase-change train. Instead, scope it to trigger at the moment the gently rusted trains are
 *  permanently destroyed."
 *
 *  AND THE OLD TIMING WAS TELLING EIGHT PRESIDENTS ABOUT A LOSS SEVEN OF THEM HAD NOT HAD YET. A phase change
 *  marks every corporation's doomed trains at once, so one purchase queued eight modals -- and under this
 *  variant the trains were not gone, they were owed a run each, at eight different future moments. The notice
 *  was true of the marking and premature about the loss.
 *
 *  THE SAME SHAPE AS `describeFleetLosses`, deliberately: a DIFF rather than a signal. #704's division is
 *  that the reducer settles and the shell narrates, and a reprieve expiry is settled inside
 *  `settleOperatingCursor` (#1001) where no caller can see it happen. What is observable afterwards is that a
 *  corporation's `pending_rust_trains` emptied and its `owned_trains` lost exactly those models -- which is
 *  this function.
 *
 *  BOTH SIDES ARE REQUIRED, and that is what stops it firing on a phase change. When the trains are MARKED,
 *  `pending_rust_trains` grows and `owned_trains` is untouched (#979); when they are DESTROYED, the marks
 *  clear and the fleet shrinks. Only the second produces entries here.
 *
 *  `rusted`, NOT `discarded`, because that is what happened: the arriving tier killed these trains and the
 *  reprieve only postponed it. The train-limit trim is a different cause with a different remedy and is
 *  narrated where it happens (#896's split). */
/** The marked trains a single dispatch actually destroyed, for one corporation.
 *
 *  ==================================================================
 *   DESIGN NOTE 1099: EXTRACTED BECAUSE TWO FUNCTIONS NEEDED THE SAME ANSWER
 *  ==================================================================
 *
 *  REPORTED, under Gentle Rust: three reprieved 2-trains finished their last run, and the player got the Rust
 *  modal (correct) AND a Train Limit modal claiming the same three trains were "returned to the depot to meet
 *  the new limit of 3" (not correct -- the limit had taken nothing).
 *
 *  BOTH NARRATORS RUN ON EVERY DISPATCH, back to back in `App.tsx`, and they disagreed about one event.
 *  `describeReprieveExpiries` knew these trains had rusted; `describeFleetLosses` saw three models leave
 *  `owned_trains` and, under this variant, attributed every departure to the trim. That attribution was
 *  written for the PHASE CHANGE, where #979 makes rust take nothing, and its own note says so: "rust only
 *  marks, so a doomed train that left the fleet in the same phase change left because the trim took it."
 *  The premise is true there and false here, and the sentence outlived it -- this codebase's third recurring
 *  shape, named in its own notes.
 *
 *  SO THE QUESTION HAS ONE OWNER NOW. Both callers ask this function instead of each deriving an answer, which
 *  is the only fix that keeps them from disagreeing again -- #891, and the reason a shared helper is worth
 *  more here than a condition bolted onto the second caller. */
export function expiredReprieves(
  was: PublicCompanyState | undefined,
  now: PublicCompanyState,
): readonly string[] {
  const marked = was?.pending_rust_trains;
  // #232: absent is "the chain did not say", and a build that never reports the field expires nothing.
  if (marked == null || marked.length === 0) return [];
  if ((now.pending_rust_trains?.length ?? 0) !== 0) return [];
  const had = was?.owned_trains;
  const has = now.owned_trains;
  if (had == null || has == null) return [];

  /* Multiset difference, for `describeFleetLosses`' own reason: two 3-trains are two trains, and a
     corporation that loses one still holds the other. */
  const remaining = [...has];
  const gone: string[] = [];
  for (const model of had) {
    const at = remaining.indexOf(model);
    if (at >= 0) remaining.splice(at, 1);
    else gone.push(model);
  }
  /* ONLY THE MARKED MODELS. A dispatch that expired a reprieve AND lost a train to something else would
     otherwise report the second as rust; intersecting with the marks keeps this about the one event. */
  const marks = [...marked];
  const destroyed: string[] = [];
  for (const model of gone) {
    const at = marks.indexOf(model);
    if (at >= 0) {
      marks.splice(at, 1);
      destroyed.push(model);
    }
  }
  return destroyed;
}

export function describeReprieveExpiries(
  before: GameStateResponse,
  after: GameStateResponse,
): FleetLoss[] {
  const losses: FleetLoss[] = [];
  for (const company of after.public_companies ?? []) {
    const was = (before.public_companies ?? []).find(
      (entry) => entry.company_id === company.company_id,
    );
    // Design note #1099: the shared answer, so this narrator and the limit's cannot disagree about one event.
    const destroyed = expiredReprieves(was, company);
    if (destroyed.length === 0) continue;
    losses.push({
      companyId: company.company_id,
      ticker: company.ticker,
      rusted: destroyed,
      discarded: [],
    });
  }
  return losses;
}

/** Reads back what `applyPhaseChange` took, by comparing the fleets it rewrote.
 *
 *  Design note #704: THE REDUCER SETTLES, THE SHELL NARRATES -- #400's division, and the same one #685 used
 *  for private revenue. `applyPhaseChange` has trimmed over-limit fleets cheapest-first since #284 and has
 *  never said so: the trains simply left the corporation's chips between one render and the next.
 *
 *  THAT SILENCE ONLY JUST BECAME REACHABLE. Until #703 the Buy Trains panel REFUSED the purchase that would
 *  leave a corporation over the new limit, so the trim ran for bystanders and almost never for the buyer. #703
 *  corrected the rule; this is the consequence that was hiding behind it.
 *
 *  AND IT IS THE BUG FROM #702 MADE REAL. That report was "I actually thought the 3-train purchase had been
 *  swapped out with it because it is so hard to see" -- a misreading, then. A president who buys a 4-train and
 *  finds two chips where three were is now reading correctly, and deserves to be told which train went and
 *  why.
 *
 *  DERIVED RATHER THAN RETURNED, so `applyPhaseChange` stays a pure state -> state function and the sentence
 *  cannot be built for a transition that did not happen. A model that left is a RUST when the arriving tier is
 *  the one that kills it, and a DISCARD otherwise -- re-derived from `RUSTS_ON`, which is the same table the
 *  trim itself consulted. */
export function describeFleetLosses(
  before: GameStateResponse,
  after: GameStateResponse,
  /* ==================================================================
      DESIGN NOTE 1245: A TRAIN THAT WAS SOLD DID NOT LEAVE TO MEET THE LIMIT
     ==================================================================
     REPORTED (§2.3): after a corporation-to-corporation trade, "Phase Change -- B&O: its 2-train was
     discarded to meet the new limit of 4." B&O SOLD that train. This function reads the fleet DIFF on every
     action, and a sale empties the seller's fleet by one exactly as a trim does -- #1099's shape again (an
     expiry is not a discard), for the one other message that legitimately takes a train off a chip.
     THE MESSAGE IS OPTIONAL so every existing caller and test stands; the shell passes it. Removed by
     multiset, as #1099 does, so a seller that also lost a train to a phase change in the same action --
     which cannot happen today, since the trade is not a depot purchase -- would still get that sentence. */
  msg?: unknown,
): FleetLoss[] {
  const arrivingTier = derivePhase(after)?.tier ?? null;
  const losses: FleetLoss[] = [];
  const sold =
    typeof msg === "object" && msg !== null && "BuyTrainFromCorporation" in msg
      ? (msg as { BuyTrainFromCorporation: { seller_protocol_id: number; model_type: string } })
          .BuyTrainFromCorporation
      : null;
  /* ==================================================================
      DESIGN NOTE 1264: A TRAIN THE SIGN TOOK DID NOT LEAVE TO MEET THE LIMIT
     ==================================================================
     REPORTED (22b, the narration half): the Mark takes a train and the president gets a Train Limit modal
     about it. #1245's shape exactly -- this diff runs on every action, the `YellowSignEvent` empties the fleet
     by one, and a corporation that has just LOST a train cannot be over the limit. The event narrates
     itself (#1046's appendix and the mechanical line), so the model it names comes out of `lost` before it
     can be read as a discard. Both stages that remove a train carry `model` (#902, #1092). */
  /* #1530: the president's own discard is narrated by the Activity Log as the action it is, not as a loss the
     phase took -- so it is taken out of the diff like a sale. */
  const discardedByChoice =
    typeof msg === "object" && msg !== null && "DiscardTrain" in msg
      ? (msg as { DiscardTrain: { protocol_id: number; model_type: string } }).DiscardTrain
      : null;
  const taken =
    typeof msg === "object" && msg !== null && "YellowSignEvent" in msg
      ? (msg as { YellowSignEvent: { protocol_id: number; model?: string | null } }).YellowSignEvent
      : null;

  /* Design note #897: THE THIRD FUNCTION IN THE SAME BLOCK, GUARDED FOR THE SAME REASON. `App.tsx` runs
     `describeFleetLosses`, `describeFleetLoss` and `describePrivateClosures` back to back on the state
     `applyPhaseChange` just returned, so any state that can reach one can reach all of them. Fixing three of
     the four would be the half-fix this codebase keeps producing -- the same rule asked in one authority and
     not in its sibling. */
  for (const company of after.public_companies ?? []) {
    const was = (before.public_companies ?? []).find(
      (entry) => entry.company_id === company.company_id,
    );
    const had = was?.owned_trains;
    const has = company.owned_trains;
    // `undefined` on either side is "the chain did not say", never "owns nothing" -- the distinction #232
    // makes, and inventing a loss from it would report trains that were never there.
    if (had == null || has == null) continue;

    /* Multiset difference, not a set one: two 3-trains are two trains, and a corporation that loses one of
       them still holds the other. Splicing from a copy is what keeps the count right. */
    const remaining = [...has];
    const lost: string[] = [];
    for (const model of had) {
      const at = remaining.indexOf(model);
      if (at >= 0) remaining.splice(at, 1);
      else lost.push(model);
    }
    // #1245: the sold train comes out of `lost` before it can be read as a discard.
    if (sold !== null && sold.seller_protocol_id === company.company_id) {
      const at = lost.indexOf(sold.model_type);
      if (at >= 0) lost.splice(at, 1);
    }
    // #1264: so does the one the Yellow Sign took.
    if (taken !== null && taken.protocol_id === company.company_id && taken.model) {
      const at = lost.indexOf(taken.model);
      if (at >= 0) lost.splice(at, 1);
    }
    if (discardedByChoice !== null && discardedByChoice.protocol_id === company.company_id) {
      const at = lost.indexOf(discardedByChoice.model_type);
      if (at >= 0) lost.splice(at, 1);
    }
    /* ==================================================================
        DESIGN NOTE 979: UNDER GENTLE RUST, RUST TAKES NOTHING -- SO THE DIFF CANNOT SEE IT
       ==================================================================
       THIS FUNCTION READS BACK WHAT `applyPhaseChange` DID by diffing `owned_trains`, and #979 stops a
       gently-rusted train from leaving that array. Left alone, the rust notice would simply stop appearing
       for the one variant whose whole point is telling the player about it -- a narrator that went quiet
       because the thing it narrates moved one field over.
       SO THE REPRIEVE IS DIFFED TOO. Trains newly ADDED to `pending_rust_trains` are the rust event; trains
       gone from `owned_trains` are what the limit took.
       AND UNDER THIS VARIANT EVERY DEPARTURE IS THE LIMIT'S. Rust only marks, so a doomed train that left the
       fleet in the same phase change left because the trim took it -- which is the more useful thing to tell
       the player, since their question is why it did not get the grace run it was just promised. The
       tier-based split below is the STANDARD rule and stays exactly as it was. */
    const gentle = resolveVariants(after.variants).gentleRust;
    const newlyReprieved: string[] = [];
    if (gentle) {
      const already = [...(was?.pending_rust_trains ?? [])];
      for (const model of company.pending_rust_trains ?? []) {
        const at = already.indexOf(model);
        if (at >= 0) already.splice(at, 1);
        else newlyReprieved.push(model);
      }
      /* ==================================================================
          DESIGN NOTE 1099: A REPRIEVE RUNNING OUT IS NOT THE LIMIT TAKING A TRAIN
         ==================================================================
         REPORTED: three reprieved 2-trains finished their last run and the player got the Rust modal AND a
         Train Limit modal about the same three trains -- "returned to the depot to meet the new limit of 3",
         when the limit had taken nothing.
         THE PARAGRAPH ABOVE IS WHY, and it is worth reading as written: "under this variant every departure
         is the limit's. Rust only marks, so a doomed train that left the fleet in the same phase change left
         because the trim took it." TRUE AT A PHASE CHANGE, where #979 stops rust removing anything. FALSE AT
         AN EXPIRY, which is the one moment under this variant when rust does empty `owned_trains` -- and
         `describeReprieveExpiries` was already narrating it correctly two hundred lines down.
         SO THE EXPIRED MODELS COME OUT OF `lost` BEFORE IT IS READ AS A DISCARD, asked of the same helper the
         other narrator asks. Removed by multiset so a corporation that loses a marked 2-train to rust and a
         second, unmarked one to the trim still gets both sentences. */
      for (const model of expiredReprieves(was, company)) {
        const at = lost.indexOf(model);
        if (at >= 0) lost.splice(at, 1);
      }
    }
    if (lost.length === 0 && newlyReprieved.length === 0) continue;

    const rusted: string[] = [];
    const discarded: string[] = [];
    if (gentle) {
      rusted.push(...newlyReprieved);
      discarded.push(...lost);
    } else {
      for (const model of lost) {
        if (arrivingTier !== null && RUSTS_ON[model] === arrivingTier) rusted.push(model);
        else discarded.push(model);
      }
    }
    losses.push({ companyId: company.company_id, ticker: company.ticker, rusted, discarded });
  }

  return losses;
}

/** One sentence per corporation, or `null` when it lost nothing worth a line. */
export function describeFleetLoss(loss: FleetLoss, trainLimit: number | null): string | null {
  const parts: string[] = [];
  if (loss.rusted.length > 0) {
    parts.push(`${namedTrains(loss.rusted)} rusted`);
  }
  if (loss.discarded.length > 0) {
    /* THE LIMIT IS NAMED, because "discarded its 2-train" without it reads as a choice the president made.
       It is not a choice -- 1830 takes the train, and the only latitude is which one, which is why the rule
       (cheapest first) is stated too. */
    const ceiling = trainLimit === null ? "the new train limit" : `the new limit of ${trainLimit}`;
    parts.push(
      `${namedTrains(loss.discarded)} ${loss.discarded.length === 1 ? "was" : "were"} discarded to meet ${ceiling}`,
    );
  }
  if (parts.length === 0) return null;
  return `${loss.ticker}: ${parts.join(", and ")}.`;
}

/** "its 2-train", "its 3-train and 3-train" -- the tier spelled as players say it (#696). */
/* Design note #1100: the phrasing moved to `trainPhrasing.ts`, shared with the modal so a rule change reaches
   both. THE POSSESSIVE STAYS HERE, because it belongs to this sentence: the modal says "B&O's ..." where this
   says "its ...", and a helper that assumed either would be worked around by the other. */
function namedTrains(models: readonly string[]): string {
  return `its ${sayTrains(models)}`;
}

/* ==================================================================
    DESIGN NOTE 1019: ALL OR NOTHING, AND IN THE AUTHORITY
   ==================================================================
   This function had no gate of any kind: it charged, banked, delivered and turned the phase whatever the
   board said. `adjustTreasury` floored at zero (Batch 7.1 retired it, #1560), so an unaffordable purchase
   took every dollar there was, gave
   the train anyway, and -- because #778's refusal detector works by identity and this mutated -- reported
   success. See `trainPurchaseGate.ts` for the log that shows all three consequences in three lines.

   THE GATE LIVES HERE, INSIDE THE SHARED FUNCTION, rather than in the two message arms that call it. Both
   `BuyHardwareFromPool` and `EmergencyBuyHardware` end up here, and an option threaded through two call
   sites is an option one of them eventually forgets -- which is #1006's bug from two batches ago, where a
   correct predicate was passed by three callers and omitted by the one that decided anything.

   `requireFunds` IS PASSED, NOT INFERRED, and it is the only thing the emergency path changes. */
function buyDepotTrain(
  state: GameStateResponse,
  companyId: number,
  /** Design note #1019: `false` only for the emergency purchase, which has already funded the treasury. */
  requireFunds = true,
  /** Design note #1314: a RETURNED model to buy at face value, instead of the tier for sale. */
  modelType?: string,
  /** #1326: the shelf tier the buyer chose, when the shelf offers more than one. */
  tierChoice?: string,
): GameStateResponse {
  if (modelType !== undefined) return buyReturnedTrain(state, companyId, modelType, requireFunds);
  /* Design note #1326: THE SHELF, NOT THE QUEUE HEAD. `openDepotTiers` is one row in the printed game and
     the 6/7/D shelf under the Level Playing Field; a named `tier` picks from it and an unnamed purchase takes
     the first, which is what every message written before the field meant. A name that is not on the shelf
     is refused -- a Diesel asked for before the first 6 is bought buys nothing. */
  const open = openDepotTiers(state);
  const tier = tierChoice === undefined ? open[0] : open.find((row) => row.tier === tierChoice);
  // An empty depot is not an error to throw at a sandbox tester; it is a
  // purchase with nothing to buy, so nothing moves.
  if (!tier) return state;

  /* REFUSES BY RETURNING THE STATE IT WAS HANDED, which is what every gate in this reducer does and what
     `actionWasRefused` detects by reference (#778). That identity is the whole of the "throw an error to the
     UI" half of the report -- the drain already renders a refusal line and #784 already names the rule. */
  /* Design note #1530: JUDGED AGAINST THE LIMIT IN FORCE, not the tier's own. `tier.trainLimit` is the limit
     that will apply once this tier is current -- for the phase-changing purchase, the NEW limit -- and
     judging the buyer by it was #296's mistake inside the reducer (#703 corrected the panel, not this gate):
     a corporation holding 2 at phase 4 could not buy the first 5-train, though rulebook 2.0 says the purchase
     "may result in the forced discard of a train by the railroad that just purchased". The limit is tested
     before the purchase resolves; the discard is what follows it. */
  if (
    trainPurchaseRefusal(state, companyId, {
      cost: tier.cost,
      trainLimit: limitInForce(state) ?? tier.trainLimit,
      requireFunds,
    }) !== null
  ) {
    return state;
  }

  /* #1560: the gate above has already required the funds (or waived them for the emergency path, which
     funded the treasury first), so this refusal is unreachable in play -- it is the boundary, not the rule. */
  const paid = transfer(state, { corporation: companyId }, BANK, tier.cost);
  if (!paid.ok) return state;
  const banked = paid.state;
  const before = derivePhase(state)?.tier ?? null;
  const delivered = withTrains(banked, companyId, (trains) => [...trains, tier.tier]);
  const after = derivePhase(delivered)?.tier ?? null;

  /* Fires only on the purchase that CHANGES the phase. Applying it to every purchase deadlocked the sandbox, because trimming a fleet returns trains to a depot derived from what is owned.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #284 */
  return after !== null && after !== before ? applyPhaseChange(delivered, after) : delivered;
}

/* ==================================================================
    DESIGN NOTE 1314: BUYING A RETURNED TRAIN
   ==================================================================
   A train traded in for a Diesel sits in `returned_trains` at its printed price. It is a purchase like any
   other -- the same round, step, actor, limit and funds gate, the same treasury-to-bank movement -- with two
   differences: it comes off the returned list rather than the printed count, and it can never turn the
   phase, because the phase is the HIGHEST train in play and a returned train is by construction below the
   Diesel that displaced it. The gate is the one `refusedAction` asks (`returnedTrainRefusal`). */
export function returnedTrainRefusal(
  state: GameStateResponse,
  companyId: number,
  modelType: string,
  /** Design note #1512: `false` only for the forced purchase, which has already funded the treasury. */
  requireFunds = true,
): string | null {
  if (!(state.returned_trains ?? []).includes(modelType)) {
    return `The Bank Depot holds no returned ${modelType}-train.`;
  }
  const tier = depotInventory(state).find((row) => row.tier === modelType);
  const limitRow = depotInventory(state).find((row) => row.remaining === null || row.remaining > 0);
  return trainPurchaseRefusal(state, companyId, {
    cost: tier?.cost ?? null,
    // The limit is the CURRENT phase's, which is the tier for sale, not the returned train's own.
    trainLimit: limitRow?.trainLimit ?? tier?.trainLimit ?? null,
    requireFunds,
  });
}

function buyReturnedTrain(
  state: GameStateResponse,
  companyId: number,
  modelType: string,
  requireFunds: boolean,
): GameStateResponse {
  /* Design note #1512: THE FORCED PURCHASE MAY TAKE A POOL TRAIN. This line read `if (!requireFunds) return
     state; // an emergency purchase buys from the printed depot, never the returned list` -- audit M9. The
     rulebook's "cheapest available train" (6.6.2) is drawn from the Bank and the Bank Pool alike, and
     `cheapestPurchasableTrain` now names the pool copy when it is the cheapest. */
  if (returnedTrainRefusal(state, companyId, modelType, requireFunds) !== null) return state;
  const cost = depotInventory(state).find((row) => row.tier === modelType)?.cost ?? 0;
  const returned = [...(state.returned_trains ?? [])];
  returned.splice(returned.indexOf(modelType), 1);
  // #1560: all or nothing -- a refused charge leaves the returned list alone as well as the treasury.
  const paid = transfer({ ...state, returned_trains: returned }, { corporation: companyId }, BANK, cost);
  if (!paid.ok) return state;
  return withTrains(paid.state, companyId, (trains) => [...trains, modelType]);
}

/** Moves one train and the price the other way. Exported so the consent flow settles a trade the same way the reducer does. Absent model is a no-op, not a throw.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #191 */
export function settleTrainSale(
  state: GameStateResponse,
  buyerId: number,
  sellerId: number,
  modelType: string,
  price: string,
): GameStateResponse {
  const seller = state.public_companies.find((entry) => entry.company_id === sellerId);
  const index = (seller?.owned_trains ?? []).indexOf(modelType);
  if (index < 0) return state;

  const paid = Number(price);
  const amount = Number.isFinite(paid) && paid > 0 ? paid : 0;

  /* Design note #1560: THE MONEY MOVES FIRST, so a price the buyer cannot cover refuses the whole sale
     rather than delivering the train and flooring the payment (which minted the difference at the seller).
     Corporation to corporation: the bank is not involved, so this is one debit and one matching credit.
     Whether the price is LEGAL -- rulebook 6.6's $1 minimum, the operating/step/consent rules -- is Batch
     7.4's predicate (S7-5); this batch only declines to invent the money. A price of $0 or less is still
     normalised to a free transfer above, exactly as before. */
  const settledPrice = transfer(state, { corporation: buyerId }, { corporation: sellerId }, amount);
  if (!settledPrice.ok) return state;
  const removed = withTrains(settledPrice.state, sellerId, (trains) => {
    const next = [...trains];
    next.splice(index, 1);
    return next;
  });
  const settled = withTrains(removed, buyerId, (trains) => [...trains, modelType]);

  /* ==================================================================
      DESIGN NOTE 1090: THE BLOOD PRICE, AND WHAT ELSE MOVES WITH THE TRAIN
     ==================================================================
     RULED: "The train immediately loses its Carcosa/Yellow Sign flag and becomes a standard train for the
     buying corporation ... The only way a corporation loses the [is_carcosan] flag is by successfully
     transferring the Carcosa train to another company (paying the Blood Price)."

     SO A CARCOSAN TRANSFER MOVES FOUR THINGS AND CLEARS A FIFTH, and it is worth listing them because a
     partial version of this is the likeliest bug:
       the train        moves, like any other train (above).
       `carcosan_trains` LOSES the model at the seller, and the buyer does NOT gain it -- the gold trim is
                        burned off by the sale. That is the ruled "becomes a standard train".
       `is_carcosan`     CLEARS at the seller. The one eraser in the game.
       the doom clock    clears with it: there is nothing left for the fog to come for.
       the share price   is the caller's, not this function's -- see below.

     THE BUYER IS NOT CURSED. Ruled explicitly ("becomes a standard train for the buying corporation"), and
     it is what makes the trade a real decision rather than a hot potato: somebody has to want the train.

     ONLY WHEN THE TRAIN WAS ACTUALLY CARCOSAN. An ordinary sale between two corporations must not move a
     market token, so the seller's mark is the gate and `movedCarcosan` reports it to the caller.

     THE MARKET MOVE IS NOT PERFORMED HERE, deliberately. This function is a reducer over `public_companies`;
     the chart lives in `SandboxMarketPrices`, a separate structure the caller owns (`applySandboxMarketAction`
     is the only thing that writes it). Reaching across would give the market two authors, which is the split
     #891 keeps costing us. `carcosanTransfer` is returned instead and `App.tsx` moves the token. */
  const marked = seller?.carcosan_trains ?? [];
  const markedAt = marked.indexOf(modelType);
  if (markedAt < 0) return settled;

  const survivingMarks = [...marked];
  survivingMarks.splice(markedAt, 1);
  return {
    ...settled,
    public_companies: settled.public_companies.map((entry) =>
      entry.company_id === sellerId
        ? {
            ...entry,
            carcosan_trains: survivingMarks,
            is_carcosan: false,
            ...(survivingMarks.length === 0
              ? { carcosan_doom_after_macro_round: undefined }
              : {}),
          }
        : entry,
    ),
  };
}

/** Whether this sale is the Carcosa train changing hands -- asked BEFORE `settleTrainSale` clears the mark.
 *
 *  Design note #1090: a predicate rather than a return value on the settle, because the caller needs the
 *  answer to decide whether to move the market and what to log, and it needs it while the seller still has
 *  the flag. Asking after the fact would require the caller to diff two states for a boolean. */
export function isCarcosanTransfer(
  state: GameStateResponse,
  sellerId: number,
  modelType: string,
): boolean {
  const seller = (state.public_companies ?? []).find((entry) => entry.company_id === sellerId);
  return (seller?.carcosan_trains ?? []).includes(modelType);
}

/* A reducer over the auction's own response shape, with the same charter: pointers, counters and lists, no rules. The cash side is RETURNED for the caller to apply -- one state change per atom.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #261 */
export interface SandboxWaterfallResult {
  waterfall: WaterfallStateResponse;
  /* Charges are a LIST of (player, amount): a cascade settles several privates and the auto-awarded ones are charged to the lone bidder, not the actor.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #334 */
  charges: Array<{ player: string; amount: number }>;
  /* Wins are a LIST in resolution order -- one purchase can cascade through several lone-bid privates.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #334 */
  won: Array<{ privateId: number; name: string; player: string; price: number }>;
  /* The all-pass payout is REPORTED, not performed: the waterfall atom does not carry private_companies. The caller runs applyPrivateRevenue, the same payout the OR uses.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #337 */
  allPassed: boolean;
  /** The markdown that came with it, for the caller's log line. */
  markdown: { privateId: number; name: string; from: number; to: number } | null;
}

/** The next seat in turn order, wrapping. */
function nextSeat(players: readonly string[], current: string): string {
  if (players.length === 0) return current;
  const at = players.indexOf(current);
  return players[(at + 1) % players.length];
}

/* The contest queue is ordered by LOWEST BID and fixed at opening. Re-sorting on every raise would move players under the cursor; nextSeat's -1 index made it accidentally right.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #544 */
function byAscendingBid(
  bidders: readonly string[],
  bids: readonly { bidder: string; bid_amount: string }[],
): string[] {
  const amountOf = (who: string) =>
    Number(bids.find((bid) => bid.bidder === who)?.bid_amount ?? 0) || 0;
  /* Ties are impossible -- every bid must beat the standing one by the $5
     increment -- so this needs no tiebreak, and `sort` being stable means a
     malformed fixture degrades to input order rather than to nondeterminism. */
  return [...bidders].sort((a, b) => amountOf(a) - amountOf(b));
}

/** Skips the high bidder -- nobody is invited to outbid themselves (waterfall::skip_leader_turns).
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #544 */
function nextMiniTurn(
  bidders: readonly string[],
  highBidder: string,
  after: string | null,
): string {
  if (bidders.length === 0) return highBidder;
  const from = after === null ? -1 : bidders.indexOf(after);
  for (let step = 1; step <= bidders.length; step += 1) {
    const candidate = bidders[(from + step + bidders.length) % bidders.length];
    if (candidate !== highBidder) return candidate;
  }
  return highBidder;
}

export function applySandboxWaterfallAction(
  waterfall: WaterfallStateResponse,
  msg: GameplayExecuteMsg,
  players: readonly string[],
): SandboxWaterfallResult {
  const unchanged: SandboxWaterfallResult = {
    waterfall,
    charges: [],
    won: [],
    allPassed: false,
    markdown: null,
  };
  const actor = waterfall.mini_auction?.current_turn ?? waterfall.current_turn;

  /** Drops a private from the offer list and re-marks the new cheapest. The
   *  list is documented as arriving in ascending face value, so "cheapest
   *  remaining" is simply the first entry. */
  const removePrivate = (privateId: number): WaterfallPrivateStatus[] =>
    waterfall.privates
      .filter((entry) => entry.private_id !== privateId)
      .map((entry, index) => ({ ...entry, is_lowest_offered: index === 0 }));

  /* Three missing transitions made the auction a dead end: a mini-auction could be resolved but never opened, passes counted forever, and the auction never ended. All three are pacing, not rules.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #271 */

  /** One ending for every way the last private can leave -- purchase, resolved contest, or markdown to free.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #271 */
  const settle = (next: WaterfallStateResponse): WaterfallStateResponse =>
    next.privates.length === 0
      ? { ...next, waterfall_auction_active: false, mini_auction: null }
      : next;

  /** The auto-award CASCADES: settling a lone-bid private promotes the next, which may itself resolve. A single if would have left the two-deep case wrong.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #336 */
  const cascade = (
    startingPrivates: WaterfallPrivateStatus[],
  ): {
    privates: WaterfallPrivateStatus[];
    mini: WaterfallMiniAuctionStatus | null;
    won: SandboxWaterfallResult["won"];
    charges: Array<{ player: string; amount: number }>;
  } => {
    let privates = startingPrivates;
    const won: SandboxWaterfallResult["won"] = [];
    const charges: Array<{ player: string; amount: number }> = [];

    for (let guard = 0; guard <= startingPrivates.length; guard += 1) {
      const lowest = privates.find((entry) => entry.is_lowest_offered);
      if (!lowest) return { privates, mini: null, won, charges };

      if (lowest.bids.length >= 2) {
        // Contested: a mini-auction decides it, and the cascade stops here.
        return { privates, mini: openMiniAuction(lowest), won, charges };
      }
      if (lowest.bids.length === 0) {
        // Open at face value. Nothing to resolve; the next player chooses.
        return { privates, mini: null, won, charges };
      }

      // Exactly one bid: it is theirs, at the price they bid -- NOT at face
      // value. The bid is the higher of the two by construction (a bid must
      // exceed face value by the increment), and charging face value would
      // hand them a discount for having been the only one interested.
      const [bid] = lowest.bids;
      const price = Number(bid.bid_amount) || 0;
      won.push({ privateId: lowest.private_id, name: lowest.name, player: bid.bidder, price });
      charges.push({ player: bid.bidder, amount: price });
      privates = privates
        .filter((entry) => entry.private_id !== lowest.private_id)
        .map((entry, index) => ({ ...entry, is_lowest_offered: index === 0 }));
    }
    return { privates, mini: null, won, charges };
  };

  const openMiniAuction = (
    target: WaterfallPrivateStatus,
  ): WaterfallMiniAuctionStatus | null => {
    if (target.bids.length < 2) return null;
    const highest = target.bids.reduce((best, bid) =>
      Number(bid.bid_amount) > Number(best.bid_amount) ? bid : best,
    );
    /* Design note #544: bid order, lowest first. Seeded from the seated
       roster so an unknown bidder cannot enter the queue, then sorted --
       `players.filter` is the membership test, `byAscendingBid` is the
       running order. */
    const bidders = byAscendingBid(
      players.filter((player) => target.bids.some((bid) => bid.bidder === player)),
      target.bids,
    );
    const leader = highest.bidder;
    return {
      private_id: target.private_id,
      bidders,
      // The contest opens on the front of the queue -- the lowest bidder --
      // skipping the leader, who is never asked to outbid themselves.
      current_turn: nextMiniTurn(bidders, leader, null),
      high_bid: highest.bid_amount,
      high_bidder: leader,
    };
  };

  if ("WaterfallBuyLowest" in msg) {
    const target = waterfall.privates.find((entry) => entry.is_lowest_offered);
    if (!target) return unchanged;
    const price = Number(target.face_value) || 0;

    // Buying the cheapest promotes the next, and a contest on it opens now -- the ordinary way a mini-auction starts.
    // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #271
    const resolved = cascade(removePrivate(target.private_id));

    return {
      waterfall: settle({
        ...waterfall,
        privates: resolved.privates,
        mini_auction: resolved.mini,
        current_turn: nextSeat(players, waterfall.current_turn),
        // Buying is not passing, so the streak that would end the auction
        // resets -- a counter, not a rule about what the streak means.
        consecutive_waterfall_passes: 0,
      }),
      // The buyer's own price, then whatever the cascade auto-awarded --
      // each to whoever actually owes it (design note #334a).
      charges: [{ player: actor, amount: price }, ...resolved.charges],
      won: [
        { privateId: target.private_id, name: target.name, player: actor, price },
        ...resolved.won,
      ],
      allPassed: false,
      markdown: null,
    };
  }

  if ("WaterfallBidHigher" in msg) {
    const { private_id, bid_amount } = msg.WaterfallBidHigher;
    const amount = Number(bid_amount) || 0;
    /* ==================================================================
        DESIGN NOTE 1184: THE INCREMENT, ASKED WHERE THE STATE MOVES
       ==================================================================
       REPORTED: "clicking Bid on a private company is registering everyone with the same bid, but players
       have to bid $5 more than the highest current bid."
       THE BUTTON HAS ALWAYS ENFORCED THIS and the board never has. `minimumBidFor` was arithmetic inside
       `WaterfallAuctionDashboard`, under a comment describing itself as a mirror of the contract constant --
       so the input defaulted correctly, `bidRejectionReason` blocked anything short, and this arm took
       whatever arrived. In ordinary play that is invisible; two clients that have not yet seen each other's
       bid both compute `face + 5`, both submit it, and both are accepted.
       SAFE IN A REPLAY, unlike #1182 above it. Both sides come out of the log: the amount travels in the
       message and the standing bids are rebuilt from the same prefix on every client. No cursor, no chart,
       no value that can differ between two browsers replaying one log.
       IT DOES CHANGE HOW EXISTING LOGS REPLAY, which was the owner's call to make and was made knowingly: a
       bid the button let through while stale is dropped on the next rebuild, and an auction's outcome can
       shift. Recorded here because a silent retroactive rule is the thing that makes an old game
       unreproducible.
       A REFUSAL LEAVES THE STATE UNCHANGED (#712), so a replay never halts on it. */
    const bidOnEntry = waterfall.privates.find((entry) => entry.private_id === private_id) ?? null;
    if (
      bidOnEntry !== null &&
      amount < minimumBidFor({ faceValue: bidOnEntry.face_value, bids: bidOnEntry.bids })
    ) {
      return unchanged;
    }
    return {
      waterfall: {
        ...waterfall,
        privates: waterfall.privates.map((entry) => {
          if (entry.private_id !== private_id) return entry;
          // One standing bid per player: a raise REPLACES rather than
          // stacking, which is what the real bid table holds.
          const others = entry.bids.filter((bid) => bid.bidder !== actor);
          return {
            ...entry,
            bids: [...others, { bidder: actor, bid_amount: String(amount) }].sort(
              (a, b) => Number(a.bid_amount) - Number(b.bid_amount),
            ),
          };
        }),
        // Design note #271: a second bidder on a private that is ALREADY the
        // lowest offer contests it on the spot -- there is no later moment
        // for it to be promoted into, so without this the one private a
        // player can always reach could never open a mini-auction.
        mini_auction:
          waterfall.mini_auction ??
          (() => {
            const bidOn = waterfall.privates.find((e) => e.private_id === private_id);
            if (!bidOn?.is_lowest_offered) return null;
            const others = bidOn.bids.filter((bid) => bid.bidder !== actor);
            return openMiniAuction({
              ...bidOn,
              bids: [...others, { bidder: actor, bid_amount: String(amount) }],
            });
          })(),
        current_turn: nextSeat(players, waterfall.current_turn),
        consecutive_waterfall_passes: 0,
      },
      // A waterfall bid is ESCROWED rather than spent, and the escrow badge
      // the dashboard already renders reads the bid list -- so no cash moves
      // here. Charging on the bid and refunding on a loss would be this file
      // modelling a rule it has no business owning.
      charges: [],
      won: [],
      allPassed: false,
      markdown: null,
    };
  }

  if ("WaterfallPass" in msg) {
    const passes = waterfall.consecutive_waterfall_passes + 1;
    const wholeTablePassed = players.length > 0 && passes >= players.length;

    /* ==================================================================
        DESIGN NOTE 1580: BOTH HALVES OF THE ALL-PASS BELONG TO THE SCHUYLKILL VALLEY (Batch 7.3, audit C5)
       ==================================================================
       #271 wrote this as "a full round of passes marks the cheapest private down $5", and the rulebook says
       something narrower twice. §1.2.3: "If all players pass and the Schuylkill Valley is UNSOLD, reduce its
       price by $5" -- the SV by name, not whichever card happens to be cheapest. And, separately: "If all
       players pass and the Schuylkill Valley HAS been sold, each of the private companies already bought pays
       revenue. Then the buy-bid-turn sequence resumes."

       TWO RULES, ONE TRIGGER, AND THE ENGINE RAN BOTH EVERY TIME. It marked down whatever was lowest -- the
       B&O from $220 to $215 in JUNO-Z6C, the James River & Kanawha from $120 to $115 under the Level Playing
       Field -- and paid private income on every all-pass whether the SV was sold or not.

       SO THE TWO CONDITIONS ARE SEPARATED AND BOTH NAMED. The markdown happens when the private on offer IS
       the SV; the revenue happens when the SV is no longer in the auction at all. In a game those are the two
       faces of one fact (the SV is the cheapest private, so it is on offer for exactly as long as it is
       unsold), and stating them separately is what makes the LPF case right without a variant branch: the JK
       is never the SV, so it is never marked down, and an all-pass while the SV is still unsold pays nobody
       (ruling D-21 / Q8).

       THE $0 BRANCH IS STILL A PURCHASE, not a payout: the SV reaching zero means it is TAKEN by the next
       seat, and it is still unsold at the moment everybody passed -- so no revenue is owed then either. */
    const svStillUnsold = waterfall.privates.some((entry) => entry.private_id === SV_PRIVATE_ID);
    if (wholeTablePassed) {
      const offered = waterfall.privates.find((entry) => entry.is_lowest_offered);
      /* Only the SV marks down. A non-SV private on offer (possible only on a board whose SV has been sold,
         or a fixture that lists no SV) keeps its price, and the all-pass is the REVENUE kind below. */
      const target = offered && offered.private_id === SV_PRIVATE_ID ? offered : null;
      if (target) {
        const marked = Math.max(0, (Number(target.face_value) || 0) - WATERFALL_PASS_MARKDOWN);
        const taker = nextSeat(players, waterfall.current_turn);

        if (marked === 0) {
          // Free, so it goes. The next seat takes it at no cost, which is
          // how the real auction stops a worthless private from blocking
          // every remaining turn.
          const freed = cascade(removePrivate(target.private_id));
          return {
            waterfall: settle({
              ...waterfall,
              privates: freed.privates,
              mini_auction: freed.mini,
              current_turn: nextSeat(players, taker),
              consecutive_waterfall_passes: 0,
            }),
            charges: freed.charges,
            won: [
              { privateId: target.private_id, name: target.name, player: taker, price: 0 },
              ...freed.won,
            ],
            /* Design note #337 reversed by #1580: this branch IS an all-pass, and an all-pass pays private
               income only when the SV has already been SOLD (§1.2.3). Here it manifestly has not -- it is the
               card being marked to zero and taken -- so nobody is paid. #337's reasoning was that the payout
               must not "depend on whether the markdown happened to land on a round number", and that is still
               true: neither markdown branch pays, for the same reason. */
            allPassed: false,
            markdown: {
              privateId: target.private_id,
              name: target.name,
              from: Number(target.face_value) || 0,
              to: 0,
            },
          };
        }

        return {
          waterfall: {
            ...waterfall,
            privates: waterfall.privates.map((entry) =>
              entry.private_id === target.private_id
                ? { ...entry, face_value: String(marked) }
                : entry,
            ),
            current_turn: nextSeat(players, waterfall.current_turn),
            // The streak restarts against the NEW price: the table has not
            // declined this offer, it has never been made one.
            consecutive_waterfall_passes: 0,
          },
          charges: [],
          won: [],
          // #1580: the SV is unsold -- that is what this markdown is -- so no private income is paid.
          allPassed: false,
          markdown: {
            privateId: target.private_id,
            name: target.name,
            from: Number(target.face_value) || 0,
            to: marked,
          },
        };
      }
    }

    /* #1580: the SV has been sold and the table has passed all the way round -- §1.2.3's OTHER all-pass.
       Every private already bought pays its revenue, nothing is marked down, and the buy-bid-turn sequence
       resumes. The streak resets for the same reason the markdown branch resets it: the sequence begins
       again, and the passes that ended it are spent. */
    const revenueAllPass = wholeTablePassed && !svStillUnsold;
    return {
      waterfall: {
        ...waterfall,
        current_turn: nextSeat(players, waterfall.current_turn),
        consecutive_waterfall_passes: revenueAllPass ? 0 : passes,
      },
      charges: [],
      won: [],
      allPassed: revenueAllPass,
      markdown: null,
    };
  }

  if ("WaterfallMiniAuctionRaise" in msg) {
    const mini = waterfall.mini_auction;
    if (!mini) return unchanged;
    const amount = Number(msg.WaterfallMiniAuctionRaise.bid_amount) || 0;
    /* Design note #1581: the $5 increment, asked where the state moves -- #1184's lesson, applied to the
       contest arm it was not applied to. `auctionAuthority.miniRaiseRefusal` states the rule with its
       sentence and the escrow behind it; this is the same arithmetic standing underneath, so a caller that
       reaches this sub-reducer directly (a test, a fixture) cannot raise by a dollar either. */
    if (amount < (Number(mini.high_bid) || 0) + MIN_BID_INCREMENT) return unchanged;
    return {
      waterfall: {
        ...waterfall,
        /* A raise IS a bid, so it goes in priv.bids -- the card renders that list, and a correct leader badge on a stale figure reads exactly like a badge on the wrong player.
           See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #302 */
        privates: waterfall.privates.map((entry) => {
          if (entry.private_id !== mini.private_id) return entry;
          const others = entry.bids.filter((bid) => bid.bidder !== actor);
          return {
            ...entry,
            bids: [...others, { bidder: actor, bid_amount: String(amount) }].sort(
              (a, b) => Number(a.bid_amount) - Number(b.bid_amount),
            ),
          };
        }),
        mini_auction: {
          ...mini,
          high_bid: String(amount),
          high_bidder: actor,
          // Design note #544: on down the queue from the raiser. They are
          // the leader now, so the skip in `nextMiniTurn` is what stops the
          // cursor coming back to them on the lap.
          current_turn: nextMiniTurn(mini.bidders, actor, actor),
          /* Design note #1581: a raise restarts the count. §1.2.2 ends the contest on passes that are
             CONSECUTIVE, so the table has to answer this bid from scratch -- including everybody who had
             already passed against the previous one. */
          passes_since_raise: 0,
        },
      },
      charges: [],
      won: [],
      allPassed: false,
      markdown: null,
    };
  }

  if ("WaterfallMiniAuctionPass" in msg) {
    const mini = waterfall.mini_auction;
    if (!mini) return unchanged;

    /* ==================================================================
        DESIGN NOTE 1581: A PASS IS A COUNT, NOT AN ELIMINATION (Batch 7.3, audit M1)
       ==================================================================
       THIS ARM USED TO REMOVE THE BIDDER AND DELETE HIS BID. Design note #313 argued for deleting the bid --
       "dropping out removes the BID, not just the bidder -- escrow is derived from priv.bids, so the money
       stayed locked for the rest of the auction" -- and that reasoning is sound about ESCROW and wrong about
       the RULE it was attached to: §1.2.2 says a bidder "may pass and still bid later if the auction does not
       end", so there is no dropping out to model. The escrow it was worried about releases anyway, one
       resolution later, when the private leaves `privates`.

       SO THE BIDDER STAYS, HIS BID STAYS, AND THE PASS IS COUNTED. The contest ends when the count reaches
       `bidders.length - 1` -- every bidder except the high bidder, who is never asked (`nextMiniTurn` skips
       him, #544). On a two-bidder contest that is one pass, which is what every contest in the corpus is and
       why their digests do not move.

       THE WINNER IS THE HIGH BIDDER, always, and at his own `high_bid`. The old arm computed
       `remaining[0] ?? high_bidder`, which was the same player only because elimination had removed everyone
       else first. */
    const passes = (mini.passes_since_raise ?? 0) + 1;

    if (passes >= Math.max(1, mini.bidders.length - 1)) {
      const winner = mini.high_bidder;
      const target = waterfall.privates.find((entry) => entry.private_id === mini.private_id);
      const price = Number(mini.high_bid) || 0;
      // Design note #271: resolving one contest can immediately expose
      // another. Design note #336: or settle it outright, if the promoted
      // private carries exactly one bid.
      const resolved = cascade(removePrivate(mini.private_id));
      return {
        waterfall: settle({
          ...waterfall,
          privates: resolved.privates,
          mini_auction: resolved.mini,
          /* A mini-auction does not consume a main turn: the seat already advanced when the contest opened, so advancing again skipped exactly one seat every time. Preserved, not recomputed.
             See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #338 */
          current_turn: waterfall.current_turn,
          consecutive_waterfall_passes: 0,
        }),
        charges: [{ player: winner, amount: price }, ...resolved.charges],
        won: [
          ...(target
            ? [{ privateId: target.private_id, name: target.name, player: winner, price }]
            : []),
          ...resolved.won,
        ],
        allPassed: false,
        markdown: null,
      };
    }

    /* Not resolved: the count stands, every bid stands, and the cursor moves to the next bidder after the
       actor -- skipping the high bidder, as it always has. */
    return {
      waterfall: {
        ...waterfall,
        mini_auction: {
          ...mini,
          current_turn: nextMiniTurn(mini.bidders, mini.high_bidder, actor),
          passes_since_raise: passes,
        },
      },
      charges: [],
      won: [],
      allPassed: false,
      markdown: null,
    };
  }

  return unchanged;
}

/* The Stock Round reducer prices the trade from the chart. A flat $67 for every corporation made the market chart decoration.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
export interface SandboxMarketResult {
  prices: SandboxMarketPrices;
  /** What the trade was priced at, so the caller can charge the same figure
   *  it displayed. `null` for a message that moves no money. */
  tradePrice: number | null;
  /** Where a token moved and WHY, for the log line (#435: three movers, three words).
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
  moved: {
    companyId: number;
    from: number;
    to: number;
    /* Design note #1090: `bloodPrice` is the fourth mover. #435's rule was "three movers, three words" and
       the word matters -- the log line and the tint both branch on it, and folding this into `sale` would
       make a Carcosa transfer report itself as somebody dumping shares. */
    reason: "sale" | "withhold" | "payout" | "bloodPrice";
  } | null;
}

export interface SandboxMarketContext {
  /** projectShareSaleMove injected -- utils/ must not import components/. Takes and returns a CELL, not a price.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
  projectSale?: (from: SandboxMarketMark, blocks: number) => SandboxMarketMark | null;
  /** projectDividendCellMove injected the same way (#291): the ordinary dividend step is the one market move a single message fully determines.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
  projectDividend?: (
    from: SandboxMarketMark,
    choice: "pay" | "withhold",
  ) => SandboxMarketMark | null;
  /** Design note #748a: the sale legality rule, so the CHART refuses what the BOARD refuses.
   *
   *  This atom advances BEFORE the game state (#272/#273), so without it an illegal sale that the reducer
   *  declines still walks the token down. The board and the chart would then disagree permanently, and the
   *  visible symptom is a price drop with no matching change in anybody's holdings -- which reads as a market
   *  bug rather than as a refused action. */
  saleRefused?: (companyId: number, percentage: number) => boolean;
  /** Design note #774: the same split again, for the dividend. This atom advances BEFORE the game state, so
   *  a declaration the reducer refuses would still walk the token left -- which IS the reported symptom, a
   *  price that moved further than anything on the board accounts for. One refusal, asked by both. */
  dividendRefused?: (companyId: number) => boolean;
  /** ==================================================================
   *   DESIGN NOTE 1090: THE BLOOD PRICE, INJECTED LIKE EVERY OTHER MOVE
   *  ==================================================================
   *
   * TWO CALLBACKS, FOR THE SAME REASON THE SALE HAS TWO. `projectBloodPrice` is the geometry, injected
   * because `utils/` must not import `components/` (#273); `isCarcosanSale` is the legality, injected because
   * this atom advances BEFORE the game state (#272/#273) and would otherwise walk a token for an ordinary
   * train sale that happened to name the right model.
   *
   * #748a AND #774 ARE THE SAME LESSON TWICE and this is the third: "the board and the chart would then
   * disagree permanently, and the visible symptom is a price drop with no matching change in anybody's
   * holdings -- which reads as a market bug rather than as a refused action." A Blood Price charged on a
   * non-Carcosan sale would be exactly that, and charged on a trade the seller had no warning about. */
  projectBloodPrice?: (from: SandboxMarketMark) => SandboxMarketMark | null;
  isCarcosanSale?: (sellerId: number, modelType: string) => boolean;
}

/** The chart facts Batch 7.2's stock authority reads, assembled from what this reducer was handed.
 *
 *  THE ZONE COMES FROM THE INJECTION AND FROM NOWHERE ELSE, and that is deliberate rather than lazy. #712's
 *  rule is that an absent `marketZoneFor` means the zone rules are NOT asked -- "a caller with no chart cannot
 *  tell a Normal price from an Orange one, and guessing would either forbid a legal purchase or wave an
 *  illegal one through" -- so deriving one here from `market_positions` would quietly make every chartless
 *  fixture stricter than the board it was written against. The PRICE is the opposite case: it is read off
 *  `market_positions` (#1196), because that is the authoritative position and a purchase priced from anything
 *  else is what S7-13 was.
 *
 *  `nominalPrice` is the chartless board's last resort, exactly the figure the arms charged before this
 *  batch (`ctx.sharePrice`, else the nominal), so a fixture with no positions prices as it always did. */
function stockChartContext(
  state: GameStateResponse,
  ctx?: SandboxActionContext,
): StockChartContext {
  const fromState = chartContextFromState(state);
  return {
    parCellFor: ctx?.parCellFor ?? fromState.parCellFor,
    marketZoneFor: ctx?.marketZoneFor,
    marketPricesByCompany: ctx?.marketPricesByCompany ?? null,
    zoneForPrice: ctx?.zoneForPrice,
    priceFor: fromState.priceFor,
    pinnedBoard: fromState.pinnedBoard,
    nominalPrice: ctx?.sharePrice ?? SANDBOX_NOMINAL_SHARE_PRICE,
  };
}

export function applySandboxMarketAction(
  prices: SandboxMarketPrices,
  msg: GameplayExecuteMsg,
  ctx?: SandboxMarketContext,
): SandboxMarketResult {
  const unchanged: SandboxMarketResult = { prices, tradePrice: null, moved: null };

  /** Falls back to the nominal for a corporation with no position, which keeps a buy from being free rather than claiming to model par.
   *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
  const priceOf = (companyId: number): number =>
    prices[companyId]?.price ?? SANDBOX_NOMINAL_SHARE_PRICE;

  if ("BuyStock" in msg) {
    // Buying does not move the token in 1830 -- only selling, dividends and
    // the sold-out check do. So this prices the trade and leaves the chart
    // alone, which is a real rule rather than an omission.
    return { prices, tradePrice: priceOf(msg.BuyStock.protocol_id), moved: null };
  }

  /* ==================================================================
      DESIGN NOTE 1090: THE ONLY MARKET MOVE A TRAIN CAN CAUSE
     ==================================================================
     RULED: "Upon successful transfer, execute the Left 1, Down 1 market movement for the selling
     corporation."
     GATED ON THE SELLER'S MARK, not on the model: two corporations may both hold a 5-train and only one of
     them holds THE 5-train. `isCarcosanSale` asks the game state, which still carries the flag at this point
     because this atom runs before the reducer clears it.
     THE SELLER MOVES, NOT THE BUYER. The toll is for letting the thing go.
     A MOVE THAT LANDS WHERE IT STARTED IS NOT A MOVE. At the chart's bottom-left corner both steps clamp,
     and reporting `from === to` would print "its share price fell from $X to $X". */
  if ("BuyTrainFromCorporation" in msg) {
    const { seller_protocol_id, model_type } = msg.BuyTrainFromCorporation;
    if (ctx?.isCarcosanSale?.(seller_protocol_id, model_type) !== true) return unchanged;
    const mark = prices[seller_protocol_id] ?? null;
    if (mark === null || !ctx?.projectBloodPrice) return unchanged;
    const landed = ctx.projectBloodPrice(mark);
    if (!landed || (landed.x === mark.x && landed.y === mark.y)) return unchanged;
    return {
      prices: { ...prices, [seller_protocol_id]: landed },
      tradePrice: null,
      moved: {
        companyId: seller_protocol_id,
        from: mark.price,
        to: landed.price,
        reason: "bloodPrice",
      },
    };
  }

  if ("SellStock" in msg) {
    const { protocol_id, percentage } = msg.SellStock;
    // Design note #748a: a sale the reducer will decline moves no token either.
    if (ctx?.saleRefused?.(protocol_id, percentage) === true) return unchanged;
    const blocks = Math.max(1, Math.round(percentage / SANDBOX_SHARE_PERCENTAGE));
    const mark = prices[protocol_id] ?? null;
    const proceeds = priceOf(protocol_id) * blocks;

    if (mark === null || !ctx?.projectSale) {
      return { prices, tradePrice: proceeds, moved: null };
    }
    // Walked from the CELL, not from the price -- design note #272. Two
    // cells share a price on this chart and stepping down from the wrong
    // one lands somewhere the marker never was.
    const landed = ctx.projectSale(mark, blocks);
    if (!landed || (landed.x === mark.x && landed.y === mark.y)) {
      return { prices, tradePrice: proceeds, moved: null };
    }
    return {
      // Design note #646: every landing is stamped with its arrival, so a
      // tie on the new cell resolves by who reached it first.
      prices: { ...prices, [protocol_id]: withArrival(prices, protocol_id, landed) },
      // Priced at the price BEFORE the drop: the seller is paid what the
      // share was worth when they sold it, and the fall is the consequence.
      tradePrice: proceeds,
      moved: { companyId: protocol_id, from: mark.price, to: landed.price, reason: "sale" },
    };
  }

  if ("DeclareDividends" in msg) {
    /* Design note #291: RIGHT on a payout, LEFT on a withhold. The cash is
       still `applySandboxAction`'s -- this owns only the marker, which is
       the same split every other arm here follows. */
    const { protocol_id, distribute } = msg.DeclareDividends;
    // Design note #774: a declaration the reducer will decline moves no token either.
    if (ctx?.dividendRefused?.(protocol_id) === true) return unchanged;
    const mark = prices[protocol_id] ?? null;
    if (mark === null || !ctx?.projectDividend) return unchanged;
    const landed = ctx.projectDividend(mark, distribute ? "pay" : "withhold");
    if (!landed || (landed.x === mark.x && landed.y === mark.y)) return unchanged;
    return {
      // Design note #646: likewise -- a dividend move is an arrival.
      prices: { ...prices, [protocol_id]: withArrival(prices, protocol_id, landed) },
      tradePrice: null,
      /* The reason travels with the move; the shell used to log every marker move as "on the sale".
         See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273 */
      moved: {
        companyId: protocol_id,
        from: mark.price,
        to: landed.price,
        reason: distribute ? "payout" : "withhold",
      },
    };
  }

  return unchanged;
}

/* settleRoundTransitions -- the round machine belongs to the reducer. The shell used to perform transitions, so a replay rebuilt corporations correctly and left the round wherever the last live dispatch had put it.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #642 */
export function applySandboxAction(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
): GameStateResponse {
  /* Design note #1300: THE BOARD COMES FROM THE STATE, and it is put in effect here -- the one entry every
     consumer (shell, replay engine, server) goes through -- so no caller can run an arm against the wrong
     board. `SetupGame` is the exception that proves it: the state has no variants until that arm writes
     them, so the deal is judged on the board the message names. */
  const variants = isSetupGameMsg(msg) ? msg.SetupGame.variants : state.variants;
  return withRules(resolveVariants(variants), () => applySandboxActionOnBoard(state, msg, ctx));
}

/* ==================================================================
    DESIGN NOTE 1340: THE REDUCER IS ATOMIC -- THE AUCTION'S CONSEQUENCES SETTLE INSIDE IT
   ==================================================================
   RULED: "refactor `applySandboxAction` to be a 100% self-contained, atomic state machine ... A single action
   dispatched to the reducer must compute the entire state transition before returning."

   WHAT WAS OUTSIDE. `applySandboxWaterfallAction` returned `{waterfall, charges, won, allPassed, markdown}`
   and two composition layers applied them: `App.tsx` (#261, #303, #334a, #337, #576) and `RoomEngine`
   (#1192, #1227, #1281). Each was a transcription of the other, and each was found short at least once --
   #1192 (the engine applied no charges), #1227 (never re-seated), #1281 (never paid the all-pass). "Every
   consumer must remember" is the property #1197 deleted for the chart; this deletes it for the auction.

   SO THE ATOM RIDES ON THE STATE (`state.waterfall`, #1196's shape) and `applyAuctionStep` below does, in
   the order `App.tsx` established: advance the atom; charge every listed player (#334a: a cascade charges
   the lone bidder, not the actor); write each winner as owner and record the settled price (#303); grant the
   C&A's free PRR share (#576); pay the all-pass private income AFTER the wins (#1281: the $0 branch hands the
   private on within the same all-pass, and the new owner is owed). Then the chart and the board as before.
   After the board: `OpenStockRound` closes the atom (#1192a), `SetupGame` re-seats it from the DEALT roster
   and privates (#1227, #1320) and leaves a delayed auction dealt-but-inactive (#905), and an auction the
   round has reached is armed (the shell's #905 condition, brought home).

   GATED ON `state.waterfall !== undefined`, exactly as the chart is on `market_positions`: a state that
   carries no auction gets none of this, so a chain game and every pre-#1340 fixture are untouched.

   THE SUB-REDUCER'S REPORT IS NOW PRIVATE TO THIS FILE. `SandboxWaterfallResult` still exists -- it is how
   the auction arm talks to this function -- but nothing outside reads its flags. Narration (the "Private
   Won" line, the markdown, the payout lines) is derived by the shell from the two states, the way every
   other line has been since #704: "the reducer settles, the shell narrates." */
function applyAuctionStep(state: GameStateResponse, msg: GameplayExecuteMsg): GameStateResponse {
  if (!state.waterfall) return state;
  const result = applySandboxWaterfallAction(state.waterfall, msg, state.player_addresses ?? []);
  let next: GameStateResponse = { ...state, waterfall: result.waterfall };

  /* ==================================================================
      DESIGN NOTE 1560 (auction): THE MONEY PAID FOR A PRIVATE GOES TO THE BANK
     ==================================================================
     This loop was an inline `Math.max(0, cash - amount)` and CREDITED NOBODY. Both halves were wrong and in
     opposite directions: an unaffordable buy minted the difference, and every affordable one destroyed the
     whole price, so the bank was short by the entire auction in every game ever played on this engine and
     broke early because of it (S7-10; the owner's ruling D-15/Q1a). The private auction's counterparty is the
     Bank, like every other purchase in 1830, so the charge is a TRANSFER.

     A $0 acquisition -- the Schuylkill Valley marked down to nothing and taken by the next seat (#271) --
     transfers $0 and is therefore unchanged, which is the point of routing it through the same call.

     ALL OR NOTHING FOR THE WHOLE STEP. A charge the buyer cannot cover refuses the auction message outright
     (the atom does not advance), rather than handing over a private for less than its price. Escrow-aware
     affordability as a RULE, asked before the atom moves, is Batch 7.3 (S7-4); this is the boundary. */
  for (const { player, amount } of result.charges) {
    const paid = transfer(next, { player }, BANK, amount);
    if (!paid.ok) return state;
    next = paid.state;
  }

  for (const { privateId, player, price } of result.won) {
    next = {
      ...next,
      private_companies: next.private_companies.map((entry) =>
        entry.private_id === privateId ? { ...entry, owner: player, settled_price: price } : entry,
      ),
    };
    if (privateId === CA_PRIVATE_ID) {
      const prr = next.public_companies.find((c) => c.ticker === CA_BONUS_TICKER);
      if (prr) {
        next = applyPrivateExchange(next, {
          ok: true,
          privateId,
          companyId: prr.company_id,
          ticker: CA_BONUS_TICKER,
          player,
          source: prr.ipo_pool_percentage >= 10 ? "Ipo" : "Bank",
          keepOpen: true,
        });
      }
    }
  }

  if (result.allPassed) {
    next = applyPrivateRevenue(next)?.state ?? next;
  }
  return next;
}

/** #1340: the auction's lifecycle, after the board has moved -- close, re-seat, arm. */
function settleAuctionLifecycle(state: GameStateResponse, msg: GameplayExecuteMsg): GameStateResponse {
  if (state.waterfall === undefined) return state;
  let waterfall = state.waterfall;
  if (waterfall && isOpenStockRoundMsg(msg) && waterfall.waterfall_auction_active) {
    waterfall = { ...waterfall, waterfall_auction_active: false };
  }
  if (isSetupGameMsg(msg)) {
    const reseated = waterfallForRoster(waterfall, state.player_addresses ?? [], state.private_companies);
    const delayed = (msg.SetupGame.variants as { delayedAuction?: unknown } | undefined)?.delayedAuction === true;
    waterfall = reseated && delayed ? { ...reseated, waterfall_auction_active: false } : reseated;
  }
  /* The delayed variant's auction is dealt inactive and the round reaches it at Stock Round 3 (#905); this is
     the arming. WITH SOMETHING LEFT TO OFFER: an auction `settle` has already closed because its last private
     sold stays closed while `OpenStockRound` is still owed -- the engine's own reading, kept so a stored log
     replays to the same atom it always did. */
  if (
    waterfall &&
    !waterfall.waterfall_auction_active &&
    waterfall.privates.length > 0 &&
    state.current_round_type === "WaterfallAuction" &&
    state.private_auction_complete !== true
  ) {
    waterfall = { ...waterfall, waterfall_auction_active: true };
  }
  return waterfall === state.waterfall ? state : { ...state, waterfall };
}

function applySandboxActionOnBoard(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
): GameStateResponse {
  /* ==================================================================
      DESIGN NOTE 1580: THE AUCTION IS JUDGED HERE, AND HERE IS HIGHER THAN THE OTHER GATES (Batch 7.3)
     ==================================================================
     Batches 7.2's stock gates live in `applySandboxActionCore`, on #1019's rule -- ahead of every settle
     stage. THE AUCTION NEEDS ONE LAYER HIGHER, because #1340 put the auction atom in front of the board:
     `applyAuctionStep` charges the buyer and writes the winner BEFORE `applySandboxActionAfterAuction` runs,
     and the board arm then advances the seat (`applyOneAction`'s `WaterfallPass` -> `recordPass`,
     `WaterfallBuyLowest` -> `advanceSeat`). A refusal asked in the core would therefore arrive after the
     money had moved, or -- when the 7.1 ledger declined the charge and `applyAuctionStep` returned the board
     it was handed -- would leave the seat advanced for a purchase that did not happen. Both are the partial
     application #1019 and #757 are about, one atom further up.

     SO THE WHOLE MESSAGE IS REFUSED, BY IDENTITY, before either atom sees it: no auction state, no cash, no
     ownership, no priority deal, no pass streak, no seat. `settleAuctionLifecycle` does not run either, which
     is correct -- it arms and closes the atom, and a message that did not happen cannot have closed it.

     THE PREDICATE IS `auctionAuthority`'s, the same one ingress asks (`turnRefusal`), and the actor it judges
     is the atom's own cursor -- the player `applySandboxWaterfallAction` would have applied the action as. */
  if (isAuctionMessage(msg) && auctionRefusal(state, state.waterfall ?? null, msg) !== null) {
    return state;
  }
  // #1340: the auction first, as `App.tsx` always ran it -- its charges land before the board is judged.
  const afterAuction = applyAuctionStep(state, msg);
  return settleAuctionLifecycle(applySandboxActionAfterAuction(afterAuction, msg, ctx), msg);
}

function applySandboxActionAfterAuction(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
): GameStateResponse {
  /* ==================================================================
      DESIGN NOTE 1197: THE CHART STEP COMES INSIDE, SO NO CALLER CAN FORGET IT
     ==================================================================
     INCREMENT 2 OF PHASE 1. #1196 put the chart's POSITIONS on the state; this puts the MOVE that produces
     them inside the reducer, which is the half that stops a caller being able to get it wrong.
     AND A CALLER DID GET IT WRONG, twice, in one afternoon. The replay harness omitted `reconcileParMarks`
     (#1193) and then wrote its own `marketContext` from the shape of the types rather than transcribing the
     shell's (#1194) -- and each omission silently rearranged the operating order, because the chart moved
     differently from the board. Every consumer of this reducer has to perform the same two-atom dance in the
     same order (#272/#273: the chart advances FIRST, because the board needs the price it reports), and
     "every consumer must remember" is the property this migration exists to delete.
     GATED ON `market_positions`, exactly as #1196's read is. A caller carrying no positions keeps the old
     arrangement untouched -- which is `App.tsx` until increment 3, still driving the atom itself. A caller
     that carries them hands the whole job here and stops calling `applySandboxMarketAction` at all.
     THE REFUSALS ARE NO LONGER INJECTED. #748a and #774 asked the shell to hand in `dividendRefused` and
     `saleRefused` so the chart could refuse whatever the board refuses; in here the reducer holds the state
     those predicates read, so it simply asks them. Two fewer injections, and the specific gap that cost
     #1194 a day cannot be reopened.
     `tradePrice` IS USED DIRECTLY rather than travelling back through `ctx.sharePrice`, so the wallet and
     the chart cannot be handed two different figures for one trade (#273's whole point). */
  if (state.market_positions) {
    const priced = applySandboxMarketAction(state.market_positions, msg, {
      ...ctx?.marketContext,
      dividendRefused: (companyId: number) => dividendRefused(state, companyId),
      /* ==================================================================
          DESIGN NOTE 1570: THE CHART ASKS THE SAME PREDICATE THE CORE WILL (Batch 7.2)
         ==================================================================
         #748a's rule, and the one part of Batch 7.2 that needed care. The chart atom advances BEFORE the
         board (#272/#273), so a sale the core is about to refuse must be refused HERE by the SAME function,
         or the token drops one row per certificate for a sale that never happened -- and "a price drop with
         no matching change in anybody's holdings ... reads as a market bug rather than as a refused action".
         It was `shareSaleBlock` plus the Batch-5 forced-sale rules; it is now `stockSaleRefusal`, which
         contains both of those unchanged and adds the round gate, the first-Stock-Round ban, the unparred
         corporation and the whole-certificate bundle. One predicate, three askers, no drift. */
      saleRefused: (companyId: number, percentage: number) => {
        const seller = ctx?.actor ?? null;
        if (!seller) return false;
        return (
          stockSaleRefusal({
            state,
            sell: { companyId, percentage },
            actor: seller,
            mapGrid: ctx?.mapGrid,
            ctx: stockChartContext(state, ctx),
          }) !== null
        );
      },
    });
    const settled: GameStateResponse = { ...state, market_positions: priced.prices };
    return applySandboxActionInner(
      settled,
      msg,
      priced.tradePrice === null
        ? ctx
        : { ...ctx, sharePrice: priced.tradePrice },
      /* #1193: a par set BY this action lands a token the NEXT queue must see, so the reconcile runs after
         the board settles -- the same order `App.tsx` runs it in. */
      ctx?.parCellFor,
    );
  }

  return applySandboxActionInner(state, msg, ctx);
}

function applySandboxActionInner(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
  parCellFor?: (parPrice: number) => { x: number; y: number } | null,
): GameStateResponse {
  const settledBoard = applySandboxActionCore(state, msg, ctx);
  if (!settledBoard.market_positions) return settledBoard;

  /* ==================================================================
      DESIGN NOTE 746b, ANSWERED: THE RISE IS COMMITTED HERE NOW
     ==================================================================
     #746b's own sentence was the reason it lived in the shell: "the reducer has already USED these rises --
     #746a overlays them so the operating queue sorts on post-rise prices -- but THE MARKET ATOM IS NOT PART
     OF `GameStateResponse`, so the tokens themselves still have to be moved here."
     THAT PREMISE STOPPED BEING TRUE AT #1196. The positions are on the state, so the half of this rule that
     was stranded in `App.tsx` comes home to sit beside the half that was always here -- and the two can no
     longer disagree about a price, which is the whole shape of §5a.
     AFTER THE BOARD SETTLES, exactly as #746b explains and for its reason: a dividend or a sale is a move the
     MESSAGE determines, so the state needs the price it produced; a rise is a move the RESULTING BOARD
     determines -- who is sold out, and whether the round just closed -- and neither fact exists until the
     reducer has run.
     THE SAME `soldOutRises` CALL, with the marks read off the state rather than through an injected resolver.
     Transcribed, not reimplemented: #1194 is what happens when this file writes its own version of something
     `App.tsx` already does. */
  const risen = ctx?.projectRise
    ? soldOutRises({
        before: state,
        after: settledBoard,
        markFor: (companyId) => settledBoard.market_positions?.[companyId] ?? null,
        projectRise: ctx.projectRise,
      })
    : [];

  let positions = settledBoard.market_positions;
  for (const rise of risen) {
    // #646: a rise is an arrival like any other, so it is stamped like one.
    positions = {
      ...positions,
      [rise.companyId]: withArrival(positions, rise.companyId, {
        price: rise.to,
        x: rise.x,
        y: rise.y,
      }),
    };
  }

  if (parCellFor) {
    positions = reconcileParMarks(positions, settledBoard.public_companies, parCellFor);
  }

  return positions === settledBoard.market_positions
    ? settledBoard
    : { ...settledBoard, market_positions: positions };
}

/* ==================================================================
    DESIGN NOTE 1596: A REFUSED SETTLEMENT RETIRES THE OFFER IT WAS SETTLING -- THE ONE DELIBERATE MUTATION
   ==================================================================
   Batch 7.4. An accepted ordinary offer is a purchase the board OWES (#1247): `nextDerivedAction` derives the
   `BuyPrivateCompany` / `BuyTrainFromCorporation` from the `accepted` flag, and the purchase arm retires the
   offer it settles. When the settlement is REFUSED -- by any gate in the core, on a board that went stale
   between acceptance and settlement -- the arm never runs, the refusal returns the board by identity, and the
   offer would stay accepted: owed again by every rebuild, re-derived once per server lifetime, and holding
   the whole table under #1590's freeze with no way out but `RevertTo`.

   SO THIS IS THE ONE PLACE A REFUSAL MUTATES, AND IT MUTATES EXACTLY ONE FIELD. When the core hands back the
   state it was given for a message that is the settlement of the standing accepted offer -- same private /
   buyer / price, or same seller / buyer / model / price -- the offer is cleared and nothing else moves: no
   money, no ownership, no train, no treasury, no cash, no seat, no step, no round, no Stock Round marker.
   #1513 and #1541 already did this inside their own two gates; here it is one rule for every gate, which is
   the only way "a refused accepted settlement cannot become permanently re-owed" can be true of gates added
   later. Every other refusal in this function is a true no-op: `applySandboxActionCore` returns the state it
   was handed, which is what `actionWasRefused` (#778) and the atomicity harnesses detect.

   NOT for the funding offer: its settlement is its own answer arm (#1541) and its refusal leaves the offer
   standing for a rescind, by design. `standing` below reads only the ordinary offers. */
function retireRefusedSettlement(state: GameStateResponse, msg: GameplayExecuteMsg): GameStateResponse {
  if ("BuyPrivateCompany" in msg) {
    const offer = state.private_purchase_offer ?? null;
    if (offer !== null && offer.funding !== true && offer.accepted === true && privateSettlementMatches(offer, msg.BuyPrivateCompany)) {
      return { ...state, private_purchase_offer: null };
    }
  }
  if ("BuyTrainFromCorporation" in msg) {
    const offer = state.train_purchase_offer ?? null;
    if (offer !== null && offer.accepted === true && trainSettlementMatches(offer, msg.BuyTrainFromCorporation)) {
      return { ...state, train_purchase_offer: null };
    }
  }
  return state;
}

function applySandboxActionCore(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
): GameStateResponse {
  const judged = applySandboxActionCoreJudged(state, msg, ctx);
  // #1596: a refusal (identity) of the settlement an accepted offer owes retires that offer, and only that.
  return judged === state ? retireRefusedSettlement(state, msg) : judged;
}

function applySandboxActionCoreJudged(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
): GameStateResponse {
  /* ==================================================================
   *  DESIGN NOTE 757: THE LAY HAD NO AUTHORITY EITHER
   * ==================================================================
   *
   * #756 closed the button on a rotation that crosses an impassable border, and I said at the time that it
   * closed the button and not the door: the reducer applied whatever `LayTile` it was handed. This is the
   * door.
   *
   * IT IS THE SAME GAP #748 FOUND ON THE SELL SIDE, and the same one #712 had already closed for buys. Every
   * placement rule in this game -- the colour step, centre preservation, path preservation, the board's rim,
   * the four barriers -- lived in a filter that decides which chips the radial selector OFFERS. A message
   * built by hand, replayed from a stale tab, or dispatched by any second control written later went
   * straight through.
   *
   * GATED HERE RATHER THAN IN THE ARM, because a lay touches three things: the terrain fee in `applyOneAction`,
   * the sub-phase cursor in `settleOperatingCursor`, and the tile grid, which is a separate atom the shell
   * owns. Refusing in the arm alone would have charged the fee and advanced the step for a tile that was
   * never placed -- the cross-atom split #748a had to solve for the market chart, arriving again.
   *
   * THE SHELL APPLIES THE SAME PREDICATE TO THE GRID, so one answer governs all three.
   *
   * CONNECTIVITY IS DELIBERATELY NOT PART OF IT, and this is the interesting scope decision. The D&H and the
   * C&SL both lay track that legally ignores network connectivity (#725/#726), and this message carries no
   * indication of which power is in play -- so a reducer that enforced connectivity would refuse two real
   * abilities. What it enforces is the set of rules that are facts about the BOARD rather than about whose
   * turn it is, which is exactly the set a hand-built message could otherwise abuse.
   *
   * A REFUSAL RETURNS THE STATE UNCHANGED, on #712's reasoning: a replay must not halt on an entry the log
   * already contains. */
  /* ==================================================================
      DESIGN NOTE 1510/1511: WHO IS ACTING, AND WHERE THE TOKEN MAY GO -- ASKED BEFORE ANY ARM RUNS
     ==================================================================
     THE IDENTITY GATE FIRST, for every message that names the corporation it acts for at an Operating Turn
     (`LayTile`, `PlaceStationToken`, `RunMultipleRoutes`, and the legacy `RunManualRoute`). The arms below
     took `protocol_id` off the message and charged whichever treasury it named -- the "protocol_id comes off
     the message, not the queue cursor" comment above them was a description, not a rule. #1182 restored this
     comparison once and withdrew it while the operating order was chart-derived; #1196/#1197 made the order
     a function of the log and #1205 gave it one judge, so the objection has expired (`operatingIdentity.ts`).
     THEN THE STATION GATE, for #1019's reason and #757's: a refusal inside the arm still lets
     `settleOperatingCursor` move the step to Routes for a token that never landed. Asked here, the state
     comes back by identity, which is what `actionWasRefused` (#778) detects and what the replay needs
     (#712: an entry the log already holds must no-op, never halt).
     THE LAY'S OWN LEGALITY IS UNCHANGED: `layRefused` below still judges the tile, and nothing about track
     rules moves in this note. */
  /* ==================================================================
      DESIGN NOTE 1530: WHILE A DISCARD IS OWED, NOTHING ELSE HAPPENS -- ASKED FIRST
     ==================================================================
     Rulebook 6.6.1: the president chooses the train to discard; 2.0: the limit is in force the moment the
     phase-changing train is bought. Between those two moments the board is not a board any rule was written
     against -- a corporation holds more trains than it may -- so every message but the discard itself (and
     the room's `CloseRoom`) is refused by identity here, ahead of the identity and obligation gates below,
     which read a cursor that is not the authority while a discard is owed. ONE gate, not one per arm: the
     Operating sub-phase, the turn's end, another corporation's move, a stock or auction action, a purchase --
     all are "anything else". `RevertTo` is resolved on the log and never reaches this function (#1026).
     The discard's own legality -- the right corporation, its president, a train it owns -- is the next line. */
  if (pendingDiscardBlock(state, msg) !== null) return state;
  if ("DiscardTrain" in msg) {
    const { protocol_id, model_type } = msg.DiscardTrain;
    if (discardTrainRefusal(state, { protocol_id, model_type }, ctx?.actor) !== null) return state;
  }
  /* ==================================================================
      DESIGN NOTE 1540: WHILE THE TRAIN MUST BE FUNDED, NOTHING ELSE HAPPENS -- AND AFTER THE END, NOTHING
     ==================================================================
     Rulebook 6.6.2/6.6.3/6.7 (`emergencyFunding.ts`). Asked here, ahead of every arm: a held message is
     refused by identity; the president's forced `SellStock` is judged by 6.6.3's three rules on top of the
     ordinary ones; the `EmergencyBuyHardware` is refused until treasury and cash cover the price, and
     refused outright when no forced purchase is owed (the president's money is only ever spent on one).
     After `GameEnd` only `CloseRoom` passes. */
  if (emergencyFundingBlock(state, msg, ctx?.mapGrid) !== null) return state;
  if ("SellStock" in msg && ctx?.actor) {
    const funding = emergencyFundingFor(state, ctx.mapGrid);
    if (funding !== null) {
      const { protocol_id, percentage } = msg.SellStock;
      if (forcedSaleRefusal(state, funding, ctx.actor, protocol_id, Math.round(percentage)) !== null) return state;
    }
  }
  if ("EmergencyBuyHardware" in msg) {
    if (emergencyPurchaseRefusal(state, msg.EmergencyBuyHardware.protocol_id, ctx?.mapGrid, ctx?.actor) !== null) {
      return state;
    }
  }
  /* #1541: the emergency private sale and the declaration -- each judged against the standing obligation. */
  if ("OfferPrivateForFunding" in msg) {
    const funding = emergencyFundingFor(state, ctx?.mapGrid);
    if (funding === null || fundingPrivateOfferRefusal(state, funding, msg.OfferPrivateForFunding, ctx?.actor) !== null) {
      return state;
    }
  }
  if ("AnswerFundingPrivateOffer" in msg && fundingPrivateAnswerRefusal(state, msg.AnswerFundingPrivateOffer, ctx?.actor, ctx?.mapGrid) !== null) {
    return state; // an acceptance is re-validated in full at settlement (#1541)
  }
  if ("RescindFundingPrivateOffer" in msg && fundingPrivateRescindRefusal(state, msg.RescindFundingPrivateOffer, ctx?.actor) !== null) {
    return state;
  }
  /* ==================================================================
      DESIGN NOTE 1590: WHILE AN ORDINARY OFFER STANDS, NOTHING ELSE HAPPENS (Batch 7.4)
     ==================================================================
     The third hold, after the discard's and the funding's -- so a board under one of those reports THAT
     reason -- and ahead of every arm, on the #1530/#1540 rule: a held message is refused by identity. One
     ordinary bilateral offer at a time (a corporation's for a private, a corporation's for a train, or a
     player's trade of a private, ruled Q6); while it stands, awaiting its answer or accepted and awaiting its
     derived settlement, only that answer, that rescission, that settlement, `RevertTo` and `CloseRoom` pass.
     The Batch-5 funding offer keeps its own freeze above; `pendingOfferBlock` never reads it.
     THE CHAIN-ERA OFFER MESSAGES (`AcceptTrainOffer` / `RejectTrainOffer` / `RescindTrainOffer`, an
     `offer_id` register the sandbox never had) are refused on a pinned board first (ruled Q11 / D-23); a
     legacy board keeps the no-op arm it was played on (D-9). */
  if (legacyOfferMessageRefusal(state, msg) !== null) return state;
  if (pendingOfferBlock(state, msg) !== null) return state;
  /* ==================================================================
      DESIGN NOTE 1595: THE OFFER MESSAGES ARE JUDGED AGAINST THE BOARD, NOT THE PAYLOAD (Batch 7.4, S7-11)
     ==================================================================
     Each proposal runs the transaction's own predicate (`privatePurchaseRefusal`, `trainSaleRefusal`,
     `privateTradeRefusal`) on the current board; each answer re-derives WHO may answer from the board (the
     private's current owner, the seller's current president, the trade's other party) and, on a yes,
     re-runs the predicate; each rescission belongs to the current proposer. The payload's `owner` and
     `seller_president` are narration from here on. Refused by identity, for #1019's reason. */
  if (isProposePrivatePurchaseMsg(msg)) {
    if (proposePrivatePurchaseRefusal(state, msg.ProposePrivatePurchase, ctx?.actor) !== null) return state;
  }
  if (isAnswerPrivatePurchaseMsg(msg)) {
    if (answerPrivatePurchaseRefusal(state, msg.AnswerPrivatePurchase, ctx?.actor) !== null) return state;
  }
  if (isRescindPrivatePurchaseMsg(msg)) {
    if (rescindPrivatePurchaseRefusal(state, msg.RescindPrivatePurchase, ctx?.actor) !== null) return state;
  }
  if (isProposeTrainPurchaseMsg(msg)) {
    if (proposeTrainPurchaseRefusal(state, msg.ProposeTrainPurchase, ctx?.actor, ctx?.mapGrid) !== null) return state;
  }
  if (isAnswerTrainPurchaseMsg(msg)) {
    if (answerTrainPurchaseRefusal(state, msg.AnswerTrainPurchase, ctx?.actor, ctx?.mapGrid) !== null) return state;
  }
  if (isRescindTrainPurchaseMsg(msg)) {
    if (rescindTrainPurchaseRefusal(state, msg.RescindTrainPurchase, ctx?.actor) !== null) return state;
  }
  if (isProposePrivateTradeMsg(msg)) {
    if (proposePrivateTradeRefusal(state, msg.ProposePrivateTrade, ctx?.actor) !== null) return state;
  }
  if (isAnswerPrivateTradeMsg(msg)) {
    if (answerPrivateTradeRefusal(state, msg.AnswerPrivateTrade, ctx?.actor) !== null) return state;
  }
  if (isRescindPrivateTradeMsg(msg)) {
    if (rescindPrivateTradeRefusal(state, msg.RescindPrivateTrade, ctx?.actor) !== null) return state;
  }
  if ("DeclareBankruptcy" in msg) {
    /* Without a grid the obligation cannot be judged (#757): the declaration is refused rather than admitted
       on a guess -- fail closed, because it ends the game. */
    const funding = ctx?.mapGrid === undefined ? null : emergencyFundingFor(state, ctx.mapGrid);
    if (declareBankruptcyRefusal(funding, ctx?.actor) !== null) return state;
  }
  if (operatingIdentityRefusal(state, msg) !== null) return state;
  /* Design note #1513: THE TURN DOES NOT END WHILE A TRAIN IS OWED. `PassTurn` and `AdvanceOperatingSubPhase`
     at the Buy Trains step are refused for a corporation with no train, a legal route, and a train for sale
     (rulebook 6.6.2). Every message that could discharge the obligation passes. The grid is what the route
     walk needs; without one (a fixture) the gate has no opinion, on #757's rule. */
  if (trainObligationRefusal(state, msg, ctx?.mapGrid) !== null) return state;
  if ("PlaceStationToken" in msg) {
    if (stationPlacementRefusal(state, msg.PlaceStationToken, ctx?.mapGrid) !== null) return state;
  }

  if ("LayTile" in msg && ctx?.layRefused) {
    const { q, r, tile_id, orientation } = msg.LayTile;
    if (ctx.layRefused(q, r, tile_id, orientation)) return state;
  }

  /* Design note #774: ONE CORPORATION, ONE DIVIDEND DECLARATION, AT THE STEP THAT OWNS THE CHOICE.
     Reported as a share price that "moved two cells left rather than one" after a trainless first Operating
     Round. Two cells is two messages: the forced $0 withhold is dispatched by an effect gated on shared
     state and not on whose turn it is, so every seated browser appended its own copy.
     THE PER-CLIENT GUARD CANNOT SEE THE OTHER CLIENT. `forcedWithholdRef` is a `Set` in one tab; the
     property it is trying to enforce belongs to a shared append-only log. So the rule lives here, where a
     duplicate from ANY source -- a second browser, a stale tab, a hand-built message -- meets the same
     answer. `settleOperatingCursor` has already moved the cursor off Dividends by the time the second one
     arrives, so the check is the ordinary rule rather than a duplicate-detector.
     UNCHANGED ON REFUSAL, on #712's reasoning: a replay must not halt on an entry the log already contains. */
  if ("DeclareDividends" in msg) {
    if (dividendRefusal(state, msg.DeclareDividends.protocol_id) !== null) return state;
  }

  /* ==================================================================
     DESIGN NOTE 1019: AND THE PURCHASE IS GATED HERE, FOR #757'S REASON
     ==================================================================
     THE FIRST DRAFT OF THIS FIX PUT THE GATE INSIDE `buyDepotTrain` AND IT WAS NOT ENOUGH. That function is
     reached from `applyOneAction`, which is only the first of five stages -- `settleRoundTransitions`,
     `settleEra`, `settleBaoPrivate` and `settleOperatingCursor` all run afterwards on whatever it returns. So
     a purchase refused down there left the treasury and the fleet correctly untouched and STILL ADVANCED THE
     CURSOR, because the shell had no way to know the arm had declined.

     #757 SAYS THIS IN ADVANCE, four paragraphs up, about the tile lay: "Refusing in the arm alone would have
     charged the fee and advanced the step for a tile that was never placed." The same sentence with two nouns
     changed, and the harness for this batch caught it by asserting object IDENTITY rather than the two fields
     everybody thinks to check.

     WHICH IS ALSO THE MISSING HALF OF THE REPORT. The log shows OR 9.1 becoming OR 9.2 immediately after the
     bogus purchase: that is `settleOperatingCursor` ending a turn on the strength of an action that never
     happened, and it is what left the cursor pointing away from NNH when the player's withhold arrived. The
     dividend refusal was a symptom of this line being absent, not a bug of its own.

     THE FUNDS CHECK IS WAIVED FOR THE EMERGENCY MESSAGE, and only that check: `EmergencyBuyHardware` reads a
     shortfall from a treasury it has not funded yet, so asking about funds here -- before its own arm tops
     the treasury up -- would refuse the one flow built for exactly this situation. */
  /* Design note #1314: a purchase that names a returned model is gated by that model's own gate, here, for
     the same identity reason as the exchange below. */
  if ("BuyHardwareFromPool" in msg && msg.BuyHardwareFromPool.returned_model_type !== undefined) {
    const { protocol_id, returned_model_type } = msg.BuyHardwareFromPool;
    if (returnedTrainRefusal(state, protocol_id, returned_model_type) !== null) return state;
  }
  /* ==================================================================
      DESIGN NOTE 1513: THE FORCED PURCHASE IS GATED HERE, FOR #1019's REASON
     ==================================================================
     A refusal inside the arm comes back as a new object -- the settle chain stamps the era after it -- so
     the two refusals the arm makes (nothing for sale; the president cannot cover the shortfall) are asked
     here first and the state returned by identity. The train it prices is the one the arm will buy:
     `cheapestPurchasableTrain`, depot or pool. */
  if ("EmergencyBuyHardware" in msg) {
    const companyId = msg.EmergencyBuyHardware.protocol_id;
    const cheapest = cheapestPurchasableTrain(state);
    if (!cheapest) return state;
    const limitRow = depotInventory(state).find((row) => row.isCurrent);
    if (
      trainPurchaseRefusal(state, companyId, {
        cost: cheapest.cost,
        trainLimit: limitRow?.trainLimit ?? null,
        requireFunds: false,
      }) !== null
    ) {
      return state;
    }
    const company = state.public_companies.find((entry) => entry.company_id === companyId);
    const shortfall = Math.max(0, cheapest.cost - (Number(company?.treasury) || 0));
    if (shortfall > 0) {
      const presidentCash = Number(
        state.player_cash.find((entry) => entry.player === company?.president)?.cash_vgp ?? 0,
      );
      if (!company?.president || !Number.isFinite(presidentCash) || presidentCash < shortfall) return state;
    }
  }
  /* ==================================================================
      DESIGN NOTE 1592 (core): THE INTERCORPORATE SALE IS JUDGED HERE, FOR #1019's REASON (Batch 7.4)
     ==================================================================
     This was two gates -- #1513's train limit and #1541's D-6 funded-trade rule -- each of which also retired
     a matching accepted offer on refusal so the board would not owe it again (#1247). `trainSaleRefusal`
     contains both, in the same order (D-6 first, exactly where it was), and adds the Operating turn, the
     Purchase Trains step, the seller's ownership, the $1 minimum, the treasury-only rule (ruled Q7) and
     consent (a matching accepted offer, or one president over both). The refusal is by identity; the
     retirement of a refused accepted settlement is `applySandboxActionCore`'s one deliberate mutation (#1596). */
  if ("BuyTrainFromCorporation" in msg) {
    const { buyer_protocol_id, seller_protocol_id, model_type, price } = msg.BuyTrainFromCorporation;
    if (
      trainSaleRefusal(
        state,
        { buyerId: buyer_protocol_id, sellerId: seller_protocol_id, model: model_type, price },
        ctx?.actor,
        ctx?.mapGrid,
        "settlement",
      ) !== null
    ) {
      return state;
    }
  }
  /* Design note #1591 (core): and the corporation's purchase of a private company, by the same rule -- the
     Operating turn, phases 3-4, an open player-owned private the B&O ban allows, the printed band, a floated
     presided buyer with the price in its treasury, and consent. The B&O ban and the player-seller rule are
     ALSO inside `transferPrivateToCorporation` (#660/#1563), where the funding sale needs them; that is the
     ledger's boundary, not a second rule. */
  if ("BuyPrivateCompany" in msg) {
    const { protocol_id, private_id, price } = msg.BuyPrivateCompany;
    if (
      privatePurchaseRefusal(state, { buyerId: protocol_id, privateId: private_id, price }, ctx?.actor, "settlement") !== null
    ) {
      return state;
    }
  }
  const depotPurchase =
    "BuyHardwareFromPool" in msg && msg.BuyHardwareFromPool.returned_model_type === undefined
      ? { companyId: msg.BuyHardwareFromPool.protocol_id, requireFunds: true }
      : null;
  if (depotPurchase) {
    /* Design note #1326: THE SHELF TIER, WHEN NAMED. A named tier that is not for sale refuses here, before
       any stage runs, for #1019's reason; an unnamed purchase is the queue head, as it always was. The gate
       prices the tier the arm will actually deliver, so a $900 Diesel is judged at $900 and not at the 6's
       $630. */
    const named =
      "BuyHardwareFromPool" in msg ? msg.BuyHardwareFromPool.model_type : undefined;
    const open = openDepotTiers(state);
    const tier = named === undefined ? open[0] : open.find((row) => row.tier === named);
    if (named !== undefined && !tier) return state;
    // #1530: the limit in force, for `buyDepotTrain`'s reason (the arriving tier's limit is a consequence).
    if (
      trainPurchaseRefusal(state, depotPurchase.companyId, {
        cost: tier?.cost ?? null,
        trainLimit: limitInForce(state) ?? tier?.trainLimit ?? null,
        requireFunds: depotPurchase.requireFunds,
      }) !== null
    ) {
      return state;
    }
  }

  /* Design note #1303: THE EXCHANGE IS GATED HERE TOO, FOR THE SAME REASON THE DEPOT PURCHASES ARE. A refusal
     has to return the state it was handed (#778 detects one by identity), and a gate inside the arm is not
     enough: the settle chain below the arm stamps `current_global_era` on a state that never carried one, and
     a refused exchange came back as a new object. Same gate as the arm and the REFUSED line ask. */
  if ("ExchangeTrainForDiesel" in msg) {
    const { protocol_id, model_type } = msg.ExchangeTrainForDiesel;
    if (dieselExchangeRefusal(state, protocol_id, model_type) !== null) return state;
  }

  /* Design note #763: NOTHING HAPPENS WHILE A HOME TOKEN IS OWED. Floating a corporation and placing its
     home token are one event in 1830; #416 split them into a prompt so the player would witness the
     placement, and that opened a window the physical game does not have. Everything downstream reads the
     board, so an action settled while a floated corporation has no token is settled against a board that
     cannot exist.
     BEFORE EVERY OTHER ARM, because the point is that no message lands -- including the ones that would
     otherwise be harmless. `homeTokenBlock` lets the placement and Undo through; a gate with no exit turns a
     bad state into an unrecoverable one. */
  if (ctx?.homeHexToAxial) {
    if (homeTokenBlock({ state, homeHexToAxial: ctx.homeHexToAxial, msg }) !== null) return state;
  }

  /* ==================================================================
      DESIGN NOTE 1570: THE STOCK TRANSACTION IS JUDGED HERE, FOR #1019's REASON (Batch 7.2)
     ==================================================================
     THE REDUCER IS CANONICAL LAW. `stockPurchaseRefusal` / `stockSaleRefusal` own the round gate, the
     president/par rules and the ladder, the price (from the corporation and the chart, never from the
     message), the physical availability of the card, the Brown continuation's corporation, the bundle's
     shape, the first-Stock-Round ban, the unparred corporation and affordability -- and they COMPOSE the
     existing predicates (`sharePurchaseBlock`, `shareSaleBlock`, `doubleSaleEffect`, `forcedSaleRefusal`)
     rather than restating them.

     ASKED BEFORE ANY STAGE RUNS, on #1019's rule: a refusal inside the arm still lets `settleRoundTransitions`
     / `settleEra` / `settleOperatingCursor` run on the way out, so the state comes back a new object and a
     caller checking identity cannot tell. Here the board is returned BY IDENTITY.

     AFTER THE HOLDS, NOT BEFORE THEM. A discard owed, a train that must be funded, a home token not yet
     placed: each of those is a board no rule was written against, and the reason a player is told must be the
     one that explains why nothing works -- not a stock rule they would meet anyway.

     THE SALE IS ALSO ASKED BY THE MARKET STEP (the `saleRefused` closure above, #748a), which runs FIRST and
     therefore decides whether the token moves. Both call this same function so they cannot disagree. */
  if ("BuyStock" in msg) {
    if (
      stockPurchaseRefusal({
        state,
        buy: purchaseIntentOf(msg.BuyStock),
        actor: ctx?.actor ?? null,
        ctx: stockChartContext(state, ctx),
      }) !== null
    ) {
      return state;
    }
  }
  if ("SellStock" in msg) {
    if (
      stockSaleRefusal({
        state,
        sell: { companyId: msg.SellStock.protocol_id, percentage: msg.SellStock.percentage },
        actor: ctx?.actor ?? null,
        mapGrid: ctx?.mapGrid,
        ctx: stockChartContext(state, ctx),
      }) !== null
    ) {
      return state;
    }
  }
  /* #1570: the B&O's private grants its President's Certificate without a purchase and without a charge
     (rulebook p.27) -- and still may not choose a price the board has no par box for (S8-9). The ownership
     and presidency preconditions stay `boPresidencyRefusal`'s, asked by the arm as they always were. */
  if (isSetBoParMsg(msg)) {
    if (parLadderRefusal(msg.SetBoPar.par_value, stockChartContext(state, ctx), BO_TICKER) !== null) {
      return state;
    }
  }

  /* ==================================================================
      DESIGN NOTE 1323/1324: THE LEVEL PLAYING FIELD'S REFUSALS, GATED HERE FOR #1019's REASON
     ==================================================================
     Each of these is ALSO refused in its arm, and #1019 records why that is not enough: the arm is the first
     of five stages, and a refusal down there still lets `settleOperatingCursor` end the turn -- a run that
     never ran would still move the step to Dividends. So the same predicates are asked before any stage
     runs, and the state comes back by identity, which is what `actionWasRefused` (#778) detects. */
  /* Spelled as one condition so `oneRunPerTurn.test.ts`'s anchor -- the arm's own `if ("RunMultipleRoutes"
     in msg) {` -- still finds the arm and not this gate. */
  if (
    "RunMultipleRoutes" in msg &&
    !mayCrossCoalRiver(state, msg.RunMultipleRoutes.protocol_id) &&
    msg.RunMultipleRoutes.routes.some((path) => routeCrossesCoalRiver(path))
  ) {
    return state;
  }
  if (
    "RunManualRoute" in msg &&
    !mayCrossCoalRiver(state, msg.RunManualRoute.protocol_id) &&
    routeCrossesCoalRiver(msg.RunManualRoute.path)
  ) {
    return state;
  }
  /* ==================================================================
      DESIGN NOTE 1550/1551/1552: THE ROUTES, THE DIVIDEND AND THE SKIP ARE JUDGED HERE (Batch 6)
     ==================================================================
     AUDIT C2: `routeSetRefusal` (`routeAuthority.ts`) re-walks every submitted route through the board's own
     rail model and refuses by identity anything the rulebook's §6.4 / §6.4.2 forbid -- a train the corporation
     does not own or names twice, more routes than trains, a route that is not continuous, reverses, reuses
     track, runs through a full city or a red area, exceeds the train's number, lacks a station, counts a city
     twice, or shares track with a sibling route -- and a second run in one turn. Judged with the same grid and
     era the arm prices on; without a grid the gate has no opinion (#757), and the arm's nominal fallback stands.
     #1551: `RunManualRoute` is a legacy replay message (#1051): nothing has dispatched it since #968, and a
     pinned board (one dealt with a `rules_engine_version`) refuses it outright rather than letting a hand-built
     copy add to `printed_route_revenue` once per message. Legacy (unpinned) logs keep the arm they were played
     on.
     AUDIT C1 / #1552: `dividendAmountRefusal` -- the declared amount must equal what the trains ran
     (`last_route_revenue`), to the dollar; the field stays on the wire for narration.
     AND THE STEP IS NOT SKIPPED PAST A PAYING ROUTE: `routeSkipRefusal` refuses `AdvanceOperatingSubPhase` /
     `PassTurn` at Run Trains while the corporation holds a train and `maxRouteRevenueFor` finds a paying route
     -- the shell's #414 obligation, asked of the authority. */
  if (
    "RunMultipleRoutes" in msg &&
    routeSetRefusal(state, msg.RunMultipleRoutes, ctx?.mapGrid, ctx?.era ?? (ctx?.mapGrid ? "Yellow" : undefined)) !== null
  ) {
    return state;
  }
  if ("RunManualRoute" in msg && typeof state.rules_engine_version === "number") return state;
  if ("DeclareDividends" in msg && dividendAmountRefusal(state, msg.DeclareDividends) !== null) return state;
  /* ON A PINNED BOARD ONLY. A board dealt under this engine never records a skip this refuses (the server
     derives skips with the same search and refuses a player's at ingress); a legacy log's recorded skips were
     the old engine's own verdicts (JUNO-CV4 88, JUNO-3XD 226 -- both skipped a corporation the old count
     thought trainless or rootless), and refusing them would strand that corporation at Run Trains for the rest
     of the replay. Development-corpus compatibility, not historical fidelity (D-9). */
  if (typeof state.rules_engine_version === "number" && routeSkipRefusal(state, msg, ctx?.mapGrid) !== null) {
    return state;
  }
  if ("LayTile" in msg) {
    const { protocol_id, q, r } = msg.LayTile;
    const key = (msg.LayTile as { ability_key?: unknown }).ability_key;
    if (key === JK_TILE_ABILITY_KEY && jkTileRefusal(state, protocol_id, q, r) !== null) return state;
  }
  if ("SellStock" in msg && ctx?.actor) {
    const company = state.public_companies.find((entry) => entry.company_id === msg.SellStock.protocol_id);
    if (company && doubleSaleEffect(company, ctx.actor, msg.SellStock.percentage).kind === "refused") {
      return state;
    }
  }
  if ("BuyStock" in msg && msg.BuyStock.certificate === "double") {
    const company = state.public_companies.find((entry) => entry.company_id === msg.BuyStock.protocol_id);
    const pool = msg.BuyStock.source === "Bank" ? "Bank" : "Ipo";
    if (!company || doublePurchaseRefusal(company, pool) !== null) return state;
  }

  return settleBankruptcy(
    settleOperatingCursor(
      state,
      /* Design note #660: the B&O private closes the moment the B&O
         corporation owns a train. Settled here beside the era for the same
         reason (#657) -- it is a function of the board, so no message can
         change the fleet and forget it. */
      settleBaoPrivate(settleEra(settleRoundTransitions(applyOneAction(state, msg, ctx), ctx))),
      msg,
    ),
    ctx,
  );
}

/* The era is SETTLED from the trains after every action, never assigned per-arm. It was stamped at seed time and never written, so a Phase 6 game still reported Yellow. The OR count is deliberately untouched (#511).
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #657 */
/* ==================================================================
    DESIGN NOTE 1540: BANKRUPTCY ENDS THE GAME, IN THE REDUCER, THE MOMENT IT IS TRUE
   ==================================================================
   Rulebook 6.7: "If there is not enough money after the president sells all of his shares that he is allowed
   to, he goes bankrupt and the game ends." Derived after every action from the standing obligation
   (`emergencyFundingFor`): a positive shortfall and no legal forced sale left. Not a message -- a client
   cannot declare it early, and nobody can decline to. Written as the round's end plus the one fact the
   ended board must carry, `bankrupt_president`, for the scoring (6.6.3) and the modal. #898 keeps the
   bank's ending at the round boundary; this one is immediate, for the reason #898 itself gives. Idempotent
   on replay, and undone by a `RevertTo` past the sale that made it unavoidable, because it is a function of
   the board. */
function settleBankruptcy(state: GameStateResponse, ctx?: SandboxActionContext): GameStateResponse {
  if (state.current_round_type !== "OperatingRound") return state;
  const funding = emergencyFundingFor(state, ctx?.mapGrid);
  if (funding === null || !funding.bankrupt) return state;
  return {
    ...state,
    current_round_type: "GameEnd" as const,
    bankrupt_president: funding.president,
    operating_sub_phase: undefined,
  };
}

function settleEra(state: GameStateResponse): GameStateResponse {
  const phase = derivePhase(state);
  /* Unknown phase -- no corporation has reported a fleet at all -- leaves the
     era alone. That is a board we know nothing about rather than a Yellow
     one, and overwriting a seeded scenario's era (`sandboxState.ts` starts
     one in "Green") with a guess would be worse than saying nothing. */
  if (!phase?.known) return state;
  // #1312: the Diesel era is Gray under the Project 18XX+ tile set and Brown otherwise.
  const era = eraForPhase(phase, resolveVariants(state.variants));
  if (era === state.current_global_era) return state;
  return { ...state, current_global_era: era };
}

/* #657's `ERA_FOR_TIER` table is gone: `eraForPhase` (gameConstants.ts #1312) is the one statement of
   which era a phase opens, and it takes the table's variants into account. */

/* The OR sub-phase cursor moves HERE, not in an App effect keyed on the era. One place with a stated default (hold) rather than a write in twelve message arms; a turn change beats every step rule.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #656 */
function settleOperatingCursor(
  before: GameStateResponse,
  after: GameStateResponse,
  msg: GameplayExecuteMsg,
): GameStateResponse {
  /* ==================================================================
     DESIGN NOTE 906a: THE REPRIEVE EXPIRES ON THE WAY OUT TOO
     ==================================================================
     Lifted ABOVE the early return below, and finding out why is the whole of this note. The reprieve clear
     started life inside the `turnChanged` block further down, beside the route-revenue reset -- which is
     unreachable when an Operating Round SET ends, because the guard below returns first for any `after` that
     is not an Operating Round.
     SO THE LAST CORPORATION OF EVERY SET GOT TWO RUNS out of a train that was owed one: its turn ended into a
     Stock Round, the clear never ran, and the mark was still there when the next set opened. Caught by the
     case that ends a single-corporation set; the sibling case, which advances between two corporations WITHIN
     a round, passed the whole time and hid it.
     THE OUTGOING CORPORATION IS `before`'S, in both paths, for the same reason: it is the one that was acting
     when this transition began, and by the time the round type has changed `after` no longer says who that
     was. */
  const outgoingCorporation =
    before.current_round_type === "OperatingRound"
      ? (before.active_operating_order ?? [])[before.active_corporation_index] ?? null
      : null;
  const expireReprieveFor = (
    state: GameStateResponse,
    corporation: number | null,
  ): GameStateResponse => {
    if (corporation === null) return state;
    const done = (company: (typeof state.public_companies)[number]) =>
      company.company_id === corporation &&
      (company.pending_rust_trains?.length ?? 0) > 0;
    if (!(state.public_companies ?? []).some(done)) return state;
    return {
      ...state,
      public_companies: state.public_companies.map((company) => {
        if (!done(company)) return company;
        /* ==================================================================
            DESIGN NOTE 979: THE EXPIRY NOW HAS A TRAIN TO TAKE
           ==================================================================
           UNDER #906 THIS CLEARED A LIST AND NOTHING ELSE, because the trains had already left `owned_trains`
           at the phase change -- so "scrapped the moment that turn ends" was, mechanically, "scrapped a
           turn earlier and forgotten about now". #979 leaves them in the fleet, which is what lets them run,
           and makes this the line that actually retires them.
           A MULTISET REMOVAL, not a filter on the model: a corporation holding a reprieved 3 and a live 3
           must lose exactly one of them. `filter(m => !reprieved.includes(m))` would take both, which is the
           bug this shape exists to avoid and the same one `describeFleetLosses` records.
           `pending_rust_trains: []` RATHER THAN THE FIELD REMOVED: by the time this runs the state has
           certainly reported a reprieve -- `done` requires a non-empty one -- so an empty list here is a
           fact rather than an invention. */
        /* ==================================================================
            DESIGN NOTE 1032: THIS FUNCTION WAS NOT THE ZOMBIE, AND THE AUDIT SAYS SO
           ==================================================================
           REPORTED: "once a reprieved train completes its Final Run ... it is permanently and completely
           removed from the corporation's roster array. They must not persist as invisible data objects that
           get re-evaluated during later phase changes."
           IT ALREADY IS. The walk below takes each marked model out of `owned_trains` and the whole mark list
           is replaced with `[]`, so after this runs there is no train and no mark. Driving the reducer
           through the reported sequence confirmed it: the trains are gone from both arrays.
           WHAT PRODUCED THE SYMPTOM WAS UPSTREAM. `applyPhaseChange` re-marked trains that were already
           marked (#1032, at the rust filter), so `pending_rust_trains` could hold four entries for two
           trains -- and a mark list longer than the fleet is what "invisible data objects" describes. The
           surplus marks matched nothing here, survived as far as the next `describeFleetLosses` diff, and
           were reported as fresh rusts. Fixed at the write rather than swept up at the read: a sweep here
           would have hidden the doubling while leaving every other reader of the field holding the wrong
           list.
           NOTHING IS CHANGED IN THIS FUNCTION. Recorded because "I checked and it was already correct" is a
           finding, and the next reader chasing this report deserves to be told where not to look. */
        const survivors = [...(company.owned_trains ?? [])];
        for (const model of company.pending_rust_trains ?? []) {
          const at = survivors.indexOf(model);
          if (at >= 0) survivors.splice(at, 1);
        }
        return {
          ...company,
          ...(company.owned_trains == null ? {} : { owned_trains: survivors }),
          pending_rust_trains: [],
        };
      }),
    };
  };

  /* Outside an OR the cursor is CLEARED, not frozen -- a stale Hardware would be handed to the next round's first corporation.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #656 */
  if (after.current_round_type !== "OperatingRound") {
    const expired = expireReprieveFor(after, outgoingCorporation);
    /* ==================================================================
        DESIGN NOTE 1046: THE GHOST STOPS BEING ONE WHEN THE ROUND ENDS
       ==================================================================
       RULED: the gift "bypasses train limit checks until the end of the Operating Round", and asked what
       happens then -- "Becomes an ordinary train; discard if over." So the exemption expires HERE, at the
       round boundary rather than at a turn change, because that is what the ruling names.
       THE TRIM RUNS IMMEDIATELY AFTER, in the same transition. Clearing the marks without trimming would
       leave a corporation sitting over the limit indefinitely: `applyPhaseChange` is the only other place
       that trims, and it fires on a phase change, which may never come again.
       CHEAPEST-FIRST AND REPRIEVED-EXEMPT, through the same `trimToTrainLimit` every other caller uses --
       #1034's rule, so the newly-ordinary ghost competes with the rest of the fleet on the ordinary terms
       rather than being singled out. It is usually the newest and most expensive train, so it usually
       survives, which is the generous reading of a gift. */
    const settled = expireGhostTrains(expired);
    /* ==================================================================
        DESIGN NOTE 1089: THE FOG COMES AT THE END OF THE OR SET, NOT THE OR
       ==================================================================
       TWO EXPIRIES, ONE TRANSITION, DIFFERENT PERIODS. `expireGhostTrains` runs every Operating Round -- the
       limit exemption is an OR-long grace. The doom clock is measured in OR SETS, so `expireCarcosanTrains`
       compares `macro_round_number` against the deadline and does nothing on the rounds in between.
       WHICH MAKES THIS TRANSITION THE RIGHT HOME FOR BOTH. #898 established that the opening of a Stock
       Round is exactly the moment an OR set has finished, and the counter has not been incremented yet at
       this point, so it still names the set that just ended. */
    /* Design note #1092: `expireCarcosanTrains` IS GONE FROM THIS TRANSITION. #1089 removed the train here;
       the fog is now the third step of the revenue sequence and takes it on a RUN, where it can be narrated
       and can ring. What survives at this boundary is `expireGhostTrains` -- the limit exemption, which is a
       per-Operating-Round grace and has nothing to do with the doom clock. */
    if (settled.operating_sub_phase === undefined) return settled;
    return { ...settled, operating_sub_phase: undefined };
  }

  const turnChanged =
    before.current_round_type !== after.current_round_type ||
    before.active_corporation_index !== after.active_corporation_index ||
    before.sub_round_index !== after.sub_round_index ||
    before.macro_round_number !== after.macro_round_number;
  if (turnChanged) {
    /* ==================================================================
     *  DESIGN NOTE 777: THE TURN CLEARS THE RUN, BECAUSE THE LOG CAN SAY SO
     * ==================================================================
     *
     * REPORTED: "B&O just ran for $200 and the toast said it paid out at $39 per share", and before that
     * "$190 ... $22 per share". $390 is $200 plus the previous run's $190; $220 is $190 plus the run before
     * that. `last_route_revenue` was carrying turns forward.
     *
     * THE RESET EXISTED AND COULD NEVER ARRIVE. `RunManualRoute` adds to the stored figure -- correct, since
     * one message per train is how a multi-train turn is recorded -- and `ctx.resetRouteRevenue` was supposed
     * to zero it on the batch's first message. But that flag is a DISPATCH-TIME OPTION, and
     * `appendSandboxAction` writes only the message and `derived` into the log. Every client, including the
     * one that pressed the button, applies actions by REPLAYING them, so the flag was never present when the
     * arm read it. The reset was unreachable on every code path in the app.
     *
     * SO THE RULE BECOMES A FACT ABOUT STATE. A corporation's route revenue describes THIS turn; the moment
     * the turn changes it describes a turn that is over. This function already computes `turnChanged` for the
     * cursor, and the same event is what makes the figure stale -- so it is cleared here rather than signalled
     * from outside. Derivable from the log alone, which is #642's standing rule for anything the reducer owns.
     *
     * ALL CORPORATIONS, NOT JUST THE OUTGOING ONE. The field is only ever read for the corporation currently
     * operating, so clearing the rest costs nothing and removes the question of which one to clear -- and a
     * round transition changes the queue itself, where "the outgoing one" is not well defined. */
    /* Design note #903: AND THE TRAIN COUNTER GOES WITH IT. `routes_run_this_turn` is what gives each train
       its own die -- a corporation running two 4-trains rolls twice -- and it describes THIS turn for exactly
       the reason above. Cleared in the same expression rather than in a second pass, because two resets of
       one turn-scoped idea drifting apart is the bug #777 is about. */
    /* ==================================================================
       DESIGN NOTE 906a: AND THE REPRIEVE ENDS HERE, WITH THE TURN
       ==================================================================
       RULED: a pending-rust train "dies at the exact end of that specific corporation's next Operating Round
       turn (immediately after it generates its final revenue)".
       THIS IS THAT MOMENT, AND IT IS ALREADY BEING COMPUTED. `turnChanged` is what clears the route revenue
       above, for the same reason: the turn that earned it is over. The doomed train earned its last revenue
       during that turn, that revenue has been recorded and paid, and now the train goes. Putting the death
       anywhere else would need a second answer to "whose turn just ended", which is #777's whole lesson.
       ONLY THE CORPORATION WHOSE TURN ENDED, unlike the revenue clear beside it. That one clears every
       corporation because the field is only ever read for the acting one, so over-clearing is free. This is
       not free: clearing another corporation's marks would destroy trains that have not had their run. The
       outgoing corporation is `before`'s cursor -- the one that was acting when this transition began. */
    /* Design note #906a: the reprieve expires through the SAME helper the non-Operating path uses, so a
       corporation whose turn ends mid-set and one whose turn ends the set are answered identically. */
    const withReprieveExpired = expireReprieveFor(after, outgoingCorporation);
    /* Design note #941: AND THE PRINTED SUM GOES WITH THEM. It is the third turn-scoped figure on a
       corporation, and the one whose survival would be least visible: a stale `printed_route_revenue` does
       not show anywhere on screen, it simply makes the NEXT turn's single roll apply to last turn's routes as
       well as this turn's. The corporation would be paid for track it did not run, from a field nobody was
       looking at. Cleared in the same expression as its two siblings for exactly #777's reason -- two resets
       of one turn-scoped idea are two things that can drift. */
    /* Design note #1031: THE BREAKDOWN IS THE FOURTH TURN-SCOPED FIGURE, and it is listed here as well as
       cleared below because the other three can all be zero while it is not -- a turn whose routes earned
       nothing still ran trains. Left out of this predicate, such a turn would leave a breakdown standing that
       no later clear would ever reach. */
    const staleRun = (company: (typeof after.public_companies)[number]) =>
      (company.last_route_revenue ?? "0") !== "0" ||
      (company.printed_route_revenue ?? "0") !== "0" ||
      (company.last_run_breakdown?.length ?? 0) !== 0 ||
      (company.routes_run_this_turn ?? 0) !== 0;
    /* ==================================================================
       DESIGN NOTE 1028: REMEMBER IT ON THE WAY OUT
       ==================================================================
       REPORTED: "all corporation cards on the Stock tab have 'Last Run --' during an Operating Round ... it
       was only printing the Last Run value of the last corporation to run."

       AND THIS IS THE LINE THAT ERASED THEM. #777's clear is right -- a turn-scoped total left standing makes
       the NEXT turn's die apply to last turn's routes -- but the figure it wipes is exactly the completed run
       the card wants to show, so the only corporation still holding one was whichever was mid-turn.

       COPIED, NOT KEPT. `last_completed_run_revenue` is written in the same expression that zeroes its
       turn-scoped sibling, which is the one moment both values are in hand and the reason this is not a
       second clear to fall out of step with the first (#777's own argument for doing all three together).

       ONLY WHEN SOMETHING RAN. A turn that earned nothing must not overwrite the last figure the corporation
       actually earned with a zero -- "Last Run" would then read $0 for a corporation whose trains were simply
       idle that round, which is a different claim from the one the card is making. */
    const cleared = withReprieveExpired.public_companies.some(staleRun)
      ? withReprieveExpired.public_companies.map((company) =>
          staleRun(company)
            ? {
                ...company,
                ...(Number(company.last_route_revenue ?? 0) > 0
                  ? { last_completed_run_revenue: company.last_route_revenue }
                  : {}),
                last_route_revenue: "0",
                printed_route_revenue: "0",
                /* ==================================================================
                    DESIGN NOTE 1031: CLEARED, WHERE #1028's FIGURE IS COPIED FORWARD
                   ==================================================================
                   THE OPPOSITE TREATMENT TO ITS NEIGHBOUR TWO LINES UP, and the difference is who reads it.
                   `last_completed_run_revenue` is shown on the Stock tab for corporations that are NOT
                   operating, so clearing it was the #1028 bug -- it erased the very thing the card wanted.
                   The breakdown is read only through the acting corporation's train chips, which exist only
                   while that corporation is the one operating. A breakdown that outlived its turn could
                   therefore only ever be read as a claim about the WRONG turn: a watcher opening the chips
                   before this corporation has run would be shown last round's figures as though the trains
                   had already gone out.
                   STRUCTURALLY IMPOSSIBLE RATHER THAN GUARDED. The alternative was to keep the field and gate
                   the chip on `routes_run_this_turn > 0`, which works right up until a second caller reads
                   the field without asking the same question -- #1006's shape, and this project's most
                   frequent one. A field that cannot be stale needs no caller to remember anything.
                   AN EMPTY ARRAY, NOT `undefined`. #232 reserves absence for "the log does not say", which is
                   what an old replay means and what the chip's pricing fallback answers. "This corporation
                   has not run this turn" is a positive fact and says so. */
                last_run_breakdown: [],
                routes_run_this_turn: 0,
              }
            : company,
        )
      : withReprieveExpired.public_companies;
    return {
      ...after,
      public_companies: cleared,
      operating_sub_phase: openingSubPhase(after),
    };
  }

  const current = after.operating_sub_phase;
  const next = stepAfterMessage(after, current, msg);
  /* ==================================================================
   *  DESIGN NOTE 1001: THE REPRIEVE ENDS AT BUY TRAINS, NOT AT THE TURN'S END
   * ==================================================================
   *
   * REPORTED: "Because they still occupy a slot during the 'Buy Trains' phase, the engine incorrectly
   * auto-skips the Buy Trains phase for corporations at the train limit, preventing them from replacing the
   * trains that just rusted."
   *
   * AND THIS IS #979's CORRECTION COLLIDING WITH #906a's TIMING. #979 made a reprieved train count against
   * the limit -- correctly, and that is what lets it run. #906a had already put its death at the end of the
   * corporation's turn, which was the right reading of "dies immediately after it generates its final
   * revenue" while the train occupied no slot. Put together, the two produce a corporation that is at its
   * limit for the whole of Buy Trains and then loses a train once buying is over: it is charged for the slot
   * at exactly the moment the slot matters and refunded it when it does not.
   *
   * SO THE DEATH MOVES ONE STEP EARLIER, to the boundary the ruling names. The train has generated its final
   * revenue by the time the cursor leaves Dividends -- Routes computed it and Dividends spent it -- so
   * "immediately after" is satisfied by the step change rather than by the turn change, and the corporation
   * reaches Buy Trains with the slot already free.
   *
   * KEYED ON THE ARRIVAL AT `Hardware`, not on the message. `DeclareDividends` is one way in and
   * `AdvanceOperatingSubPhase` is the other (the Skip button and #439's auto-skip both arrive as that), and a
   * rule written per message would have to name both and would miss the third. What matters is that the
   * cursor is entering the step after the run, which is one comparison.
   * DESIGN NOTE 1102 CORRECTED WHICH STEP THAT IS: it read "entering Buy Trains", two steps past the run.
   *
   * THE ACTING CORPORATION, NOT THE OUTGOING ONE. This fires mid-turn, so `before`'s cursor is the
   * corporation still acting -- the opposite of the turn-change path below it, where the outgoing one is the
   * only right answer. Two callers, two subjects, one helper.
   *
   * AND THE TURN-CHANGE EXPIRY STAYS AS A BACKSTOP. A turn can end without reaching Buy Trains -- an Operating
   * Round set ending, or any path that skips the step entirely -- and a reprieve that survived that would
   * hand the train a second run, which is #906a's own bug in reverse. Two triggers for one event is normally
   * the fault this codebase keeps finding; here they are the same expression called on the same helper, and
   * the second is idempotent because the first leaves nothing to expire. */
  /* ==================================================================
      DESIGN NOTE 1102: THE REPRIEVE ENDS WHEN THE RUN DOES, NOT TWO STEPS LATER
     ==================================================================
     REPORTED: "on Gentle Rust, the Rust modal is firing after a player finishes the Dividends phase ... really
     it should happen at the beginning of the Dividends subphase / end of Run Routes."
     IT FIRED ON `enteringHardware`, WHICH IS THE STEP AFTER DIVIDENDS. The rule the variant states is "you
     can run these trains one more time before they retire", so the reprieve is spent the moment the run is
     over -- and the first moment after the run is the cursor entering Dividends. Hardware was simply the
     first place anybody looked for "later"; it was never the rule.
     THE CONSEQUENCE THAT MADE IT WORTH MOVING is the collision, not the accuracy: at Hardware the modal lands
     on top of the dividend money machine and the revenue flash, so a blocking interruption arrives over an
     animation the player is still reading.
     NO PAYOUT CHANGES WITH IT, which is the thing to check before moving a reducer step: `DeclareDividends`
     prices the turn from `revenue_amount` on the message (#752), never from the fleet, so a train removed on
     the way INTO Dividends cannot alter what Dividends pays.
     THE TURN-CHANGE BACKSTOP BELOW IS UNTOUCHED and still earns its place -- a turn can end without reaching
     Dividends at all, and a reprieve that survived that would hand the train a second run. */
  const enteringDividends = next === "Dividends" && current !== "Dividends";
  const actingCorporation =
    (after.active_operating_order ?? [])[after.active_corporation_index] ?? null;
  const settled = enteringDividends ? expireReprieveFor(after, actingCorporation) : after;
  if (next === current) return settled;
  return { ...settled, operating_sub_phase: next };
}

/** The four explicit arms mirror the CONTRACT's own cursor (hexmap::execute_lay_tile advances off Track on success), not an invented sandbox sequence.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #656 */
function stepAfterMessage(
  state: GameStateResponse,
  current: OperatingSubPhase | undefined,
  msg: GameplayExecuteMsg,
): OperatingSubPhase {
  /* A corporation lays one tile per turn, so the Track step is done.
     Design note #776: UNLESS THE LAY WAS EXTRA. This arm was unconditional, and it is the line that both
     enforces "one tile per turn" and -- wrongly -- ended the Track step on the Champlain & St. Lawrence's
     bonus lay. The cursor is what withdraws the Lay Track controls, so ending the step here is the second
     lay being taken away. `layEndsTrackStep` reads a flag the shell sets; an unflagged lay is ordinary, so
     every message written before #776 behaves exactly as it did. */
  if ("LayTile" in msg) {
    return layEndsTrackStep(msg) ? settleSubPhase(state, "Tokens") : settleSubPhase(state, current);
  }
  // One station placement per turn likewise.
  if ("PlaceStationToken" in msg) return settleSubPhase(state, "Routes");
  /* Running the routes COMPUTES the revenue; declaring dividends chooses
     what to do with it (design note #142). Two steps, so two messages. */
  /* Design note #968: BOTH RUN MESSAGES END THE STEP. `RunMultipleRoutes` is the whole turn's running in one
     action and `RunManualRoute` is one route of it -- either way the revenue has been computed and the choice
     of what to do with it is the next step. Omitting the new arm would leave the cursor on Routes after a
     turn that had run, which is the one state the Dividends controls do not render in. */
  if ("RunManualRoute" in msg || "RunMultipleRoutes" in msg) {
    return settleSubPhase(state, "Dividends");
  }
  if ("DeclareDividends" in msg) return settleSubPhase(state, "Hardware");
  /* The Skip button and the auto-skip (design note #439) both arrive as
     this, and both mean the same thing to the cursor. */
  if ("AdvanceOperatingSubPhase" in msg) {
    return nextSubPhase(state, settleSubPhase(state, current));
  }
  /* The default is to stay put, and it is the important arm: a phase change is not a turn event.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #656 */
  return settleSubPhase(state, current);
}

/* One-shot flags are consumed in the dispatch that raised them. One transition per action, deliberately, rather than a while loop.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #642 */
function settleRoundTransitions(
  state: GameStateResponse,
  ctx?: SandboxActionContext,
): GameStateResponse {
  if (state.stock_round_just_ended) {
    /* ==================================================================
     *  DESIGN NOTE 746a: THE RISE HAPPENS BEFORE THE QUEUE IS ORDERED
     * ==================================================================
     *
     * The operating order sorts floated corporations by market price, and the sold-out rise is an end-of-
     * Stock-Round event -- so a corporation that rises past a rival must operate ahead of it in the very next
     * Operating Round. Applying the rise in the shell after this transition would have built the queue on
     * pre-rise prices and got that ordering wrong for one round, every time.
     *
     * SO THE OVERLAY, rather than a second `buildOperatingOrder` call afterwards. #642 is the reason it is not
     * done in the shell: "the round machine belongs to the reducer. The shell used to perform transitions, so
     * a replay rebuilt corporations correctly and left the round wherever the last live dispatch had put it."
     * A rise that reordered the queue from outside would be that mistake with a new name.
     *
     * THE SHELL STILL COMMITS THE MOVE to the market atom, because that atom is not part of
     * `GameStateResponse` -- it derives the rises from the same pure function with the same injected
     * traversal, so the queue and the chart cannot disagree about where a token landed. */
    const rises = roundEndSoldOutRises(state, ctx?.marketMarkFor, ctx?.projectRise);
    const risenPrice = new Map(rises.map((rise) => [rise.companyId, rise.to]));
    const risenMark = new Map(rises.map((rise) => [rise.companyId, { x: rise.x, y: rise.y }]));

    /* The queue is built here; leaving it to the caller is what produced an OR with an empty order that advanceCorporation then "recovered" back to 1.1.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #411 */
    const opened = {
      ...openOperatingRound(
        state,
        (companyId) => risenPrice.get(companyId) ?? ctx?.marketPriceFor?.(companyId) ?? null,
        (companyId) => risenMark.get(companyId) ?? ctx?.marketMarkFor?.(companyId) ?? null,
      ),
      stock_round_just_ended: false,
    };

    /* ==================================================================
        DESIGN NOTE 1448: A ROUND NOBODY CAN OPERATE MUST NOT OPEN
       ==================================================================
       FOUND replaying the #1447 playtest. With no corporation floated, `buildOperatingOrder` correctly
       returns an EMPTY queue -- it filters on floated-with-a-president and always has. The fault is what
       happens next: the round opened anyway, and an open Operating Round with an empty queue cannot be
       left.

       THE RECOVERY EXISTED AND WAS UNREACHABLE. `advanceCorporation` rebuilds an empty queue and raises
       `operating_round_just_ended` when the rebuild is empty too (#411) -- but it only runs when somebody
       ACTS, and in this state nobody can. `actingSeatIndex` resolves the acting seat from
       `active_operating_order[active_corporation_index]`; an empty queue makes that `undefined` and the
       function returns `null`, so `isMyTurn` is false for every player at the table and every control is
       disabled. A repair that can only be triggered by an action is no repair for a state that forbids
       them.

       SO THE EMPTINESS IS SETTLED AT THE OPENING, where a caller still exists. The round is opened --
       `openOperatingRound` pays the private income that opening one owes, and that is due whether or not a
       corporation runs -- and is then immediately marked finished, so the machine carries on to the next
       Stock Round through the same branch that ends every other set. Recursing rather than duplicating that
       branch keeps the bank-break ending (#898) on this path too; it terminates because the next pass takes
       a different branch and a Stock Round always seats a player.

       NOT A RULES CHANGE. A set that opens with nothing floated is Yellow by construction (nothing has
       floated, so no train has been bought), and Yellow runs one Operating Round per set -- so there is no
       second round in the set being skipped. */
    if (opened.active_operating_order.length === 0) {
      return settleRoundTransitions({ ...opened, operating_round_just_ended: true }, ctx);
    }
    /* Design note #685: THE PRIVATES ARE PAID HERE, BY THE REDUCER.

       REPORTED as a regression -- "the Private Companies are supposed to pay out their income every Operating
       Round, and in previous playthroughs they have, but in my latest playthrough they did not."

       They were paid by a REACT EFFECT in the shell, watching `current_round_type` for an edge against a ref.
       That is precisely the arrangement design note #1206 above removed for the round machine itself -- "the
       shell used to perform transitions, so a replay rebuilt corporations correctly and left the round wherever
       the last live dispatch had put it" -- and the payout never got the same treatment.

       IT BROKE THE MOMENT A REBUILD BECAME MORE LIKELY. `rebuildSandbox` resets the board but not the shell's
       edge-detector ref, so after a rebuild the ref still said "OperatingRound" while the replay ended in one:
       no edge, no payout, no error. `firebase_middleware.md` #668 replaced a length check with a prefix check,
       which correctly rebuilds in cases the old one missed -- and each of those newly-correct rebuilds silently
       skipped a round of private income.

       AND IT COULD NEVER HAVE BEEN RIGHT IN A ROOM. The money moved outside the log, so a client that rebuilt
       and a client that did not held different treasuries from then on -- the same divergence class the action
       log itself was hardened against.

       HERE IT IS DETERMINISTIC BY CONSTRUCTION: one place, on the one transition that opens an Operating Round,
       replayed identically by every client. No ref to go stale, no effect to miss a batch. */
    /* Design note #1015: the payout moved INTO `openOperatingRound`, which `opened` already went through.
       Left here it would pay twice on this branch and not at all on the other. */
    return opened;
  }

  if (state.operating_round_just_ended) {
    /* ==================================================================
     *  DESIGN NOTE 898: THE BANK BREAKS, AND THE SET STILL FINISHES
     * ==================================================================
     *
     * REPORTED: "If the bank breaks during an Operating Round set, players complete that current set before
     * the game ends. If the bank breaks during a Stock Round, players complete one final set of ORs after
     * that Stock Round before the game ends."
     *
     * THE OLD TRIGGER ENDED THE GAME MID-TURN. `App.tsx` derived the ending as `bankIsBroken(gameState)` on
     * every render, so the modal appeared the instant a payout emptied the bank -- in the middle of somebody's
     * Operating Round, with corporations still owed their runs. Two rules were missing and the derivation had
     * nowhere to put them: it could see the bank, and it could not see the calendar.
     *
     * TWO REPORTED CASES, ONE CONDITION, and finding that collapse is most of this note. Written out:
     *   break during OR set N  -> set N finishes -> game ends.
     *   break during SR N      -> SR finishes, OR set N runs in full -> game ends.
     * Both are "the game ends when the first OR SET COMPLETES at or after the break". So nothing anywhere
     * needs to record WHEN the bank broke -- no `bank_broke_at` field, no macro-round comparison, no second
     * fact to keep in step with `macro_round_number`. The transition that opens a Stock Round is exactly the
     * moment an OR set has finished, so asking about the bank HERE answers both cases at once.
     *
     * AND IT HAS TO BE HERE RATHER THAN IN THE SHELL, for #1206's reason: the round machine belongs to the
     * reducer. An ending computed in `App.tsx` is an ending one client can hold and another cannot, and it
     * cannot be undone -- a `RevertTo` that rewinds past the break has to un-end the game, which a replay does
     * for free and a live derivation never would.
     *
     * BANKRUPTCY IS STILL IMMEDIATE and is deliberately not routed through here. 1830 stops the game the
     * moment a president cannot fund a mandatory purchase; there is no set to finish, because the corporation
     * cannot take the turn it is in. `App.tsx` keeps that arm.
     *
     * See docs/ai_architecture/state_machine.md, sandboxSession.ts #898. */
    if (bankIsBroken(state)) {
      return {
        ...state,
        operating_round_just_ended: false,
        current_round_type: "GameEnd" as const,
      };
    }

    /* ==================================================================
     *  DESIGN NOTE 905: THE DELAYED AUCTION IS INSERTED, NOT SUBSTITUTED
     * ==================================================================
     *
     * REQUESTED: move the private auction "from the start of the game to immediately before Stock Round 3".
     *
     * SO IT SITS IN THE SAME TRANSITION THE STOCK ROUND WOULD HAVE OPENED FROM. The OR set that precedes
     * Stock Round 3 hands off to `WaterfallAuction` instead, and when that auction closes, `OpenStockRound`
     * -- the event that has always closed it -- opens Stock Round 3. Nothing else in the round machine learns
     * a new shape: the auction is a round, and this puts a round where a round already went.
     *
     * THE CALENDAR STILL ADVANCES HERE. `macro_round_number` is incremented on this transition whether the
     * next round is a Stock Round or the auction, because it is the ROUND NUMBER and the auction occupies
     * that slot -- leaving it behind would mean the auction ran "during" the Stock Round just past, and
     * `OpenStockRound` would then re-open a round the table had already played.
     *
     * THE TRIGGER IS THE 3-TRAIN, NOT A ROUND NUMBER -- corrected mid-build. It was "immediately before Stock
     * Round 3"; the rule is "at the exact end of the Operating Round set in which the first 3-train is
     * purchased". The B&O lock is untouched by that change, which is the whole reason #904a asked the auction
     * rather than the calendar: the timing became dynamic and the lock did not have to notice.
     *
     * AND NO FLAG IS NEEDED, which is the substantive departure from the instructions. The request said "you
     * will need to flag the state when the first 3-train is purchased", and the flag would be derivable from
     * two facts already on the state, so it would be a third thing to keep in step with them:
     *   The phase reaches tier 3 exactly once, and only a 3-train purchase takes it there.
     *   `private_auction_complete` is false until the auction runs, and this is the only thing that runs it.
     * So "the phase is at or past 3 and the auction is still owed" IS "the first 3-train was bought during
     * the set that just ended" -- if it had been bought in an EARLIER set, the auction would have fired at
     * that set's end and the completion flag would be true. #898's collapse, one variant over.
     * A `RevertTo` that rewinds past the purchase un-flags it for free, too, because there is no flag: the
     * rebuilt state simply has no 3-train in it and the phase drops back on its own.
     *
     * THE PRIORITY DEAL IS UNTOUCHED and that is the ruling: seeded by whoever holds it going into the
     * auction. It is already in `priority_deal_index`, and `OpenStockRound` seats it when the auction hands
     * off to the Stock Round that follows.
     *
     * IF NO 3-TRAIN IS EVER BOUGHT, no auction ever happens and the privates never enter play. That is the
     * honest consequence of a dynamic trigger rather than a bug, and it is reachable on a short bank -- see
     * the report accompanying this note. */
    const variants = resolveVariants(state.variants);
    if (variants.delayedAuction && state.private_auction_complete !== true) {
      const tier = derivePhase(state)?.tier ?? null;
      const reachedThreeTrain =
        tier !== null && TIER_ORDER.indexOf(tier) >= TIER_ORDER.indexOf(DELAYED_AUCTION_TRIGGER_TIER);
      if (reachedThreeTrain) {
        return {
          ...state,
          operating_round_just_ended: false,
          current_round_type: "WaterfallAuction" as const,
          macro_round_number: state.macro_round_number + 1,
          sub_round_index: 0,
          consecutive_passes: 0,
        };
      }
    }

    return {
      ...state,
      operating_round_just_ended: false,
      current_round_type: "StockRound" as const,
      macro_round_number: state.macro_round_number + 1,
      // Design note #621: the cycle counter resets, and the next
      // `beginOperatingRound` stamps it back to 1.
      sub_round_index: 0,
      /* Design note #909: everything a Stock Round opening invalidates, from the one place that names it --
         so this opening and `OpenStockRound`'s cannot drift about what a new round wipes. */
      ...openingStockRoundReset(state),
    };
  }

  return state;
}

/** Which private ability, if any, this message spends. `null` for the overwhelming majority.
 *
 *  TWO SOURCES, AND THEY ARE NOT SYMMETRIC (#1204).
 *
 *  `PlaceHomeStation` ALREADY SAYS SO. `kind: "dh"` distinguishes the D&H's free station from an ordinary
 *  home placement and has done since #560 -- index 115 of `JUNO-3XD` is one. Nothing new was needed; the log
 *  has been carrying this answer all along and nobody was reading it.
 *
 *  `LayTile` HAS TO BE TOLD. The same hex can be laid by the power or in spite of it, with opposite
 *  consequences, and #817 is what getting that wrong looked like to a player. So the message carries an
 *  explicit `ability_key` and this reads it rather than inferring from coordinates -- an inference is exactly
 *  the heuristic that produced the report. */
function abilitySpentBy(msg: GameplayExecuteMsg): string | null {
  if (isPlaceHomeStationMsg(msg)) {
    return msg.PlaceHomeStation.kind === "dh" ? "dh-token" : null;
  }
  if ("LayTile" in msg) {
    const key = (msg.LayTile as { ability_key?: unknown }).ability_key;
    return typeof key === "string" && key !== "" ? key : null;
  }
  return null;
}

/** The one transfer every corporate purchase of a private goes through -- the ordinary `BuyPrivateCompany` and
 *  the accepted emergency offer (#1541): treasury to the player, the private to the corporation for good. */
function transferPrivateToCorporation(
  state: GameStateResponse,
  protocol_id: number,
  private_id: number,
  paid: number,
): GameStateResponse {
    /* The B&O private may never be sold to a corporation. Enforced here as well as in the offer filter, because a remote client replays MESSAGES, not button states. A no-op, not a throw.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #660 */
    if (!isSellableToCorporation(private_id)) return state;
    const target = state.private_companies.find((entry) => entry.private_id === private_id);
    /* #1247: IDEMPOTENT ON THE OWNER. A replay applies and never generates (#1203), so a log written before
       this note -- the shell's own `BuyPrivateCompany` after an accepted answer -- still buys exactly once.
       This guard is for the other copy: a Firestore-path client that dispatched from its drain a moment after
       the on-turn client did. The private is already this corporation's; paying for it twice is the bug. */
    if (target?.owner_protocol_id === protocol_id) return state;

    /* ==================================================================
        DESIGN NOTE 1563: A SALE HAS TWO ENDS, AND BOTH HAVE TO BE THERE
       ==================================================================
       This read `const seller = target?.owner ?? null` and then `seller ? adjustCash(charged, seller, paid)
       : charged`, so THE MISSING-SELLER CASE WAS WRITTEN OUT AS AN OPTION: the treasury was debited and
       nobody was paid. Two boards reach it -- a private owned by another CORPORATION (`owner` is null and
       `owner_protocol_id` is set), which is also rulebook 3.1's "private companies may be bought by railroad
       corporations but not sold by them", and a private the state holds with no owner at all. Both destroyed
       the price (S7-12).

       SO THE SELLER IS NOW A PRECONDITION. The private must belong to a PLAYER: that is the only sale
       rulebook 3.1 describes, it is what makes the payment have a payee, and it is what the emergency sale
       (D-5) has always been -- a player -> corporation directed offer -- so nothing about Batch 5 changes
       here. A corporation-owned or unowned private refuses, transferring nothing and paying nothing.

       AND THE PRICE IS A PRICE. `paid` reached the treasury as a raw `Number(price) || 0`, so `price:
       "-500"` ran the transfer BACKWARDS -- $500 into the buyer's treasury and the owner zeroed by the cash
       floor. `transfer` takes a non-negative whole amount and refuses anything else, so a negative or
       fractional price is a refusal rather than a reversal.

       WHAT IS DELIBERATELY NOT HERE: the phase, the 1/2-2x band, the operating-corporation check, the
       consent and the `closed` test. Those are rules (S7-6/S7-7/S7-12), they belong to Batch 7.4's
       `privatePurchaseRefusal`, and adding them here would change which purchases are legal in a batch whose
       brief is the money. This is the ledger boundary: the transaction either moves money honestly between
       two real parties or it does not happen. */
    const seller = target?.owner ?? null;
    const corporateSeller =
      target?.owner_protocol_id !== null && target?.owner_protocol_id !== undefined;
    if (!target || seller === null || corporateSeller) return state;

    const paidOver = transfer(state, { corporation: protocol_id }, { player: seller }, paid);
    if (!paidOver.ok) return state;
    const settled = paidOver.state;

    const owned: GameStateResponse = {
      ...settled,
      private_companies: settled.private_companies.map((entry) =>
        entry.private_id === private_id
          ? {
              ...entry,
              // `owner` and `owner_protocol_id` are MUTUALLY EXCLUSIVE --
              // `msg.rs::PrivateCompanyState` says so, and the readouts
              // branch on which one is set. Clearing the first while
              // setting the second is the whole transfer.
              owner: null,
              owner_protocol_id: protocol_id,
            }
          : entry,
      ),
    };
    /* Design note #1323: "The first corporation to purchase the JK private company from a player immediately
       receives one Kanawha License for free." ONCE, game-wide -- the flag is on the state, so a second sale
       of the JK between corporations grants nothing -- and outside the four the Bank sells. */
    const grantsLicence =
      kanawhaLicensesInPlay(owned) &&
      private_id === JK_PRIVATE_ID &&
      seller !== null &&
      owned.jk_license_granted !== true;
    if (!grantsLicence) return owned;
    return {
      ...owned,
      jk_license_granted: true,
      public_companies: owned.public_companies.map((company) =>
        company.company_id === protocol_id
          ? { ...company, kanawha_licenses: licensesHeldBy(company) + 1 }
          : company,
      ),
    };
}

function applyOneAction(
  state: GameStateResponse,
  msg: GameplayExecuteMsg,
  ctx?: SandboxActionContext,
): GameStateResponse {
  /* ==================================================================
      DESIGN NOTE 1189: THE LIFECYCLE MESSAGES COME HOME
     ==================================================================
     FOUND BY THE HEADLESS HARNESS (`replayLog.ts`), which replayed all 322 entries of `JUNO-3XD` and ended
     with the game still in the opening auction: nothing floated, an empty operating order, no Operating
     Round ever begun. The reducer was behaving correctly on the game it was handed. It was handed a game
     that never started.

     BECAUSE `isSandboxOnlyMsg` (`gameSetup.ts` #546) ENUMERATES TEN MESSAGES THE CHAIN NEVER KNEW ABOUT, and
     `App.tsx` has been handling every one of them itself. That was correct while a browser was the only
     thing that ever replayed a log. It stops being correct the moment anything else has to -- a test, a
     diagnostic, or the authoritative server this is being extracted for. A SERVER HAS NO SHELL.

     THESE TWO FIRST, because they are the ones that make a game a game: `SetupGame` deals it and
     `OpenStockRound` ends the auction. Without the pair, no corporation can float and no Operating Round can
     open, so every rule downstream is unreachable and untestable from the log alone. The remaining seven
     (`SetBoPar`, `PlaceHomeStation`, `ExchangePrivate`, the two negotiation pairs, `CloseRoom`) follow.
     `RevertTo` is NOT among them and never will be -- #1026: a revert is an instruction ABOUT the log, and
     `effectiveActions` resolves it before the reducer sees any history at all.

     THE SHELL KEEPS ITS NARRATION AND LOSES ITS ARITHMETIC, which is this project's standing division (#704:
     "the reducer settles, the shell narrates"). `App.tsx` still writes the round line and the nicknames; it
     no longer computes the state, because two writers of one fact is how they come to disagree. */
  if (isSetupGameMsg(msg)) {
    /* #902: THE VARIANTS COME OFF THE MESSAGE, never off a local selection. The host chose them, every client
       deals from this action, and a replay must find the same answer the live game did. */
    const dealt = dealSandboxGame({
      players: msg.SetupGame.players,
      variants: msg.SetupGame.variants,
    });
    /* A ROSTER THAT CANNOT BE DEALT LEAVES THE STATE ALONE (#712's rule: a refusal never halts a replay).
       The shell says so to the player; the board simply does not move. */
    if (!dealt) return state;
    /* Design note #1551: the pin travels onto the board, so the reducer can tell a pinned game from a legacy
       one (the legacy `RunManualRoute` arm is closed to the former). `undefined` stays `undefined` (#232). */
    const pinned = msg.SetupGame.rules_engine_version;
    const rulesPin =
      typeof pinned === "number" && Number.isInteger(pinned) ? { rules_engine_version: pinned } : {};

    /* ==================================================================
        DESIGN NOTE 1228: THE DELAYED AUCTION OPENED ON STOCK ROUND 1 -- IN THE SHELL ONLY
       ==================================================================
       FOUND BY THE #1227 HARNESS ON ITS FIRST DRAFT. A case asserted `current_round_type === "StockRound"`
       after a `delayedAuction` deal, because that is what a client shows -- and it failed here, because the
       client shows it for a reason that has nothing to do with this arm. `App.tsx` computed it:
       `opensOnStockRound ? { ...seated, current_round_type: "StockRound", private_auction_complete: false,
       macro_round_number: 1 } : seated`. The reducer dealt the same game and left it in the auction.

       SO A DELAYED-AUCTION GAME DIVERGED AT INDEX 0. Not a drift -- a different opening position, on the
       server and on every replay, for every game that used the variant. It went unnoticed because nothing
       compared the two until #1223, and because the variant is not the default.

       #905's RULE, WHERE IT BELONGS. "Straight to SR1; no privates exist yet; corporations must float on share
       capital alone for two Stock Rounds." The three fields are one decision: the round opens as a Stock Round,
       the auction is MOVED rather than skipped (`private_auction_complete` stays FALSE, which keeps the B&O
       locked per #904a and tells `settleRoundTransitions` an auction is still owed before Stock Round 3),
       and the macro round is 1. Setting two of the three would produce a game no rule was written for.

       THE SHELL'S COPY IS LEFT STANDING FOR NOW AND IS NOW REDUNDANT. On the client the shell's `SetupGame`
       branch returns before this arm runs, so the two do not compose -- each side runs exactly one of them,
       and they now agree. Removing the shell's copy is the §3.1 work and is done there, message by message,
       under the alarm; this change is what makes that removal a no-op rather than a behaviour change. */
    const opensOnStockRound = dealt.variants.delayedAuction === true;

    const dealtState: GameStateResponse = {
      ...state,
      ...rulesPin,
      ...(opensOnStockRound
        ? {
            current_round_type: "StockRound" as const,
            private_auction_complete: false,
            macro_round_number: 1,
          }
        : {}),
      player_addresses: dealt.playerAddresses,
      player_cash: dealt.playerCash,
      virtual_bank_vgp: String(dealt.bankRemaining),
      /* #902: what THIS game started with, not the printed constant -- a short game's ledger has to read
         $4,500 or the bank gauge measures against a pool that was never there. */
      virtual_bank_start: String(dealt.bankStart),
      /* #902: recorded on state so the reducer can read it -- Unpredictable Revenue asks it on every run,
         and a replay must find the same answer the live game did. */
      variants: dealt.variants,
      max_players: dealt.playerAddresses.length,
      active_player_index: 0,
      priority_deal_index: 0,
      /* #535: a room starts UNOWNED. The fixture's mock presidents and private owners are cut, because no
         `canAct` would ever match them. The board itself survives. */
      public_companies: state.public_companies.map((company) => ({
        ...company,
        president: null,
        player_holdings: [],
        is_floated: false,
      })),
      private_companies: state.private_companies.map((entry) => ({
        ...entry,
        owner: null,
        owner_protocol_id: null,
      })),
    };
    /* #1320 / #1322: the Level Playing Field's two corporations and its seventh private join HERE, on the
       deal, so every client and the server hold the same roster from index 0. The fixture never carries them. */
    return dealt.variants.levelPlayingField ? withLevelPlayingFieldEntities(dealtState) : dealtState;
  }

  if (isOpenStockRoundMsg(msg)) {
    /* #546: the round turns over for everyone, because every client replays this. IDEMPOTENT -- a second copy
       sets the same values, so the guard is an optimisation rather than a correctness requirement. */
    if (state.current_round_type !== "WaterfallAuction") return state;
    /* #905: THE ONE EVENT THAT CLOSES THE AUCTION, WHENEVER IT RAN -- at the top of a standard game, and
       mid-game under the delayed variant. `private_auction_complete` is what unlocks the B&O (#904a), and two
       events that both had to remember to set it is precisely how one of them comes not to.
       #909: `openingStockRoundReset` is the one place that names what a Stock Round opening invalidates --
       the sell-then-buy lock (#744) among them, which under the delayed variant would otherwise be carried
       into Stock Round 3 and refuse a legal buy-back for the rest of the game. */
    /* ==================================================================
        DESIGN NOTE 1235: THE STOCK ROUND OPENS TO THE LEFT OF THE LAST PLAYER WHO ACTED
       ==================================================================
       REPORTED: "Host received BO private company -- the last action of the Auction Round -- then also
       started the Stock Round. That is wrong. In the physical board game, play passes to the last active
       player's left."

       `openingStockRoundReset` SEATS `priority_deal_index`, AND NOTHING IN THE AUCTION EVER TOUCHED IT. The
       field is written in three places in the whole codebase: `SetupGame` (to 0), the Stock Round pass logic,
       and nowhere in the auction. So Stock Round 1 always opened to seat 0. #909 recorded that as a ruling --
       "in a standard game `priority_deal_index` is 0 at genesis, so that is the seat it always was" -- WHICH
       IT WAS NOT. The rule was always "to the left of the last player who acted"; the code had a constant.

       IT PASSED EVERY PREVIOUS PLAYTEST BY COINCIDENCE, and the coincidence is worth spelling out because it
       is how a missing rule survives: the two answers agree whenever the last auction actor sits in the LAST
       seat. In the golden master (three players) the B&O par was set by seat 2, so left-of-seat-2 is seat 0.
       In the previous two-player game seat 1 set it, so left is seat 0. In this game seat 0 set it, left is
       seat 1, and seat-0-always said seat 0 -- the first game where the constant and the rule disagreed, and
       the first time anyone could see there was no rule. `replayJuno3XD` could not catch it either, for the
       same reason: on that log the two answers coincide.

       THE SEAT ALREADY HOLDS THE ANSWER. Every ordinary waterfall action advances the seat past its actor,
       and #1232 keeps the seat honest through a mini-auction -- so at the moment the auction closes,
       `active_player_index` IS the player to the left of whoever acted last. `SetBoPar` does not move it
       (the B&O par is set BY the buyer, not a turn taken), so a game whose final auction act is the B&O
       purchase still opens to the buyer's left. The priority deal is set from it here, once, and
       `openingStockRoundReset` seats the holder as it always has.

       APPLIED TO BOTH OPENINGS. The delayed variant (#905) closes its auction mid-game and the same rule
       reads the same seat; #905's "priority untouched" was the same constant misread as a ruling, and one
       rule for "who opens after an auction" is what the physical game has. */
    const priority = state.active_player_index;
    return {
      ...state,
      current_round_type: "StockRound",
      private_auction_complete: true,
      priority_deal_index: priority,
      ...openingStockRoundReset({ ...state, priority_deal_index: priority }),
    };
  }

  if (isSetBoParMsg(msg)) {
    /* #550: applied on every client, FROM THE LOG. The winner travels in the message rather than being
       inferred from the turn cursor -- which is #549's rule, and the reason `SetBoParMsg` carries a `player`
       at all.
       #904b: THE REFUSAL IS ASKED FIRST so the shell can name the actual cause. It was once a bare identity
       check that swallowed the whole event, and a player who had just paid for the B&O private got no
       certificate, no par and no line anywhere.
       THE PAR MARK IS NOT WRITTEN HERE. `placeParMark` moves the CHART, which is a separate atom this
       reducer must not reach into (#273/#411) -- the shell still does it, and Phase 1 folds it in with the
       rest of the chart. Recorded so the omission reads as a boundary rather than as a gap. */
    const { player, par_value: parValue } = msg.SetBoPar;
    if (boPresidencyRefusal(state, BO_TICKER) !== null) return state;
    return grantBOPresidency(state, player, parValue, BO_TICKER);
  }

  /* ==================================================================
      DESIGN NOTE 1198: THE LAST FIVE, AND THE LINE THEY DRAW
     ==================================================================
     THE REMAINDER OF `isSandboxOnlyMsg` (#1189): both negotiation pairs and the room closure. None of them
     appears in `JUNO-3XD`, so unlike the first five these are NOT covered by the replay harness -- they are
     covered by `shellMessageArms.test.ts`, written case by case, and that difference is worth stating rather
     than discovering.
     THE OFFER MESSAGES ARE PURE STATE and nothing else: propose writes the offer, answer settles it. What
     they must NOT do is append the purchase that follows.
     BECAUSE AN ACCEPTED OFFER IS FOLLOWED BY A NEW LOG ACTION -- an ordinary `BuyPrivateCompany` or
     `BuyTrainFromCorporation`, so consent and legality run through the same code as every other purchase
     (#662, #701). #576's rule: "a consequence is DERIVED by every client, not appended by each of them --
     appending inside a replay is how one win issued two certificates."
     ==================================================================
      DESIGN NOTE 1247: THE PURCHASE IS OWED BY THE BOARD, NOT SENT BY THE SHELL
     ==================================================================
     #1198 left the follow-up dispatch in the shell's drain branch -- and the drain runs on EVERY client for
     every entry, so an accepted offer had every seated browser dispatch the purchase: the buyer's went
     through, the seller's died at the client's turn gate with "It is not your turn" on the seller's screen,
     and a reload of the buyer's client re-dispatched it from history. That is the exact fault #576 names, on
     the message that quoted #576 as its reason for staying in the shell.
     SO THE ANSWER ARM RECORDS THE ACCEPTANCE (`accepted: true` on the offer) and the purchase becomes a
     DERIVED action (#1203): `nextDerivedAction` generates it from that flag, the server appends it once, and
     every client applies it from the log. The purchase arm clears the offer it settles, so a rebuilt board
     owes nothing. Same mechanism as an auto-skip: the board says what it owes, one writer writes it. */
  /* ==================================================================
      DESIGN NOTE 1595 (arms): THE OFFER NAMES THE COUNTERPARTY THE BOARD NAMES (Batch 7.4)
     ==================================================================
     The core has already judged each of these (#1595) -- the transaction's legality, the one-offer rule, and
     who may propose, answer or withdraw -- so the arms only move state. The offer RECORDS the private's
     current owner and the seller's current president as the board has them at proposal; the payload's
     `owner` / `seller_president` are narration and are not written. Every later moment re-derives the
     counterparty from the board again rather than trusting even this record (`answerPrivatePurchaseRefusal`,
     `answerTrainPurchaseRefusal`, the settlement predicates). */
  if (isProposePrivatePurchaseMsg(msg)) {
    const { private_id, private_name, buyer_protocol_id, buyer_ticker, price } = msg.ProposePrivatePurchase;
    const priv = state.private_companies.find((entry) => entry.private_id === private_id);
    const buyer = state.public_companies.find((entry) => entry.company_id === buyer_protocol_id);
    const owner = currentPrivateOwner(state, private_id);
    if (!priv || !buyer || owner === null) return state;
    // #1597: numbered as it is written -- the settlement's identity is this instance, not the transaction.
    const { instance, offer_serial } = allocateOfferInstance(state);
    return {
      ...state,
      offer_serial,
      private_purchase_offer: {
        private_id,
        private_name: priv.name ?? private_name,
        owner,
        buyer_protocol_id,
        buyer_ticker: buyer.ticker ?? buyer_ticker,
        price,
        instance,
      },
    };
  }

  if (isAnswerPrivatePurchaseMsg(msg)) {
    /* #662: answering an offer that is no longer there is NOT an error -- the first answer settles it and
       the second finds nothing. A replayed duplicate takes this arm and changes nothing. */
    const offer = state.private_purchase_offer ?? null;
    if (!offer || offer.accepted || offer.funding || offer.private_id !== msg.AnswerPrivatePurchase.private_id) {
      return state; // #1541: a funding offer is not this arm's to settle
    }
    // #1247: a yes is recorded, not acted on; the purchase it owes is derived. A no clears the question.
    return msg.AnswerPrivatePurchase.accept
      ? { ...state, private_purchase_offer: { ...offer, accepted: true } }
      : { ...state, private_purchase_offer: null };
  }

  /* #1594: the withdrawal. The core has established it is the buyer's current president's. Clears the offer;
     moves nothing; ends no turn (S7-14). */
  if (isRescindPrivatePurchaseMsg(msg)) {
    const offer = state.private_purchase_offer ?? null;
    if (!offer || offer.funding || offer.private_id !== msg.RescindPrivatePurchase.private_id) return state;
    return { ...state, private_purchase_offer: null };
  }

  if (isProposeTrainPurchaseMsg(msg)) {
    const { seller_protocol_id, seller_ticker, buyer_protocol_id, buyer_ticker, model_type, price } =
      msg.ProposeTrainPurchase;
    const seller = state.public_companies.find((entry) => entry.company_id === seller_protocol_id);
    const buyer = state.public_companies.find((entry) => entry.company_id === buyer_protocol_id);
    if (!seller || !buyer) return state;
    const { instance, offer_serial } = allocateOfferInstance(state); // #1597
    return {
      ...state,
      offer_serial,
      train_purchase_offer: {
        seller_protocol_id,
        seller_ticker: seller.ticker ?? seller_ticker,
        seller_president: sellerPresident(state, seller_protocol_id),
        buyer_protocol_id,
        buyer_ticker: buyer.ticker ?? buyer_ticker,
        model_type,
        price,
        instance,
      },
    };
  }

  if (isAnswerTrainPurchaseMsg(msg)) {
    // #701: the same guard as #662's, for the same reason.
    const offer = state.train_purchase_offer ?? null;
    if (
      !offer ||
      offer.accepted ||
      offer.seller_protocol_id !== msg.AnswerTrainPurchase.seller_protocol_id
    ) {
      return state;
    }
    // #1247: as for the private -- recorded on a yes, cleared on a no.
    return msg.AnswerTrainPurchase.accept
      ? { ...state, train_purchase_offer: { ...offer, accepted: true } }
      : { ...state, train_purchase_offer: null };
  }

  if (isRescindTrainPurchaseMsg(msg)) {
    const offer = state.train_purchase_offer ?? null;
    if (!offer || offer.seller_protocol_id !== msg.RescindTrainPurchase.seller_protocol_id) return state;
    return { ...state, train_purchase_offer: null };
  }

  /* ==================================================================
      DESIGN NOTE 1593 (arms): THE PLAYER <-> PLAYER TRADE, SETTLED IN ITS ANSWER (Batch 7.4, D-26 / D-27)
     ==================================================================
     The core judged the proposal (rulebook 3.1 through `privateTradeRefusal`: a Stock Round after the first,
     the buyer's or the seller's turn, a distinct seated buyer, an open private the seller owns, a whole price
     of $0 or more, the buyer's cash, the certificate limit) and, on the answer, the answerer and the same
     predicate again on the board of that moment. Here the offer is written, or cleared, or settled.

     WHAT MOVES ON A YES (owner ruling N1, D-26): `price` from the buyer to the seller through the ledger --
     conserved, and $0 is a legal transfer of nothing -- and the card's `owner`. NOTHING ELSE IS TOUCHED,
     which is the whole of N1: every still-unexercised ownership-dependent power follows the card because
     every one of them is read off `owner` at the moment it is used (the M&H exchange asks `priv.owner`; the
     D&H / C&SL / JK lays and the D&H station ask the same); `used_private_abilities` is per private and is
     not rewritten, so a used ability stays used; the C&A's PRR share was granted at the auction and lives in
     `player_holdings`, so a later sale of the C&A grants nothing; the B&O's certificate and par were
     established by `SetBoPar` and live on the corporation, so a later sale of the BO private re-owes nothing
     (`boPresidencyRefusal` still refuses a second par). The BO private itself is saleable here -- 3.1's ban is
     on selling it to a CORPORATION, and `isSellableToCorporation` is deliberately not consulted.

     WHAT THE STOCK ROUND RECORDS (owner ruling N2, D-27): the trade is transaction activity by the CURRENT-TURN
     player -- the buyer or the seller whose turn it is, never the answerer as such. `turn_action_taken: true`,
     so the End Turn that follows is `advanceSeat` and not `recordPass` (#745); `consecutive_passes: 0` (the
     sale arm's own reset); `last_trader_index` = the seat, through `markTrader` (#352), so the Priority Deal
     treats that player as the latest trader. `bought_this_turn` / `bought_this_turn_company` are untouched
     (a private changing hands is not the turn's certificate purchase); the seat cursor is untouched (the
     counterparty's acceptance is an off-turn consent answer, not a turn); `stock_turn_stage` is untouched.
     All five writes are this arm's on `accept: true`; a refusal, a rejection or a rescind writes none. */
  if (isProposePrivateTradeMsg(msg)) {
    const { private_id, seller, buyer, price } = msg.ProposePrivateTrade;
    const priv = state.private_companies.find((entry) => entry.private_id === private_id);
    if (!priv) return state;
    const proposer = ctx?.actor ?? stockRoundSeat(state) ?? seller;
    const { instance, offer_serial } = allocateOfferInstance(state); // #1597: one counter for all three kinds
    return {
      ...state,
      offer_serial,
      private_trade_offer: { private_id, private_name: priv.name, seller, buyer, price, proposer, instance },
    };
  }

  if (isAnswerPrivateTradeMsg(msg)) {
    const offer = state.private_trade_offer ?? null;
    if (!offer || offer.private_id !== msg.AnswerPrivateTrade.private_id) return state; // #662's duplicate
    const cleared: GameStateResponse = { ...state, private_trade_offer: null };
    if (!msg.AnswerPrivateTrade.accept) return cleared;
    const paid = transfer(cleared, { player: offer.buyer }, { player: offer.seller }, offer.price);
    if (!paid.ok) return state; // the core has already refused this; the ledger is the last line, not the rule
    const seat = stockRoundSeat(state);
    const traded: GameStateResponse = {
      ...paid.state,
      private_companies: paid.state.private_companies.map((entry) =>
        entry.private_id === offer.private_id ? { ...entry, owner: offer.buyer, owner_protocol_id: null } : entry,
      ),
      turn_action_taken: true,
      consecutive_passes: 0,
    };
    return markTrader(traded, seat);
  }

  if (isRescindPrivateTradeMsg(msg)) {
    const offer = state.private_trade_offer ?? null;
    if (!offer || offer.private_id !== msg.RescindPrivateTrade.private_id) return state;
    return { ...state, private_trade_offer: null };
  }

  /* ==================================================================
      DESIGN NOTE 1323: THE LICENCE PURCHASE
     ==================================================================
     RULED: "During a corporation's Lay Track action step, it may purchase a Kanawha License from the Bank for
     $120. This is an optional extra action that does not replace the normal track lay." So this arm touches
     the treasury, the bank, the corporation's licence count and the game's sale counter -- and nothing about
     the sub-phase or the lay-used flag, which is what "extra" means. Gated by `kanawhaLicenseRefusal`, the
     same function the action bar asks (#784's rule: one refusal, every surface). */
  if (isBuyKanawhaLicenseMsg(msg)) {
    const companyId = msg.BuyKanawhaLicense.protocol_id;
    if (kanawhaLicenseRefusal(state, companyId) !== null) return state;
    const paid = transfer(state, { corporation: companyId }, BANK, KANAWHA_LICENSE_COST);
    if (!paid.ok) return state; // #1560: unreachable -- `kanawhaLicenseRefusal` already required the funds.
    const charged = paid.state;
    return {
      ...charged,
      kanawha_licenses_sold: (charged.kanawha_licenses_sold ?? 0) + 1,
      public_companies: charged.public_companies.map((company) =>
        company.company_id === companyId
          ? { ...company, kanawha_licenses: licensesHeldBy(company) + 1 }
          : company,
      ),
    };
  }

  if (isCloseRoomMsg(msg)) {
    /* #899: THE FIRST CLOSE WINS AND THE REST ARE NOT ERRORS. Every client runs its own countdown and any
       player may press the button, so this arm is reached several times for one closure -- by design. Both
       guards refuse SILENTLY: a player whose timer lost the race has done nothing wrong.
       THE PAYOUT IS NOT FIRED HERE. `room_closed` already true means this is a duplicate or a replay, and
       the settlement is the shell's to dispatch once on the transition -- an effect, like the accepts above,
       and the contract still owes a real guard of its own (`closeRoomPayout.ts` #899). */
    if (state.room_closed === true) return state;
    if (state.current_round_type !== "GameEnd") return state;
    return { ...state, room_closed: true };
  }

  if (isExchangePrivateMsg(msg)) {
    /* #573: THE RESOLVED GRANT, APPLIED EVERYWHERE. The legality question was answered once, by the acting
       client, before this was ever appended -- so this arm applies a decision rather than re-deriving one,
       and `ExchangePrivateMsg` carries every field that decision produced.
       `applyPrivateExchange` REFUSES A CLOSED OR MISSING PRIVATE by returning the state it was handed, which
       is what makes a replayed duplicate safe. */
    const { private_id, company_id, player, source, keep_open } = msg.ExchangePrivate;
    return applyPrivateExchange(state, {
      ok: true,
      privateId: private_id,
      companyId: company_id,
      ticker: state.public_companies.find((c) => c.company_id === company_id)?.ticker ?? "",
      player,
      source,
      // Design note #576: the B&O's grant leaves its private OPEN; every other exchange closes it.
      keepOpen: keep_open === true,
    });
  }

  /* ==================================================================
      DESIGN NOTE 1204: THE PRIVATE POWERS ARE RECORDED ON THE BOARD
     ==================================================================
     BEFORE EVERY OTHER ARM, and deliberately not inside them. Spending a power is a fact about the log
     rather than about any one message's effect -- the lay still lays and the station still places -- so
     recording it beside the arms would mean two arms remembering, which is how one of them comes not to
     (#905's exact lesson, one file over).
     ADDITIVE AND IDEMPOTENT. A replayed duplicate re-adds a key the list already holds and changes nothing;
     the list is a set spelled as an array so it survives the wire without a `Set` on the other side. */
  const spent = abilitySpentBy(msg);
  if (spent !== null && !(state.used_private_abilities ?? []).includes(spent)) {
    state = {
      ...state,
      used_private_abilities: [...(state.used_private_abilities ?? []), spent],
    };
  }

  if (isPlaceHomeStationMsg(msg)) {
    /* #550: a placement is a choice about a shared board, so it travels in the log and every client applies
       it identically.
       WITHOUT THE BOARD'S OWN LABEL TABLE THIS CANNOT BE DONE HONESTLY. `homeHexToAxial` is #363's
       injection -- the map's `label -> (q, r)` table, so a corporation that floats gets its token on the hex
       the board actually draws rather than on a coordinate this reducer guessed. A caller with no table gets
       the state back unchanged rather than a token somewhere invented, which is the same answer
       `buildOperatingOrder` gives when its price resolver is absent. */
    if (!ctx?.homeHexToAxial) return state;
    const {
      company_id: companyId,
      q,
      r,
      city_index: cityIndex,
    } = msg.PlaceHomeStation;
    return placeHomeStationToken(state, companyId, q, r, cityIndex, ctx.homeHexToAxial);
  }

  /* Three cases, each saying one thing: undefined means solo (cursor is the actor), a seated author is used, anything else is null. `??` would reinstate the nondeterminism #549 removed.
     See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #549 */
  const logged = ctx?.actor;
  const actor =
    logged === undefined
      ? state.player_addresses[state.active_player_index] ?? null
      : logged !== null && state.player_addresses.includes(logged)
        ? logged
        : null;

  /* ==================================================================
      DESIGN NOTE 1174: THE TURN CHECK THAT CANNOT LIVE HERE, AND WHY
     ==================================================================
     REPORTED: "other players are clicking buttons and triggering actions on my turn."
     AND THE DIAGNOSIS HOLDS: the only turn gate in the app is `runGameplayAction`'s `!isMyTurnRef.current`,
     on the client that dispatches, reading a `gameState` a room keeps one Firestore round trip behind
     (#1173). Nothing here has ever asked. `actor` above is resolved for ATTRIBUTION -- whose cash moves,
     whose name the log carries -- and never compared against the seat.

     I ADDED THAT COMPARISON AND IT WAS WRONG. `offTurnRefusal(state, msg, actor)` sat here, refusing a
     Stock Round `BuyStock`/`SellStock`/`PassTurn` whose actor was not `player_addresses[active_player_index]`.
     It broke ten tests across four suites, and the one that matters is `replayAttribution` -- #549's harness,
     whose whole subject is this:

       "`applySandboxAction` resolved the acting player as `state.player_addresses[state.active_player_index]`
        -- the turn cursor on whichever machine was doing the applying ... it means the reducer is not a
        function of the log: feed the same message to two clients whose cursors differ and they credit two
        different players, silently, forever after."

     #549 REMOVED THE CURSOR AS AN INPUT TO ATTRIBUTION. My gate put it back as an input to something
     STRICTER -- whether the action applies at all -- so two clients whose cursors disagreed would not merely
     credit different players, one would apply the purchase and the other would drop it. That is the same
     divergence one layer deeper, and #549's test hands the same message to `state(0)` and `state(1)` and
     asserts they agree precisely to catch it.

     SO THE AUTHORITY QUESTION IS NOT ANSWERABLE FROM INSIDE THE REPLAY, and this note is what the audit
     needs rather than a fix. "Whose turn is it" has FOUR answers and this function can compute only one:

       Stock Round        `player_addresses[active_player_index]`   the cursor -- which #549 forbids reading
       Waterfall auction  the auction's own rotation                needs `waterfallState`, not passed here
       Mini-auction       `mini_auction.current_turn` (#544)        needs `waterfallState`, not passed here
       Operating Round    the operating corporation's PRESIDENT     not the seat index at all

     And four flows are legitimately off-turn: a null actor in solo play (#549b), `automatic` dispatches
     re-attributed to `actingAddressRef`, `offTurn` consent answers on a two-party trade (#701), and a
     `SellStock` that does not advance the seat at all.
     WHAT ACTUALLY BELONGS HERE IS A TURN STAMPED ON THE LOG ENTRY -- an action carrying the seat it was taken
     for, so the check compares two things the log controls and the cursor stops being consulted. That is a
     log-format change, which is the audit's business and not a patch's.
     WHAT SHIPS INSTEAD is #1173's in-flight latch, which stops the hand that produced the report, and
     #1172's purchase count, which stops the duplicate inside a turn. Neither reads the cursor. */

  // Passing means two things: a player declining a seat-driven turn, or a CORPORATION ending its OR turn. Treating both as a seat advance strands the OR on its first company.
  // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0
  if ("PassTurn" in msg) {
    if (state.current_round_type === "OperatingRound") {
      return advanceCorporation(state, ctx?.marketPriceFor, ctx?.marketMarkFor);
    }
    /* Design note #745: ENDING A TURN IS NOT PASSING IT. A player who has already sold this turn is pressing
       this button to finish, not to decline -- selling is an action, and 1830 guarantees anyone who acts
       another opportunity before the round closes. `advanceSeat` moves the seat and leaves the streak at
       zero; `recordPass` moves it and counts. One message, two meanings, and the flag says which. */
    /* ==================================================================
        DESIGN NOTE 1443: SELL-BUY-SELL -- THE PASS WALKS THE STAGES; THE TURN ENDS ON THE LAST
       ==================================================================
       CORRECTED: "the rule for the Stock Round is Sell-Buy-Sell. Players can Sell any number of certificates,
       then Buy at most 1 certificate ... then Sell any number of shares again. This means the round should
       NOT auto-pass after a player buys a certificate."
       THREE STAGES, TWO OF THEM ON THE PASS. The turn opens on SELL (any number of sales, no advance); a
       Pass there moves to BUY; a purchase moves to SELL AGAIN (`bought_this_turn > 0`, no seat move -- see
       the `BuyStock` arm); a Pass in BUY ends the turn, since with no purchase the third stage would only
       offer what the first already did; a Pass in SELL AGAIN ("End Turn") ends it. Ending is #745's rule
       as before: a turn that acted advances without counting, one that did not is a pass in the streak.
       WHILE A HOME TOKEN IS OWED THE TURN CANNOT END (#769: the seat is held for the placement), so the Pass
       is refused by returning the state -- the shell's gate says why.
       ONLY UNDER THE REVISION: a log dealt before it (#1443 in `gameVariants.ts`) ends the turn on the buy
       as it always did, so it replays to the same board. */
    if (sellBuySellInForce(resolveVariants(state.variants))) {
      const stage = stockTurnStage(state);
      if (stage === "sell") return { ...state, stock_turn_stage: "buy" };
      if (ctx?.homeHexToAxial && pendingHomeTokens(state, ctx.homeHexToAxial).length > 0) return state;
    }
    return hasActedThisTurn(state) ? advanceSeat(state) : recordPass(state);
  }

  if ("WaterfallPass" in msg) {
    return recordPass(state);
  }

  // ---- Seat-driven rounds: the Waterfall Auction and the Stock Round.

  if ("BuyStock" in msg) {
    // The share has to actually move: adjusting cash alone left the pool, the holding and the source button unchanged, which reads as a dead button. ONE certificate per message.
    // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273
    const { protocol_id, source } = msg.BuyStock;
    const target = state.public_companies.find((c) => c.company_id === protocol_id);

    /* ==================================================================
        DESIGN NOTE 1570: THE PRICE IS A FACT ABOUT THE BOARD (Batch 7.2, ruling Q4 / D-17)
       ==================================================================
       WHAT THIS ARM USED TO DO, and #579 was right about the half it fixed and wrong about the whole:
       "The reducer reads the MESSAGE's par_value. `ctx.parValue` is assembled per browser and falls through
       to '100' on every replaying client." Both are true, and the conclusion drawn from them -- price the
       purchase from the message -- handed the price to whoever wrote the message. `{par_value: "1"}` bought a
       parred corporation's share for $1 (S7-13); an unparred IPO buy with no par at all silently became the
       President's Certificate purchase at $67 (m8/S8-9).

       THE THIRD OPTION IS THE CORPORATION ITSELF. An IPO share costs the par the corporation was STARTED at,
       which is on the board and identical on every client; a Bank Pool share costs what the token stands on
       (`market_positions`, #1196). The message's `par_value` prices exactly one purchase -- the one that sets
       the par -- and `priceStockPurchase` validates it against the chart's own ladder before it is used.
       Every other spelling of it is narration, ignored whether present, absent or forged.

       AND THE PLAN IS THE GATE'S PLAN. `stockPurchaseRefusal` in `applySandboxActionCore` has already asked
       this same function and refused everything below, so by the time this arm runs the pricing cannot fail;
       it is re-asked rather than threaded through so the two can never be handed different figures (#273's
       rule about the wallet and the chart), and a caller that reaches the arm another way still cannot
       mis-price a share. */
    const pricing = priceStockPurchase(state, purchaseIntentOf(msg.BuyStock), stockChartContext(state, ctx));
    if (!pricing.ok) return state;
    const { kind, certificates, percentage, charged, par } = pricing.plan;
    const isPresidentBuy = kind === "president" && !!actor;
    const buysDouble = kind === "double";

    /* Design note #712: THE REDUCER REFUSES TOO, and that is not belt-and-braces.
       The panel's gate is advice on one screen; this runs on every client that replays the log, so a purchase
       that should not have happened cannot enter the shared state from a stale tab, a hand-built message, or
       a client whose market grid had not loaded when the button was drawn.
       IT REUSES THE SAME FUNCTION, so the button and the board cannot disagree about a rule -- the failure
       this codebase keeps finding when a rule is stated twice. The zone comes from `ctx.marketZoneFor`, which
       is the shared chart rather than any browser's copy of it.
       A REFUSAL RETURNS THE STATE UNCHANGED rather than throwing: a replay must not halt on an entry the log
       already contains, and an illegal buy that somehow got written is best treated as a move that did
       nothing. */
    if (actor && ctx?.marketZoneFor) {
      const blocked = sharePurchaseBlock({
        state,
        buyer: actor,
        companyId: protocol_id,
        source,
        quantity: kind === "ordinary" ? certificates : 1,
        zone: ctx.marketZoneFor(protocol_id),
        marketPrices: ctx.marketPricesByCompany ?? null,
        zoneForPrice: ctx.zoneForPrice,
        certificate: buysDouble ? "double" : undefined, // #1324
        /* ==================================================================
            DESIGN NOTE 1172: THE ARGUMENT RULE 4 HAS BEEN WAITING FOR SINCE #712
           ==================================================================
           REPORTED: "they bought a share of B&O and it didn't register, so they clicked again and suddenly
           they had two B&O shares."
           `sharePurchaseBlock` HAS REFUSED THIS SINCE #712 and could never fire, because `boughtThisTurn`
           defaults to `0` and no caller -- not this one, not the panel's -- ever passed it. The rule was
           written, tested against its own unit, and unreachable in the game.
           IT NORMALLY GOES UNNOTICED because a buy ends with `advanceSeat`, so the seat moves out from under
           a second purchase and the turn gate catches it instead. Two windows defeat that: #769 HOLDS the
           seat when the purchase floats a corporation owing a home token, and a room's turn gate reads a
           `gameState` one Firestore round trip behind (#1173). In both, the seat still belongs to the buyer
           and nothing else was checking.
           THE BROWN ALLOWANCE IS UNTOUCHED, and this is why the count is certificates rather than a flag: a
           Brown-zone Bank Pool multi-buy arrives as ONE message carrying `quantity`, so it is one purchase
           however many certificates it takes, and `allowsExtraPoolBuys` still waives the rule for the second
           message as well. */
        boughtThisTurn: state.bought_this_turn ?? 0,
      });
      if (blocked !== null) return state;
    }

    /* Design note #1324: without the gate (no `marketZoneFor` in the context -- a bare harness), the double's
       own placement is still checked here, so a replay cannot move a card that is not in that pool. */
    if (buysDouble && (!target || doublePurchaseRefusal(target, source === "Bank" ? "Bank" : "Ipo") !== null)) {
      return state;
    }
    /* ==================================================================
        DESIGN NOTE 1560 (BuyStock): THE BUYER PAYS, OR THE PURCHASE DOES NOT HAPPEN
       ==================================================================
       `adjustCash` floored, so a $100 share bought with $50 in hand took the $50, credited the bank $100 and
       MINTED the other $50 -- audit C3, and the single most common non-conservation in the corpus (JUNO-3XD
       28/31/211/291-300, JUNO-Z6C 193/261/264/347-354/473-483, JUNO-FCJ 106/109/150/181-194/288-303/379).

       Refused as one movement, so nothing is charged and no certificate moves. The PRICE is no longer this
       arm's own arithmetic: Batch 7.2 (#1570) put it on `priceStockPurchase` -- the corporation's stored par
       for an IPO share, the chart for a pool share, a validated ladder par for the President's Certificate --
       and `stockPurchaseRefusal` puts the affordability RULE, with its ingress sentence, in front of this
       boundary (S7-13/D-17). The boundary stays: a later batch that adds a predicate must not remove it.

       NO ACTOR, NO MONEY. A bare harness board with no `actor` used to credit the bank anyway -- a purchase
       with no buyer that still made the bank richer. There is nobody to take it from, so nothing moves. */
    const settlement = actor === null || actor === undefined
      ? null
      : transfer(state, { player: actor }, BANK, charged);
    if (settlement !== null && !settlement.ok) return state;
    const banked = settlement === null ? state : settlement.state;
    const movedShares = moveShares(
      banked,
      protocol_id,
      actor,
      source === "Bank" ? "Bank" : "Ipo",
      percentage,
    );
    // #1324: the card follows the twenty it names.
    const moved = buysDouble && actor ? withDoubleAt(movedShares, protocol_id, actor) : movedShares;

    /* Presidency and par written together -- the panel locks its ladder on par_value !== null.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #351 */
    const crowned = isPresidentBuy
      ? {
          ...moved,
          public_companies: moved.public_companies.map((company) =>
            company.company_id === protocol_id
              ? {
                  ...company,
                  president: actor,
                  /* Design note #1570: THE VALIDATED PAR, and only it. #579 took the figure from the message
                     because `ctx.parValue` was a per-browser ladder selection; the message is no better a
                     source on its own, so `priceStockPurchase` has already checked this par against the
                     chart's own par boxes, checked that the buyer can pay twice it, and returned it. The
                     presidency and the par are still written together, because a corporation cannot be
                     presided over and priceless at the same time (#399). */
                  par_value: company.par_value ?? String(par),
                }
              : company,
          ),
        }
      : moved;

    /* Buying is the only action that can cross the float threshold, so the check rides on it. Without homeHexToAxial the company still floats and simply gets no token.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #363 */
    const floated = ctx?.homeHexToAxial
      ? applyFloatThreshold(crowned, ctx.homeHexToAxial)
      : crowned;

    /* Design note #596: a purchase can take the presidency off somebody. Run
       AFTER the float check, because a buy that both floats a company and
       crowns a new president must resolve the float against the holdings that
       caused it, not against a board mid-transfer. */
    /* Design note #1172: the count the rule above reads, recorded on the purchase that earns it. CERTIFICATES
       taken, not messages sent, so a Brown-zone pool buy of three reports three -- and ACCUMULATED rather
       than set, because the Brown allowance permits a second message in the same turn and the rule needs the
       running total to judge it. Cleared by the three sites that clear `turn_action_taken` (#745). */
    /* ==================================================================
        DESIGN NOTE 1447: THE BUY COUNTS AS THIS TURN'S ACTION, BECAUSE IT NO LONGER ENDS THE TURN
       ==================================================================
       REPORTED from a playtest: "we all only got one round during the Stock Round and then it pushed us to
       the Operating Round -- nobody has floated." Three players each bought a president's certificate and
       the round ended anyway.

       #745 PUT THIS FLAG ON THE SALE ONLY, and said exactly why: "Set here rather than in `moveShares`
       because a sale is the only Stock Round action that leaves the seat where it is; every other one ends
       the turn itself." That was true when it was written. #1443 MADE IT FALSE -- under Sell-Buy-Sell the
       purchase is the middle of the turn and the seat stays with the buyer, who ends the turn with a Pass.

       SO THE PASS AFTER A PURCHASE WAS READ AS A PASS. `PassTurn` ends with
       `hasActedThisTurn(state) ? advanceSeat(state) : recordPass(state)`, the flag was still false, and
       `recordPass` counted a player who had just bought into the streak. Three buyers, three counted passes,
       streak equals the player count, Stock Round over with nothing floated -- and an Operating Round with an
       empty queue (#1448).

       ACCUMULATED WITH THE COUNT, on the same purchase, for #745's own reason: "the flag is what survives
       between the two messages." Set here rather than on the `sellBuySellInForce` branch below so both
       early returns carry it -- that branch and #769's home-token hold. Under the old revision the buy falls
       through to `advanceSeat`, which clears the flag on its way past, so a pre-#1443 log replays unchanged. */
    /* Design note #1570: AND WHICH CORPORATION IT WAS SPENT ON (S7-18, ruling Q9 / D-22). Rulebook §4.4's
       Brown allowance is "any number of certificates from the bank pool of ONE corporation", and the engine
       spells that allowance as several messages -- so the corporation of the FIRST purchase of the turn is
       what the continuation is judged against. Written once and not overwritten by the continuation itself,
       which names the same corporation anyway; cleared with `bought_this_turn` by all three seat sites. */
    const counted: GameStateResponse = {
      ...settlePresidencies(floated).state,
      bought_this_turn: (state.bought_this_turn ?? 0) + certificates,
      bought_this_turn_company: state.bought_this_turn_company ?? protocol_id,
      turn_action_taken: true,
    };
    const settledBuy = markTrader(counted, actor);

    /* ==================================================================
       DESIGN NOTE 769: THE SEAT STAYS WITH THE PRESIDENT UNTIL THE TOKEN IS DOWN
       ==================================================================
       REPORTED: "After a corporation floated, the president player did not immediately know they needed to
       place the station ... It immediately moved to the other player's turn, even though the President player
       hadn't placed their home station: the other player's button clicks were logged in the activity log, but
       nothing happened."
       #763 STOPPED THE OTHER PLAYER ACTING AND LEFT THE SEAT WHERE IT SHOULD NOT BE. The float happens ON this
       purchase, and the purchase ends by advancing the seat -- so the round announced somebody else's turn and
       then refused everything they tried. Two players both stuck, and neither screen said why.
       BEING REFUSED IS NOT THE SAME AS NOT BEING ASKED. A gate that blocks actions is correct and invisible;
       what tells a table whose move it is, is the cursor. So the seat is held rather than advanced, which
       makes the obligation legible from every screen without anybody reading a message.
       ONLY WHEN THIS PURCHASE OWES A TOKEN. A buy that floats nothing advances the seat exactly as before --
       the condition is the debt, not the float, so a corporation with no resolvable home hex (#416) does not
       freeze the round. */
    if (ctx?.homeHexToAxial && pendingHomeTokens(settledBuy, ctx.homeHexToAxial).length > 0) {
      return settledBuy;
    }
    /* #1443: under Sell-Buy-Sell the purchase is the middle of the turn, not its end -- the seat stays with
       the buyer, who may sell again and then ends the turn with a Pass. */
    if (sellBuySellInForce(resolveVariants(settledBuy.variants))) return settledBuy;

    return advanceSeat(settledBuy);
  }

  if ("SellStock" in msg) {
    // Selling does not advance the seat (trading.rs #9) and sold shares go to the BANK POOL, never the IPO. The message says how much, so honour it.
    // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #273
    const { protocol_id, percentage } = msg.SellStock;
    const sold = Math.max(SANDBOX_SHARE_PERCENTAGE, Math.round(percentage));

    /* ==================================================================
     *  DESIGN NOTE 748: THE SELL SIDE HAD NO AUTHORITY AT ALL
     * ==================================================================
     *
     * REPORTED: "P1 had a 10% share and P2 had a 50% share including the 1 President's certificate. P1 sold
     * their 10% share and P2 was then able to sell 40%: this respected the 50% bank pool limit, but it did not
     * respect the rule that a President's certificate can never be sold."
     *
     * `shareSaleBlock` REFUSES THAT SALE, AND HAS SINCE #713. Run against the reported board it returns
     * "Selling 40% would leave you under the 20% President's Certificate, and no other player holds 20% to
     * take it." The rule was right, the message was right, and nothing in the reducer ever asked.
     *
     * ONE CALLER, AND IT WAS THE PANEL. `shareSaleBlock` had exactly one call site -- `App.saleBlockFor`,
     * feeding a disabled state on the Stock Round card. So the rule was advice on one screen while the log
     * accepted anything: a stale tab, a replay, a hand-built message, or any second sell control written
     * later all went straight through. #736's phrasing fits it exactly -- readers with no writer.
     *
     * WHAT MAKES THIS ONE POINTED is that #712 fixed precisely this for the BUY side twenty lines above, and
     * #744 got its enforcement for free BECAUSE that work had been done -- "the reducer already routed buys
     * through `sharePurchaseBlock`, so adding the rule there closed both at once". The sell side never got the
     * same treatment, and nothing on screen distinguished the two.
     *
     * A REFUSAL RETURNS THE STATE UNCHANGED, on #712's reasoning: a replay must not halt on an entry the log
     * already contains, and an illegal sale that somehow got written is best treated as a move that did
     * nothing. */
    if (actor) {
      const refused = shareSaleBlock({
        state,
        seller: actor,
        companyId: protocol_id,
        percentage: sold,
      });
      if (refused !== null) return state;
    }

    const takings = ctx?.sharePrice ?? SANDBOX_NOMINAL_SHARE_PRICE;

    /* #1560: the bank funds the sale and its balance may go NEGATIVE doing it (D-15/Q1b) -- the old floor
       made the bank's figure a fiction the moment it broke, and `debitBank` latches `bank_broken` instead
       (#1561). No actor, no movement: there is nobody to pay. */
    const takingsPaid = actor === null || actor === undefined
      ? null
      : transfer(state, BANK, { player: actor }, takings);
    if (takingsPaid !== null && !takingsPaid.ok) return state;
    const returnedShares = moveShares(
      takingsPaid === null ? state : takingsPaid.state,
      protocol_id,
      actor,
      "Bank",
      -sold,
    );
    /* Design note #1324: WHICH CARD WENT. The percentages above are already right for both the block sale and
       the half-sale (the pool nets +10 either way in the half case: the card goes in, a 10% card comes out).
       What the percentages cannot record is that the 20% certificate is now the pool's, so that is written
       here. A refused half-sale never reaches this arm -- `shareSaleBlock` above asks `doubleSaleRefusal`. */
    const sellingCompany = state.public_companies.find((entry) => entry.company_id === protocol_id);
    const doubleEffect =
      actor && sellingCompany ? doubleSaleEffect(sellingCompany, actor, sold) : { kind: "none" as const };
    if (doubleEffect.kind === "refused") return state;
    const returned =
      doubleEffect.kind === "block" || doubleEffect.kind === "half"
        ? withDoubleAt(returnedShares, protocol_id, "Bank")
        : returnedShares;
    // A sale moves the crown too -- selling below another holder hands them the presidency. Same function as the buy, so the two cannot disagree.
    // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #596
    /* Design note #744: AND IT LOCKS THE BUY-BACK. Reported: a player sold and then bought the same
       corporation in the same Stock Round, which is how a stock price is crated and restocked at the bottom.
       Recorded on the SALE rather than checked at the buy, because the buy cannot see backwards: the log has
       the sale, but a reducer arm sees only its own message. The record is the memory. */
    /* Design note #745: AND IT COUNTS AS THIS TURN'S ACTION. `consecutive_passes: 0` below already broke the
       streak, but the seat does not move on a sale -- the player may still buy -- so the Pass that finishes
       the turn was putting the streak straight back to one and erasing the sale. The flag is what survives
       between the two messages. Set here rather than in `moveShares` because a sale is the only Stock Round
       action that leaves the seat where it is; every other one ends the turn itself. */
    const settled = markTrader(
      { ...settlePresidencies(returned).state, consecutive_passes: 0, turn_action_taken: true },
      actor,
    );
    if (!actor) return settled;
    const already = settled.sold_this_round?.[actor] ?? [];
    if (already.includes(protocol_id)) return settled;
    return {
      ...settled,
      sold_this_round: {
        ...(settled.sold_this_round ?? {}),
        [actor]: [...already, protocol_id],
      },
    };
  }

  /* ==================================================================
      DESIGN NOTE 1232: A CONTEST SUSPENDS THE ROTATION -- ON BOTH ATOMS
     ==================================================================
     REPORTED: "a mini-auction occurred, and then the game locked after the mini-auction concluded. It says
     it's one person's turn but nothing they click does anything."

     THE TRACE, from replaying the six-action log:

       after #4 WaterfallBuyLowest        seat=0  wf.current_turn=sandbox  mini={turn: Host}  acting=Host
       after #5 WaterfallMiniAuctionPass  seat=1  wf.current_turn=sandbox  mini=null          acting=Host

     THE AUCTION ATOM DID THE RIGHT THING. #544: "while a contest is live the main rotation does not advance ...
     the reducer has preserved `waterfall.current_turn` across a contest since #338 precisely so it can be
     resumed untouched." So its cursor stayed on sandbox, whose turn it was when the contest began.
     THIS ARM DID NOT. It advanced the seat on every waterfall message alike, contest actions included -- so
     the pass moved the seat to Host while the auction still waited for sandbox. `actingAddress` reads the seat
     when no contest is live (#544 says that field "is right about the WATERFALL", which was true only while
     this arm kept it so). Host's clicks passed the gate and died in an auction that was not theirs; sandbox's
     clicks died at the gate. Nobody could move.

     THE MINI-AUCTION MESSAGES LEAVE THE SEAT ALONE. A raise or a pass inside a contest is a move in a
     sub-sequence, not a step of the rotation; the rotation resumes where it was suspended, on both atoms,
     because neither moved it. #1232 in `gameState.ts` closes the same hole from the reading side. */
  if ("WaterfallMiniAuctionRaise" in msg || "WaterfallMiniAuctionPass" in msg) {
    return state;
  }

  if ("WaterfallBuyLowest" in msg || "WaterfallBidHigher" in msg || "BidOnPrivate" in msg) {
    return advanceSeat(state);
  }

  // OR actions charge the acting CORPORATION and none of them end its turn -- only PassTurn does. protocol_id comes off the message, not the queue cursor.
  // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0
  // Design note #1510: AND IT IS CHECKED AGAINST THE CURSOR before any of these arms run -- see
  // `operatingIdentityRefusal` in `applySandboxActionCore`. The message still names the corporation; it no
  // longer decides it.

  if ("LayTile" in msg) {
    /* The GROUND costs money, not the tile: $0 clear, $80 river, $120 mountain, by coordinate. The flat $20 was a placeholder the renderer had been contradicting on screen.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #432 */
    /* Design note #723: AND IT IS PAID ONCE. Reported twice -- "it is wrong to keep charging the terrain cost
       for every lay track action on a terrain hex". This arm charged unconditionally and always had; the rule
       existed only in `pendingTileCost` (#673), which is the figure the player is SHOWN. So an upgrade over a
       river previewed as free and debited $80, and the only surface anybody could check was the one telling
       them it was fine.
       THE SET LIVES IN STATE, not on the tile grid -- `terrainFee.ts` #723 has the reasoning, and it is about
       replay: `ctx.mapGrid` does not advance action by action inside the Undo rebuild loop, so a board lookup
       here would be right live and wrong on every rebuild. */
    const { protocol_id, q, r, token_city, token_cities, tile_id } = msg.LayTile;
    /* Design note #1323: THE JK'S HALF-PRICE LAY. "The corporation owning JK may choose to close the private
       company to lay one track on any hex adjacent to L8 at half price. This counts as the corporation's
       normal tile lay action." So the key halves the terrain fee, closes the JK, and otherwise this is an
       ordinary lay -- connectivity and the rest are judged where they always are. A key that does not pass
       `jkTileRefusal` refuses the whole lay rather than laying at full price, because the player chose the
       power and a silent substitution is the kind of divergence #891 records. */
    const abilityKey = (msg.LayTile as { ability_key?: unknown }).ability_key;
    const jkLay = abilityKey === JK_TILE_ABILITY_KEY;
    if (jkLay && jkTileRefusal(state, protocol_id, q, r) !== null) return state;
    const fullFee = terrainFeeDue(state.terrain_fees_paid, q, r, terrainBuildFeeAt);
    const fee = jkLay ? jkHalfFee(fullFee) : fullFee;
    if (jkLay) {
      state = {
        ...state,
        private_companies: state.private_companies.map((entry) =>
          entry.private_id === JK_PRIVATE_ID ? { ...entry, closed: true } : entry,
        ),
      };
    }
    /* Design note #1315: THE TILE CANNOT HOLD A CITY INDEX IT DOES NOT HAVE. The shell's plan (`tokenMigration`)
       lands every token, and a log written by an older client carries no `token_cities` at all -- so after
       the map is applied, any token on this hex still pointing at a city the new tile lacks is clamped to the
       last city it has. For #62 -> #883 that is index 1 -> 0, the merge; for every ordinary lay it is a
       no-op, because a tile that shrinks its city count is not a legal upgrade. */
    const cityCap = Math.max(1, tileCitySlotCounts(tile_id).length);
    const clampCity = (city: number) => Math.min(city, cityCap - 1);
    /* ==================================================================
       DESIGN NOTE 891: THE GROUND HAS TO BE PAID FOR, NOT MERELY BILLED
       ==================================================================
       REPORTED: "B&O had $0 in its treasury and was able to lay a track tile on a terrain hex costing $80.
       Its treasury stayed $0."
       BOTH HALVES OF THAT SENTENCE HAD ONE CAUSE, and it was `adjustTreasury`, which ended
       `Math.max(0, current + delta)`. That floor was right for its other callers -- a treasury must not go
       negative -- and here it turned an unaffordable charge into a SILENT no-op: the debit was issued, the
       clamp swallowed it, the tile landed, and nothing anywhere said no. #723 taught this arm to charge the
       fee once; nobody had asked whether it could be charged at all.
       SO THE CHECK IS HERE, BEFORE THE RECORD IS BUILT. Returning the state unchanged is how every other
       refusal in this reducer is spelled, and it refuses the WHOLE action -- the tile does not land, which is
       the rule 1830 actually has. A corporation that cannot pay the terrain cost may not build there.
       THE UI REFUSES FIRST (`App.tsx` #891) so a player is told rather than ignored; this is the authority
       behind that, and it is the one that survives a replay. */
    const layingTreasury = Number(
      state.public_companies.find((company) => company.company_id === protocol_id)?.treasury ?? 0,
    );
    if (fee > 0 && (!Number.isFinite(layingTreasury) || layingTreasury < fee)) return state;
    const recorded: GameStateResponse = {
      ...state,
      terrain_fees_paid: withTerrainPaid(state.terrain_fees_paid, q, r, fee),
      /* ==================================================================
         DESIGN NOTE 824: THE TOKEN GOES WHERE THE PRESIDENT PUT IT
         ==================================================================

         REPORTED, of ERIE's home: "in an actual physical game, when a player upgrades ERIE's home hex, the
         station is removed from the board to place the new tile, then the player sets their token where they
         want it. Because there is no marking for 'City 1' vs 'City 2' on the preprinted yellow hex, there is
         no way to debate whether one city or the other is the correct one."

         SO THE INDEX WAS OURS AND NOT THE BOARD'S. `tokenMigration.ts` #824 has the argument; this is the
         half that makes it stick, because a choice the log does not carry is a choice that does not survive
         a replay -- and "the log is the game" (#522).

         EVERY TOKEN ON THE HEX MOVES, not only the acting corporation's. On an unlaid preprinted OO hex the
         cities are indistinguishable for whoever is standing there, so a second occupant's index is exactly
         as arbitrary as the first's. In practice there is one -- nobody else may token these hexes before
         they are upgraded -- but a rule that quietly assumed that would be a rule about the board rather than
         about the cardboard.
         ABSENT MEANS UNCHANGED, which is every ordinary upgrade in the game.

         ==================================================================
          DESIGN NOTE 880: BOTH ARMS OF THAT WERE WRONG
         ==================================================================
         ASKED: "If a tile has multiple stations and a corporation upgrades it, it is necessary that all the
         stations maintain their connectivity, not just the one whose corporation is upgrading."

         "EVERY TOKEN ON THE HEX MOVES" WAS TRUE AND MOVED THEM ALL TO ONE CITY. Right for ERIE's home, where
         only one token stands; on a shared OO hex it stacks two corporations into the same circle.
         "ABSENT MEANS UNCHANGED" WAS THE LIVE BUG. Every ordinary upgrade sent nothing, so no token ever
         moved -- and #878 is the finding that a token's city is NOT preserved across an upgrade, it is
         recomputed from the network. This arm is why the report said "upgrades to OO tiles are not
         preserving corporation station network connectivity": the frontend could compute the right city and
         had no way to say it, and the reducer's default was to do nothing.

         SO THE MAP DECIDES, PER COMPANY, and `token_city` survives only as the old spelling: a log written
         before this must replay to where it landed then (#522, "the log is the game"). */
      public_companies: (() => {
        const perCompany = new Map<number, number>(token_cities ?? []);
        if (perCompany.size === 0 && token_city === undefined) return state.public_companies;
        return state.public_companies.map((company) => {
          /* THE OLD SPELLING APPLIED TO EVERYBODY, which is what it meant when it was written; the new one
             applies to the company it names and leaves the rest alone. */
          const city = perCompany.has(company.company_id)
            ? perCompany.get(company.company_id)
            : perCompany.size === 0
              ? token_city
              : undefined;
          if (city === undefined) return company;
          return {
            ...company,
            station_tokens:
              company.station_tokens?.map((entry) =>
                entry[0] === q && entry[1] === r
                  ? ([entry[0], entry[1], clampCity(city)] as [number, number, number])
                  : entry,
              ) ?? null,
          };
        });
      })(),
    };
    /* #1315, the other half: tokens the message did not name (an older log, or a lay the shell sent without a
       plan) are clamped too, so no token on this hex can outlive the city it stood in. */
    const merged: GameStateResponse = {
      ...recorded,
      public_companies: recorded.public_companies.map((company) => {
        const tokens = company.station_tokens;
        if (!tokens || !tokens.some(([tq, tr, city]) => tq === q && tr === r && city > cityCap - 1)) {
          return company;
        }
        return {
          ...company,
          station_tokens: tokens.map((entry) =>
            entry[0] === q && entry[1] === r
              ? ([entry[0], entry[1], clampCity(entry[2])] as [number, number, number])
              : entry,
          ),
        };
      }),
    };
    /* ==================================================================
        DESIGN NOTE 1560 (terrain): THE GROUND IS PAID FOR TO SOMEBODY
       ==================================================================
       #891 made the fee unaffordable-proof; what nobody asked was where the money WENT. `adjustTreasury(-fee)`
       stood alone, so every terrain lay in every game destroyed the fee (S7-10). The Bank is the counterparty
       of a terrain cost as it is of every other purchase (owner ruling D-15/Q1a), so this is a transfer.
       The legality and affordability gates above are untouched: the fee is still the authoritative
       `terrainFeeDue`, still charged once per hex (#723), and a corporation that cannot pay still may not
       build. A refused transfer refuses the WHOLE lay -- `state`, not `merged` -- which is #891's own rule. */
    if (fee <= 0) return merged;
    const paid = transfer(merged, { corporation: protocol_id }, BANK, fee);
    return paid.ok ? paid.state : state;
  }

  if ("BuyHardwareFromPool" in msg) {
    return buyDepotTrain(
      state,
      msg.BuyHardwareFromPool.protocol_id,
      true,
      msg.BuyHardwareFromPool.returned_model_type, // #1314: a returned train, when named
      msg.BuyHardwareFromPool.model_type, // #1326: the shelf tier, when named
    );
  }

  /* ==================================================================
      DESIGN NOTE 1303: THE D-TRAIN EXCHANGE
     ==================================================================
     Project 18XX+: "a 4-, 5- or 6-train may be traded in to purchase a D-train for $800." One train out, one
     Diesel in, $800 treasury to bank -- and the phase settles from the fleet as it always does, so the FIRST
     Diesel on the board rusts every 4-train (Gentle Rust aware, through the same `applyPhaseChange`).
     THE TRADED TRAIN LEAVES BEFORE THE PHASE TURNS, so a 4-train traded in on the first exchange is exchanged
     rather than rusted: it is gone from `owned_trains` by the time the rust sweep looks. And a traded-in train
     never returns to the depot -- the depot is derived from the fleet, and once the Diesel is for sale every
     lower tier reads as sold out (#4's queue rule), so nothing can resell it.
     GATED BY `dieselExchangeRefusal`, the same function the REFUSED line and the panel ask (#784). Refuses by
     returning the state it was handed, which is what every gate here does and what #778 detects. */
  if ("ExchangeTrainForDiesel" in msg) {
    const { protocol_id, model_type } = msg.ExchangeTrainForDiesel;
    if (dieselExchangeRefusal(state, protocol_id, model_type) !== null) return state;

    const exchangeCost = dieselExchangeCostFor(state); // #1326: $750 under the Level Playing Field
    const paidCost = transfer(state, { corporation: protocol_id }, BANK, exchangeCost);
    if (!paidCost.ok) return state; // #1560: unreachable -- `dieselExchangeRefusal` asked `trainPurchaseRefusal`.
    const banked = paidCost.state;
    const before = derivePhase(state)?.tier ?? null;
    const exchanged = withTrains(banked, protocol_id, (trains) => {
      const at = trains.indexOf(model_type);
      const rest = at < 0 ? [...trains] : [...trains.slice(0, at), ...trains.slice(at + 1)];
      return [...rest, DIESEL_TIER];
    });
    const after = derivePhase(exchanged)?.tier ?? null;
    /* Design note #1314: THE TRADED TRAIN GOES BACK TO THE BANK. RULED: it "must be returned to the Bank's
       Supply Depot, where it becomes available for any corporation to purchase at face value (provided it
       hasn't rusted)". Returned BEFORE the phase settles, so a 4-train traded in for the very first Diesel
       is put in the depot and then scrapped by the same rust sweep that takes every other 4 -- the depot is
       not a place to hide a train from the phase. */
    const returned: GameStateResponse = {
      ...exchanged,
      returned_trains: [...(exchanged.returned_trains ?? []), model_type],
    };
    return after !== null && after !== before ? applyPhaseChange(returned, after) : returned;
  }

  /* ==================================================================
      DESIGN NOTE 1541: THE EMERGENCY PRIVATE SALE AND THE DECLARATION (arms)
     ==================================================================
     Each was judged in `applySandboxActionCore` against the standing obligation; here they only move state.
     The offer is the ordinary `private_purchase_offer` marked `funding`, so every prompt that reads the
     register sees it; acceptance settles through `transferPrivateToCorporation`, the one transfer every
     corporate purchase of a private uses, and the shortfall is simply re-read afterwards. */
  if ("OfferPrivateForFunding" in msg) {
    const { private_id, buyer_protocol_id, price } = msg.OfferPrivateForFunding;
    const priv = state.private_companies.find((entry) => entry.private_id === private_id);
    const buyer = state.public_companies.find((entry) => entry.company_id === buyer_protocol_id);
    if (!priv || !priv.owner || !buyer) return state;
    return {
      ...state,
      private_purchase_offer: {
        private_id,
        private_name: priv.name,
        owner: priv.owner,
        buyer_protocol_id,
        buyer_ticker: buyer.ticker,
        price,
        funding: true,
      },
    };
  }
  if ("AnswerFundingPrivateOffer" in msg) {
    const offer = state.private_purchase_offer ?? null;
    if (!offer || !offer.funding || offer.private_id !== msg.AnswerFundingPrivateOffer.private_id) return state;
    const cleared: GameStateResponse = { ...state, private_purchase_offer: null };
    if (!msg.AnswerFundingPrivateOffer.accept) return cleared;
    return transferPrivateToCorporation(cleared, offer.buyer_protocol_id, offer.private_id, offer.price);
  }
  if ("RescindFundingPrivateOffer" in msg) {
    const offer = state.private_purchase_offer ?? null;
    if (!offer || !offer.funding || offer.private_id !== msg.RescindFundingPrivateOffer.private_id) return state;
    return { ...state, private_purchase_offer: null };
  }
  if ("DeclareBankruptcy" in msg) {
    /* Rulebook 6.7, declared rather than derived only because an optional private sale was still possible
       (#1541). The core refused every premature declaration; the ending is written exactly as
       `settleBankruptcy` writes it. */
    const funding = emergencyFundingFor(state, ctx?.mapGrid);
    if (funding === null) return state;
    return {
      ...state,
      current_round_type: "GameEnd" as const,
      bankrupt_president: funding.president,
      operating_sub_phase: undefined,
    };
  }

  /* ==================================================================
      DESIGN NOTE 1530: THE PRESIDENT'S DISCARD
     ==================================================================
     Rulebook 6.6.1, the half the trim used to decide. Exactly the named train leaves the fleet (the first
     matching copy -- two 3-trains are interchangeable) and enters the Bank Pool (`returned_trains`, the one
     structure #1512 established for trains the bank holds loose), where it is purchasable at face value.
     Nobody is paid: "its railroad receives no payment for it". The obligation is not tracked, so nothing
     here advances it -- `pendingTrainDiscards` reads the fleet that results, still owes the same corporation
     while it is still over, names the next one when it is not, and owes nothing when none is. The gate in
     `applySandboxActionCore` has already refused a discard that is not this corporation's, its president's,
     or of a train it holds. */
  if ("DiscardTrain" in msg) {
    const { protocol_id, model_type } = msg.DiscardTrain;
    const company = state.public_companies.find((entry) => entry.company_id === protocol_id);
    const owned = company?.owned_trains;
    if (!company || owned == null) return state;
    const at = owned.indexOf(model_type);
    if (at < 0) return state;
    const remaining = [...owned.slice(0, at), ...owned.slice(at + 1)];
    return {
      ...state,
      public_companies: state.public_companies.map((entry) =>
        entry.company_id === protocol_id ? { ...entry, owned_trains: remaining } : entry,
      ),
      returned_trains: [...(state.returned_trains ?? []), model_type],
    };
  }

  if ("EmergencyBuyHardware" in msg) {
    /* The president's money actually moves: treasury pays what it has, president covers the shortfall, then buyDepotTrain runs against an exact balance so its arithmetic is unchanged.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #333 */
    const companyId = msg.EmergencyBuyHardware.protocol_id;
    /* Design note #1512: THE CHEAPEST TRAIN THE BANK WILL SELL, from the depot or the Bank Pool -- one
       question, asked of `cheapestPurchasableTrain`, which the shell's emergency plan asks too. This read
       `depotInventory(state).find(remaining > 0)`: the depot's first row with stock, never the pool (M9). */
    const cheapest = cheapestPurchasableTrain(state);
    if (!cheapest) return state;
    const company = state.public_companies.find((entry) => entry.company_id === companyId);
    const treasury = Number(company?.treasury) || 0;
    const shortfall = Math.max(0, cheapest.cost - treasury);
    const buy = (funded: GameStateResponse) =>
      cheapest.source === "pool"
        ? buyDepotTrain(funded, companyId, false, cheapest.tier)
        : buyDepotTrain(funded, companyId, false, undefined, cheapest.tier);
    /* Design note #1019: the funds check is waived on this path and every other rule still applies -- the
       president may cover a shortfall, not buy out of turn or out of phase. */
    if (shortfall === 0 || !company?.president) return buy(state);
    /* ==================================================================
        DESIGN NOTE 1513: THE PRESIDENT PAYS WHAT THE PRESIDENT HAS
       ==================================================================
       `adjustCash` floored at zero (retired by #1560), so a president with $100 against a $360 shortfall used
       to pay $100 and the
       corporation got the train anyway -- money minted by a clamp (audit C4c). Refused instead, by identity:
       the obligation then stands (#1513 in `trainAvailability.ts`), which is the honest state and the one
       Batch 5's funding cascade -- share sales, then bankruptcy -- is written to resolve. Nothing here
       decides how the shortfall is raised; it only declines to invent the money. */
    const presidentCash = Number(
      state.player_cash.find((entry) => entry.player === company.president)?.cash_vgp ?? 0,
    );
    if (!Number.isFinite(presidentCash) || presidentCash < shortfall) return state;
    // The president's contribution passes THROUGH the treasury, which is
    // what makes `buyDepotTrain`'s single treasury -> Bank transfer correct
    // for both the ordinary and the emergency case.
    const funded = transfer(state, { player: company.president }, { corporation: companyId }, shortfall);
    if (!funded.ok) return state; // #1560: unreachable -- the cash check above is #1513's own gate.
    return buy(funded.state);
  }

  if ("BuyTrainFromCorporation" in msg) {
    /* Settle the transfer; whether the counterparty AGREED is train_trade.rs's offer flow and the panel's consent modal. One train, since msg.rs carries no count.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #191 */
    const { buyer_protocol_id, seller_protocol_id, model_type, price } =
      msg.BuyTrainFromCorporation;
    /* #1247: THE OFFER THIS PURCHASE SETTLES COMES OFF THE BOARD FIRST, whatever the sale then does. Cleared
       before `settleTrainSale` rather than after, because a sale that cannot be made (the train has gone)
       must still retire the accepted offer -- otherwise `nextDerivedAction` would owe the same purchase
       again on the next look, and again. The cost is #778's identity check reading a cleared-but-unsold
       board as "applied"; a train that vanished between offer and answer is rarer than a loop is bad. */
    const offer = state.train_purchase_offer ?? null;
    const settling =
      offer !== null &&
      offer.seller_protocol_id === seller_protocol_id &&
      offer.buyer_protocol_id === buyer_protocol_id &&
      offer.model_type === model_type
        ? { ...state, train_purchase_offer: null }
        : state;
    /* Design note #1513: the buyer's limit (rulebook 6.6, audit M14) is asked in `applySandboxActionCore`,
       before this arm, so the refusal is by identity. */
    /* #1541 (owner rule): under a forced obligation the treasury pays first and the president pays the rest
       -- through the treasury, exactly as the emergency purchase does, so `settleTrainSale`'s single charge is
       right. The core has already refused a trade the two cannot cover. */
    const funding = emergencyFundingFor(settling, ctx?.mapGrid);
    const paid = Number(price) || 0;
    /* #1560: the contribution is a transfer like any other. A refusal here leaves the OFFER cleared and the
       money alone, and `settleTrainSale` then refuses the sale for want of a treasury -- which is the same
       outcome, without #1247's derived-action loop. `fundedTradeRefusal` has already refused a trade the
       treasury and the president cannot cover between them (D-6), so it does not fire in play. */
    const contribution =
      funding !== null && funding.companyId === buyer_protocol_id && paid > funding.treasury
        ? transfer(
            settling,
            { player: funding.president },
            { corporation: buyer_protocol_id },
            paid - funding.treasury,
          )
        : null;
    const funded = contribution !== null && contribution.ok ? contribution.state : settling;
    return settleTrainSale(funded, buyer_protocol_id, seller_protocol_id, model_type, price);
  }

  if ("BuyPrivateCompany" in msg) {
    // The private has to actually change hands. Whether the trade was PERMITTED stays with trading.rs::execute_buy_private_company.
    // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0
    const { protocol_id, private_id, price } = msg.BuyPrivateCompany;
    // #1247: the offer this purchase settles comes off the board first -- see `BuyTrainFromCorporation`.
    const pending = state.private_purchase_offer ?? null;
    if (pending !== null && pending.private_id === private_id) {
      state = { ...state, private_purchase_offer: null };
    }
    return transferPrivateToCorporation(state, protocol_id, private_id, Number(price) || 0);
  }

  if ("PlaceStationToken" in msg) {
    /* Record the slot ONLY when city_index is in the message -- declining to write down information the app was given is not restraint. Both arrays written in the same order and the same breath.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #560 */
    const { protocol_id, q, r } = msg.PlaceStationToken;
    const placedCityIndex =
      typeof msg.PlaceStationToken.city_index === "number"
        ? msg.PlaceStationToken.city_index
        : null;
    // Idempotent per hex. Not a rules claim -- the contract decides whether a
    // second token there is legal. This is so a double-click cannot stack two
    // markers on one hex and charge for both, which would be a rendering bug
    // rather than a simulated rule.
    const owner = state.public_companies.find((company) => company.company_id === protocol_id);
    if (owner?.station_token_hexes.some(([hq, hr]) => hq === q && hr === r)) {
      return state;
    }
    /* The token price escalates: home free, second $40, third onward $100. stationTokenPrice is the same schedule the button quotes.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #239 */
    const placedCount = owner?.station_token_hexes.length ?? 0;
    // #1302: a corporation whose home is a printed herald has no free home placement -- its first token is its second station.
    const cost = stationTokenPrice(placedCount, heraldHexFor(protocol_id) !== null);
    const placed: GameStateResponse = {
      ...state,
      public_companies: state.public_companies.map((company) =>
        company.company_id === protocol_id
          ? {
              ...company,
              station_token_hexes: [...company.station_token_hexes, [q, r] as [number, number]],
              // Design note #560: together, always.
              station_tokens:
                placedCityIndex === null
                  ? company.station_tokens ?? null
                  : [
                      ...(company.station_tokens ?? []),
                      [q, r, placedCityIndex] as [number, number, number],
                    ],
            }
          : company,
      ),
    };
    // #1560: `stationPlacementGate` (#1511) has already required `treasury >= cost`, so this cannot refuse
    // in play; a refusal refuses the whole placement rather than landing a token nobody paid for.
    const paidToken = transfer(placed, { corporation: protocol_id }, BANK, cost);
    return paidToken.ok ? paidToken.state : state;
  }

  if ("RunManualRoute" in msg) {
    // Running a route RECORDS; declaring pays. payout_strategy is deliberately not read here.
    // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #192
    const { protocol_id, path } = msg.RunManualRoute;
    // #1323: the legacy arm keeps the same licence gate as the live one.
    if (!mayCrossCoalRiver(state, protocol_id) && routeCrossesCoalRiver(path)) return state;
    // The flat nominal is now only the FALLBACK. With a map to read, the
    // figure comes from the stops the player actually selected, so building
    // a longer route through richer cities visibly pays more -- which is the
    // entire point of a route tester. See `sandboxRouteRevenue`.
    const printed = ctx?.mapGrid
      ? sandboxRouteRevenue(ctx.mapGrid, path, ctx.era ?? "Yellow", protocol_id)
      : SANDBOX_NOMINAL_ROUTE_REVENUE;

    /* ==================================================================
     *  DESIGN NOTE 903: THE DIE IS ROLLED HERE, AND IT CANNOT BE RE-ROLLED
     * ==================================================================
     *
     * REQUESTED: "every running train rolls a d6 modifying its printed route revenue" under a deterministic
     * RNG "seeded by the actionId or state hash so the event ledger replays identically".
     *
     * THE ACTION-ID SEED WOULD HAVE BEEN AN EXPLOIT and this is the one place it shows. Undo a bad run and
     * re-run the same train: that is a NEW action with a NEW index, so an action-seeded die hands out a fresh
     * face, and a player can sit there undoing until they roll a 6. The ledger would replay identically the
     * whole time.
     * SO THE SEED IS THE TURN. Macro round, sub round, corporation, and how many trains this corporation has
     * already run this turn -- all four read off state, so a rebuild reproduces them and a retry lands on the
     * same face. Re-routing through different cities changes the PRINTED figure and not the multiplier, which
     * is right: the die is the railway's luck this round, not a property of the hexes chosen.
     *
     * ONE SEAM, DELIBERATELY. Revenue is computed in several places for PREVIEW -- the route planner, the
     * dividend projection, the auto-tracer -- and none of them may roll. This arm is the only one that
     * COMMITS a figure to state, so it is the only one that applies the modifier; a preview showing an
     * unmodified figure and the commit applying the die is honest, where a preview that rolled would be
     * showing a number the player could then re-roll by looking away. */
    const variants = resolveVariants(state.variants);
    const ordinalBefore =
      state.public_companies.find((entry) => entry.company_id === protocol_id)
        ?.routes_run_this_turn ?? 0;
    /* ==================================================================
        DESIGN NOTE 941: ONE DIE FOR THE TURN, RE-APPLIED TO THE WHOLE SUM
       ==================================================================
       RULED: "The Unpredictable Revenue die must be rolled exactly ONCE per corporation's operating turn,
       applied to the total aggregated printed revenue of all trains combined, not per train."
       AND THE ARM CANNOT SEE THE END OF THE LOOP, which is the constraint that shapes this. One
       `RunManualRoute` is dispatched per train and the reducer is handed them one at a time; nothing tells it
       which is last. So instead of waiting for the final train, every dispatch RECOMPUTES the whole turn:
       add this route to the printed sum, then apply the turn's one roll to that sum from scratch.
       WHICH IS CORRECT AT EVERY PREFIX, not just at the end. After two of four trains the figure is the die
       applied to those two trains' total -- a true statement about what has run so far -- and the fourth
       dispatch leaves exactly the die applied to all four. No "is this the last train" signal exists, and
       none is needed.
       THE PRINTED SUM IS KEPT SEPARATELY (#941 on `printed_route_revenue`) because #938's rounding is lossy:
       the modified figure cannot be turned back into the printed one.
       THE SEED NO LONGER CARRIES THE ORDINAL. Round, sub-round and corporation identify the turn, which is
       now the unit of the roll -- so all four trains consult one face, by construction rather than by
       agreement. `routes_run_this_turn` survives, because the LOG still counts runs and #777 still clears it;
       it simply no longer feeds the die. */
    const company = state.public_companies.find((entry) => entry.company_id === protocol_id);
    const previousPrinted = Math.max(0, Number(company?.printed_route_revenue ?? 0) || 0);
    const printedTotal = previousPrinted + printed;
    /* ==================================================================
        DESIGN NOTE 1051: THE LEGACY ARM KEEPS THE LEGACY DIE
       ==================================================================
       NOTHING DISPATCHES `RunManualRoute` ANY MORE. #968 replaced the one-message-per-train shape with a
       single `RunMultipleRoutes` for the whole turn, and this arm survives only to replay logs written before
       that -- which is exactly the population that also predates #1051's recorded roll.
       SO IT ASKS FOR THE OLD ANSWER EXPLICITLY. Those games were played against the hash; rebuilding them
       against a fresh draw would give every client a different board for a history that is closed. Naming
       `legacyTurnSeed` here rather than falling through to it is what makes that a decision a reader can see,
       and it is the only caller of that function that is not a fallback. */
    const roll = variants.unpredictableRevenue
      ? rollTurnRevenue(printedTotal, {
          macroRound: state.macro_round_number ?? 0,
          subRound: state.sub_round_index ?? 0,
          companyId: protocol_id,
          turnSeed: legacyTurnSeed(
            state.macro_round_number ?? 0,
            state.sub_round_index ?? 0,
            protocol_id,
          ),
        })
      : null;
    /* Design note #777's zeroing still lives on the turn change; what changed is that there are now TWO
       turn-scoped figures to clear rather than one. */
    const running = roll ? roll.adjusted : printedTotal;
    return {
      ...state,
      public_companies: state.public_companies.map((entry) =>
        entry.company_id === protocol_id
          ? {
              ...entry,
              last_route_revenue: String(running),
              printed_route_revenue: String(printedTotal),
              /* Design note #903, amended by #941: still incremented with the revenue and still in the same
                 object, because the log counts runs and the turn-change clear pairs the two fields. It no
                 longer selects a die face -- the turn does. */
              routes_run_this_turn: ordinalBefore + 1,
            }
          : entry,
      ),
    };
  }

  /* ==================================================================
      DESIGN NOTE 968: THE WHOLE TURN'S RUNNING, IN ONE TRANSITION
     ==================================================================
     REPORTED, from a live room: three trains run, one paid. The dispatch was one message per train, and the
     room's index cursor cannot survive three appends in flight -- see `sessionKey`'s note for the mechanism.
     THIS ARM IS THE SAME ARITHMETIC AS `RunManualRoute`, GATHERED. It prices every route with the same
     `sandboxRouteRevenue`, sums the printed values, and applies the turn's one die to that sum -- which is
     what the per-route arm was already converging on, since #941 made it recompute the aggregate on every
     dispatch. What changes is that the aggregate is now assembled from routes that cannot be separated by a
     network, rather than from a field carried between transitions.
     IT STILL ADDS TO WHAT IS THERE. A corporation could in principle run, then run again in one turn -- the
     UI does not offer it, but the reducer must not silently discard a prior total if it ever does, and #777's
     turn-change clear is what bounds this rather than an assumption about the caller.
     `routes_run_this_turn` COUNTS THE ROUTES, not the messages. It exists for the log and for #777's clear,
     and a four-train turn that arrived as one message still ran four trains. */
  /* ==================================================================
      DESIGN NOTE 1046: THE SIGN CHANGES THE BOARD, SO THE REDUCER DOES IT
     ==================================================================
     THE ACTING CLIENT DECIDED AND THIS APPLIES. `model` and `cash` are carried on the message rather than
     re-derived here, because by the time a replay reaches this action the fleet has moved on -- re-deriving
     "the cheapest train" against a later roster would take a different train on the rebuild than it took in
     the game, which is the whole class of bug #902's "an old log replays to the game it was played as" rule
     exists to prevent.
     REFUSES BY RETURNING THE STATE IT WAS HANDED (#778), like every other gate here. */
  if ("YellowSignEvent" in msg) {
    const { protocol_id, stage, model, cash, revenue_seed } = msg.YellowSignEvent;
    const company = state.public_companies.find((entry) => entry.company_id === protocol_id);
    if (!company) return state;

    /* ==================================================================
        DESIGN NOTE 1092: THE FOG COLLECTS, AND THE CURSE STAYS
       ==================================================================
       THE THIRD STAGE, dispatched from the run that narrated it. It takes the named train and clears the
       clock, and deliberately does NOT clear `is_carcosan`: ruled that "if the Carcosa train rusts while
       owned, the corporation remains permanently cursed", which is the edge case the corporation-level flag
       was added for -- a scoreboard keyed on holding the train would find nobody here.
       THE MODEL COMES OFF THE MESSAGE, like the Mark's does (#902): by the time an old log replays here the
       fleet has moved on, and re-deriving "the marked train" against a later roster could take a different
       one than the game took.
       REFUSES BY RETURNING THE STATE IT WAS HANDED if the train is already gone -- a replayed duplicate must
       not take a second train. */
    if (stage === "fog") {
      const owned = company.owned_trains;
      const marks = company.carcosan_trains ?? [];
      const markedAt = marks.indexOf(model ?? "");
      if (markedAt < 0) return state;
      const survivingMarks = [...marks];
      survivingMarks.splice(markedAt, 1);
      const survivors = owned == null ? null : [...owned];
      if (survivors) {
        const at = survivors.indexOf(model ?? "");
        if (at >= 0) survivors.splice(at, 1);
      }
      return {
        ...state,
        public_companies: state.public_companies.map((entry) =>
          entry.company_id === protocol_id
            ? {
                ...entry,
                ...(survivors === null ? {} : { owned_trains: survivors }),
                carcosan_trains: survivingMarks,
                ...(survivingMarks.length === 0
                  ? { carcosan_doom_after_macro_round: undefined }
                  : {}),
              }
            : entry,
        ),
      };
    }

    if (stage === "mark") {
      /* ==================================================================
          DESIGN NOTE 1421: THE REDUCER IS THE LAST GATE ON A MARK
         ==================================================================
         JUNO-Z6C's log carries a second Mark (index 567, ERIE, phase D) while C&O had held the sign since
         OR 6.1 -- a line no current client can compose: the Mark's window is phases 2-4 and the game holds
         one sign. It was dispatched by a tab still running a build from before #1404, whose forced Mark
         skipped the window and whose sign state came off the log's sentence after #1375 had moved the clause
         off it. The table reverted it by hand. THE RULES ARE CHECKED HERE TOO, because a stale client is a
         thing that happens at a playtest and every client replays this same reducer: a Mark while a sign is
         out, or outside its window, is a no-op on every screen rather than a second curse on one. Entry 203
         (C&O, phase 4, first sign) replays exactly as before. */
      const signOut = state.public_companies.some((entry) => entry.has_yellow_sign === true || entry.is_carcosan === true);
      const tier = derivePhase(state)?.tier ?? "2";
      if (signOut || !["2", "3", "4"].includes(tier)) return state;
      /* THE TRAIN GOES AND THE TURN EARNS NOTHING. Ruled: "loses its lowest value train. It receives no
         standard route revenue for this submission. Instead, award the corporation cash equal to 0.5x the
         deleted train's depot value."
         BOTH REVENUE FIELDS ARE ZEROED, not just the modified one. `printed_route_revenue` is what the next
         train's roll accumulates onto (#941), so leaving it would pay for these routes on the corporation's
         NEXT dispatch -- the silent double-payment #934 was reported for. */
      const owned = company.owned_trains;
      if (owned == null) return state;
      const at = owned.indexOf(model);
      if (at < 0) return state;
      const survivors = [...owned];
      survivors.splice(at, 1);
      const award = Math.max(0, Number(cash ?? 0) || 0);
      /* ==================================================================
          DESIGN NOTE 1375: THE OTHER TRAINS' ROUTES STAND
         ==================================================================
         RULED SINCE #1046: the Mark takes the train and THAT TRAIN'S ROUTE; what the rest of the fleet ran
         is still earned. `runWithoutTrain` (yellowSign.ts) takes the taken train's printed route out of the
         run and rolls the remainder under the seed the run itself used -- carried on the message, because
         the reducer must not draw (#1051). A message without the seed is one written under the old ruling
         and keeps the zeroing it was played with, so no stored log replays to a different board. */
      const kept = revenue_seed === undefined ? null : runWithoutTrain(company, model, {
        macroRound: state.macro_round_number ?? 0,
        subRound: state.sub_round_index ?? 0,
        companyId: protocol_id,
        turnSeed: revenue_seed,
      });
      return {
        ...state,
        public_companies: state.public_companies.map((entry) =>
          entry.company_id === protocol_id
            ? {
                ...entry,
                owned_trains: survivors,
                has_yellow_sign: true,
                treasury: String((Number(entry.treasury ?? 0) || 0) + award),
                last_route_revenue: String(kept ? kept.adjusted : 0),
                printed_route_revenue: String(kept ? kept.printed : 0),
                ...(kept && kept.breakdown ? { last_run_breakdown: kept.breakdown } : {}),
                ...(kept ? { routes_run_this_turn: kept.routes } : {}),
              }
            : entry,
        ),
      };
    }

    /* THE GIFT. Ruled: "instantly gains a train matching the current phase's tier ... it does not deplete the
       bank's supply ... and it bypasses train limit checks until the end of the Operating Round."
       IT JOINS `owned_trains` LIKE ANY OTHER TRAIN and is ALSO listed in `ghost_trains`, which is #979's
       shape: the roster stays the one place a fleet lives, and the exception is a mark beside it. A separate
       array of ghost trains would be a second roster to fall out of step with the first.
       THE FLAG IS CLEARED HERE. "Remove the corporation's flag ... so it cannot re-occur." */
    return {
      ...state,
      public_companies: state.public_companies.map((entry) =>
        entry.company_id === protocol_id
          ? {
              ...entry,
              owned_trains: [...(entry.owned_trains ?? []), model],
              ghost_trains: [...(entry.ghost_trains ?? []), model],
              /* ==================================================================
                  DESIGN NOTE 1089: THREE MARKS, THREE CLOCKS, ONE GIFT
                 ==================================================================
                 `ghost_trains` IS THE LIMIT EXEMPTION and empties at the end of this Operating Round (#1046).
                 `carcosan_trains` IS THE IDENTITY -- the gold trim, the chip icon, the thing the doom clock
                 comes for -- and outlives it by a full OR set. Written together here and separated
                 everywhere after, because this is the one moment they are the same train for the same
                 reason. */
              carcosan_trains: [...(entry.carcosan_trains ?? []), model],
              /* THE CURSE IS ON THE COMPANY. Ruled: "the only way a corporation loses the flag is by
                 successfully transferring the Carcosa train". It survives the train's own destruction, which
                 is the edge case the end-game egg needed -- a scoreboard keyed on holding the train would
                 find nobody once it had rusted. */
              is_carcosan: true,
              /* THE DOOM CLOCK, STARTED HERE ONLY FOR A GIFTED DIESEL. Ruled: "A Carcosan D-train begins
                 this countdown the moment it is gifted ... completes the OR set in which it is gifted, and
                 then the next OR set before disappearing into the fog." A gifted 5 or 6 waits for the first
                 D-train instead, which `startCarcosanDoomClock` handles at the phase change.
                 `+ 1` IS THE WHOLE RULE: triggered during set N, gone at the conclusion of set N + 1. */
              ...(trainTier(model) === "D"
                ? { carcosan_doom_after_macro_round: (state.macro_round_number ?? 0) + 1 }
                : {}),
              has_yellow_sign: false,
            }
          : entry,
      ),
    };
  }

  if ("RunMultipleRoutes" in msg) {
    const { protocol_id, routes, trains, train_indices } = msg.RunMultipleRoutes;
    /* Design note #1323: THE AUTHORITY BEHIND THE PLANNER'S REFUSAL. The walks refuse Coal River for an
       unlicensed corporation (`barredHexesFor`); this is the reducer saying the same thing about a path the
       log carries, so a client that drew the route by other means still cannot be paid for it. */
    if (
      !mayCrossCoalRiver(state, protocol_id) &&
      routes.some((path) => routeCrossesCoalRiver(path))
    ) {
      return state;
    }
    /* ==================================================================
        DESIGN NOTE 1183: ONE TURN, ONE RUN
       ==================================================================
       FROM THE EXPORTED LOG: indices 318 and 319 are the same two routes for the same corporation, six
       seconds apart, both stamped revenue_turn "7.1.7". Index 320 then declared dividends on $540, which is
       $270 twice. `seedAlreadyRolled` exists to catch exactly this and searches the RAW log, which in a room
       does not hold the first run until its snapshot returns -- so the second click outran it.
       THE KEY IS IN THE MESSAGE, so this compares two things the log controls: `revenue_turn` travels with
       the run, and the field it is checked against is rebuilt by the replay. Every client refuses the
       duplicate at the same index.
       AN UNDO STILL RE-RUNS. Reverting drops the first run from the effective history, so the rebuild never
       records its key and the honest re-dispatch is accepted -- which is why #1051 minted this key at all.
       ABSENT IS NOT A VALUE (#232): a run from before #1051 carries no key, and two of those must not
       collide on `undefined`. */
    const runTurnKey = msg.RunMultipleRoutes.revenue_turn;
    if (
      typeof runTurnKey === "string" &&
      runTurnKey !== "" &&
      state.last_run_turn_key === runTurnKey
    ) {
      return state;
    }
    const variants = resolveVariants(state.variants);
    /* ==================================================================
        DESIGN NOTE 1550: PRICED FROM THE AUTHORITY'S ANSWER, NOT FROM THE MESSAGE
       ==================================================================
       With a grid, the routes have already passed `routeSetRefusal` in `applySandboxActionCore`; the same
       evaluator is asked again here for its figures, so the revenue written to state is the revenue of the
       routes AS THE BOARD READ THEM (a `bypass` the rails force is normalised on, a `bypass` the rails do not
       offer was refused). The message can still say WHICH routes and WHICH trains; it can no longer say what
       they are worth. Without a grid (a fixture) the nominal fallback stands, as it always has. */
    const verdict = ctx?.mapGrid
      ? evaluateRouteSet({
          state,
          mapGrid: ctx.mapGrid,
          era: ctx.era ?? "Yellow",
          companyId: protocol_id,
          routes,
          trainIndices: train_indices ?? null,
          trains: trains ?? null,
        })
      : null;
    if (verdict && verdict.kind === "refused") return state; // the gate already said so; this is the second lock.
    const priced = verdict
      ? verdict.runs.map((run) => run.revenue)
      : routes.map(() => SANDBOX_NOMINAL_ROUTE_REVENUE);
    const printedThisMessage = priced.reduce((sum, value) => sum + value, 0);
    /* ==================================================================
        DESIGN NOTE 1031: THE BREAKDOWN WAS ALREADY COMPUTED AND THEN DISCARDED
       ==================================================================
       `priced` HAS HELD THE PER-TRAIN FIGURES ALL ALONG and this arm summed them and dropped the rest, which
       is why a watcher could be told the corporation earned $640 and never which train earned which half.
       Nothing new is calculated here; what changes is that the array survives the reduce.
       WRITTEN ONLY WHERE THE LOG IDENTIFIES THE TRAINS. `train_indices` is optional (#232), and a breakdown
       built from routes whose trains cannot be named would be a list of figures attached to guesses -- worse
       than the absence, because the chip's fallbacks are honest about not knowing and a wrong index is not.
       So an old log leaves the field untouched and the chip prices what it can, exactly as before.
       IT REPLACES RATHER THAN APPENDS, where the two revenue totals accumulate. That asymmetry is deliberate:
       #968 keeps adding to `printed_route_revenue` because a corporation could in principle run twice in one
       turn and the money must not be discarded. A SECOND run's breakdown, though, describes the same fleet
       slots as the first -- appending would put two entries on one chip, and the later one is the current
       truth about that train. Money accumulates; the account of which train is where does not. */
    const breakdown =
      train_indices && train_indices.length === routes.length
        ? routes.map((_path, at) => ({
            train_index: train_indices[at],
            // #1550: the model the fleet slot holds, when the authority read it; the message's word otherwise.
            model: verdict?.runs[at]?.model ?? trains?.[at] ?? "",
            printed_revenue: String(priced[at]),
          }))
        : null;
    const company = state.public_companies.find((entry) => entry.company_id === protocol_id);
    const previousPrinted = Math.max(0, Number(company?.printed_route_revenue ?? 0) || 0);
    const printedTotal = previousPrinted + printedThisMessage;
    /* ==================================================================
        DESIGN NOTE 1051: THE ROLL COMES OFF THE MESSAGE, NOT OUT OF A HASH
       ==================================================================
       THE REDUCER MUST NOT DRAW. It runs on every client, on every replay, for every entry in the log -- so a
       `Math.random()` here would give four browsers four different boards and a reload a fifth. The draw
       happens ONCE, in the shell, at dispatch; this reads what the log recorded.
       THE FALLBACK IS FOR LOGS, NOT FOR MISTAKES. An entry with no `revenue_seed` predates this batch, and
       replaying it through the hash rebuilds the board it was actually played on. It is deliberately NOT a
       silent safety net for a dispatch that forgot to draw -- `batch50.test.ts` pins that the shell always
       supplies one, because a live game quietly falling back to the hash would be the predictable die
       returning with nothing on screen to say so. */
    const roll = variants.unpredictableRevenue
      ? rollTurnRevenue(printedTotal, {
          macroRound: state.macro_round_number ?? 0,
          subRound: state.sub_round_index ?? 0,
          companyId: protocol_id,
          turnSeed:
            msg.RunMultipleRoutes.revenue_seed ??
            legacyTurnSeed(
              state.macro_round_number ?? 0,
              state.sub_round_index ?? 0,
              protocol_id,
            ),
        })
      : null;
    const running = roll ? roll.adjusted : printedTotal;
    return {
      ...state,
      /* Design note #1183, CORRECTED BY BATCH 6 (#1550): the turn this run belongs to, so a second copy of it
         is refused above. IT WAS WRITTEN ON THE CORPORATION AND READ OFF THE STATE. The field is declared on
         `GameStateResponse`, the check above reads `state.last_run_turn_key`, and this spread sat inside the
         `public_companies.map` below -- so the key landed on the company entry, the state's own field stayed
         `undefined`, and the refusal never fired once. `oneRunPerTurn.test.ts` asserted both strings and
         could not see that they named different objects (#490a's warning, in a new shape). Found by the
         Batch-6 corpus sweep: JUNO-3XD 319 -- the very duplicate the note was written for -- was applied in
         every replay since, NNH's turn totalling 680 printed. The authoritative one-run-per-turn rule
         (`routeSetRefusal`, on `routes_run_this_turn`) now refuses it whatever key it carries; this write is
         moved to where the read is so the key's own undo semantics (#1183's second paragraph) hold as well. */
      ...(typeof runTurnKey === "string" && runTurnKey !== "" ? { last_run_turn_key: runTurnKey } : {}),
      public_companies: state.public_companies.map((entry) =>
        entry.company_id === protocol_id
          ? {
              ...entry,
              last_route_revenue: String(running),
              printed_route_revenue: String(printedTotal),
              // Design note #1031: only when the log named the trains; otherwise the field keeps whatever it
              // held, because "this message could not say" is not "the previous answer was wrong".
              ...(breakdown ? { last_run_breakdown: breakdown } : {}),
              routes_run_this_turn: (entry.routes_run_this_turn ?? 0) + routes.length,
            }
          : entry,
      ),
    };
  }

  if ("DeclareDividends" in msg) {
    /* The dividend buttons were a no-op. Withhold credits the corporation; Pay splits ten ways. The price
       ladder stays market.rs's.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #193
       Design note #706 CORRECTED THE SECOND HALF OF THAT SENTENCE, which read "players to cash, IPO to the
       treasury, bank pool to the bank" -- the two pools the wrong way round, stated plainly, for as long as
       this branch has existed. 1830: "Shares in the bank pool pay dividends to the corporate treasury. No
       payments are made for unsold initial offering shares." */
    const { protocol_id, distribute } = msg.DeclareDividends;
    const company = state.public_companies.find((entry) => entry.company_id === protocol_id);

    /* ==================================================================
     *  DESIGN NOTE 752: THE PHANTOM $1000, AND IT WAS A DECLARED ZERO
     * ==================================================================
     *
     * REPORTED: "a corporation's trains rusted with $500 in its treasury and the cheapest next train was
     * $630. On its turn it laid track and then was auto-skipped to Buy Trains, where it miraculously suddenly
     * had $1500 to make the purchase. This amount did not come from the player's cash."
     *
     * MY FIRST GUESS WAS RE-CAPITALISATION, ten times par. REPORTED BACK: "it definitely isn't
     * recapitalization: the company was pared at 72, so I don't know where the $1000 came from." $72 x 10 is
     * $720, which killed it outright -- and the instrument (#750) was already the right call, because the
     * actual writer is three lines below this one.
     *
     * THE CONDITION READ `stated > 0`, so a DECLARED ZERO fell through to the fallback. A trainless
     * corporation is auto-skipped past Routes and the game declares a forced $0 withhold on its behalf
     * (#668). The shell computes that zero correctly -- `dividendDeclaration` exists for exactly this and
     * #484 says so: "a skipped Routes step declares $0, not last turn's revenue". It then sends
     * `revenue_amount: "0"`, and this line threw it away and reached for `last_route_revenue` instead: the
     * figure from the last Operating Round the corporation actually ran, before its trains rusted. A withhold
     * credits the treasury, so the bank paid out $1000 for a run that did not happen.
     *
     * SO #486 WAS FIXED IN THE SHELL AND UNDONE HERE. Its own opening sentence describes this bug --
     * "the dispatch read `last_route_revenue` straight off the corporation -- a PREVIOUS turn's figure for a
     * corporation that skipped Routes, so a forced $0 withhold could move real money for a run that did not
     * happen" -- and the reducer's fallback quietly reinstated it for every client that replays the log. The
     * project's recurring shape once more: a rule corrected at one surface and left standing in the
     * authority.
     *
     * ABSENT IS NOT ZERO. The fallback still exists, because a message written before `revenue_amount` was
     * carried has no figure at all and guessing zero for those would silently cancel real dividends. What
     * changed is that an explicit `"0"` is now a FIGURE rather than a missing one. */
    /* Design note #775: THE ARITHMETIC MOVED TO `dividendSplit`, unchanged. Every rule this branch had
       settled -- #752's explicit zero, the trainless fallback, #706's two pools, the floor -- now lives in
       one module, because the LOG LINE and the TOAST were computing the same figures a second time from
       their own snapshot and getting a different answer. Reported as a payout notice showing double what was
       actually paid: two implementations, one of which moves money.
       THE REDUCER IS STILL THE AUTHORITY. It is the only caller that acts on the result; the describers only
       read it. What changed is that there is now one calculation for them to read. */
    const settlement = dividendSplit(state, protocol_id, msg.DeclareDividends.revenue_amount, distribute);
    if (!settlement || !company) return state;
    const { revenue } = settlement;

    if (!distribute) {
      // #1560/#1561: the bank funds the withhold and may go negative doing it, latching the break.
      return settleMoney(state, transfer(state, BANK, { corporation: protocol_id }, revenue));
    }

    /* Design note #706: THE TWO POOLS WERE EXACTLY SWAPPED.
       1830: "Shares in the bank pool pay dividends to the corporate treasury. No payments are made for unsold
       initial offering shares."
       This paid `ipo_pool_percentage` INTO the treasury and let `bank_pool_percentage` stay with the bank --
       both wrong, and wrong in opposite directions, which is why the total still looked plausible. A
       corporation with shares unsold banked a slice it is not owed; one whose shares had been sold back into
       the pool lost a slice it is.
       IT MATTERS MOST EARLY AND LATE. A freshly floated corporation is mostly IPO, so it was collecting on
       nearly every dividend it declared; a corporation players have dumped into the pool is where the real
       rule pays, and it was collecting nothing. The bug rewarded exactly the position 1830 does not.
       THE BANK FUNDS EXACTLY WHAT IT PAID -- players plus the pool's slice, summed rather than reconstructed
       from `revenue` minus other slices. The old expression had to stay in step with two figures computed
       elsewhere, and did not. */
    /* #1560: ONE BANK DEBIT FOR THE WHOLE PAYOUT, kept from #329/#376 -- and now it is exact rather than
       floored, so the bank's balance after a payout it could not fund is the shortfall it actually owes and
       `bank_broken` latches on the way past zero (#1561). `totalPaid` is the players' shares plus the pool
       slice by construction, so the debit and the credits below are the same money. */
    const funded = debitBank(state, settlement.totalPaid);
    if (!funded.ok) return state;
    let next = funded.state;
    for (const share of settlement.players) {
      const paidShare = creditPlayer(next, share.player, share.amount);
      if (!paidShare.ok) return state;
      next = paidShare.state;
    }
    if (settlement.poolSlice > 0) {
      const pooled = creditTreasury(next, protocol_id, settlement.poolSlice);
      if (!pooled.ok) return state;
      next = pooled.state;
    }
    // `ipo_pool_percentage` is deliberately absent: unsold shares pay nobody.
    return next;
  }

  if (
    "AdvanceOperatingSubPhase" in msg ||
    "AcceptTrainOffer" in msg ||
    "RejectTrainOffer" in msg ||
    "RescindTrainOffer" in msg ||
    "ExecuteOperatingRound" in msg
  ) {
    /* The three offer messages are UNMODELLABLE here, not merely unmodelled: they address an offer_id and the register is its own query. An accepted offer settles via BuyTrainFromCorporation.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0 */
    return state;
  }

  if ("BeginOperatingRound" in msg) {
    /* Design note #411: this set the round type and zeroed the cursor, and
       left `active_operating_order` at whatever it already held -- which
       from the zero state is `[]`, the empty queue that made the round
       unadvanceable. `beginOperatingRound` builds it. */
    return beginOperatingRound(state, ctx?.marketPriceFor, ctx?.marketMarkFor);
  }

  if ("UndoLastAction" in msg) {
    // Genuinely unmodellable: undo is a full replay of the contract's event
    // log, and the sandbox has no log. An explicit no-op rather than a
    // default-arm turn advance, which would make undo look like an action.
    return state;
  }

  // Any unconsidered ExecuteMsg variant. Advancing the turn keeps the loop alive, and a turn that moves wrongly is far easier to notice than a control that silently does nothing.
  // See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #2
  return advanceSeat(state);
}

/** Whether `phase` is one where seats act in order, as opposed to
 *  corporations. Exported for the toolbar, which labels the auto-follow
 *  target differently in each. */
export function isSeatDrivenRound(phase: RoundType): boolean {
  return phase !== "OperatingRound";
}

/* Floating is a threshold with a bookkeeping consequence, so it belongs here. #376: full capitalisation is ten times par, paid BY THE BANK -- that money already went in on the share purchases.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #363
   Design note #749: THE CONSTANT AND THE MEASURE MOVED TO `floatThreshold.ts`. They are re-exported so every
   existing importer keeps working, but the arithmetic now lives in one place -- the local
   `soldToPlayersPercent` here and a same-named one in `StockRoundPanel` computed the same wrong quantity two
   different ways, and each read as obviously correct on its own. */
export { FLOAT_THRESHOLD_PERCENT, FULL_CAPITALISATION_MULTIPLE } from "./floatThreshold";

/** Floats every corporation over the threshold. Returns the SAME state when nothing changed so callers can skip on identity. homeHexToAxial is injected (utils/ must not import components/).
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #416 */
export function applyFloatThreshold(
  state: GameStateResponse,
  homeHexToAxial: (label: string) => readonly [number, number] | null,
): GameStateResponse {
  let changed = false;
  // Design note #376: what the bank pays out this pass, in one debit.
  let capitalised = 0;

  const companies = state.public_companies.map((company) => {
    if (company.is_floated) return company;
    /* Design note #749: OUT OF THE IPO, not in players' hands. This read the sum of `player_holdings`, which
       is the same number until somebody sells and permanently smaller afterwards -- so a corporation whose
       shares had reached 60% out of the IPO by way of the Bank Pool never floated, and had no way to. */
    if (!metFloatThreshold(company)) return company;

    changed = true;

    /* Design note #376: ten times par, into a treasury that was empty. Added
       to whatever is there rather than assigned, so a company that somehow
       already holds money is not silently reset by floating. */
    const par = Number(company.par_value);
    const capital =
      Number.isFinite(par) && par > 0 ? par * FULL_CAPITALISATION_MULTIPLE : 0;
    capitalised += capital;
    const treasury = String((Number(company.treasury) || 0) + capital);

    /* The token is PROMPTED, not placed: the prompt is not asking which hex, it is making the player witness the placement. homeHexToAxial still decides whether a home hex RESOLVES.
       See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #416 */
    return { ...company, is_floated: true, treasury };
  });

  if (!changed) return state;
  /* Design note #376: one debit for the whole pass, for the same reason design note #329's payout banks once.
     #1560: the reason has changed from "several calls would floor differently" to "several calls would latch
     at different moments"; the shape is the same and so is the arithmetic. The treasuries above were credited
     in the map, so this debit is the matching half and the pass conserves. A refused debit floats nobody --
     a corporation capitalised out of a bank that never paid would be the mint this batch exists to end. */
  const capitalisation = debitBank({ ...state, public_companies: companies }, capitalised);
  return capitalisation.ok ? capitalisation.state : state;
}

/** A corporation that has floated and still owes its home station token.
 *  Design note #416: what the prompt is raised from. */
export interface PendingHomeToken {
  companyId: number;
  ticker: string;
  hexLabel: string;
  q: number;
  r: number;
  president: string | null;
  /** Design note #1325: every hex the token may go on. One entry for the printed eight; two for the Level
   *  Playing Field's C&O, whose prompt then asks which. The first is `hexLabel`/`q`/`r`. */
  options: ReadonlyArray<{ hexLabel: string; q: number; r: number }>;
}

/** Derived from the board, so a reload or a late poll cannot lose the prompt. Ordered by operating order; a company whose label does not resolve is absent rather than pending.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #416 */
export function pendingHomeTokens(
  state: GameStateResponse,
  homeHexToAxial: (label: string) => readonly [number, number] | null,
): PendingHomeToken[] {
  const rank = new Map(state.active_operating_order.map((id, index) => [id, index]));

  const pending = state.public_companies.flatMap((company) => {
    if (!company.is_floated || !company.home_hex_label) return [];
    // Design note #1302: a home that is a printed herald owes no token -- there is no city to put one in.
    if (heraldHexFor(company.company_id) !== null) return [];
    const axial = homeHexToAxial(company.home_hex_label);
    if (!axial) return [];
    const [q, r] = axial;
    /* Design note #1325: THE HOME IS PLACED WHEN THE CORPORATION HOLDS ANY TOKEN. Its first token is always
       its home (the gate holds play until it is placed), so this and the per-hex test agree for the printed
       eight -- and only this one is right for a corporation with two homes, which may have sat on the other. */
    const already =
      company.station_token_hexes.length > 0 ||
      company.station_token_hexes.some(([hq, hr]) => hq === q && hr === r);
    if (already) return [];
    const homeLabel = company.home_hex_label;
    const options = homeHexesFor(company.company_id)
      .map((home) => ({ hexLabel: home.label, q: home.q, r: home.r }))
      .sort((a, b) => (a.hexLabel === homeLabel ? -1 : b.hexLabel === homeLabel ? 1 : 0));
    return [
      {
        companyId: company.company_id,
        ticker: company.ticker,
        hexLabel: company.home_hex_label,
        q,
        r,
        president: company.president,
        options: options.length > 0 ? options : [{ hexLabel: company.home_hex_label, q, r }],
      },
    ];
  });

  return pending.sort(
    (a, b) =>
      (rank.get(a.companyId) ?? Number.MAX_SAFE_INTEGER) -
        (rank.get(b.companyId) ?? Number.MAX_SAFE_INTEGER) || a.companyId - b.companyId,
  );
}

/** The other half of the prompt, and IDEMPOTENT -- a double-click or replayed dispatch cannot stack two tokens on one hex.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #416 */
export function placeHomeStationToken(
  state: GameStateResponse,
  companyId: number,
  q: number,
  r: number,
  /** Design note #560: WHICH city on the hex. `null` leaves the renderer's
   *  heuristic in charge, which is right for a single-city hex and is the
   *  only honest answer when the click could not be resolved. */
  cityIndex: number | null = null,
  /** Design note #769a: the board's label lookup, injected on #7's rule. Absent means the seat is not
   *  released -- the honest answer for a caller that cannot tell whether anything is still owed. */
  homeHexToAxial?: (label: string) => readonly [number, number] | null,
): GameStateResponse {
  const company = state.public_companies.find((entry) => entry.company_id === companyId);
  if (!company || !company.is_floated) return state;
  if (company.station_token_hexes.some(([hq, hr]) => hq === q && hr === r)) return state;
  /* Design note #1325: a two-home corporation's token goes on one of its homes and nowhere else. Checked
     only when the board names more than one, so a log written for a single-home corporation keeps replaying
     to wherever it recorded. */
  const homes = homeHexesFor(companyId);
  if (homes.length > 1 && !homes.some((home) => home.q === q && home.r === r)) return state;

  const placed: GameStateResponse = {
    ...state,
    public_companies: state.public_companies.map((entry) =>
      entry.company_id === companyId
        ? {
            ...entry,
            // Home token first, matching `grant_home_station_token`'s own
            // ordering -- several readers take `[0]` as "the home station".
            station_token_hexes: [[q, r] as [number, number], ...entry.station_token_hexes],
            /* The slot registry, written in the same order and the same breath -- a partial index is worse than none, because the renderer trusts it.
               See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #560 */
            station_tokens:
              cityIndex === null
                ? entry.station_tokens ?? null
                : [
                    [q, r, cityIndex] as [number, number, number],
                    ...(entry.station_tokens ?? []),
                  ],
          }
        : entry,
    ),
  };

  /* ==================================================================
     DESIGN NOTE 769a: THE PLACEMENT COMPLETES THE TURN THE PURCHASE STARTED
     ==================================================================
     #769 holds the seat on the President when their purchase floats a corporation, so the round does not
     announce somebody else's turn and then refuse everything they try. That hold needs a release, and the
     placement is it -- otherwise the President keeps the seat and takes a second turn, which is a worse bug
     than the one #769 fixed.
     ONE TURN, TWO MESSAGES. Floating and placing are a single event in 1830 (#763); we split them into two
     messages so the player witnesses the placement, and this is where the halves are put back together.
     GUARDED ON THE ROUND AND ON THE REMAINING DEBT. A Stock Round only: nothing else advances a seat this
     way. And only when no OTHER corporation still owes a token -- two floats in one purchase is not a board
     1830 reaches, but a release that fired on the first of two would hand the turn on with an obligation
     still outstanding, which is exactly the state this pair of notes exists to prevent. */
  if (state.current_round_type !== "StockRound") return placed;
  if (homeHexToAxial && pendingHomeTokens(placed, homeHexToAxial).length > 0) return placed;
  /* #1443: under Sell-Buy-Sell the placement completes the PURCHASE, not the turn -- the president may still
     sell, and ends the turn with the Pass. */
  if (sellBuySellInForce(resolveVariants(placed.variants))) return placed;
  return advanceSeat(placed);
}

/* Private revenue never became money: revenue_per_or was printed as a property and nothing paid it. #328: once per ROUND, not once per corporation. #329: the bank pays; unowned, closed and corporate-owned are handled distinctly.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #327 */
export interface PrivatePayout {
  privateId: number;
  privateName: string;
  amount: number;
  /** Exactly one of these is set -- see design note #329. */
  toPlayer: string | null;
  toCompanyId: number | null;
}

export interface PrivatePayoutResult {
  state: GameStateResponse;
  payouts: PrivatePayout[];
  /** What left the bank in total, for the caller's summary line. */
  total: number;
}

/** One round's private income. Same state and an empty list when nothing is owed, so the caller can skip its log write on identity.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #327 */
export function applyPrivateRevenue(state: GameStateResponse | null): PrivatePayoutResult | null {
  if (!state) return null;

  const payouts: PrivatePayout[] = [];
  for (const priv of state.private_companies) {
    if (priv.closed) continue;
    const amount = Number(priv.revenue_per_or) || 0;
    if (amount <= 0) continue;

    if (priv.owner_protocol_id !== null && priv.owner_protocol_id !== undefined) {
      payouts.push({
        privateId: priv.private_id,
        privateName: priv.name,
        amount,
        toPlayer: null,
        toCompanyId: priv.owner_protocol_id,
      });
    } else if (priv.owner) {
      payouts.push({
        privateId: priv.private_id,
        privateName: priv.name,
        amount,
        toPlayer: priv.owner,
        toCompanyId: null,
      });
    }
  }

  if (payouts.length === 0) return { state, payouts, total: 0 };

  /* Design note #329: the bank funds it, in ONE write rather than one per private. #1560: the debit comes
     first now, so the bank is the single source of the money the credits below hand out and the pass
     conserves exactly; #1561 latches the break on the way past zero. A refusal pays nobody and reports
     nothing owed, so the caller's narration and the board agree. */
  const total = payouts.reduce((sum, payout) => sum + payout.amount, 0);
  const funded = debitBank(state, total);
  if (!funded.ok) return { state, payouts: [], total: 0 };
  let next = funded.state;
  for (const payout of payouts) {
    const paidOut = payout.toPlayer
      ? creditPlayer(next, payout.toPlayer, payout.amount)
      : creditTreasury(next, payout.toCompanyId as number, payout.amount);
    if (!paidOut.ok) return { state, payouts: [], total: 0 };
    next = paidOut.state;
  }

  return { state: next, payouts, total };
}

/* The B&O private grants the 20% President's Certificate free and sets par from the winner's choice; it does NOT float the corporation. #399: the par is taken WITH the grant, because an unparred presided company is a broken state.
   See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #354 */
/** Why the B&O President's Certificate cannot be granted right now, or `null` when it can.
 *
 *  Design note #904b: SEPARATE FROM THE GRANT so the shell can say it. `grantBOPresidency` has to stay a pure
 *  `state -> state` function whose refusal is "the same state back"; a reason is a second return value, and
 *  bolting one on would make every existing caller destructure a tuple to ignore half of it. Asked here, once,
 *  by both the grant and the narration -- so the sentence a player reads and the decision the reducer makes
 *  cannot disagree. */
export function boPresidencyRefusal(
  state: GameStateResponse,
  boTicker = "B&O",
): string | null {
  const bo = state.public_companies.find((entry) => entry.ticker === boTicker);
  if (!bo) {
    return "This game has no B&O corporation, so its President's Certificate cannot be awarded.";
  }
  if (bo.president !== null) {
    /* THE COLLISION #904 IS ABOUT, named rather than swallowed. Under a delayed auction this is what a player
       who just paid for the B&O private would otherwise hit in total silence. */
    return `${boTicker} already has a President, so the certificate from the private auction has nowhere to go. This is the collision the B&O lock exists to prevent — the corporation should not have been buyable before the auction concluded.`;
  }
  if (bo.ipo_pool_percentage < SANDBOX_PRESIDENT_PERCENTAGE) {
    /* THE INVENTED-SHARES CASE. Reached when the IPO has been drawn down below the 20% the certificate is cut
       from -- which the old `Math.max(0, ...)` clamp would have absorbed while still crediting the winner. */
    return `${boTicker}'s initial offering holds only ${bo.ipo_pool_percentage}%, which is less than the ${SANDBOX_PRESIDENT_PERCENTAGE}% President's Certificate. Granting it would create shares that do not exist.`;
  }
  return null;
}

export function grantBOPresidency(
  state: GameStateResponse,
  winner: string,
  /** Design note #399: the winner's chosen par, collected before this runs.
   *  A company cannot be presided over and priceless at the same time. */
  parValue: string,
  boTicker = "B&O",
): GameStateResponse {
  const bo = state.public_companies.find((entry) => entry.ticker === boTicker);
  /* ==================================================================
     DESIGN NOTE 904b: THE REFUSAL SAYS WHY, BECAUSE THE ALTERNATIVE IS A CERTIFICATE THAT EVAPORATES
     ==================================================================
     This was `if (!bo || bo.president !== null) return state;` and the caller bails on `granted === base`
     BEFORE it logs -- so a grant that could not be made produced no certificate, no par, no error and not one
     line in the Activity Log. Unreachable under standard rules, where the auction resolves before anybody can
     buy anything; reachable the moment #904's delayed auction exists, and reachable exactly when somebody has
     just PAID for the B&O private.
     THE THIRD COLLISION IS THE ONE TO WATCH and it is why "already presided" is not the only guard here. The
     grant does `ipo_pool_percentage - SANDBOX_PRESIDENT_PERCENTAGE` under a `Math.max(0, ...)`; with the IPO
     already drawn down, that clamp under-removes from the pool while still adding 20% to the winner, which
     invents shares. So the pool is checked BEFORE the subtraction rather than clamped after it.
     STILL RETURNS THE STATE UNCHANGED on refusal -- the reducer stays pure and the caller keeps its identity
     check. What is new is `boPresidencyRefusal`, which the shell asks so it can say something. */
  const refusal = boPresidencyRefusal(state, boTicker);
  if (refusal !== null || !bo) return state;

  return {
    ...state,
    public_companies: state.public_companies.map((entry) => {
      if (entry.company_id !== bo.company_id) return entry;
      const held =
        entry.player_holdings.find((h) => h.player === winner)?.percentage ?? 0;
      return {
        ...entry,
        president: winner,
        // Design note #399: set here, with the certificate, so the pair
        // cannot come apart.
        par_value: parValue,
        ipo_pool_percentage: Math.max(
          0,
          entry.ipo_pool_percentage - SANDBOX_PRESIDENT_PERCENTAGE,
        ),
        player_holdings: [
          ...entry.player_holdings.filter((h) => h.player !== winner),
          { player: winner, percentage: held + SANDBOX_PRESIDENT_PERCENTAGE },
        ],
        total_shares_issued:
          entry.total_shares_issued +
          SANDBOX_PRESIDENT_PERCENTAGE / SANDBOX_SHARE_PERCENTAGE,
      };
    }),
  };
}

/** A named function with a return value, because an inline version survived being switched off entirely -- every source-text assertion still matched. #467: the branches ask whether the company HAS a home, since #416 means no float ever gains a token here.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #400 */
export function describeFloat(
  previous: { is_floated: boolean; station_token_hexes?: ReadonlyArray<unknown> | null },
  company: {
    company_id?: number;
    ticker: string;
    treasury: string;
    is_floated: boolean;
    home_hex_label?: string | null;
    station_token_hexes?: ReadonlyArray<unknown> | null;
  },
): string | null {
  if (previous.is_floated || !company.is_floated) return null;

  /* Design note #1332: a home that is a printed herald owes no token (#1302), so the sentence must not ask
     for one -- the modal that follows this line says the rest. */
  const herald =
    company.company_id !== undefined && company.home_hex_label
      ? heraldHexFor(company.company_id)
      : null;
  /* Design note #1343 (feedback 2 / 2a): ONE LINE PER FLOAT. A corporation that owes a home token gets its
     line at the placement (`actionLog.ts` #1343), so this says nothing for it; a corporation that owes none
     -- the herald home -- gets the same line here, without the placement clause. */
  if (herald) {
    return `${company.ticker} has floated. It received $${company.treasury}.`;
  }

  if (company.home_hex_label) return null;

  /* NNH has no home hex on this board (see `applyFloatThreshold`), so it
     floats without one. Said outright rather than leaving the sentence half
     finished, which would read as a placement that failed. */
  return `${company.ticker} has floated. It received $${company.treasury}. It has no home hex on this board, so no home token is placed.`;
}

/** "Schuylkill Valley pays $5 to Alice." One line per payout, because the
 *  Activity Log is a ledger and a summarised "privates paid $70" cannot be
 *  reconciled against any individual balance on screen. */
export function describePrivatePayout(
  payout: PrivatePayout,
  labelForAddress: (address: string) => string,
  labelForCompany: (companyId: number) => string,
): string {
  const recipient = payout.toPlayer
    ? labelForAddress(payout.toPlayer)
    : labelForCompany(payout.toCompanyId as number);
  /* Design note #1059: NUMBERED, in the form five other surfaces already use (#1052). A player reading the
     feed and a player reading the Ledger are looking at the same six companies, and until now only one of
     them was told which. */
  return `${numberedPrivate(payout.privateId, payout.privateName)} pays $${payout.amount} to ${recipient}.`;
}

/** One toast for a whole round of private income, from the viewer's side of it.
 *
 *  ==================================================================
 *   DESIGN NOTE 967: ONE TOAST, BECAUSE IT IS ONE EVENT
 *  ==================================================================
 *
 *  REQUESTED: "Create a single, consolidated toast notification that fires at the start of the OR summarizing
 *  all PC revenues paid to the player."
 *
 *  THE LOG ALREADY WRITES ONE LINE PER PRIVATE and should keep doing so -- the feed is a record, and a record
 *  wants each payment findable. A toast is the opposite kind of surface: it is glanced at once, and four of
 *  them in a row is four things to dismiss to learn one number.
 *
 *  THE VIEWER'S OWN PRIVATES ONLY. `applyPrivateRevenue` pays every player and some corporations; a toast
 *  saying "$95 was paid out" to somebody who received $5 of it is worse than silence. Corporate payouts are
 *  excluded for the same reason -- a corporation's treasury is not the player's money (#743), and folding the
 *  two into one figure is precisely the confusion that note exists to prevent.
 *
 *  `null` WHEN THE VIEWER RECEIVED NOTHING, so the caller raises no toast rather than an empty one. A player
 *  holding no privates is the common case for most of a game.
 *
 *  THE DETAIL LISTS THE SOURCES because "you were paid $45" invites the question the list answers, and the
 *  list is short by construction: 1830 has six privates and one player rarely holds more than three. */
export interface PrivateRevenueSummary {
  total: number;
  /** How many of the viewer's privates paid -- the caller uses it for nothing, and a reader checking the
   *  arithmetic against the detail line needs it. */
  count: number;
  text: string;
  detail: string;
  /* ==================================================================
      DESIGN NOTE 984: THE ROWS, AS ROWS
     ==================================================================
     REPORTED: "Cramming all the companies onto one line is unreadable ... so the company titles and their
     respective revenues are vertically stacked and easily comparable."
     `detail` IS KEPT AND IS NOW THE FALLBACK. It is the Activity Log's shape and the shape every other
     consumer of a summary expects, and deleting it would make this function's output toast-specific.
     THE STRUCTURE TRAVELS INSTEAD OF BEING RE-DERIVED. The alternative is for the toast to split `detail` on
     its separator, which makes a middle dot into load-bearing punctuation -- one private company with a dot
     in its name and the table is silently wrong. */
  /* ==================================================================
      DESIGN NOTE 1052: THE ROW CARRIES THE PRIVATE'S NUMBER, NOT A POSITION
     ==================================================================
     REPORTED of the payout modal: "the private companies lack their enumerations, e.g. '1. Schuykill Valley'".
     AND THE NUMBER IS ALREADY ESTABLISHED, which is what decides WHICH number it is. Five surfaces render
     `${private_id}. ${name}` -- the Ledger, the player cards, the trade panel, the auction dashboard and the
     action bar -- so a private has a number a player has already learned. Numbering these rows 1..n by their
     position in one player's holdings would put a SECOND numbering on the same objects, which is #891's shape:
     two surfaces answering one question two ways. A player holding the C&A and the B&O sees "5." and "6."
     everywhere else, and would see "1." and "2." here.
     THE ID TRAVELS, THE LABEL STAYS THE NAME. Baking "5. " into `label` would make the presentation decision
     here, where the caller can no longer undo it -- and `PlayerCards` composes the same pair at its own render
     site for the same reason. */
  rows: readonly { privateId: number; label: string; value: string }[];
}

export function summarisePrivateRevenueForPlayer(
  payouts: readonly PrivatePayout[],
  viewerAddress: string | null,
): PrivateRevenueSummary | null {
  if (!viewerAddress) return null;
  const mine = payouts.filter((payout) => payout.toPlayer === viewerAddress);
  if (mine.length === 0) return null;
  const total = mine.reduce((sum, payout) => sum + payout.amount, 0);
  /* A private that pays $0 is not a payment, and a summary of nothing reads as a fault. Guarded on the TOTAL
     rather than on the list, because several $0 privates are still $0. */
  if (total <= 0) return null;
  return {
    total,
    count: mine.length,
    text: `Your private companies paid you $${total}.`,
    detail: mine.map((payout) => `${payout.privateName} $${payout.amount}`).join(" \u00B7 "),
    /* Design note #984: the same figures, unjoined. The `$` lives with the VALUE rather than being a column
       of its own -- a currency mark is part of the number a player compares, and splitting it would put two
       right-aligned columns where the request asks for one. */
    rows: mine.map((payout) => ({
      // Design note #1052: the catalog's number, the same one every other surface prints.
      privateId: payout.privateId,
      label: payout.privateName,
      value: `$${payout.amount}`,
    })),
  };
}

/* ==================================================================
    DESIGN NOTE 1049: THE PAYOUT IS A PHASE, NOT A NOTIFICATION
   ==================================================================

   ASKED, immediately after #1047 built the toast that waits: "in the physical game, the PC payouts is a
   separate phase prior to any corporation acting. All players receive their PC income at that time, and I
   think the current version has minimized or obscured that process."

   AND #1047 DECLINED A MODAL ON A PREMISE THAT WAS THEN CORRECTED. That note's case was that "modals kept
   firing at the start of basically every operating round" -- to which the answer came back: "the reason the
   modals happening every Operating Round was annoying is that the information they were displaying was
   irrelevant/old." That is a complaint about #1032's stale notices, which #1032 fixed, and not about modals.
   Once the premise went, the argument went with it, and the remaining objection -- two modals stacking on one
   turn -- was priced and accepted rather than waved away: "there aren't any Rust/Train Limit events in the
   first two phases ... two modals carrying meaningful information does not seem so overwhelming, and one is
   for players, the other is for the corporation."

   SO THIS FUNCTION GIVES THE PHASE ITS TABLE. `summarisePrivateRevenueForPlayer` above answers "what did I
   get", which is the whole of what a toast should say and half of what a phase looks like: in the physical
   game you watch everybody collect. The viewer's own privates stay itemised, because those are the figures
   they check; every other player gets ONE LINE carrying a total.

   NOT ITEMISED FOR EVERYONE, deliberately. Four players by up to six privates, every Operating Round, is a
   table nobody reads twice -- and the half of #967's objection that was right survives here: "a toast saying
   '$95 was paid out' to somebody who received $5 of it is worse than silence". A per-player total is not that
   figure. It is several figures, each labelled with whose it is, which is the thing $95 was not.

   SHOWING IT DISCLOSES NOTHING. Private ownership and revenue are public in 1830, and the Activity Log
   already writes one line per payment (#967) -- so this only spares the reader assembling from a feed what
   the table did in a single moment.

   CORPORATE PAYOUTS ARE STILL EXCLUDED, on #743's rule that a treasury is not a player's money.
   `applyPrivateRevenue` pays both; only `toPlayer` reaches this table. Folding a corporation's private income
   into a row headed by a player's name would be precisely that confusion, with a face on it.

   THE ROWS ARE IN PAYOUT ORDER, which is `state.private_companies` order, which every client replays
   identically. Stated out loud because #1044 is this session's standing lesson: a list assembled through a
   `Set` or sorted by a locale-dependent comparator would put two browsers' rows in two orders for the same
   round, and that desync would present as a rendering quirk rather than as what it is. */
export interface PrivateRevenueRound {
  /** The viewer's own privates, itemised. `null` when they collected nothing this round. */
  mine: PrivateRevenueSummary | null;
  /** Every OTHER player who collected, in payout order, with their round total.
   *  Design note #1270: ITEMISED AFTER ALL, but folded. #1049's "never itemised" was the concession that
   *  kept four players by six privates off the panel; the 7 September plan asks for the rows back behind a
   *  click -- "collapsed: player name and cash consequence; expanded: that entity's private company holdings
   *  and each company's income." The rows are built here, once, in the same shape as the viewer's own. */
  others: readonly {
    address: string;
    total: number;
    rows: readonly { privateId: number; label: string; value: string }[];
  }[];
}

export function summarisePrivateRevenueRound(
  payouts: readonly PrivatePayout[],
  viewerAddress: string | null,
): PrivateRevenueRound {
  const mine = summarisePrivateRevenueForPlayer(payouts, viewerAddress);
  /* AN ARRAY OF PAIRS RATHER THAN A `Map`, so first-payment order IS the order and there is no iteration
     contract to reason about at all. 1830 has six privates, so the linear scan is not worth a second thought
     and the guarantee is worth stating in code rather than in a comment about `Map` insertion semantics. */
  const others: {
    address: string;
    total: number;
    rows: { privateId: number; label: string; value: string }[];
  }[] = [];
  for (const payout of payouts) {
    if (!payout.toPlayer) continue;
    if (payout.toPlayer === viewerAddress) continue;
    /* GUARDED THE SAME WAY THE VIEWER'S SUMMARY IS. `applyPrivateRevenue` already skips a private paying
       nothing, so this is belt-and-braces -- but a row reading "$0" beside a player's name asserts they were
       paid, and #562's rule is that a zero and an absence are different facts. */
    if (payout.amount <= 0) continue;
    const row = { privateId: payout.privateId, label: payout.privateName, value: `$${payout.amount}` };
    const seen = others.find((entry) => entry.address === payout.toPlayer);
    if (seen) {
      seen.total += payout.amount;
      seen.rows.push(row);
    } else {
      others.push({ address: payout.toPlayer, total: payout.amount, rows: [row] });
    }
  }
  return { mine, others };
}

/* ------------------------------------------------------------------ */
/* The board: laying a tile in sandbox                                */
/* ------------------------------------------------------------------ */

/** The tile grid is a separate query document, so it gets its own reducer. The whole tiles array is rebuilt because the renderer's draw effect watches identity. Legality stays hexmap::execute_lay_tile's.
 *  See docs/ai_architecture/sandbox_reducer.md - sandboxSession.ts #0 */
export function applySandboxLayTile(
  mapGrid: MapGridResponse,
  q: number,
  r: number,
  tileId: number,
  orientation: number,
  /** Design note #757: the SAME refusal `applySandboxAction` applies, so the tile grid and the game state
   *  cannot disagree about whether a lay happened. Absent means no opinion. */
  layRefused?: (q: number, r: number, tileId: number, orientation: number) => boolean,
): MapGridResponse {
  /* Unchanged, by identity, for #712's reason -- and because the caller is a `setMapGrid` updater, where
     returning the same reference is also what stops a refused lay from repainting the board. */
  if (layRefused?.(q, r, tileId, orientation) === true) return mapGrid;

  const catalogEntry = TILE_CATALOG_BY_ID.get(tileId);
  const existing = mapGrid.tiles.find((tile) => tile.q === q && tile.r === r);

  const placed: MapTileEntry = {
    q,
    r,
    tile_id: tileId,
    orientation,
    // `paths` drives the track splines. Passing the catalog's own base
    // (pre-rotation) pairs matches exactly what the chain returns, so
    // `rotatePaths` downstream behaves identically either way.
    paths: catalogEntry?.paths ?? null,
    // `revenue` is what a stop on this hex pays. Serialised as a STRING on
    // the wire because the backend field is `Uint128`; matching that here
    // keeps `chainTileRevenue`'s single parse site honest rather than
    // handing it a number only the sandbox ever produces.
    revenue: catalogEntry?.revenue === undefined ? undefined : String(catalogEntry.revenue),
    // `landmark` is a property of the HEX, not of the tile sitting on it --
    // Boston is still Boston after its yellow tile is upgraded to green. So
    // an upgrade carries the existing value forward rather than clearing it,
    // and a first lay on a plain hex has none.
    landmark: existing?.landmark ?? null,
  };

  // An upgrade REPLACES the tile already on that hex rather than stacking a
  // second entry on the same coordinate -- two entries at one `(q, r)` would
  // draw both tiles on top of each other, and `hexHasLaidTile`'s membership
  // test would still pass after a hypothetical removal.
  const kept = mapGrid.tiles.filter((tile) => tile !== existing);

  return { ...mapGrid, tiles: [...kept, placed] };
}
