// frontend/src/components/tileTransitionCanvas.ts
//
// VF-5: the tile-lay and tile-upgrade flourish -- the PAINTING half. Everything here takes a context and a
// `TileTransitionFrame` (`tileTransition.ts`) and returns nothing; nothing here decides what moves.
//
// ONE PEN WITH THE BOARD. Rails go through `strokeTrackLayers` at `trackPenWidth` with the same white outline
// and the destination's own layer order and overpasses, and every station outline is the same fattened stroke
// `drawStationCircle` / `drawStationPill` / `drawStationCluster` paint -- ink band at the station radius,
// white inside -- so the last frame of a transition and the authoritative tile that replaces it are the same
// picture, and the hand-over is not a visible event.
//
// THE ONE EXCEPTION IS NEW RAIL WHILE IT ERUPTS (#1469): a portion behind the construction front carries a
// `widthScale`, and is stroked with the same pen at that multiple and its own opacity, in its destination rail's
// layer. It is gone from the frame once it settles, so the settled frame is still the board's pen throughout.

import { STANDARD_TRACK_INK } from "./hexBoardData";
import { TRACK_OUTLINE_EXTRA_PX, TRACK_OUTLINE_INK, drawHexPath, strokeTrackLayers, trackPenWidth } from "./hexCanvasPrimitives";
import { ringCoveredArcs, ringUnionArcs, type FrameCity, type FrameRing, type TileTransitionFrame, type Vec } from "./tileTransition";

type Point = { x: number; y: number };

const toPx = (center: Point, size: number, v: Vec): Point => ({ x: center.x + v.x * size, y: center.y + v.y * size });

/** The hex's fill and rim, in the tile loop's place: old tier, foundation, destination wash, bottom to top, then the
 *  one rim at the tile loop's own width. */
export function drawTileTransitionFill(
  ctx: CanvasRenderingContext2D,
  center: Point,
  size: number,
  frame: TileTransitionFrame,
): void {
  ctx.save();
  for (const fill of frame.fills) {
    if (fill.alpha <= 0) continue;
    ctx.globalAlpha = fill.alpha;
    drawHexPath(ctx, center, size);
    ctx.fillStyle = fill.color;
    ctx.fill();
  }
  if (frame.rim.alpha > 0) {
    ctx.globalAlpha = frame.rim.alpha;
    drawHexPath(ctx, center, size);
    ctx.strokeStyle = frame.rim.color;
    ctx.lineWidth = 2;
    ctx.stroke();
  }
  ctx.restore();
}

function pathThrough(center: Point, size: number, points: readonly Vec[], closed = false): Path2D {
  const path = new Path2D();
  points.forEach((point, index) => {
    const at = toPx(center, size, point);
    if (index === 0) path.moveTo(at.x, at.y);
    else path.lineTo(at.x, at.y);
  });
  if (closed) path.closePath();
  return path;
}

function coincident(points: readonly Vec[]): boolean {
  return points.every((point) => Math.abs(point.x - points[0].x) < 1e-6 && Math.abs(point.y - points[0].y) < 1e-6);
}

/** Rails then revenue centres, in the order `drawHardcodedTileArtwork` paints them. Call inside the hex clip. */
export function drawTileTransitionArt(
  ctx: CanvasRenderingContext2D,
  center: Point,
  size: number,
  frame: TileTransitionFrame,
): void {
  const pen = trackPenWidth(size);
  const ink = frame.ink;

  /* ---- rails ---- */
  ctx.save();
  // Pieces fading out (an unexpected pair's leftovers, or reduced motion's crossfade) are stroked on their own.
  for (const track of frame.tracks) {
    if (track.widthScale !== undefined || track.alpha >= 1 || track.alpha <= 0 || track.points.length < 2) continue;
    ctx.save();
    ctx.globalAlpha = track.alpha;
    strokeTrackLayers(ctx, { layers: [[pathThrough(center, size, track.points)]], crossings: [] }, pen, TRACK_OUTLINE_EXTRA_PX, ink);
    ctx.restore();
  }
  // Opaque pieces are gathered by destination rail, so the destination's layers and overpasses apply. Each
  // piece is its own subpath of that rail's path (built point by point: `addPath` may join subpaths).
  const piecesByTrack = new Map<number, Vec[][]>();
  const loose: Path2D[] = [];
  // New rail still erupting (#1469), by the layer of the destination rail it is building.
  const eruptingByLayer = new Map<number, EruptingPortion[]>();
  const allErupting: EruptingPortion[] = [];
  for (const track of frame.tracks) {
    if (track.points.length < 2) continue;
    if (track.widthScale !== undefined) {
      if (track.alpha <= 0 || track.destTrack === null) continue;
      const layer = frame.destLayers[track.destTrack] ?? 0;
      const portion = {
        path: eruptingPath(center, size, track.points),
        alpha: Math.min(1, track.alpha),
        widthScale: track.widthScale,
        destTrack: track.destTrack,
      };
      eruptingByLayer.set(layer, [...(eruptingByLayer.get(layer) ?? []), portion]);
      allErupting.push(portion);
      continue;
    }
    if (track.alpha < 1) continue;
    if (track.destTrack === null) {
      loose.push(pathThrough(center, size, track.points));
      continue;
    }
    piecesByTrack.set(track.destTrack, [...(piecesByTrack.get(track.destTrack) ?? []), track.points]);
  }
  const byTrack = new Map<number, Path2D>();
  piecesByTrack.forEach((pieces, trackIndex) => {
    const path = new Path2D();
    for (const points of pieces) {
      points.forEach((point, index) => {
        const at = toPx(center, size, point);
        if (index === 0) path.moveTo(at.x, at.y);
        else path.lineTo(at.x, at.y);
      });
    }
    byTrack.set(trackIndex, path);
  });
  const layerCount = frame.destLayers.reduce((max, layer) => Math.max(max, layer + 1), 0);
  const layers: Path2D[][] = Array.from({ length: layerCount }, () => []);
  byTrack.forEach((path, trackIndex) => {
    const layer = frame.destLayers[trackIndex] ?? 0;
    layers[layer].push(path);
  });
  const crossings = frame.crossings.flatMap((crossing) => {
    const over = byTrack.get(crossing.over);
    if (!over) return [];
    const at = toPx(center, size, crossing);
    return [{ x: at.x, y: at.y, sinAngle: crossing.sinAngle, over }];
  });
  if (loose.length > 0) strokeTrackLayers(ctx, { layers: [loose], crossings: [] }, pen, TRACK_OUTLINE_EXTRA_PX, ink);
  // Layer by layer, as one `strokeTrackLayers` call would -- with each layer's erupting portions inside the same two
  // passes: their outline goes down before the layer's rails and their ink after, so no white is ever laid over
  // ink of the layer (where a branch leaves a rail that is already there), and a higher layer still crosses over.
  layers.forEach((layer, layerIndex) => {
    const erupting = eruptingByLayer.get(layerIndex) ?? [];
    strokeErupting(ctx, erupting, TRACK_OUTLINE_INK, pen + TRACK_OUTLINE_EXTRA_PX);
    if (layer.length > 0) strokeTrackLayers(ctx, { layers: [layer], crossings: [] }, pen, TRACK_OUTLINE_EXTRA_PX, ink);
    strokeErupting(ctx, erupting, ink, pen);
  });
  if (crossings.length > 0) strokeTrackLayers(ctx, { layers: [], crossings }, pen, TRACK_OUTLINE_EXTRA_PX, ink);
  // An overpass whose upper rail is still erupting there cuts its gap with that rail's erupting portions, through
  // the same overpass stroke at the portion's own pen and opacity.
  for (const crossing of frame.crossings) {
    for (const portion of allErupting) {
      if (portion.destTrack !== crossing.over) continue;
      const at = toPx(center, size, crossing);
      ctx.save();
      ctx.globalAlpha = portion.alpha;
      strokeTrackLayers(
        ctx,
        { layers: [], crossings: [{ x: at.x, y: at.y, sinAngle: crossing.sinAngle, over: portion.path }] },
        pen * portion.widthScale,
        TRACK_OUTLINE_EXTRA_PX * portion.widthScale,
        ink,
      );
      ctx.restore();
    }
  }
  ctx.restore();

  /* ---- revenue centres ---- */
  for (const city of frame.cities) drawCity(ctx, center, size, city);
  ctx.save();
  ctx.fillStyle = "#000000";
  for (const town of frame.towns) {
    if (town.radius <= 0 || town.alpha <= 0) continue;
    ctx.globalAlpha = town.alpha;
    const at = toPx(center, size, town.at);
    ctx.beginPath();
    ctx.arc(at.x, at.y, town.radius * size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/** How far, in board pixels, an erupting portion starts back under the rail behind it. Two antialiased cuts that
 *  merely abut let a hairline of the tile show between them; half a pixel of overlap along the rail's own direction
 *  closes it without moving either cut the frame describes. */
const PORTION_SEAM_PX = 0.5;

function eruptingPath(center: Point, size: number, points: readonly Vec[]): Path2D {
  const px = points.map((point) => toPx(center, size, point));
  const [first, second] = px;
  const run = Math.hypot(second.x - first.x, second.y - first.y);
  if (run > 1e-6) {
    px[0] = {
      x: first.x - ((second.x - first.x) / run) * PORTION_SEAM_PX,
      y: first.y - ((second.y - first.y) / run) * PORTION_SEAM_PX,
    };
  }
  const path = new Path2D();
  px.forEach((at, index) => (index === 0 ? path.moveTo(at.x, at.y) : path.lineTo(at.x, at.y)));
  return path;
}

interface EruptingPortion {
  path: Path2D;
  alpha: number;
  widthScale: number;
  destTrack: number;
}

/** One pass of the rail pen over erupting portions (#1469), each at its own opacity and swollen width. Butt-capped
 *  with round joins, as `strokeTrackLayers` strokes every rail, so a portion swells across the rail, not along it. */
function strokeErupting(ctx: CanvasRenderingContext2D, portions: readonly EruptingPortion[], color: string, width: number): void {
  if (portions.length === 0) return;
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "butt";
  ctx.strokeStyle = color;
  for (const portion of portions) {
    ctx.globalAlpha = portion.alpha;
    ctx.lineWidth = width * portion.widthScale;
    ctx.stroke(portion.path);
  }
  ctx.restore();
}

/* All ink bands first, then all white interiors, so shapes that overlap -- a pill extruding into a triangle,
   two cities growing a neck -- read as ONE outline with no ink inside it. Then the slot rings, as the union of
   their circles, so a dividing slot is one pinched outline rather than two rings crossing. */
function drawCity(ctx: CanvasRenderingContext2D, center: Point, size: number, city: FrameCity): void {
  if (city.alpha <= 0) return;
  const markerPx = city.markerScale * size;
  const rim = Math.max(2, markerPx * 0.06);
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  const pass = (color: string, grow: number) => {
    for (const blob of city.blobs) {
      const radius = blob.radius * size + grow;
      const alpha = city.alpha * (blob.alpha ?? 1);
      if (radius <= 0 || blob.points.length === 0 || alpha <= 0) continue;
      ctx.globalAlpha = alpha;
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      if (coincident(blob.points)) {
        const at = toPx(center, size, blob.points[0]);
        ctx.beginPath();
        ctx.arc(at.x, at.y, radius, 0, Math.PI * 2);
        ctx.fill();
        continue;
      }
      const closed = blob.closed && blob.points.length >= 3;
      const path = pathThrough(center, size, blob.points, closed);
      ctx.lineWidth = radius * 2;
      ctx.stroke(path);
      if (closed) ctx.fill(path);
    }
  };
  pass(STANDARD_TRACK_INK, rim / 2);
  pass("#ffffff", -rim / 2);

  const ringWidth = Math.max(1, markerPx * 0.03);
  ctx.strokeStyle = STANDARD_TRACK_INK;
  const strokeArc = (ring: FrameRing, start: number, end: number, alpha: number) => {
    if (alpha <= 0 || ring.radius <= 0) return;
    const at = toPx(center, size, ring.at);
    ctx.globalAlpha = alpha;
    ctx.lineWidth = ringWidth * ring.lineScale;
    ctx.beginPath();
    ctx.arc(at.x, at.y, ring.radius * size, start, end);
    ctx.stroke();
  };
  if (city.ringsWhole >= 1) {
    // Whole circles, each stroked once -- the printed drawing, crossings included: the old tile's before the slots
    // move, the destination's once they settle.
    for (const ring of city.rings) strokeArc(ring, 0, Math.PI * 2, city.alpha * ring.alpha);
  } else {
    // In between, the union's outline, with the arcs it leaves out -- where one ring runs inside another -- at the
    // circles' wholeness. Those arcs are the union's complement, never a second stroke over it: a ring stroked twice
    // antialiases heavier, and the hand-over to the tile pass would visibly thin every ring on the hex.
    const union = ringUnionArcs(city.rings);
    for (const arc of union) strokeArc(city.rings[arc.ring], arc.start, arc.end, city.alpha * city.rings[arc.ring].alpha);
    if (city.ringsWhole > 0) {
      for (const arc of ringCoveredArcs(city.rings, union)) {
        const ring = city.rings[arc.ring];
        strokeArc(ring, arc.start, arc.end, city.alpha * ring.alpha * city.ringsWhole);
      }
    }
  }
  ctx.restore();
}
