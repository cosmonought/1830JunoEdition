// frontend/src/utils/routeAutoTrace.ts
//
// The Auto Route button's tracer -- a client-side SUGGESTION, not an oracle.
//
// Design note #0: a player asking for a route drawn for them is asking the UI to pre-fill the manual builder,
// which needs no chain at all. The result still travels to the contract as the same `RunManualRoute` the
// player could have clicked out by hand, and the contract still validates it.
//
// THE LINE THIS MUST NOT CROSS. `pathfinding.rs` remains the only authority on what a legal route IS, and
// the following are deliberately NOT a to-do list: TOKEN ACCESS (this starts AT a token, which satisfies half
// by construction, and ignores city-slot blocking entirely); CITY SLOTS (a two-city hex is one node here);
// TRAIN COUNT (#7 approximates the allocation problem, it does not solve it); OVERLAP (#4 bars rails, which
// is the rule -- an earlier pass barred whole hexes, which was stricter and therefore safe for a suggestion,
// but was not the rule and must not be mistaken for it).
//
// Design note #1: connectivity is checked from BOTH SIDES. Checking one side only is the classic 18xx map
// bug -- a dead-end stub reads as connected to whatever sits beyond it, and the tracer walks off the rails.
//
// Design notes #2-#9: see `docs/ai_architecture/routing_pathfinding.md`.

import { isUnlimitedReach } from "./trainReach";
import {
  HEX_NEIGHBOR_OFFSETS,
  /* Design note #852: `liveEdgesForHex` is no longer called here, for the reason `trackReach.ts` #686 gives
     for dropping it there: it answers "every rail on this hex", which is the hex-as-a-node model, and the
     start of a route is the last place that model survived. `cityExitEdges` answers the same question for a
     one-city hex and a narrower one for a hex with two. */
  cityExitEdges,
  hexRouteValue,
  /* STILL USED BY `bridgeWaypoints` ALONE, and #852 leaves it there deliberately. The bridge starts at a hex
     the PLAYER CLICKED, not at a token, and a click carries no city -- so scoping it would need waypoints to
     name a city, which is a contract change (`RouteWaypointDto` has no such field) rather than a fix. The gap
     is real and is recorded at that function rather than papered over here: a manual route bridging out of a
     two-city hex can still leave by the wrong arm. */
  liveEdgesForHex,
} from "../components/hexGeometry";
import type { MapGridResponse } from "../components/hexContractTypes";
import { STATIC_BOARD_HEXES, boardMemo, heraldAt } from "../components/hexBoardData";
import type { TileColorTier } from "../components/hexTileCatalog";
import { isRouteTerminusHex, sandboxRouteBreakdown } from "./sandboxSession";
// Design note #730: which city an arrival lands in -- shared with the network walk so both ask one question.
import { cityForArrival, stopForArrival, type StationToken } from "./trackReach";
// Design note #1023: the same shut-city predicate the network walk and the auto-tracer already ask.
import { cityShutAt } from "./cityBypass";
import {
  neighbourAcross,
  segmentsTouchingEdge,
  traversalSegments,
  traversalsFrom,
  type HexTraversal,
  type SegmentKey,
} from "./trackSegments";

/** One traced stop, in the shape `App`'s `RoutePoint` already uses. */
export interface TracedHex {
  q: number;
  r: number;
  hexLabel: string;
  /** Design note #737: which authored way through this hex the route took. `undefined` and `0` both mean the
   *  first, which is every hex on the board except Altoona. Carried so `routeSegments` can name the right
   *  rail -- two trains taking H12's two different tracks hold different keys. */
  variant?: number;
  /** Design note #737: the route crossed this hex WITHOUT reaching its revenue centre.
   *  Set at trace time, where the rail chain is known, and read by `sandboxRouteBreakdown`, where it is not.
   *  A bypassed hex pays nothing AND costs no stop -- the second is what makes the bow worth taking. */
  bypass?: boolean;
}

const labelByCoord = boardMemo(
  (board): ReadonlyMap<string, string> =>
    new Map(board.hexes.map((hex) => [`${hex.q},${hex.r}`, hex.label])),
);

function labelFor(q: number, r: number): string | null {
  return labelByCoord().get(`${q},${r}`) ?? null;
}

/* `connectedNeighbours` is GONE with design note #9 -- it was this file's last hex-as-a-node walker, and the
   waypoint bridge was its last caller. `trackSegments.neighbourAcross` keeps the both-sides rule and
   `traversalsFrom` supplies the half it never had: WHICH rail.
   Deleted rather than left unused. It survived the tracer's conversion because nothing pointed at it from
   there any more, and one function still quietly calling it is exactly how tile #56 kept bridging its two
   curves for a whole chunk after the bug was declared fixed. */

/* Design note #5: CLICKING TWO CITIES SHOULD NOT MEAN CLICKING NINE HEXES. The builder's only connectivity
   rule was "the next point must be a DIRECT NEIGHBOUR" -- correct about what a route is, wrong about what a
   player is doing when they draw one. Nobody choosing a route is choosing the plain track; they are choosing
   the STOPS. A five-stop route was twenty clicks, nineteen of which had exactly one legal answer.
   IT PREFERS PLAIN TRACK, AND THAT IS THE INTERESTING PART. A bridge that passes through a third city
   silently adds that city's revenue AND spends one of the train's stops, neither of which was asked for -- so
   crossing a revenue centre costs far more than crossing plain track. Where there is no alternative the
   centre IS included, because the train genuinely stops there, and it appears in the stop list with its
   value. What must never happen is a stop appearing in the total that the player cannot see.
   THE MANUAL CLICK STILL WINS: the bridge only fills gaps the player left.
   WHAT THIS IS NOT: token access, city slot capacity, or whether another train has used this track. Same
   list as #0, same owner. */

/** The cost of routing a bridge THROUGH a revenue centre, in units of plain
 *  hexes. Large enough that no realistic detour outweighs it, finite so an
 *  unavoidable centre is still crossed rather than the bridge failing. */
const CENTRE_DETOUR_COST = 1000;

/** The hexes joining `from` to `to` over live track, `to` included and `from` excluded.
 *  `null` when no connected path exists, which the caller reports rather than papering over: two hexes with no
 *  rails between them are not a route, and inventing a straight line across the board is exactly the class of
 *  plausible fiction #216 deleted.
 *  `avoid` is the hexes already on this route. A route is a simple path, so a bridge may not loop back through
 *  one -- without this, clicking a city the route already passed through would produce a chain that visits a
 *  hex twice and prices it once, and the two would disagree. */
export function bridgeWaypoints(
  mapGrid: MapGridResponse,
  from: TracedHex,
  to: TracedHex,
  avoid: ReadonlySet<string> = new Set(),
  /** ==================================================================
   *   DESIGN NOTE 1023: THE THIRD WALK, AND THE ONE THAT NEVER LEARNED THE RULE
   *  ==================================================================
   *
   * REPORTED: "When trying to route C&O past Altoona, the router snaps to the tokened-out PRR city and throws
   * an error. Worse, it completely refuses to draw a path along the bypass track."
   *
   * `blocksThrough` HAS BEEN THREADED THROUGH TWO WALKS AND NOT THIS ONE. #729 taught the network reach about
   * tokens, #730 taught the auto-tracer, and #820 taught both about the bow -- "the wall has a door in it".
   * The MANUAL bridge, which is what fills the gap between two clicked hexes, was never given the predicate at
   * all. It is the same omission #808's own note lists as its first finding, one walk over: "this walk may
   * still explore out of the wrong arm ... so it can propose a bridge the token rule will then refuse."
   *
   * OMITTED MEANS NO BLOCKING, reproducing every pre-#1023 caller exactly. */
  blocksThrough?: (q: number, r: number, cityIndex: number) => boolean,
): TracedHex[] | null {
  const fromKey = `${from.q},${from.r}`;
  const toKey = `${to.q},${to.r}`;
  if (fromKey === toKey) return null;

  /* ==================================================================
      DESIGN NOTE 852a: THE BRIDGE STILL LEAVES BY ANY RAIL, AND THAT IS A GAP
     ==================================================================
     #852 scoped the SEARCH's start to the tokened city, because a token knows which city it is in. A BRIDGE
     starts at a hex the player CLICKED, and a click carries no city: `RouteWaypointDto` has a hex and nothing
     else, so there is no city index to scope by and inventing one here would be a guess dressed as a rule.
     THE CONSEQUENCE, NARROWED BY #853. This paragraph originally said a manual route out of a two-city hex
     was accepted and that fixing it needed `RouteWaypointDto` to carry a city -- a contract change. BOTH
     HALVES WERE WRONG, and the correction is kept rather than quietly rewritten:
       WHAT ACCEPTED SUCH A ROUTE was `routeIncludesOwnedToken`, comparing coordinates. #853 makes it ask
       which city the route's own rails belong to, so a run touching New York by the other arm is refused
       whatever drew it.
       NO NEW FIELD WAS NEEDED. The hexes either side of a point determine the edges the route uses at that
       point -- which `hexCanvasPrimitives.ts` #689 has been deriving to DRAW the route all along.
     WHAT SURVIVES HERE is smaller and is about SEARCH rather than legality: this walk may still explore out
     of the wrong arm while looking for a path between two waypoints, so it can propose a bridge the token
     rule will then refuse. A rejected suggestion rather than an illegal route -- worth fixing, not urgent.

     Design note #9: THE BRIDGE WALKS RAILS TOO. Reported: with tile #56 on G7, the router bridges H8 to F6
     across two curves that do not touch. `trackSegments.ts #0` fixed this class of bug in the network reach and
     in the auto-tracer, and this function was missed -- it kept its own hex-to-hex Dijkstra, which is the
     hex-as-a-node model that cannot see a crossover.
     Reproduced on the real board with the reported hexes before the fix, which is also why the earlier audit
     came back clean: the AUTO tracer asks the strict primitive. Only the manual bridge did not, so only manual
     routing hallucinated -- and the previous report had named the auto-router.
     The walk is over (HEX, ARRIVAL EDGE) states now. One hex may legitimately be visited twice by two different
     rails, so the visited set is keyed on the state rather than the hex. */
  /* ==================================================================
      DESIGN NOTE 1023: THE BOW IS A DISTINCT EDGE, AND THIS GRAPH HAD COLLAPSED IT
     ==================================================================
     REPORTED: "The pathfinding algorithm is treating the bypass track as non-existent or inextricably linked
     to the blocked city node."

     EXACTLY SO, AND THE COLLAPSE WAS ONE `.map`. The expansion read
       `traversalsFrom(...).map((transit) => transit.exitEdge)`
     which throws away everything #737 built that list to preserve: it "yields one entry per WAY through, not
     per exit", and Altoona's two tracks join the SAME two edges. Mapping to `exitEdge` turns two distinct arms
     into one number, so the graph could not represent the bow at all -- and the node it emitted carried
     neither `variant` nor `bypass`, so even a crossing that had taken the bow was recorded as a crossing
     through the station.

     THE STATE CARRIES THE ARM NOW. `variant` joins the key, so the two ways through one hex are two states
     rather than one that dedupes the other away -- the same fix #4 made to the network walk when a crossover
     was two rails rather than a junction. */
  interface BridgeState {
    q: number;
    r: number;
    /** `null` only for the start, which the player is standing on and may
     *  leave by any of its rails. */
    arrivalEdge: number | null;
    /** Design note #1023: which authored way through this hex was taken to reach it. */
    variant?: number;
    /** Design note #1023: that way missed the hex's revenue centre. */
    bypass?: boolean;
  }
  const stateKey = (state: BridgeState) =>
    `${state.q},${state.r}:${state.arrivalEdge ?? "start"}:${state.variant ?? 0}`;

  const startState: BridgeState = { q: from.q, r: from.r, arrivalEdge: null };
  const dist = new Map<string, number>([[stateKey(startState), 0]]);
  /* Design note #9: `cameFrom` is the predecessor STATE's key, and `nodeAt` turns a key back into a hex. The
     split is load-bearing -- an earlier cut stored each node under its own key and walked the chain back
     through it, which reads a node's predecessor as itself and returned `null` for every connected pair. */
  const cameFrom = new Map<string, string>();
  const stateAt = new Map<string, BridgeState>([[stateKey(startState), startState]]);
  const nodeAt = new Map<string, TracedHex>([[stateKey(startState), from]]);
  const settled = new Set<string>();
  /** Design note #1023: how each settled state was CROSSED on the way out of it. */
  const crossingAt = new Map<string, { variant?: number; bypass?: boolean }>();

  let arrivedKey: string | null = null;

  for (;;) {
    let bestKey: string | null = null;
    let bestCost = Infinity;
    dist.forEach((cost, key) => {
      if (!settled.has(key) && cost < bestCost) {
        bestCost = cost;
        bestKey = key;
      }
    });
    if (bestKey === null) break;
    const at = stateAt.get(bestKey as string);
    if (!at) break;
    if (at.q === to.q && at.r === to.r) {
      arrivedKey = bestKey;
      break;
    }
    settled.add(bestKey as string);

    /* From the start hex, every rail on it is available -- the player is
       standing in the city. Having arrived on a rail, only the exits that
       rail actually reaches. */
    /* ==================================================================
        DESIGN NOTE 1023: A SHUT CITY LEAVES ONLY THE WAYS THAT MISS IT
       ==================================================================
       This is #820's rule, applied to the third walk. That note fixed the network reach: "a city full of other
       corporations' tokens has nothing to say about track that never touches it", so a blocked hex keeps its
       BYPASS arms and loses the rest.

       WHICH IS ALSO ITEM 2 OF THE REPORT -- "the algorithm must dynamically weight tokened-out city nodes as
       impassable ... This must force the algorithm to naturally traverse the bypass edge." Impassable rather
       than expensive, deliberately: a weight can always be outbid by a long enough detour, and a route through
       a shut city is not a worse route, it is an illegal one. The bow becomes the only way across, which is
       what makes the player's click land on it without any snapping rule of its own.

       ASKED ON THE HEX BEING LEFT, not the one being entered -- the arm is a property of the crossing, which
       is #820's own correction to #729's arrival-time check.

       THE START IS EXEMPT. `arrivalEdge === null` is the hex the player is standing on; a corporation is not
       blocked by a city it is already in, and the terminus rule (#730) says a run may END in a shut city. */
    const shutHere =
      at.arrivalEdge !== null && blocksThrough
        ? cityShutAt(at.q, at.r, blocksThrough)
        : false;
    const transits: { exitEdge: number; variant?: number; bypass?: boolean }[] =
      at.arrivalEdge === null
        ? liveEdgesForHex(mapGrid, at.q, at.r).map((exitEdge) => ({ exitEdge }))
        : traversalsFrom(mapGrid, at.q, at.r, at.arrivalEdge).filter(
            (transit) => !shutHere || transit.bypass === true,
          );

    for (const transit of transits) {
      const edge = transit.exitEdge;
      const next = neighbourAcross(mapGrid, at.q, at.r, edge);
      if (!next) continue;
      const hexLabel = labelFor(next.q, next.r);
      if (hexLabel === null) continue;

      const isDestination = next.q === to.q && next.r === to.r;
      // The destination is allowed even if `avoid` lists it -- the caller
      // decides what clicking an existing hex means, and that is the undo
      // rule rather than this function's business.
      if (!isDestination && avoid.has(`${next.q},${next.r}`)) continue;

      /* Design note #1023: the arm is a property of the crossing that LEAVES a hex, so it is recorded on the
         state that arrives at the next one -- and reconstructed onto the predecessor when the path is walked
         back, which is where it belongs on a waypoint. */
      const nextState: BridgeState = { q: next.q, r: next.r, arrivalEdge: next.arrivalEdge };
      const key = stateKey(nextState);
      if (settled.has(key)) continue;

      /* The DESTINATION's own value is not charged: the player asked for it, so its cost is not a reason to route
         around it. Only hexes the bridge passes THROUGH are weighted.
         `hexRouteValue` is `null` off the value table and `0` for plain track -- both mean "pays nothing", and only
         a positive value is a revenue centre worth detouring around. */
      const paysHere = (hexRouteValue(next.q, next.r, mapGrid) ?? 0) > 0;
      const step = isDestination || !paysHere ? 1 : CENTRE_DETOUR_COST + 1;
      const cost = bestCost + step;
      if (cost < (dist.get(key) ?? Infinity)) {
        dist.set(key, cost);
        cameFrom.set(key, bestKey as string);
        stateAt.set(key, nextState);
        nodeAt.set(key, { q: next.q, r: next.r, hexLabel });
        /* Design note #1023: the crossing that got us OUT of `at` describes `at`, not `next`. Recorded against
           the predecessor's key so the reconstruction below can stamp the hex the bow actually belongs to --
           without this the flag would land one hex downstream, which prices the wrong tile. */
        if (transit.bypass === true || transit.variant !== undefined) {
          crossingAt.set(bestKey as string, {
            variant: transit.variant,
            bypass: transit.bypass,
          });
        }
      }
    }
  }

  if (arrivedKey === null) return null;

  const path: TracedHex[] = [];
  let cursor: string = arrivedKey;
  const startKey = stateKey(startState);
  while (cursor !== startKey) {
    const node = nodeAt.get(cursor);
    const previous = cameFrom.get(cursor);
    if (!node || previous === undefined) return null;
    /* Design note #1023: stamp the hex with the way it was crossed. `crossingAt` is keyed by the state the
       crossing LEFT, which is this node's own key on the way back. `TracedHex` has carried these two fields
       since #737 and this walk was dropping both -- so a manual bridge over Altoona re-priced through the
       station even when it had gone round it. */
    const crossing = crossingAt.get(cursor);
    path.unshift(
      crossing === undefined
        ? node
        : {
            ...node,
            ...(crossing.variant !== undefined ? { variant: crossing.variant } : {}),
            ...(crossing.bypass === true ? { bypass: true } : {}),
          },
    );
    cursor = previous;
    // A corrupt predecessor chain would spin forever; the board is finite
    // and no simple path can exceed it.
    if (path.length > MAX_BRIDGE_HEXES) return null;
  }
  return path;
}

/** No simple path over the authentic board can be longer than the board. */
const MAX_BRIDGE_HEXES = 120;

/** How far the search may wander, and how much work it may do getting there. A depth cap alone is not enough:
 *  a dense late-game board branches, and an unbounded DFS over it is exponential. The expansion budget makes
 *  the worst case a bounded amount of work rather than a frozen tab -- reached, it returns the best route
 *  found so far, which is a suggestion that is merely not optimal rather than one that never arrives.
 *
 *  ==================================================================
 *   DESIGN NOTE 892: A HEX IS NOT A REVENUE CENTRE
 *  ==================================================================
 *
 *  REPORTED: "Something is definitely broken with auto-route on D trains. The auto-route gave me a $400 run
 *  but I was able to manually construct a run with the D train for $530 ... The autoroute chose to end the
 *  route at a $70 stop instead of continuing, shortchanging the corporation out of $190."
 *
 *  AND THE PLAYER'S OWN GUESS WAS RIGHT: "I wonder in part if there is in fact a revenue center cap that has
 *  been imposed on D-trains." There was, and it was this constant. `candidateRoutes` read
 *  `const cap = isUnlimitedReach(maxRevenueCentres) ? MAX_PATH_HEXES : maxRevenueCentres` -- a PATH LENGTH
 *  used as a STOP BUDGET. Two quantities, one number, and `trainReach.ts` documented the arrangement as
 *  deliberate: "routeAutoTrace bounds an unlimited budget by MAX_PATH_HEXES at its own end, so handing it
 *  this is safe as well as consistent." It was not safe; it was a cap wearing the wrong unit.
 *
 *  MEASURED AGAINST THE REPORTED GAME, AND THE FIRST READING OF THAT MEASUREMENT WAS WRONG. It is recorded
 *  because the correction is the useful part.
 *
 *  THE CLAIM WAS: ERIE's logged run is 25 hexes, `MAX_PATH_HEXES` was 14, therefore the walk could not reach
 *  it. That is false, and the negative control said so -- reverting both constants to 14 left every
 *  assertion passing. `candidateRoutes` JOINS TWO ARMS through the starting token (#2, right above the join),
 *  so the leash bounds each ARM and not the route: at 14 the search still returned a 23-hex path.
 *
 *  WHAT THE CAPS ACTUALLY COST, replayed on that board: the old code found $520 and the decoupled one finds
 *  $740 over 41 hexes. So the ceiling was real and expensive -- $220 on one run -- and it bit through the
 *  STOP BUDGET rather than through the walk. A Diesel handed a budget of 14 stops banks its fourteenth and
 *  stops, which is the report's own words: "the autoroute chose to end the route at a $70 stop instead of
 *  continuing."
 *
 *  THE UNIT CONFUSION IS STILL THE BUG. A path length spent as a stop budget is wrong whichever of the two
 *  limits happens to bind first, and the fix is the same. What changed is the sentence explaining it.
 *
 *  SO THE TWO ARE SEPARATED, and only the unlimited train's numbers change. A capped train's budget is its
 *  own reach and always was; what it needed was a walk long enough to SPEND that budget, since the hexes
 *  between two paying stops cost path length and no capacity at all.
 *
 *  THE PERFORMANCE ARGUMENT ABOVE IS UNCHANGED AND IS WHY THIS IS NOT SIMPLY A BIGGER NUMBER. A Diesel over
 *  a Phase-D board is exactly the exponential case the budget defends against, so the walk gains two things
 *  that make a longer leash affordable: it visits the richest continuation first (so a truncated search has
 *  already banked a good route), and it abandons a branch whose best conceivable finish cannot beat the best
 *  route already found. See `walk` for both. */
/** ONE LEASH, RAISED FROM 14. A separate `MAX_PATH_HEXES_UNLIMITED = 48` was tried and the negative control
 *  refused it: pointing every train at this constant instead left every assertion passing, so the second
 *  number earned nothing.
 *
 *  45 RATHER THAN 40, AND THE REASON IS THE JOIN. `candidateRoutes` pairs two arms through the starting
 *  token, so this bounds each ARM and a finished route may be roughly twice it -- which is the correction
 *  the negative controls forced on this pass's first diagnosis. 45 therefore covers a ~90-hex run against a
 *  92-hex board: a player who snakes the entire map is not shortened by the search.
 *  MEASURED BEFORE IT WAS LOCKED IN, on the reported Phase-D board: see `dieselRouteCap.test.ts`'s timing
 *  guard. The cost of the extra five is nil, because the expansion budget is never approached -- the search
 *  exhausts the reachable simple paths long before it exhausts its allowance. */
const MAX_PATH_HEXES = 45;
const MAX_EXPANSIONS = 20_000;
/** A Diesel searches a far larger space and is the one train that most needs the answer to be right: it is
 *  bought last, costs the most, and its run is the biggest number on the board. Twenty times the budget is
 *  still a bounded amount of work, and with the ordering and the bound below it is rarely spent. */
const MAX_EXPANSIONS_UNLIMITED = 400_000;

interface SearchResult {
  path: TracedHex[];
  revenue: number;
}

/* Design note #6: THE WALK FOLLOWS RAILS, AND SPENDS THEM -- two changes that are the same change seen from
   two sides.
   IT WALKS (HEX, ARRIVAL EDGE) STATES. The old walk treated a hex as a node where all its rails meet; on #20
   (two separate straights), the OO tiles and New York that is false, and the tracer would route a train in
   one straight and out the other. `traversalsFrom` resolves the authored rail instead.
   IT SPENDS SEGMENTS, NOT HEXES. Barring whole hexes forbids the commonest legal shape on a built-up board --
   two trains crossing one hex on two different curves, or reaching the two stations of an OO tile -- and on a
   late-game map that approximation was leaving real revenue unrouted.
   A ROUTE ALSO MAY NOT REUSE ITS OWN TRACK, which falls out of the same set. The old `visited` hex set
   enforced a stronger and slightly wrong version: a route may legally touch a hex twice by different rails,
   and 1830 pays it once either way. */

/** Every rail a finished route occupies, endpoints included. Exported because occupancy is a fact about a
 *  route that two callers need -- the assignment search, and any caller wanting to know whether two drafted
 *  routes actually conflict. */
export function routeSegments(
  mapGrid: MapGridResponse,
  path: readonly TracedHex[],
): Set<SegmentKey> {
  const used = new Set<SegmentKey>();
  if (path.length < 2) return used;

  const edgeBetween = (from: TracedHex, to: TracedHex): number | null => {
    const found = HEX_NEIGHBOR_OFFSETS.findIndex(
      ([dq, dr]) => from.q + dq === to.q && from.r + dr === to.r,
    );
    return found < 0 ? null : found;
  };

  for (let i = 0; i < path.length; i += 1) {
    const previous = path[i - 1];
    const next = path[i + 1];
    const entry = previous ? edgeBetween(path[i], previous) : null;
    const exit = next ? edgeBetween(path[i], next) : null;

    if (entry !== null && exit !== null) {
      // A transit: the rails joining the two edges.
      // Design note #737: `variant` picks WHICH way through, so the bow and the through-run hold different keys.
      for (const key of
        traversalSegments(mapGrid, path[i].q, path[i].r, entry, exit, path[i].variant ?? 0) ?? []) {
        used.add(key);
      }
      continue;
    }
    // An endpoint: the train runs in and stops, so it holds the entry rail.
    const only = entry ?? exit;
    if (only === null) continue;
    for (const key of segmentsTouchingEdge(mapGrid, path[i].q, path[i].r, only)) used.add(key);
  }
  return used;
}

interface SearchResult {
  path: TracedHex[];
  revenue: number;
  segments: Set<SegmentKey>;
  /** #1399: every `hex:city` the path stands in, the start included. What a second arm must keep off. */
  visits: Set<string>;
}

/* ==================================================================
    DESIGN NOTE 1399: A ROUTE MAY RE-ENTER A HEX BY ITS OTHER CITY
   ==================================================================
   REPORTED (JUNO-Z6C, B&O's D-train): "Auto-Route is bypassing H18 with tile 626 that has two separate
   cities ... If you add that city it goes to $550", and the ruling: "each revenue center only counts once,
   so trains can re-enter hexes with multiple towns and cities as long as they aren't reusing track or
   revenue centers."
   THE WALK KEPT A SET OF HEXES. `onPath` refused any hex already on the path "even by different rails",
   which its own comment called 1830's rule. The pricing had already moved on: #1318 pays PER CITY VISITED
   and `routeDraftEdit`'s rail-level rule lets a hand-drawn route come back into an OO hex's other city --
   so the hand could draw what the router refused to look for, which is the reported gap.
   SO THE WALK KEEPS A SET OF VISITS, `hex:stop`, where the stop is the one the arrival lands in --
   `stopForArrival` (#1319), which is `cityForArrival` for cities (a city named only on a hex with two, 0
   otherwise) and the rail's own town on a double-town tile. NOT `cityForArrival` alone: that answers 0 for
   both towns of a #631, and the second report on this note was exactly a route that could not come back
   through G17's other town ("continuing through the small town to the next city"). A one-stop hex or plain
   track keys the same way twice and is refused as before; a two-stop hex keys differently by its two stops
   and may be entered once by each. Track is still spent by `used`, so the second entry cannot ride the
   first's rails. The join test below asks the same question of the two arms together, in place of "no hex
   twice". The pricing (`cityVisitedAt`, #1318/#1319) already reads the same stop, so what the walk may now
   draw is what the readout already paid. */
function visitKeyFor(mapGrid: MapGridResponse, q: number, r: number, arrivalEdge: number | null, startCity: number | null): string {
  const stop = arrivalEdge === null ? (startCity ?? 0) : stopForArrival(mapGrid, q, r, arrivalEdge);
  return `${q},${r}:${stop === null ? "-" : stop}`;
}

/** The K best simple paths from `start`, bounded by revenue centres and by the caps above.
 *  K RATHER THAN ONE, because the assignment search (#7) needs alternatives: the single best route for a
 *  5-train may be the one that strands the 3-train, and there is no way to know that without a second option.
 *  Scored by `sandboxRouteBreakdown`, so the tracer and the readout price a route the same way and 1830's
 *  pay-a-hex-once rule comes for free rather than being reimplemented as a running total. */
function candidatePathsFrom(
  mapGrid: MapGridResponse,
  era: TileColorTier,
  start: TracedHex,
  /** Design note #852: which city on `start` the token sits in, or `null` for "the whole hex". */
  startCity: number | null,
  maxCentres: number,
  occupied: ReadonlySet<SegmentKey>,
  keep: number,
  blocksThrough?: BlocksThrough,
  /** Design note #892: the walk's own leash, separate from the stop budget above. Two quantities, two
   *  parameters -- the whole of the reported bug was them sharing one constant. */
  maxPathHexes: number = MAX_PATH_HEXES,
  maxExpansions: number = MAX_EXPANSIONS,
  /** Design note #1302: the corporation running, so its printed herald prices and may be declined. */
  forCompanyId?: number,
  /** #1399: visits a second arm must keep off -- the first arm's, so the two join into one legal route. */
  avoidVisits?: ReadonlySet<string>,
  /** #1408: confine the FIRST step out of the token to this edge, so the caller can ask for the best arms
   *  down each way out of the city rather than the best arms overall. */
  firstExitEdge?: number,
): SearchResult[] {
  const found: SearchResult[] = [];
  let expansions = 0;
  /* ==================================================================
      DESIGN NOTE 892: THE BRANCH-AND-BOUND AND THE ORDERING ARE GONE, AND THE MEASUREMENT IS WHY
     ==================================================================
     THIS PASS ADDED THREE THINGS TO MAKE A LONGER LEASH AFFORDABLE: a richest-first ordering of the arms, a
     branch-and-bound prune, and a twenty-fold expansion budget. They were added against a stated fear -- "a
     dense late-game board branches, and an unbounded DFS over it is exponential" -- and the negative controls
     found that NONE of the three changes any outcome on the reported Phase-D board. Removing the ordering,
     removing the bound and reverting the budget each left every assertion passing.

     SO THEY WERE SPECULATIVE MACHINERY, and two of them cost real work per node: the ordering priced every
     neighbouring hex with a `sandboxRouteBreakdown` call before choosing an arm, and the bound spent a
     comparison per arm. The search completes in about 250ms well inside the ORIGINAL expansion budget even
     with a 48-hex leash, so the cost bought nothing and the fear it answered does not occur.

     THE BOUND WAS ALSO WORTHLESS WHERE IT WAS AIMED. Its own note recorded this before the controls did: an
     admissible revenue bound needs a stop budget to run out of, and the train this whole pass is about has
     none. It could only ever have helped the capped trains, which were not the bug.

     WHAT IS LEFT IS THE FIX: two constants that were one. `a gesture with one possible outcome should be
     removed, not made prettier` -- three of them, in this case, and the measurement is what said so. */

  const path: TracedHex[] = [];
  const used = new Set<SegmentKey>();
  /** #1399: `hex:city` visits on the current path. Was a set of hexes -- see the note above. */
  const visits = new Set<string>();

  const record = (candidate: SearchResult) => {
    // Same hex chain, already seen: keep the better scoring one.
    const signature = candidate.path.map((p) => p.hexLabel).join(">");
    const at = found.findIndex((entry) => entry.path.map((p) => p.hexLabel).join(">") === signature);
    if (at >= 0) {
      if (candidate.revenue > found[at].revenue) found[at] = candidate;
      return;
    }
    found.push(candidate);
    found.sort((a, b) => b.revenue - a.revenue);
    if (found.length > keep) found.length = keep;
  };

  const walk = (at: TracedHex, arrivalEdge: number | null) => {
    if (expansions >= maxExpansions) return;
    expansions += 1;

    path.push(at);
    const visitKey = visitKeyFor(mapGrid, at.q, at.r, arrivalEdge, startCity);
    visits.add(visitKey);

    const breakdown = sandboxRouteBreakdown(
      mapGrid,
      // Design note #737: the bypass flag travels into the pricing.
      path.map((point) => ({ hex: point.hexLabel, bypass: point.bypass })),
      era,
      forCompanyId,
    );

    /* A route needs two paying stops to be a route at all -- 1830's two-revenue-centre minimum, which the
       contract enforces too -- and design note #3: it has to END somewhere it may end (#1555: since the S6-10
       ruling that is any revenue centre, towns included -- the sentence below is history). Towns pay, so without the
       terminus test the best-paying prefix was routinely one that stopped on a town. */
    if (
      path.length >= 2 &&
      breakdown.centres >= 2 &&
      breakdown.centres <= maxCentres &&
      isRouteTerminusHex(mapGrid, at.hexLabel, forCompanyId)
    ) {
      /* Recomputed rather than copied from `used`: that set holds the TRANSITS taken so far, and a route also holds
         the rails it STARTS and STOPS on. A terminus is not a transit -- it is discovered at the moment the route
         is recorded -- so without this a route could legally end on a rail another train was already using, and the
         assignment search would hand back a set that violated the disjointness it exists to enforce. Caught by the
         sweep across 150 board patches, which reported the overlap directly. */
      const segments = routeSegments(mapGrid, path);
      let clashes = false;
      segments.forEach((key) => {
        if (occupied.has(key)) clashes = true;
      });
      /* Design note #737: each point COPIED, not the array alone. The walk tags `at` with the variant it is
         about to take and untags it on the way out, so a banked path holding the same object would have its
         hex silently rewritten by a sibling branch. A shallow array copy was enough before there was anything
         mutable on a point. */
      if (!clashes) {
        record({
          path: path.map((point) => ({ ...point })),
          revenue: breakdown.revenue,
          segments,
          visits: new Set(visits),
        });
      }
    }

    /* ==================================================================
     *  DESIGN NOTE 730: A TOKENED-OUT CITY IS A TERMINUS
     * ==================================================================
     *
     * REPORTED: "a corporation's trains are running through tokened out cities when they should be blocked
     * (i.e., the token out city must be treated as a terminus)."
     *
     * THE SAME DEFECT AS #729 AND THE SAME SHAPE OF FIX, in the other tracer. #729 taught the NETWORK walk
     * about tokens; this is the ROUTE search, a separate DFS that also knew only about rails. They had to be
     * fixed together or the board would have promised reach the router then refused -- which is worse than
     * both being wrong, because a player would see a legal-looking hex and a route that would not run to it.
     *
     * "TERMINUS" IS EXACTLY RIGHT and it is why this goes HERE rather than at the top of `walk`. The recording
     * block above has already run, so a path ending in this city is still offered and still priced; what is
     * refused is going any further. Blocking on arrival instead would delete the legal run that stops there.
     *
     * NOT AT A START. `arrivalEdge === null` is the train sitting in its own city, and a corporation is never
     * blocked by the city it holds -- `cityBlocking.ts` rule 2.
     *
     * ==================================================================
     *  DESIGN NOTE 808: A SHUT CITY BARS THE ARMS THAT ENTER IT
     * ==================================================================
     *
     * REPORTED: the auto-router "did not select the highest value route ... it could have run Pittsburgh to
     * Baltimore (bypassing the tokened out Altoona) for $80" and ran a $70 route instead.
     *
     * THE ANSWER WAS RIGHT AND THE QUESTION WAS ASKED TOO EARLY. This is computed on ARRIVAL, which is before
     * the walk has chosen WHICH WAY THROUGH it will take -- and #737's bow is a property of the way through.
     * Used as a gate on the whole expansion loop, it refused every arm because one of them enters the city.
     * MEASURED BEFORE IT WAS CHANGED: with H12's only slot full, the tracer returned `["H14","H12"]` where
     * `["H14","H12","H10"]` over the bow is legal and worth $40. It was not choosing badly on the reported
     * board; it was choosing from a board with a wall across the middle of it.
     *
     * SO THE CITY IS REMEMBERED RATHER THAN ACTED ON, and the refusal moves into the loop below where each
     * arm can answer for itself. `blockedCity` is the city an arrival on this edge lands in when that city is
     * shut, and `null` otherwise -- the two states the loop needs and no more.
     *
     * #730'S TERMINUS RULE IS UNTOUCHED. The recording block above has already run, so a route that ENDS in
     * the shut city is still offered and still priced. What changes is only what may happen after it. */
    const blockedCity =
      arrivalEdge !== null && blocksThrough !== undefined
        ? (() => {
            const city = cityForArrival(mapGrid, at.q, at.r, arrivalEdge);
            return city !== null && blocksThrough(at.q, at.r, city) ? city : null;
          })()
        : null;

    /* ==================================================================
     *  DESIGN NOTE 821: THE STOP BUDGET WAS SPENT BEFORE THE ARM WAS CHOSEN
     * ==================================================================
     *
     * REPORTED, after #808 and #820: "the auto-route feature still stops a route at Altoona instead of
     * bypassing it for a higher value final revenue center."
     *
     * A THIRD GATE WITH THE SECOND ONE'S MISTAKE. #808 moved the BLOCKING test into the loop because the arm
     * decides whether a full city is in the way. This is the CAPACITY test and it has exactly the same shape:
     * `breakdown` prices the path with the current hex counted as a STOP, because at this point in the walk
     * nothing has yet said otherwise -- and a hex crossed on the bow is not a stop at all (#737: "a bypassed
     * hex pays nothing AND costs no stop -- the second is what makes the bow worth taking").
     *
     * SO A TRAIN AT ITS LIMIT STOPPED DEAD AT ALTOONA. Arriving there put it on its last stop; the gate then
     * refused to expand, and the run ended on a $10 city instead of passing it for free and finishing
     * somewhere worth more. Which is the report, in its own words.
     *
     * AND IT WAS NEVER ABOUT BLOCKING, which is why #808 and #820 did not touch it: this happens whether or
     * not the city is shut, so it applies to the PENNSYLVANIA too -- the one corporation for which Altoona is
     * never a wall. The two bugs share a hex and nothing else.
     *
     * THE COUNT IS ADJUSTED RATHER THAN RE-PRICED. `stops` already names the hexes that pay, and the path is
     * simple, so "does this hex pay" is one lookup -- where a second `sandboxRouteBreakdown` per transit
     * would be the same answer at a search's cost. */
    const hexPays = breakdown.stops.some((stop) => stop.hex === at.hexLabel);
    const centresIfBypassed = breakdown.centres - (hexPays ? 1 : 0);

    if (path.length < maxPathHexes) {
      /* Design note #6: from a start, every rail on the hex is available --
         the train begins inside the city. Having arrived on a rail, only
         the exits that rail reaches. */
      /* Design note #737: typed as `HexTraversal[]` so the start branch and the transit branch are one shape.
         Left as an inferred literal, the start's `{exitEdge, segments}` widened the union and the variant
         fields became unreachable on both. */
      const rawExits: HexTraversal[] =
        arrivalEdge === null
          ? /* Design note #852: THE TOKEN'S CITY, NOT THE HEX. `cityExitEdges` returns every live edge when
               `startCity` is `null` -- one city, or a caller that did not say -- so the ordinary board is
               untouched and New York is not. See `AutoTraceInput.startHexes` for the report. */
            cityExitEdges(mapGrid, at.q, at.r, startCity)
              .filter((exitEdge) => firstExitEdge === undefined || exitEdge === firstExitEdge) // #1408
              .map((exitEdge) => ({
                exitEdge,
                segments: [] as readonly SegmentKey[],
              }))
          : traversalsFrom(mapGrid, at.q, at.r, arrivalEdge);
      /* Design note #1302: THE OWNER MAY PASS ITS HERALD WITHOUT COUNTING IT. Crossing the herald hex, every
         way through is offered twice -- once stopping (the $10, one centre) and once as a bypass, which the
         pricing already reads as "passed, not counted" (#737). The search then finds for itself whether the
         stop is worth a centre of a short train's budget. Only when arriving: a route that STARTS here is
         starting from its home, and a home is counted. */
      const heraldHere =
        arrivalEdge !== null &&
        forCompanyId !== undefined &&
        heraldAt(at.hexLabel)?.companyId === forCompanyId;
      const exits: HexTraversal[] = heraldHere
        ? rawExits.flatMap((transit) => [
            { ...transit, bypass: false },
            { ...transit, bypass: true },
          ])
        : rawExits;

      for (const transit of exits) {
        /* Design note #808: THE REFUSAL, PER ARM. A city full of other corporations' tokens says nothing
           about track that goes around it -- the bow does not enter the city, so there is nothing for a full
           city to be full of. Every other arm through this hex reaches the centre and is barred, which is
           #730's rule unchanged; this is the one case where "may I pass" has two different answers on one
           hex, and it exists because 1830 printed it that way. */
        if (blockedCity !== null && transit.bypass !== true) continue;
        /* Design note #821: and the stop budget, per arm. A bypassing transit does not spend this hex, so the
           count it must fit under is the one that excludes it. Every other hex on the board pays the same
           either way and this is `breakdown.centres`, unchanged. */
        if ((transit.bypass === true ? centresIfBypassed : breakdown.centres) >= maxCentres) continue;
        const next = neighbourAcross(mapGrid, at.q, at.r, transit.exitEdge);
        if (!next) continue;
        // #1399: the same revenue centre twice is refused; the other city of a two-city hex is not.
        const nextKey = visitKeyFor(mapGrid, next.q, next.r, next.arrivalEdge, startCity);
        if (visits.has(nextKey) || avoidVisits?.has(nextKey)) continue;
        // Occupied by another train, or already used by this route.
        if (transit.segments.some((key) => occupied.has(key) || used.has(key))) continue;

        const hexLabel = labelFor(next.q, next.r);
        if (hexLabel === null) continue;

        /* Design note #737: the variant belongs to THIS hex -- the one being crossed -- so it is recorded on
           `at` for the duration of the branch and cleared after. `traversalsFrom` yields one entry per way
           through, so two entries with the same `exitEdge` are the two arms of Altoona's fork. */
        const previousVariant = at.variant;
        const previousBypass = at.bypass;
        if (transit.variant !== undefined) at.variant = transit.variant;
        if (transit.bypass !== undefined) at.bypass = transit.bypass;

        for (const key of transit.segments) used.add(key);
        walk({ q: next.q, r: next.r, hexLabel }, next.arrivalEdge);
        for (const key of transit.segments) used.delete(key);

        at.variant = previousVariant;
        at.bypass = previousBypass;

        if (expansions >= maxExpansions) break;
      }
    }

    path.pop();
    visits.delete(visitKey);
  };

  walk(start, null);
  return found;
}

/** Design note #730: whether this corporation may run THROUGH city `cityIndex` on `(q, r)`. The rule is in
 *  `cityBlocking.ts`; this is only its shape, named so the three signatures that take it cannot drift. */
export type BlocksThrough = (q: number, r: number, cityIndex: number) => boolean;

export interface AutoTraceInput {
  mapGrid: MapGridResponse;
  era: TileColorTier;
  /** The corporation's station tokens. A route must touch one, so these are the only legal places to start
   *  looking.
   *
   *  ==================================================================
   *   DESIGN NOTE 852: `[q, r]` IS NOT ENOUGH, AND NEW YORK PROVES IT
   *  ==================================================================
   *
   *  REPORTED: "NNH has two 3-trains. In Run Routes, one train runs from its home station (on the upper right
   *  city) to Providence, and the other train is running from the disconnected lower left city. This is
   *  actually two major problems: i) the two cities are not part of NNH's network, and ii) the second train
   *  doesn't run through any NNH station. This had been fixed before and has now returned."
   *
   *  IT WAS FIXED IN THE OTHER TRACER. `trackReach.ts` #686 -- "A TOKEN IS IN A CITY, NOT ON A HEX" -- was
   *  reported on this exact corporation and this exact hex, and it fixed the NETWORK walk. This module is the
   *  ROUTE search, a separate DFS, and it kept the model: from a start it took every live edge on the hex.
   *  New York (G19) is `[{edges:[1]}, {edges:[4]}]`, two cities whose spurs do not touch. NNH's token is in
   *  the top-right city, which owns edge 1. Edge 4 belongs to the other one -- so the search departed from a
   *  city NNH holds nothing in, and every route down that arm satisfies neither half of the rule.
   *
   *  #730 SAW THIS COMING AND SAID SO: "the same defect as #729 and the same shape of fix, in the other
   *  tracer. They had to be fixed together or the board would have promised reach the router then refused."
   *  #686 was the same defect one layer down, and only one tracer was told.
   *
   *  `[q, r]` STILL WORKS and means "the whole hex", which is the right answer for the ~90% of the board with
   *  one city on it and is exactly the pre-#852 behaviour. What must be passed for a two-city hex is
   *  `[q, r, cityIndex]` -- `stationTokensOf` in `trackReach.ts` produces precisely that. */
  startHexes: ReadonlyArray<StationToken>;
  /** The train's capacity in REVENUE CENTRES (`sandboxSession.ts #156`); the Diesel is treated as uncapped.
   *  TOWNS COUNT: every hex that pays is a centre, so `City -> Town -> City` is three stops and a 2-train cannot
   *  run it. Verified rather than assumed -- see the regression tests. */
  maxRevenueCentres: number;
  /* Design note #4: TRACK ANOTHER TRAIN HAS ALREADY TAKEN. A corporation runs every train it owns, each on its
     own route, and two of its trains may not run over the same track.
     THIS USED TO BAR WHOLE HEXES and said so -- "stricter than the rule, which is the safe direction for a
     drafting aid". Safe, and expensive: it forbids two trains crossing one hex on two different curves, and
     reaching the two separate stations of an OO tile, both of which 1830 permits.
     Occupancy is per RAIL now -- `trackSegments.ts #3` for what a segment key is and why a hex id could not be
     one. */
  excludeSegments?: ReadonlySet<SegmentKey>;
  /** Design note #730: cities this corporation may not run THROUGH -- see `cityBlocking.ts` #729. Injected
   *  for the same reason the network walk's copy is: the slot counts and the token owners live in places this
   *  module may not read. Omitted means no blocking, which reproduces every pre-#730 caller. */
  blocksThrough?: BlocksThrough;
  /** Design note #1302: the corporation running. Only a board that prints a herald reads it. */
  companyId?: number;
}

export interface AutoTraceResult {
  path: TracedHex[];
  revenue: number;
  /** The rails this route occupies, for a caller assembling a set. */
  segments: Set<SegmentKey>;
  /** Why nothing was found, when nothing was. Phrased for a player rather
   *  than as an error code -- an Auto Route button that goes quiet is
   *  indistinguishable from one that is still broken. */
  reason: string | null;
}

/** How many alternatives to keep per starting token. Four trains times a
 *  handful of candidates each is a search space the combination step below
 *  crosses in microseconds; going wider buys worse routes. */
const CANDIDATES_PER_TOKEN = 6;

/** Every route worth considering for one train, best first. */
function candidateRoutes(input: AutoTraceInput): SearchResult[] {
  const { mapGrid, era, startHexes, maxRevenueCentres, excludeSegments } = input;
  /* Design note #881: the sentinel through the one function that owns it. This read `>= 999` while the
     draft flag read `!== 999` -- two spellings of one magic number, which is how a hypothetical 1000-reach
     train would have been unlimited here and over-long there. */
  /* ==================================================================
      DESIGN NOTE 892: THE STOP BUDGET AND THE WALK'S LEASH, SEPARATELY
     ==================================================================
     THIS READ `const cap = isUnlimitedReach(maxRevenueCentres) ? MAX_PATH_HEXES : maxRevenueCentres`, which
     handed a Diesel a stop budget of 14 because 14 was how far the walk could go. See the constants above
     for the measurement against the reported game.
     AN UNLIMITED TRAIN GETS AN UNLIMITED BUDGET, spelled as the leash rather than as `Infinity`: a route
     cannot have more paying stops than it has hexes, so the walk's own length is the true ceiling and using
     it keeps every downstream comparison finite. That is the same number the old code used -- what changed
     is that the LEASH grew, and the budget follows it instead of pinning it.
     A CAPPED TRAIN KEEPS ITS OWN REACH and gains a walk long enough to spend it. Six stops can be twenty
     hexes apart on a late board; the old shared constant is why a 6-train could not always find its sixth. */
  const unlimited = isUnlimitedReach(maxRevenueCentres);
  const expansionLimit = unlimited ? MAX_EXPANSIONS_UNLIMITED : MAX_EXPANSIONS;
  /* THE BUDGET IS STILL EXPRESSED AS THE LEASH for an unlimited train, and that is correct rather than a
     residue of the bug: a route cannot have more paying stops than it has hexes, so the walk's length is a
     true ceiling on the stop count. What was wrong was the NUMBER -- 14 -- which made "as many stops as it
     has hexes" mean "fourteen stops" for the one train in the game that has no reach limit. */
  const cap = unlimited ? MAX_PATH_HEXES : maxRevenueCentres;
  const occupied = excludeSegments ?? new Set<SegmentKey>();

  const all: SearchResult[] = [];
  for (const entry of startHexes) {
    const [q, r] = entry;
    const hexLabel = labelFor(q, r);
    if (hexLabel === null) continue;
    /* Design note #852: `[q, r, cityIndex]` where the caller knows, `[q, r]` where it does not -- the same
       `StationToken` shape `trackReach.ts` #686 introduced, so the two tracers read one record. `null` means
       "the whole hex", which is right for a one-city hex and is the pre-#852 behaviour everywhere. */
    const startCity = entry.length > 2 ? (entry[2] as number) : null;
    const token: TracedHex = { q, r, hexLabel };

    /* ==================================================================
        DESIGN NOTE 1408: THE BEST ARMS DOWN EACH WAY OUT, NOT THE BEST ARMS OVERALL
       ==================================================================
       REPORTED (ERIE's D-train, JUNO-Z6C 9.3): "It could be running through both cities in TO before going
       to ERIE's home hex and then off to Kingston". The exhaustive pairing finds $640; the router drew $570.
       EVERY KEPT ARM LEFT THE HOME THE SAME WAY. From E11 the richest direction is through Toronto's near
       city, so all six of the best arms began E11 -> D10 -> D12, and the second arm -- which must keep off
       the first's centres (#1399) -- could then never take the short loop C9 -> C11 into Toronto's other
       city. The winning route needs the LONG arm to leave by E13 and the SHORT arm to take D10; a top-N by
       revenue never offers that pairing, because the long arm's D10 version outscores its E13 version by
       one city. So the first arm is searched once per exit edge of the token's city, `CANDIDATES_PER_TOKEN`
       kept down each, and the union is what the second arm is paired against. A one-exit city is the old
       search exactly; New York's or Toronto's three exits cost three searches, which the measurement below
       (`reenterOtherCity.test.ts`) puts at well under a second. */
    const exits = cityExitEdges(mapGrid, q, r, startCity);
    const oneArm: SearchResult[] = [];
    const armSeen = new Set<string>();
    for (const exit of exits.length > 0 ? exits : [undefined]) {
      for (const arm of candidatePathsFrom(
        mapGrid,
        era,
        token,
        startCity,
        cap,
        occupied,
        CANDIDATES_PER_TOKEN,
        // Design note #730: the search may not cross a city this corporation is shut out of.
        input.blocksThrough,
        MAX_PATH_HEXES,
        expansionLimit,
        input.companyId,
        undefined,
        exit,
      )) {
        const signature = arm.path.map((p) => p.hexLabel).join(">");
        if (armSeen.has(signature)) continue;
        armSeen.add(signature);
        oneArm.push(arm);
      }
    }
    all.push(...oneArm);

    /* Design note #2: A ROUTE RUNS THROUGH A TOKEN far more often than it starts at one, so each arm is paired
       with a second arm going the other way and joined through the shared city. The second arm is barred from the
       FIRST arm's rails, which is what keeps the joined path a legal single route rather than one that doubles
       back over itself. */
    for (const armA of oneArm) {
      const barred = new Set<SegmentKey>();
      occupied.forEach((key) => barred.add(key));
      armA.segments.forEach((key) => barred.add(key));
      /* #1399: THE SECOND ARM IS KEPT OFF THE FIRST ARM'S CENTRES WHILE IT SEARCHES, not after. It used to be
         found freely and then thrown away at the join for sharing a hex with arm A -- and with only two
         candidates kept, both were routinely the richest arms out of the token, which run through the
         same country as arm A and were both discarded. The route then began at the token instead of
         running through it, which on the reported board is the town and city the D-train "stops running
         before hitting". The start is the one visit both arms share, and is allowed. */
      const startKey = visitKeyFor(mapGrid, q, r, null, startCity);
      const avoid = new Set(armA.visits);
      avoid.delete(startKey);
      const armsB = candidatePathsFrom(
        mapGrid,
        era,
        token,
        startCity,
        cap,
        barred,
        3,
        input.blocksThrough,
        MAX_PATH_HEXES,
        expansionLimit,
        input.companyId,
        avoid,
      );
      for (const armB of armsB) {
        if (armB.path.length < 2) continue;
        const joined = [...armB.path.slice(1).reverse(), ...armA.path];
        // #1399: a joined route may stand in each revenue centre once; the two arms share only the start.
        let overlaps = false;
        armB.visits.forEach((key) => {
          if (key !== startKey && armA.visits.has(key)) overlaps = true;
        });
        if (overlaps) continue;
        const breakdown = sandboxRouteBreakdown(
          mapGrid,
          joined.map((point) => ({ hex: point.hexLabel, bypass: point.bypass })),
          era,
          input.companyId,
        );
        if (breakdown.centres > cap) continue;
        // Re-priced whole rather than summing the two arms: the token hex
        // is in both and would otherwise be paid for twice.
        const segments = routeSegments(mapGrid, joined);
        // The join itself may cross a rail the other train holds.
        if (Array.from(segments).some((key) => occupied.has(key))) continue;
        const visits = new Set(armA.visits);
        armB.visits.forEach((key) => visits.add(key));
        all.push({ path: joined, revenue: breakdown.revenue, segments, visits });
      }
    }
  }

  all.sort((a, b) => b.revenue - a.revenue);
  // Distinct hex chains only -- two tokens on one network find the same
  // routes, and duplicates crowd out genuine alternatives.
  const seen = new Set<string>();
  const distinct: SearchResult[] = [];
  for (const candidate of all) {
    const signature = candidate.path.map((p) => p.hexLabel).join(">");
    if (seen.has(signature)) continue;
    seen.add(signature);
    distinct.push(candidate);
    if (distinct.length >= CANDIDATES_PER_TOKEN * 2) break;
  }
  return distinct;
}

const NO_TOKEN_REASON =
  "This corporation has no station token on the board yet, so there is no city its trains can run from.";
const NO_ROUTE_REASON =
  "No route found from this corporation's tokens — its network does not yet reach two paying stops. Lay more track, then try again.";

export function autoTraceRoute(input: AutoTraceInput): AutoTraceResult {
  if (input.startHexes.length === 0) {
    return { path: [], revenue: 0, segments: new Set(), reason: NO_TOKEN_REASON };
  }
  const best = candidateRoutes(input)[0];
  if (!best || best.path.length < 2) {
    return { path: [], revenue: 0, segments: new Set(), reason: NO_ROUTE_REASON };
  }
  return { path: best.path, revenue: best.revenue, segments: best.segments, reason: null };
}

/* Design note #7: THE BEST SET, NOT THE BEST ROUTE REPEATED. The greedy order was defensible and is still
   wrong in a way that is easy to state: the highest-paying route for a 5-train may be the only route a
   3-train could have run, and giving it away costs more than it gains. Greedy cannot see that, because it
   decides the 5-train's route before it has looked at the 3-train at all.
   AN EXHAUSTIVE SEARCH OVER A DELIBERATELY SMALL SPACE: at most four trains, at most a dozen candidates each,
   every clashing branch pruned. Thousands of combinations in the worst case -- microseconds -- and exact over
   the candidates considered.
   IT IS STILL NOT `trace_best_route_set`. Candidates are generated per train by a bounded DFS, so a route no
   train proposed cannot be chosen: the guarantee is "the best combination of the routes we found", which is
   the honest claim for a drafting aid.
   TRAINS THAT GET NOTHING ARE NOT A FAILURE -- a three-train corporation on a network supporting two routes
   should draft two and leave the third empty, which is what the contract would accept. */
export interface RouteSetTrain {
  /** Caller's own identity for this train -- returned untouched. */
  trainIndex: number;
  /** Capacity in revenue centres; `999` for the Diesel. */
  maxRevenueCentres: number;
}

export interface RouteSetInput {
  mapGrid: MapGridResponse;
  era: TileColorTier;
  /** Design note #852: tokens, not hexes -- `[q, r]` or `[q, r, cityIndex]`. See `AutoTraceInput`. */
  startHexes: ReadonlyArray<StationToken>;
  trains: readonly RouteSetTrain[];
  /** Design note #730: threaded to every train's search, so a corporation's whole draft respects the walls. */
  blocksThrough?: BlocksThrough;
  /** Design note #1302: the corporation running, for its herald. */
  companyId?: number;
}

export interface RouteSetResult {
  /** One entry per train that got a route. Trains with none are absent. */
  assignments: Array<{ trainIndex: number; path: TracedHex[]; revenue: number }>;
  /** Combined payout of the chosen set. */
  totalRevenue: number;
  /** Set when NOTHING could be drafted for any train. */
  reason: string | null;
}

export function assignRouteSet(input: RouteSetInput): RouteSetResult {
  const { mapGrid, era, startHexes, trains, blocksThrough } = input;
  if (startHexes.length === 0) {
    return { assignments: [], totalRevenue: 0, reason: NO_TOKEN_REASON };
  }
  if (trains.length === 0) {
    return { assignments: [], totalRevenue: 0, reason: NO_ROUTE_REASON };
  }

  type Choice = { trainIndex: number; path: TracedHex[]; revenue: number };
  type Plan = { choices: Choice[]; total: number };

  const optionsFor = (train: RouteSetTrain, occupied: ReadonlySet<SegmentKey>) =>
    candidateRoutes({
      mapGrid,
      era,
      startHexes,
      maxRevenueCentres: train.maxRevenueCentres,
      excludeSegments: occupied,
      // Design note #730: every train in the set walks the same walls.
      blocksThrough,
      companyId: input.companyId,
    });

  /* STRATEGY A: sequential, in a given train order. This is the OLD algorithm, kept deliberately -- see design
     note #8 for why the optimiser needs it rather than merely beating it. */
  const sequential = (order: readonly RouteSetTrain[]): Plan => {
    const used = new Set<SegmentKey>();
    const choices: Choice[] = [];
    let total = 0;
    for (const train of order) {
      const best = optionsFor(train, used)[0];
      if (!best || best.path.length < 2) continue;
      choices.push({ trainIndex: train.trainIndex, path: best.path, revenue: best.revenue });
      total += best.revenue;
      best.segments.forEach((key) => used.add(key));
    }
    return { choices, total };
  };

  /* STRATEGY B: the joint combination search. Every train proposes against an UNTOUCHED board and the set is
     chosen together, which is the only way to see that the big train's best route is the small train's only
     route. */
  const joint = (): Plan => {
    const perTrain = trains
      .map((train) => ({ train, options: optionsFor(train, EMPTY_SEGMENTS) }))
      // Widest capacity first: those lists differ most, so committing them
      // early prunes the deepest.
      .sort((a, b) => b.train.maxRevenueCentres - a.train.maxRevenueCentres);

    let bestTotal = -1;
    let bestChoices: Choice[] = [];
    const chosen: Choice[] = [];
    const used = new Set<SegmentKey>();

    const search = (depth: number, runningTotal: number) => {
      if (depth === perTrain.length) {
        if (runningTotal > bestTotal) {
          bestTotal = runningTotal;
          bestChoices = chosen.map((entry) => ({ ...entry }));
        }
        return;
      }
      // Optimistic bound: if every remaining train took its own best
      // candidate unopposed and that still could not beat the incumbent,
      // stop opening this branch.
      let optimistic = runningTotal;
      for (let i = depth; i < perTrain.length; i += 1) {
        optimistic += perTrain[i].options[0]?.revenue ?? 0;
      }
      if (optimistic <= bestTotal) return;

      const { train, options } = perTrain[depth];
      for (const option of options) {
        if (Array.from(option.segments).some((key) => used.has(key))) continue;
        option.segments.forEach((key) => used.add(key));
        chosen.push({ trainIndex: train.trainIndex, path: option.path, revenue: option.revenue });
        search(depth + 1, runningTotal + option.revenue);
        chosen.pop();
        option.segments.forEach((key) => used.delete(key));
      }
      // This train runs nothing -- always available, so a train with no
      // legal option never blocks the ones that have.
      search(depth + 1, runningTotal);
    };

    search(0, 0);
    return { choices: bestChoices, total: Math.max(0, bestTotal) };
  };

  /* Design note #8: THE OPTIMISER MUST NOT BE ABLE TO LOSE. The joint search alone is WORSE than greedy on a
     lot of real boards, and the reason is not obvious and cost a rewrite to find: every train's candidates are
     generated against an untouched board, so all of them crowd around the same few best rails -- commit the
     widest train to one and the other lists can be entirely conflicted out. The sequential algorithm
     REGENERATES after each commitment, so it discovers the second-best corridor the joint search never put on
     the table.
     Measured across 150 board patches: the joint search alone tied on 100 and LOST on 50, once by $240 to $80.
     A smarter optimiser that is sometimes three times worse is not an optimiser.
     So both run, plus the sequential pass in reverse order (a narrow train choosing first sometimes leaves a
     better remainder), and the best plan wins -- which makes "never worse than what we replaced" true by
     construction rather than by hope.
     A FILL PASS FINISHES THE JOB: any train left without a route gets one more look at what is left over. Pure
     upside, and it is what lets the joint search's strength combine with the sequential one's. */
  const widestFirst = [...trains].sort((a, b) => b.maxRevenueCentres - a.maxRevenueCentres);
  const plans: Plan[] = [
    sequential(widestFirst),
    sequential([...widestFirst].reverse()),
    joint(),
  ];

  let plan = plans[0];
  for (const candidate of plans) {
    if (candidate.total > plan.total) plan = candidate;
  }

  // The fill pass.
  const used = new Set<SegmentKey>();
  for (const choice of plan.choices) {
    routeSegments(mapGrid, choice.path).forEach((key) => used.add(key));
  }
  const assigned = new Set(plan.choices.map((choice) => choice.trainIndex));
  let total = plan.total;
  const choices = [...plan.choices];
  for (const train of widestFirst) {
    if (assigned.has(train.trainIndex)) continue;
    const best = optionsFor(train, used)[0];
    if (!best || best.path.length < 2) continue;
    choices.push({ trainIndex: train.trainIndex, path: best.path, revenue: best.revenue });
    total += best.revenue;
    best.segments.forEach((key) => used.add(key));
  }

  if (choices.length === 0) {
    return { assignments: [], totalRevenue: 0, reason: NO_ROUTE_REASON };
  }
  return {
    assignments: choices.sort((a, b) => a.trainIndex - b.trainIndex),
    totalRevenue: total,
    reason: null,
  };
}

const EMPTY_SEGMENTS: ReadonlySet<SegmentKey> = new Set<SegmentKey>();
