// The anteroom: who is here, what they are called, and who may start.
//
// Design note #529: this REPLACES the board rather than sitting over it. Before
// setup lands there is no game -- the player count is undecided, so starting
// cash and the certificate limit are too, and showing the board underneath would
// show a plausible, correctly-rendered game nobody is playing.
//
// Design note #529a: everyone gets Ready; only the host gets Start. Start is the
// one write that DEALS the game, and two clients sending it would put two setups
// with different shuffles in the log, each replayed by every client.
//
// See docs/ai_architecture/firebase_middleware.md, SandboxWaitingRoom.tsx #529.

import React, { useState } from "react";
import {
  bankSizeLabel,
  GAME_LENGTH_BLURB,
  GAME_MODE_COPY,
  GAME_TYPE_COPY,
  STANDARD_VARIANTS,
  VARIANT_COPY,
  type VariantCopyKey,
  gameTypeOf,
} from "../gameEngine/gameVariants";

import { FONT_FAMILY, FONT_SIZE, LINE_HEIGHT, RADIUS } from "../styles/typography";
import {
  roomSeatCap,
  roomVisibility,
  seatsNeeded,
  waitingRoomBlock,
  waitingRoomNotice,
  type SandboxRoomDoc,
} from "../utils/sandboxRoom";
import { MIN_PLAYERS, certLimitForPlayers, startingCashForPlayers } from "../gameEngine/gameSetup";
// #1415: the ante's figures and the subsidy line, the same ones the host's setup card showed.
import { ANTE_SUBSIDY_NOTE, VISIBILITY_COPY } from "./HostSetupCard";
import { anteBreakdown, formatJuno } from "../utils/anteMath";
import { SEAT_COLORS, SEAT_COLOR_NAMES, resolveSeatColors } from "../utils/playerLabels";
import { type AudioControlsProps } from "./AudioControls";
/* Design note #1138: the shell's own bar, mounted here so the audio controls stop moving between the
   anteroom and the table. */
import TopBar from "./TopBar";
import AppFooter from "./AppFooter";
// Design note #1341: the seat PIN, set and rejoined from the roster.
import { SeatPinModal } from "./SeatPinModal";
import { setSkipIntroPreferred, skipIntroPreferred } from "../utils/introPreference";
import { chromeZoomFor } from "../styles/appStyles";
/* Design note #1294: the chrome scale, live. */
import { useUiScale } from "../utils/useUiScale";
/* Design note #1122: the sandbox signal ladder. */
import {
  SANDBOX_TITLE,
} from "../styles/palette";

/** Design note #910: the four boolean variants as DATA, so adding a fifth is one row rather than a fifth
 *  hand-written block that could be forgotten -- which is exactly the failure this note is fixing, at the
 *  scale of a whole panel. `key` is typed against `GameVariants`, so a renamed flag is a compile error here
 *  rather than a toggle that silently stops binding. */
/* ==================================================================
    DESIGN NOTE 961a: NEITHER THE LABELS NOR THE BLURBS ARE WRITTEN HERE
   ==================================================================
   This table used to carry both, and BOTH had drifted from the Lobby's: the blurb by a whole sentence about
   dividend rounding, and the label by a word -- "Delayed private auction" here against "Delayed auction"
   there. One variant with two names, on the two screens a table reads before agreeing to it.
   THE ORDER IS STILL THIS FILE'S OWN, which is why the keys are listed rather than taken from
   `Object.keys`: the sequence a host reads the toggles in is a presentation decision, and the record is a
   dictionary rather than a running order. Typed as `VariantCopyKey`, so a renamed flag is a compile error
   here rather than a toggle that silently stops binding. */
/* Design note #1271: `expandedMap` and `levelPlayingField` are NOT toggles -- they are the Game Type, one
   choice with its illegal combinations removed (see `gameVariants` #1271). #1415: the CONTROLS for all of
   these live on `HostSetupCard` now; this table is the ORDER the terms in force are listed in here, and
   `GAME_TYPE_FLAGS` names the two the type owns, so `variantWiring.test.ts` can still ask that every boolean
   flag reaches a control somewhere. */
export const GAME_TYPE_FLAGS = ["expandedMap", "levelPlayingField"] as const;
const VARIANT_TOGGLES: ReadonlyArray<{
  key: VariantCopyKey;
  label: string;
  blurb: string;
}> = (
  [
    "unpredictableRevenue",
    "dynamicStockMarket",
    "gentleRust",
    "delayedAuction",
    "plusTiles",
  ] as const
).map((key) => ({ key, ...VARIANT_COPY[key] }));

export interface SandboxWaitingRoomProps {
  roomCode: string;
  room: SandboxRoomDoc | null;
  /** This browser's seat -- design note #528. */
  localPlayerId: string;
  error: string | null;
  busy: boolean;
  onSetNickname: (nickname: string) => void;
  /** Design note #569: `null` returns this seat to the assigned default. */
  onSetColor: (color: string | null) => void;
  onToggleReady: (isReady: boolean) => void;
  onStart: () => void;
  onLeave: () => void;
  /* ==================================================================
      DESIGN NOTE 1415: THE TERMS ARE READ HERE, NOT WRITTEN
     ==================================================================
     `onSetVariants` IS GONE. #910 put the house-rules controls on this screen so every seat could see them
     before agreeing; the host now chooses them on the setup card BEFORE the room exists (`HostSetupCard`),
     and "rules frozen after Create Room" is the ruling. What this screen keeps is #910's real point -- the
     terms are on the room document and every seat reads the same ones -- drawn as a summary rather than a
     form. A host who wants different terms hosts a different room.
     `onKick` IS NEW: the host removes a joiner, before the start only. `undefined` for a guest. */
  onKick?: (playerId: string) => void;
  /** ==================================================================
   *   DESIGN NOTE 1101: THE RADIO WAS ALREADY PLAYING HERE, WITH NOTHING TO PRESS
   *  ==================================================================
   *
   * ASKED: "can we have the radio playable in the Waiting Room and continue smoothly into the game start?"
   *
   * THE CONTINUITY HALF NEEDED NO WORK, and that is worth stating because it looks like it should have.
   * `useRadioStream`'s element is owned by `AppShell`, built once under a `[]`-dep effect and released only
   * when that component unmounts. This screen and the game shell are two BRANCHES OF THE SAME RENDER -- an
   * early return and the fall-through -- so the element is already alive here, and pressing Start does not
   * touch it. No reconnect, no re-buffer, no gap.
   *
   * WHAT WAS MISSING WAS REACH. The toggle lives in `TopBar`, which the early return skips, so the stream
   * sat there with no control attached. This prop is that control and nothing more.
   *
   * SUPERSEDED IN PART BY #1102. This first shipped as a plain on/off toggle, on the reasoning that volume
   * and per-category switches do not belong on a screen whose job is to be left. REPORTED back: "I'm not
   * sure the audio button should behave one way in the Waiting Room and another in the Game." The reasoning
   * was sound and the premise was not -- a player should not learn two audio controls for one app -- so this
   * now renders the very same `AudioControls` the bar does.
   *
   * AND IT BUYS THE AUTOPLAY GESTURE. Browsers require a click before audio may start (#1009), which is why
   * the stream defaults to paused; a click here satisfies it, so the game never has to ask for one. */
  audio?: AudioControlsProps["audio"];
}

export function SandboxWaitingRoom({
  roomCode,
  room,
  localPlayerId,
  error,
  busy,
  onSetNickname,
  onSetColor,
  onToggleReady,
  onStart,
  onLeave,
  onKick,
  audio,
}: SandboxWaitingRoomProps) {
  /* Design note #1294: the chrome scale, live. */
  const uiScale = useUiScale();
  const players = room?.players ?? [];
  const me = players.find((player) => player.id === localPlayerId) ?? null;
  /* Design note #1337: one colour per seat, chosen or assigned, the same on every client. */
  const resolvedColors = resolveSeatColors(players);
  const isHost = room?.hostId === localPlayerId;
  /* Design note #910: read off the ROOM, so a guest and the host are looking at one answer. */
  const variants = room?.variants ?? STANDARD_VARIANTS;
  /* #1415: the table's terms beyond the variants -- who may join, how many, and what a seat puts in. */
  const visibility = roomVisibility(room);
  const seatCap = roomSeatCap(room);
  const exactCount = typeof room?.playerCount === "number" ? room.playerCount : null;
  const ante = anteBreakdown(room?.anteUjuno);
  const canKick = isHost && room?.status === "waiting" && !busy && onKick !== undefined;
  /* #1415: this seat was removed -- the roster no longer holds it and the document says why. */
  const wasKicked = room !== null && me === null && (room.kicked ?? []).includes(localPlayerId);
  /* #1415: Ready is the deposit, so it asks first; un-Ready is the withdrawal and asks too. */
  const [readyConfirm, setReadyConfirm] = useState<"deposit" | "withdraw" | null>(null);
  const [kicking, setKicking] = useState<string | null>(null);
  /* ==================================================================
     DESIGN NOTE 1169a: AN INITIALISER IS NOT A SUBSCRIPTION
     ==================================================================
     `useState(me?.nickname ?? "")` reads its argument ONCE, on the mount -- and on the mount there is no `me`,
     because the seat arrives with the first snapshot one round trip later (#764's third state, again). So the
     field opened empty for a player who already had a name: rejoin a room, or reload into one, and the box
     said nothing while the roster below it said "B". Found next to #1169 rather than reported, and it is the
     same shape -- a control drawn from data that had not arrived yet.
     SEEDED ONCE, AND NEVER OVER TYPING. `touched` is what separates "has not been filled in yet" from "is
     deliberately empty because I am clearing it", which a `!nicknameText` test would run together. */
  const [skipIntro, setSkipIntro] = useState(() => skipIntroPreferred());
  /* Design note #1341: the seat-PIN card -- set mine, or rejoin another seat from this device. */
  const [seatPin, setSeatPin] = useState<{ mode: "set" | "rejoin"; seatId: string | null } | null>(null);
  const [nicknameText, setNicknameText] = useState(me?.nickname ?? "");
  const [nicknameTouched, setNicknameTouched] = useState(false);
  const knownNickname = me?.nickname ?? "";
  React.useEffect(() => {
    if (nicknameTouched || knownNickname === "") return;
    setNicknameText(knownNickname);
  }, [knownNickname, nicknameTouched]);

  /* #1415: "exactly N" means N -- the server refuses the (N+1)th seat, so "at least N" here IS exactly N. */
  const needed = seatsNeeded(room, MIN_PLAYERS);
  const enough = players.length >= needed;
  const allReady = players.length > 0 && players.every((player) => player.isReady);
  const canStart = isHost && enough && allReady;
  /* Design note #857: what the ROOM is short of, from the same reader `canStartSandboxGame` uses -- so the
     host's tooltip and the guest's line cannot describe the same room differently. */
  const block = waitingRoomBlock(room, MIN_PLAYERS);
  const notice = waitingRoomNotice(room, MIN_PLAYERS, {
    isHost,
    isReady: me?.isReady ?? false,
  });

  /* Design note #529: the numbers this room WOULD be dealt, shown live as people
     arrive. They are the whole consequence of the player count, and a lobby that
     hides them makes the count feel cosmetic. `null` off the printed table. */
  /* #1320: the Level Playing Field has its own tables and a seventh seat, so the figures read the room's
     variants -- the same object the toggles below edit, so they move the moment the host ticks the box. */
  const cash = startingCashForPlayers(players.length, variants);
  const certs = certLimitForPlayers(players.length, variants);
  const maxPlayers = seatCap;

  /* Design note #1144: the same 70% the shell and the lobby draw at. This screen is the one the report named
     first -- "did the Waiting Room panel become huge at some point?" -- and #1137 answered the half of that
     question that was about the ROOT. This is the other half: the panel really is drawn larger than the
     player has been reading it at, because they have been reading everything at 70%. */
  return (
    <div style={{ ...styles.root, ...chromeZoomFor(uiScale) }}>
      {/* Design note #1266: the photograph, on its own fixed layer. */}
      <div style={styles.sceneLayer} aria-hidden="true" />
      {/* ==================================================================
           DESIGN NOTE 1138: THE ANTEROOM GETS THE SHELL'S OWN TITLE BAR
          ==================================================================
          ASKED: "should the Waiting Room have the same title bar as the Game Room ... right now the audio
          controls are in the Waiting Room panel and then jump to the title bar, when they could probably just
          live there between the two rooms?"
          YES, AND IT IS `TopBar` ITSELF rather than a second header that looks like it. #1102 already made
          this argument one level down: the waiting room stopped hand-rolling an audio toggle and mounted the
          bar's own `AudioControls`, "one object, one component, both screens". The control stopped differing
          and only its POSITION kept moving -- which is the half that jumps.
          NOTHING IRRELEVANT COMES WITH IT. `TopBar` reads the wallet and the session from context and every
          one of those is conditional: no wallet is connected in an offline sandbox, so the address, the
          balance, the session-key dot and the error slots all render nothing. What is left is the brand, the
          room code, the audio pair and the offline dot -- which is the header this screen wanted.
          `roomName` CARRIES THE CODE, so the bar shows it the same way the game does. The panel keeps its own
          `codeBlock` below: that one is the code at the size people read it aloud from, which is a different
          job from the bar's running label. */}
      <TopBar roomName={roomCode} onLeaveGame={onLeave} audio={audio} />
      {/* Design note #1138: the bar runs to the window's edges, so the inset that used to live on the root
          moves here -- onto the thing that actually wants it. */}
      <div style={styles.panelWrap}>
      <div style={styles.panel}>
        <div style={styles.headerRow}>
          <span style={styles.title}>Sandbox waiting room</span>
        </div>

        {/* The code, at the size of the thing people have to read aloud. */}
        <div style={styles.codeBlock}>
          <span style={styles.codeLabel}>Room code</span>
          <code style={styles.code}>{roomCode}</code>
          {/* #1415: a private room is unlisted, and the sentence says so -- the code is the only door. */}
          <span style={styles.note}>
            {visibility === "private"
              ? "Private room — unlisted. Only someone with this code can join, and nobody can watch."
              : "Public room — listed under Join Game. Anyone with this code can join from the lobby too."}
          </span>
        </div>

        <form
          style={styles.nickRow}
          onSubmit={(event) => {
            event.preventDefault();
            onSetNickname(nicknameText);
          }}
        >
          <input
            style={styles.input}
            value={nicknameText}
            onChange={(event) => {
              setNicknameTouched(true);
              setNicknameText(event.target.value);
            }}
            placeholder="Your name"
            aria-label="Your nickname"
            maxLength={20}
          />
          <button type="submit" style={styles.button} disabled={busy}>
            Set name
          </button>
        </form>

        {/* Design note #569a: optional by construction -- a seat that never touches this
           gets the palette by index and is never colourless. Taken colours are DISABLED
           rather than hidden: a greyed swatch with the holder's name says why it cannot
           be chosen, where removing it would make the palette a different size for every
           player and look like a bug. */}
        <div style={styles.colorRow} role="group" aria-label="Your colour">
          <span style={styles.colorLabel}>Colour</span>
          {SEAT_COLORS.map((color) => {
            /* #1337: a seat's DEFAULT colour is held too -- the table sees colours, not intents. */
            const holder = players.find(
              (player) => resolvedColors[player.id] === color && player.id !== localPlayerId,
            );
            const mine = me?.color === color;
            return (
              <button
                key={color}
                type="button"
                aria-pressed={mine}
                aria-label={SEAT_COLOR_NAMES[color] ?? color}
                disabled={busy || !me || holder !== undefined}
                onClick={() => onSetColor(mine ? null : color)}
                title={
                  holder
                    ? `${holder.nickname || "Another player"} has taken ${SEAT_COLOR_NAMES[color] ?? "this"}.`
                    : mine
                      ? `${SEAT_COLOR_NAMES[color] ?? "This colour"} — click again to let the game assign one.`
                      : (SEAT_COLOR_NAMES[color] ?? color)
                }
                style={{
                  ...styles.swatch,
                  backgroundColor: color,
                  ...(mine ? styles.swatchMine : {}),
                  ...(holder ? styles.swatchTaken : {}),
                }}
              />
            );
          })}
        </div>

        <div style={styles.roster} role="list" aria-label="Players in this room">
          {players.length === 0 ? (
            <span style={styles.note}>Nobody here yet.</span>
          ) : (
            players.map((player) => (
              <span key={player.id} style={styles.rosterRow} role="listitem">
                <span style={styles.rosterName}>
                  {/* Design note #569: the seat's colour, where the seat is
                      named -- so a player can see the assignment before the
                      game starts rather than discovering it on the board. */}
                  <span
                    style={{
                      ...styles.rosterDot,
                      backgroundColor:
                        resolvedColors[player.id],
                    }}
                    aria-hidden="true"
                  />
                  {player.nickname || "unnamed"}
                  {player.id === room?.hostId && <span style={styles.hostTag}>HOST</span>}
                  {player.id === localPlayerId && <span style={styles.youTag}>YOU</span>}
                </span>
                <span style={styles.rosterRight}>
                  {/* Design note #1341: my seat sets its PIN; another seat can be rejoined from here.
                      #1341a: offered for a seat with NO PIN too -- it adopts the one typed. Gating this on
                      `hasPin` while the shell's button does not would put the migration behind whichever
                      screen the player happened to be looking at. */}
                  {player.id === localPlayerId ? (
                    <button
                      type="button"
                      style={styles.pinButton}
                      onClick={() => setSeatPin({ mode: "set", seatId: null })}
                      title="A four-digit PIN, for this room only, so you can pick this seat up on another device."
                    >
                      {player.hasPin ? "PIN set" : "Set PIN"}
                    </button>
                  ) : (
                    <button
                      type="button"
                      style={styles.pinButton}
                      onClick={() => setSeatPin({ mode: "rejoin", seatId: player.id })}
                      title={
                        player.hasPin
                          ? `Rejoin ${player.nickname || "this seat"} on this device with its PIN.`
                          : `${player.nickname || "This seat"} has no PIN yet -- rejoining it here sets one.`
                      }
                    >
                      Rejoin
                    </button>
                  )}
                  <span style={player.isReady ? styles.ready : styles.notReady}>
                    {player.isReady ? "Ready" : "Not ready"}
                  </span>
                  {/* #1415: the host removes a joiner -- never themselves, never after the start. Asked
                      twice, inline: a seat is a person, and a mis-click here is a person gone. */}
                  {canKick && player.id !== room?.hostId && (
                    kicking === player.id ? (
                      <span style={styles.kickConfirm}>
                        <button
                          type="button"
                          style={styles.kickButtonConfirm}
                          onClick={() => {
                            setKicking(null);
                            onKick?.(player.id);
                          }}
                          data-testid={`kick-confirm-${player.id}`}
                        >
                          Remove{player.isReady ? " (refunds ante)" : ""}
                        </button>
                        <button type="button" style={styles.pinButton} onClick={() => setKicking(null)}>
                          Keep
                        </button>
                      </span>
                    ) : (
                      <button
                        type="button"
                        style={styles.kickButton}
                        onClick={() => setKicking(player.id)}
                        aria-label={`Remove ${player.nickname || "this player"} from the table`}
                        title="Remove this player. They cannot rejoin this room."
                        data-testid={`kick-${player.id}`}
                      >
                        ✕
                      </button>
                    )
                  )}
                </span>
              </span>
            ))
          )}
        </div>

        {/* Design note #1341: said once, under the roster, so nobody takes the PIN for an account. */}
        <span style={styles.note}>
          Seat PINs are for this room only: set one to move your seat between devices mid-game.
        </span>

        {/* Design note #529: what this many players are dealt. */}
        <div style={styles.dealRow}>
          {cash !== null && certs !== null ? (
            <span style={styles.note}>
              {players.length} players — <strong style={styles.figure}>${cash}</strong> each,
              certificate limit <strong style={styles.figure}>{certs}</strong>.
            </span>
          ) : (
            <span style={styles.note}>
              {exactCount !== null
                ? `The host set this table for exactly ${exactCount} players. Waiting for more.`
                : `Project 18XX is dealt for ${MIN_PLAYERS}–${maxPlayers} players. Waiting for more.`}
            </span>
          )}
          {/* #1415: the seat count against the cap, always -- "3 of 5 seats". */}
          <span style={styles.note}>
            {players.length} of {maxPlayers} seats{exactCount !== null ? " (exactly)" : ""}.
          </span>
        </div>

        {/* ==================================================================
             DESIGN NOTE 910: THE HOUSE RULES, WHERE THE GAME IS ACTUALLY STARTED
            ==================================================================
            REPORTED: "there are no options visible in the Lobby to actually select them."
            THEY WERE VISIBLE, ON A SCREEN NOBODY USES. #902 built this same panel on `Lobby.tsx`'s
            create-room form -- the on-chain staging path -- while a sandbox table starts its game from HERE.
            SHOWN TO EVERY SEAT, EDITABLE BY THE HOST. A guest sees the same five rows, disabled: they are
            about to agree to this game by pressing Ready, and a table's terms that only the host can read are
            not terms. That is also why they live on the room document rather than in the host's component
            state -- see `sandboxRoom.ts` #910.
            LOCKED ONCE THE GAME STARTS. `status !== "waiting"` closes the controls, because the variants
            travel in the `SetupGame` action and changing them afterwards would describe a game that is not
            the one being played. */}
        {/* ==================================================================
             DESIGN NOTE 1415: THE PANEL IS A SUMMARY NOW -- see the prop note above
            ==================================================================
            #924's rule survives it: a seat reads the TERMS IN FORCE, not the menu. The rows that are always
            true of a table (type, pace, players, bank, ante) are always shown; a rule variant is a row only
            when it is on, and with none on the sentence says so rather than leaving a heading over nothing. */}
        <div style={styles.variantPanel}>
          <span style={styles.variantHeading}>House rules</span>
          <span style={styles.variantNote}>
            Set by the host before this room opened. You are agreeing to them when you press Ready.
          </span>

          <TermRow label="Game type" value={GAME_TYPE_COPY[gameTypeOf(variants)].label} />
          <TermRow label="Pace" value={GAME_MODE_COPY[variants.mode].label} note={GAME_MODE_COPY[variants.mode].blurb} />
          <TermRow label="Visibility" value={VISIBILITY_COPY[visibility].label} />
          <TermRow
            label="Players"
            value={exactCount !== null ? `Exactly ${exactCount}` : `Any — ${MIN_PLAYERS} to ${maxPlayers}`}
          />
          <TermRow
            label="Bank"
            value={bankSizeLabel(variants.length)}
            note={GAME_LENGTH_BLURB[variants.length]}
          />
          <TermRow
            label="Ante"
            value={formatJuno(ante.anteUjuno)}
            note={
              ante.anteUjuno === "0"
                ? ANTE_SUBSIDY_NOTE
                : `${formatJuno(ante.subsidyUjuno)} of each ante funds the developer treasury for fee grants; ${formatJuno(ante.netUjuno)} reaches the pool.`
            }
          />

          {/* The rule variants in force, from the shared copy (#961a) -- `VARIANT_COPY[key]` by way of the
              ordered table, so the rule reads here exactly as it did on the setup card. */}
          {VARIANT_TOGGLES.filter((toggle) => variants[toggle.key]).map((toggle) => (
            <div key={toggle.key} style={styles.variantToggle}>
              <span style={styles.termTick} aria-hidden="true">✓</span>
              <span style={styles.variantToggleText}>
                <span style={styles.variantToggleLabel}>{toggle.label}</span>
                <span style={styles.variantNote}>{toggle.blurb}</span>
              </span>
            </div>
          ))}

          {!VARIANT_TOGGLES.some((toggle) => variants[toggle.key]) && gameTypeOf(variants) === "standard" && (
            <span style={styles.variantNote}>
              {/* Design note #924/#977: silence would read as a loading state, and "the standard game"
                  rather than the number (`appNaming` #706). */}
              No variants are switched on — this table is playing the standard game, as printed.
            </span>
          )}
        </div>

        {/* Design note #1239 (`introPreference.ts`): THIS browser's choice, not a term of the game -- so it sits
            outside the variants panel, is never disabled for guests, and is not written to the room. */}
        <label style={styles.variantToggle}>
          <input
            type="checkbox"
            checked={skipIntro}
            onChange={(event) => {
              setSkipIntroPreferred(event.target.checked);
              setSkipIntro(event.target.checked);
            }}
          />
          <span style={styles.variantToggleText}>
            <span style={styles.variantToggleLabel}>Skip the opening titles</span>
            <span style={styles.variantNote}>
              On this browser only. Other players still see them unless they tick this too.
            </span>
          </span>
        </label>

        {/* ==================================================================
             DESIGN NOTE 1415: READY IS THE DEPOSIT
            ==================================================================
            RULED: "Players get a seat, then when they click 'Ready' they ante into the game. Then the Host
            starts the game." So the button asks first, with the figures: the ante, the treasury's share, and
            what reaches the pool -- the same three numbers the receipt will carry. Un-Ready is the withdrawal
            and asks the same way. The wallet is not wired yet (the ante is 0), but the CONFIRMATION is the
            shape of the thing, and a player learns it now on a table where it costs nothing. */}
        {readyConfirm && (
          <div style={styles.readyConfirm} role="dialog" aria-label={readyConfirm === "deposit" ? "Confirm your ante" : "Withdraw your ante"}>
            <span style={styles.variantToggleLabel}>
              {readyConfirm === "deposit" ? "Ready to play — ante into this game?" : "Not ready — withdraw your ante?"}
            </span>
            <span style={styles.note}>
              {readyConfirm === "deposit" ? (
                <>
                  Ante <strong style={styles.figure}>{formatJuno(ante.anteUjuno)}</strong> · developer
                  treasury <strong style={styles.figure}>{formatJuno(ante.subsidyUjuno)}</strong> · to the
                  pool <strong style={styles.figure}>{formatJuno(ante.netUjuno)}</strong>.
                  {ante.anteUjuno === "0" ? " Nothing moves on this table — the ante is off." : ""}
                </>
              ) : (
                <>
                  Your ante of <strong style={styles.figure}>{formatJuno(ante.anteUjuno)}</strong> is refunded
                  and your seat stays. Press Ready again to ante back in.
                </>
              )}
            </span>
            <span style={styles.kickConfirm}>
              <button
                type="button"
                style={styles.buttonPrimary}
                onClick={() => {
                  setReadyConfirm(null);
                  onToggleReady(readyConfirm === "deposit");
                }}
                disabled={busy}
                data-testid="ready-confirm"
              >
                {readyConfirm === "deposit" ? "Confirm and ante" : "Withdraw"}
              </button>
              <button type="button" style={styles.button} onClick={() => setReadyConfirm(null)}>
                Cancel
              </button>
            </span>
          </div>
        )}

        <div style={styles.actionRow}>
          <button
            type="button"
            style={me?.isReady ? styles.button : styles.buttonPrimary}
            onClick={() => setReadyConfirm(me?.isReady ? "withdraw" : "deposit")}
            disabled={busy || !me || readyConfirm !== null}
            title={
              me?.isReady
                ? "Withdraw your ante and mark yourself not ready."
                : `Ante ${formatJuno(ante.anteUjuno)} and mark yourself ready.`
            }
          >
            {me?.isReady ? "Not ready" : "Ready to play"}
          </button>
          {isHost && (
            <button
              type="button"
              style={{ ...styles.buttonStart, ...(canStart ? {} : styles.buttonDisabled) }}
              onClick={onStart}
              disabled={!canStart || busy}
              /* A disabled control with no explanation is the thing this
                 codebase's own prop conventions exist to prevent, so the
                 reason names whichever condition is actually blocking. */
              /* Design note #857: the SAME reader the guest's line uses. This tooltip was the only statement
                 of what was blocking, and it was hovered by the one person who could act on it. */
              title={
                block === "need-players"
                  ? exactCount !== null
                    ? `You set this table for exactly ${exactCount} players; ${players.length} ${players.length === 1 ? "is" : "are"} seated.`
                    : `Project 18XX needs at least ${MIN_PLAYERS} players.`
                  : block === "need-ready"
                    ? "Waiting for everyone to mark themselves ready."
                    : "Deal the game and begin."
              }
            >
              Start game
            </button>
          )}
        </div>

        {/* ==================================================================
             DESIGN NOTE 857: THE GUEST IS TOLD WHAT THE HOST WAS ONLY HOVERING
            ==================================================================
            ASKED: "when a non-host player clicks 'Ready,' there should be a notification like 'Waiting for
            Host to start the game...' so that players know they don't need to do anything else."
            BELOW THE ROW, because it is the ANSWER to the button just pressed -- the same placement rule
            #835 applied to the Track hint and #855 to the route detail: a line about a control goes under it.
            NOT AN ERROR, and drawn so: nothing has gone wrong, the player has finished their part. `error`
            below keeps its own louder treatment. */}
        {wasKicked ? (
          <span style={styles.error}>
            The host removed you from this table. You cannot rejoin this room; leave and join or host another.
          </span>
        ) : (
          notice && <span style={styles.notice}>{notice}</span>
        )}

        {error && <span style={styles.error}>{error}</span>}
      </div>

      {/* Design note #1113: the meta-UI credit, the same component and the same moving mark the lobby
          carries. The waiting room is the one screen between them and had no footer at all. */}
      </div>
      {/* Design note #1341: the seat-PIN card, owned here so the shell carries none of it. */}
      {seatPin && (
        <SeatPinModal
          mode={seatPin.mode}
          roomCode={roomCode}
          localPlayerId={localPlayerId}
          players={players}
          initialSeatId={seatPin.seatId}
          onClose={() => setSeatPin(null)}
        />
      )}
      <AppFooter surface="meta" />
    </div>
  );
}

export default SandboxWaitingRoom;

/* ==================================================================
    DESIGN NOTE 1258: THE HOLD IS DRAWN IN THE ROOM IT IS HOLDING FOR
   ==================================================================
   REPORTED: "screen flash on Host Game."
   THE FLASH WAS A THIRD SCREEN. Pressing Host unmounts the lobby -- the boardroom photograph -- and the
   shell's first render is #764's hold: a small card on the bare app ground, no photograph, no title bar,
   for exactly the one round trip it takes the room document to arrive. Then THIS screen mounts, with its
   own photograph and its own bar. Two full-bleed scenes with a dark card between them is a flash however
   short the middle frame is, and the host sees it on every single game.
   #764 WAS RIGHT THAT THERE MUST BE A HOLD -- the board is not a safe default -- and wrong only about what
   it looks like. The hold now renders in this component's own root, bar and panel, so the frame between
   the lobby and the waiting room IS the waiting room, with a sentence where the roster will be. One
   transition rather than two, and the photograph is already decoded when the roster lands.
   `roomCode` IS SHOWN IMMEDIATELY. It is known before the document is -- `hostSandboxRoom` returns it --
   and it is the one thing a host wants to start reading aloud. */
export function SandboxWaitingRoomHold({
  roomCode,
  onLeave,
  audio,
}: Pick<SandboxWaitingRoomProps, "roomCode" | "onLeave" | "audio">) {
  const uiScale = useUiScale();
  return (
    <div style={{ ...styles.root, ...chromeZoomFor(uiScale) }}>
      <div style={styles.sceneLayer} aria-hidden="true" />
      <TopBar roomName={roomCode} onLeaveGame={onLeave} audio={audio} />
      <div style={styles.panelWrap}>
        <div style={styles.panel}>
          <div style={styles.headerRow}>
            <span style={styles.title}>Sandbox waiting room</span>
          </div>
          <div style={styles.codeBlock}>
            <span style={styles.codeLabel}>Room code</span>
            <code style={styles.code}>{roomCode}</code>
            <span style={styles.note}>Fetching the room…</span>
          </div>
          <div style={styles.actionRow}>
            <button type="button" style={styles.button} onClick={onLeave}>
              Cancel
            </button>
          </div>
        </div>
      </div>
      <AppFooter surface="meta" />
    </div>
  );
}

/** #1415: one term of the table, read-only -- a label, its value, and the sentence that explains it. */
function TermRow({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div style={styles.variantToggleText}>
      <div style={styles.variantRow}>
        <span style={styles.variantLabel}>{label}</span>
        <span style={styles.termValue}>{value}</span>
      </div>
      {note && <span style={styles.variantNote}>{note}</span>}
    </div>
  );
}

/* Design note #1258: the same photograph the root paints, fetched while the player is still in the lobby
   so it is in the cache before the hold needs it. A `link rel=preload` would want the document head; an
   `Image` is the same request from here. Idempotent -- the browser dedupes a URL it already holds. */
export function preloadWaitingRoomScene(): void {
  if (typeof Image === "undefined") return;
  const img = new Image();
  img.src = `${process.env.PUBLIC_URL ?? ""}/images/waiting-room.jpg`;
}

const styles: Record<string, React.CSSProperties> = {
  /* ==================================================================
      DESIGN NOTE 1100: THE ONE SCREEN THAT NEVER PAINTED ITS OWN GROUND
     ==================================================================
     REPORTED: "the Lobby and Game screens are both full-page in the color scheme, but the Waiting Room has a
     bright white background that is jarring between the two darks."
     AND IT WAS NEVER DARK -- this is not something #1092 broke. This root declared layout and padding only,
     so the page behind the panel was whatever `body` happened to be, which is the user-agent default. The
     lobby and the shell each set `minHeight: 100vh` and a `backgroundColor` on their own roots and so never
     showed it; this screen sits between them and did.
     BOTH HALVES ARE FIXED, deliberately. This root now paints itself like its two neighbours, AND
     `index.html` paints `body` -- see the note there. Either alone would have closed the report; together
     they also close the NEXT screen that forgets, because a full-height root is a thing an author has to
     remember and a painted body is not. */
  /* ==================================================================
      DESIGN NOTE 1112: THE BOARDROOM BEHIND THE ANTEROOM
     ==================================================================
     THE OVERLAY IS MUCH LIGHTER THAN THE ONE SUGGESTED, and the reason is measurable rather than a matter of
     taste. The proposed treatment was `rgba(0,0,0,0.72)` to `0.85` -- sound advice for an ordinary bright
     photograph, and wrong for this one. This image is ALREADY dark: its median luminance is 0.008 and its
     95th percentile is 0.108, with only the three desk lamps above 0.5. Under a 0.72-0.85 wash the 95th
     percentile lands at 0.023, which is to say the room disappears and what remains is a black screen with
     three green dots. Rendered side by side, that reads as a rendering fault rather than as a backdrop.
     0.24 -> 0.38 is where it landed after looking at it: "it doesn't look like it needs much darkening",
     and it does not -- the wash is here to stop the lamps competing with the panel, not to hide the room.
     The gradient still runs darker downward, which is the suggestion's good half: it puts the heavier wash
     under the panel's lower body where the roster and the buttons are.
     `#080808` RATHER THAN PURE BLACK, so the wash is the theme's own ground and the letterbox edges of a
     `cover` fit match the page behind them.
     NO `align-items: center`, which the suggestion also proposed. This panel grows with the roster and the
     variant toggles; vertically centring it would push a six-player table off both ends of a short window,
     where top-anchored padding simply scrolls. */
  /* Design note #1113: a COLUMN now rather than a centred row, so the credit can sit at the foot of the
     screen. `alignItems: center` keeps the panel where it was -- horizontally centred, top-anchored, which
     is #1112's rule about not vertically centring a panel that grows with the roster -- and `AppFooter`'s
     own `marginTop: auto` does the rest: it drops to the bottom on a short room and follows the content on
     a full one. The only thing that changed for the panel is that it is now a flex ITEM in a column, which
     is why it keeps its own `width: 100%` and `maxWidth`. */
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    /* ==================================================================
        DESIGN NOTE 1137: THE PANEL DID NOT GROW -- THE ROOM AROUND IT DID
       ==================================================================
       ASKED: "did the Waiting Room panel become huge at some point? I remember it used to fit on my screen
       and now I have to scroll." THE PANEL IS UNCHANGED. Its `maxWidth`, its padding and its contents are
       what they were; three edits to the ROOT are what stopped it fitting, and they arrived one at a time in
       three different batches:
         the retheme      added `minHeight: 100vh`, so the root stopped being as tall as its content
         the same batch   mounted `AudioControls` inside the panel
         the cinematic    added `AppFooter` and DROPPED `justifyContent: center`
       Each was right on its own. Together they turned a centred panel on an auto-height page into a
       top-anchored panel plus a footer on a page with a floor -- and 40px of top padding that made sense
       when the panel was centred is dead weight once it is anchored to the top.
       24px, AND THE CENTRING STAYS OFF: #1112's rule is that a panel which grows with the roster must not be
       vertically centred, or it walks up the screen as players arrive. The padding is what gives back the
       room the footer took. */
    /* Design note #1138: no padding at all -- `TopBar` is full-bleed and brings its own, so any inset here
       would leave a stripe of photograph above a bar meant to sit on the window's edge. The panel's own
       breathing room moved to `panelWrap`. */
    padding: 0,
    minHeight: "100vh",
    backgroundColor: "#0f0f0f",
    /* ==================================================================
        DESIGN NOTE 1266: THE PHOTOGRAPH WAS SIZED TO THE PAGE, AND THE PAGE GREW
       ==================================================================
       REPORTED: "clicking Ready in the waiting room causes the screen to zoom in a bit?"
       IT DOES, AND IT IS THE PICTURE. The photograph was a `cover` background on THIS box, and this box is as
       tall as its content once the roster outgrows `100vh` (#1137 records that it does). Pressing Ready adds
       #857's notice line under the button, the panel grows by one line, the root grows with it, and `cover`
       re-fits the photograph to a taller box -- so every pixel of the room scales up by a few percent, at
       once, behind a panel that did not move. That is a zoom, however it was produced. The same thing happens
       on every reflow: a player joining, a name being set, an error line.
       THE PICTURE MOVES TO A FIXED LAYER sized to the window, where nothing the roster does can reach it.
       `sceneLayer` below; `backgroundColor` stays here as the fallback #1100 argued for. The root becomes a
       stacking context (`isolation`) so the layer's negative `z-index` sits above this fill and below the
       content -- and the footer's mark still keys against the photograph, because the root is the PAINTER's
       group, which #1170a allows. `blendIsolation.test.ts` pins the chain. */
    position: "relative",
    isolation: "isolate",
    color: "#f2f0eb",
    fontFamily: FONT_FAMILY,
    boxSizing: "border-box",
  },
  /* Design note #1266: the room, on a layer the size of the window. `fixed` inside the chrome zoom still
     measures the full window (#1144's measurement), and `cover` against a box that never changes size is a
     picture that never changes size. Inert to the pointer; it is scenery. */
  sceneLayer: {
    position: "fixed",
    inset: 0,
    zIndex: -1,
    pointerEvents: "none",
    backgroundImage:
      "linear-gradient(rgba(8, 8, 8, 0.24), rgba(8, 8, 8, 0.38)), " +
      `url("${process.env.PUBLIC_URL ?? ""}/images/waiting-room.jpg")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
  },
  /* Design note #1138: what the root's padding used to be, on the element that wants it. `alignItems` keeps
     the panel centred horizontally now that the root is no longer doing it for the bar as well. */
  panelWrap: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: "100%",
    padding: "24px 20px 0",
    boxSizing: "border-box",
  },
  panel: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    width: "100%",
    maxWidth: "520px",
    padding: "22px 24px",
    borderRadius: RADIUS.layer,
    border: "1px solid #2a2a2a",
    /* ==================================================================
        DESIGN NOTE 1112: NEARLY OPAQUE, AND NO BACKDROP BLUR
       ==================================================================
       THE SUGGESTION WAS `rgba(18,18,18,0.88)` WITH `backdrop-filter: blur(8px)`, and those two fight each
       other: at 88% opacity only an eighth of the backdrop reaches the blur, so the effect is close to
       invisible while still forcing the compositor to filter the area behind a panel on every frame. Pick
       one. This picks opacity, and the blur is dropped rather than kept as decoration.
       0.90 IS A MEASURED FLOOR, NOT A FEEL. A LAMP SITS DIRECTLY BEHIND THIS PANEL -- the brightest pixel in
       the region it covers is rgb(255, 254, 227) -- so the worst case is not the dark panelling, it is that
       glow. Under the 0.24-0.38 wash, that spot pushes the effective fill to `#201f1e`, and the ladder's
       FAINTEST text step lands at 4.75:1 there. Still past AA, which is what sets the number: at 0.88 it is
       4.54 and at 0.82 it is 4.10 and under the bar. Everywhere else on the panel the backdrop is near black
       and the fill is effectively `#0f0f0f` at 16.83:1.
       WHAT IT COSTS, stated because this whole re-theme has refused to spend contrast quietly: primary text
       goes 16.83 -> 14.45 and the faint step 5.53 -> 4.75, in the one region under the lamp. Accepted --
       the panel reads as glass over the room, which is the thing that was asked for, and nothing drops below
       the bar. Opaque again is a one-word change if it looks wrong in play.
       THE SHADOW IS WHAT ACTUALLY LIFTS IT off the image, and it costs nothing to verify. */
    backgroundColor: "rgba(15, 15, 15, 0.90)",
    boxShadow: "0 18px 48px rgba(0, 0, 0, 0.55)",
  },
  headerRow: { display: "flex", alignItems: "center", justifyContent: "space-between" },
  title: { fontSize: FONT_SIZE.heading, fontWeight: 800, color: "#f2f0eb" },
  codeBlock: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
    padding: "12px 14px",
    borderRadius: RADIUS.card,
    backgroundColor: "#141414",
    border: "1px solid #2a2a2a",
  },
  codeLabel: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    letterSpacing: "0.05em",
    textTransform: "uppercase",
    color: "#a8a6a0",
  },
  code: {
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
    fontSize: "28px",
    fontWeight: 800,
    letterSpacing: "0.12em",
    color: "#7ee0a1",
    userSelect: "all",
  },
  note: { fontSize: FONT_SIZE.small, color: "#8a8a86", lineHeight: LINE_HEIGHT.normal },
  figure: { color: "#f2f0eb", fontVariantNumeric: "tabular-nums" },
  nickRow: { display: "flex", flexDirection: "row", gap: "8px" },
  colorRow: { display: "flex", flexDirection: "row", alignItems: "center", gap: "6px" },
  colorLabel: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    letterSpacing: "0.05em",
    textTransform: "uppercase",
    color: "#a8a6a0",
    marginRight: "2px",
  },
  swatch: {
    width: "26px",
    height: "26px",
    borderRadius: RADIUS.circle,
    border: "2px solid transparent",
    cursor: "pointer",
    padding: 0,
  },
  swatchMine: { borderColor: "#f2f0eb", boxShadow: "0 0 0 2px rgba(226,230,238,0.25)" },
  swatchTaken: { opacity: 0.28, cursor: "not-allowed" },
  rosterDot: { width: "10px", height: "10px", borderRadius: RADIUS.circle, flex: "none" },
  input: {
    flex: 1,
    fontSize: FONT_SIZE.control,
    padding: "7px 10px",
    borderRadius: RADIUS.control,
    border: "1px solid #3a3a3a",
    backgroundColor: "#141414",
    color: "#f2f0eb",
  },
  roster: { display: "flex", flexDirection: "column", gap: "4px" },
  rosterRow: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "6px 10px",
    borderRadius: RADIUS.control,
    backgroundColor: "#1c1c1c",
    fontSize: FONT_SIZE.small,
    color: "#c8c6c0",
  },
  rosterName: { display: "inline-flex", alignItems: "center", gap: "7px", fontWeight: 700 },
  hostTag: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 800,
    letterSpacing: "0.06em",
    // Design note #1122: the sandbox heading tone, shared rather than re-picked.
    color: SANDBOX_TITLE,
  },
  youTag: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 800,
    letterSpacing: "0.06em",
    color: "#9ec5ff",
  },
  rosterRight: { display: "inline-flex", alignItems: "center", gap: "10px" },
  /* Design note #1341: a quiet control on the roster row -- the row's own ink, a hairline border. */
  pinButton: {
    padding: "2px 8px",
    borderRadius: RADIUS.control,
    border: "1px solid #3a3a3a",
    backgroundColor: "transparent",
    color: "#c8c6c0",
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    cursor: "pointer",
  },
  ready: { color: "#7ee0a1", fontWeight: 700 },
  notReady: { color: "#8a8a86" },
  dealRow: { paddingTop: "2px" },
  actionRow: { display: "flex", flexDirection: "row", gap: "8px", flexWrap: "wrap" },
  button: {
    fontSize: FONT_SIZE.control,
    fontWeight: 700,
    padding: "8px 16px",
    borderRadius: RADIUS.card,
    border: "1px solid #3a3a3a",
    backgroundColor: "#1c1c1c",
    color: "#c8c6c0",
    cursor: "pointer",
  },
  buttonPrimary: {
    fontSize: FONT_SIZE.control,
    fontWeight: 800,
    padding: "8px 16px",
    borderRadius: RADIUS.card,
    border: "1px solid #2f6f6a",
    backgroundColor: "#14312f",
    color: "#7fe0d0",
    cursor: "pointer",
  },
  buttonStart: {
    fontSize: FONT_SIZE.control,
    fontWeight: 800,
    padding: "8px 18px",
    borderRadius: RADIUS.card,
    border: "1px solid #38bdf8",
    backgroundColor: "#1d3a55",
    color: "#9ec5ff",
    cursor: "pointer",
    marginLeft: "auto",
  },
  buttonDisabled: { opacity: 0.4, cursor: "not-allowed" },
  /* Design note #910: a panel rather than loose rows, because these five belong together as one agreement. */
  variantPanel: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    padding: "12px 14px",
    borderRadius: RADIUS.card,
    border: "1px solid #2a2a2a",
    backgroundColor: "#0f0f0f",
    marginTop: "10px",
  },
  variantHeading: {
    fontSize: FONT_SIZE.micro,
    fontWeight: 800,
    letterSpacing: "0.08em",
    color: "#8a8a86",
    textTransform: "uppercase",
  },
  variantRow: { display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "10px", flexWrap: "wrap" },
  variantLabel: { fontSize: FONT_SIZE.small, fontWeight: 700, color: "#f2f0eb" },
  /* #1415: a term's value, read rather than chosen -- the control's ink without the control. */
  termValue: { fontSize: FONT_SIZE.small, fontWeight: 700, color: "#c8c6c0", fontVariantNumeric: "tabular-nums", textAlign: "right" },
  termTick: { color: "#7ee0a1", fontWeight: 800, fontSize: FONT_SIZE.small, lineHeight: LINE_HEIGHT.normal },
  /* #1415: the ante confirmation, drawn as a card above the buttons it answers for. */
  readyConfirm: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    padding: "12px 14px",
    borderRadius: RADIUS.card,
    border: "1px solid #2f6f6a",
    backgroundColor: "#0f1a19",
    marginTop: "10px",
  },
  kickConfirm: { display: "inline-flex", alignItems: "center", gap: "6px" },
  kickButton: {
    padding: "2px 7px",
    borderRadius: RADIUS.control,
    border: "1px solid #3a3a3a",
    backgroundColor: "transparent",
    color: "#8a8a86",
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    cursor: "pointer",
    lineHeight: 1,
  },
  kickButtonConfirm: {
    padding: "2px 8px",
    borderRadius: RADIUS.control,
    border: "1px solid #7a3f3f",
    backgroundColor: "#401d1d",
    color: "#f5e6e6",
    fontSize: FONT_SIZE.micro,
    fontWeight: 700,
    cursor: "pointer",
  },
  variantToggle: { display: "flex", flexDirection: "row", gap: "9px", alignItems: "flex-start" },
  variantToggleText: { display: "flex", flexDirection: "column", gap: "1px", minWidth: 0 },
  variantToggleLabel: { fontSize: FONT_SIZE.small, fontWeight: 700, color: "#f2f0eb" },
  /* ==================================================================
      DESIGN NOTE 924: THE RULES ARE THE CONTENT, NOT A CAPTION
     ==================================================================
     REPORTED: "the variant rules text in the Lobby is too small and too gray against the dark background."
     AND THE TREATMENT WAS BORROWED FROM THE WRONG PLACE. `AutoPassModal`'s captions are `micro` in `#8a90a0`
     because they explain a control whose LABEL already carries the decision. Here the description IS the
     decision -- a player agreeing to Gentle Rust has to read the sentence, because the two words above it do
     not say what the rule does.
     `small` ON `#c8cdd8`, which is this app's body treatment for text meant to be read rather than glanced
     at: the same pairing the fleet-loss modal and the Auto-Pass body use. */
  variantNote: {
    fontSize: FONT_SIZE.small,
    color: "#c8c6c0",
    lineHeight: LINE_HEIGHT.normal,
  },
  /* Design note #857: calm, not alarmed. #707's distinction between a refusal and a status -- this reports
     that the player has finished and the room has not, which is neither an error nor an instruction. */
  notice: {
    fontSize: FONT_SIZE.small,
    lineHeight: LINE_HEIGHT.normal,
    color: "#9ec5ff",
  },
  error: { fontSize: FONT_SIZE.small, color: "#e07a7a" },
};
